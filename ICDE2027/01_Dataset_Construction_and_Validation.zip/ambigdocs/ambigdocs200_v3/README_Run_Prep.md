# AmbigDocs V3: next-dataset run preparation

This package contains the source-reviewed V3 benchmark, the preparation script, and prebuilt task input manifests. No LLM calls were made.

## Work per model

- Dimension Identification: 200 calls
- Gold-condition Answering: 479 calls
- End-to-End: 200 calls
- Total: 879 calls per model

`run_inputs_prepared/` contains model-only inputs and a rough token preflight. `gold_for_scoring_only.jsonl` includes answers; keep it out of prompts and use only for evaluation. AmbigDocs uses the label `Entity Disambiguation`; the generic legacy prompt/scorer must be updated to honor that label and each pair's `acceptable_answers`.

Estimated input is about 655k tokens per model using a 3-characters-per-token proxy. This is a rough sizing estimate, not provider usage or a cost quote. The script can rebuild manifests without an API key:

```python
!python prepare_ambigdocs_eval_v3.py \
  --standard example_output/ambigdocs_eval_standard.jsonl \
  --outdir run_inputs_prepared
```

The package notes that the V3 source-based review was not an independent human validation; this remains part of the benchmark provenance.

#!/usr/bin/env python3
"""统一题库格式；不调用 API、不重新生成标注、不从 gold 构造模型输入表。

用法（Python 3.9+，仅标准库）：
  python standardize_benchmark.py --input online_retail_eval_standard.jsonl --output retail_standard.jsonl
  python standardize_benchmark.py --input sec_eval_standard.jsonl --output sec_standard.jsonl --require-table
  python standardize_benchmark.py --input samples_target_generated.json --output early_standard.jsonl

缺少表格时仍可整理 gold，evaluation_ready=false。不能直接跑旧版评测。
提供独立上下文（按题目 id 映射的 JSON 文件）：
  {"题目id": {"table": "Markdown表格或证据文本", "source": "来源说明"}}
  python standardize_benchmark.py --input INPUT --output OUTPUT --contexts contexts.json --require-table

旧版 run_eval.py 读取本脚本的 OUTPUT（包含评分 gold）。其 prompts.py 仅取
query/table；不要把整个 OUTPUT 直接发送给模型。
--model-inputs 可另存只有 id/query/table 的文件；该文件不适用于旧版评分入口。
--dimension 仅用于早期 instances 格式缺少维度时，必须人工确认。
--term 可明确指定歧义词，默认使用问题全文（只是标注占位，不推断词片段）。

本脚本不证明答案正确性，不自动加载 Excel 或执行交易聚合。
检测到 condition/answer 对照表会报错，避免重复已有评测中的答案可见问题。
启发式检查不能识别所有答案泄漏，独立上下文仍需人工检查。
"""
import argparse
import copy
import json
import re
from pathlib import Path


def read_records(path):
    path = Path(path)
    if path.suffix.lower() == '.jsonl':
        rows = [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    else:
        rows = json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(rows, list) or not rows or not all(isinstance(r, dict) for r in rows):
        raise ValueError('输入必须是非空 JSON 数组或每行一个对象的 JSONL。')
    return rows


def present(value):
    return value is not None and (not isinstance(value, str) or bool(value.strip()))


def table_text(table):
    if isinstance(table, dict):
        return str(table.get('content', ''))
    return str(table or '')


def validate_table(table):
    text = table_text(table)
    for line in text.splitlines():
        cells = [re.sub(r'[^a-z_]', '', x.lower()) for x in line.strip().strip('|').split('|')]
        if any(x in cells for x in ('condition', 'conditions', 'interpretation')) and any(x in cells for x in ('answer', 'gold_answer', 'gold_answers')):
            raise ValueError('table 是 condition—answer 对照表；请用 --contexts 提供独立数据/证据。')
    return bool(text.strip())


def make_gold(row, dimension=None, term=None):
    query = row.get('query') or row.get('question') or row.get('ambiguous_query')
    if not isinstance(query, str) or not query.strip():
        raise ValueError('缺少 query/question/ambiguous_query。')
    if isinstance(row.get('gold'), dict):
        gold = copy.deepcopy(row['gold'])
    elif isinstance(row.get('gold_answers'), list):
        dim = row.get('dimension') or dimension
        if not dim:
            raise ValueError('缺少 dimension。')
        pairs = []
        for item in row['gold_answers']:
            if not present(item.get('condition')) or not present(item.get('answer')):
                raise ValueError('gold_answers 中 condition/answer 为空。')
            pairs.append({'conditions': {dim: item['condition']}, 'answer': item['answer']})
        conditions = [p['conditions'][dim] for p in pairs]
        if 'gold_conditions' in row and row['gold_conditions'] != conditions:
            raise ValueError('gold_conditions 与 gold_answers 条件顺序或内容不一致。')
        if 'answer_by_condition' in row and row['answer_by_condition'] != {p['conditions'][dim]: p['answer'] for p in pairs}:
            raise ValueError('answer_by_condition 与 gold_answers 不一致。')
        if 'gold_condition_count' in row and row['gold_condition_count'] != len(pairs):
            raise ValueError('gold_condition_count 与配对数不一致。')
        gold = {'ambiguous_conditions': [{'term': term or query, 'dimension': dim, 'conditions': conditions}], 'condition_answer_pairs': pairs}
    elif isinstance(row.get('instances'), list):
        dims = row.get('state_dimensions') or ([dimension] if dimension else [])
        if len(dims) != 1:
            raise ValueError('早期 instances 格式必须有且只有一个已确认维度；多维条件需显式编写 gold。')
        dim = dims[0]
        pairs = []
        for item in row['instances']:
            if not present(item.get('condition')) or not present(item.get('answer')):
                raise ValueError('instances 缺少短 condition/answer；不自动压缩 state_description。')
            pairs.append({'conditions': {dim: item['condition']}, 'answer': item['answer']})
        gold = {'ambiguous_conditions': [{'term': term or query, 'dimension': dim, 'conditions': [p['conditions'][dim] for p in pairs]}], 'condition_answer_pairs': pairs}
    else:
        raise ValueError('未知格式：需要 gold、gold_answers 或 instances。')
    validate_gold(gold)
    return query, gold


def validate_gold(gold):
    annotations = gold.get('ambiguous_conditions')
    pairs = gold.get('condition_answer_pairs')
    if not isinstance(annotations, list) or not annotations or not isinstance(pairs, list) or len(pairs) < 2:
        raise ValueError('歧义题必须有维度标注及至少两组 condition-answer 配对。')
    expected = {}
    for item in annotations:
        dim, conds = item.get('dimension'), item.get('conditions')
        if not present(item.get('term')) or not present(dim) or not isinstance(conds, list) or len(conds) < 2:
            raise ValueError('维度标注需要 term、dimension 和至少两个 conditions。')
        if dim in expected or not all(isinstance(c, str) and c.strip() for c in conds) or len(set(conds)) != len(conds):
            raise ValueError('维度重复或条件为空/重复。')
        expected[dim] = set(conds)
    seen, covered = set(), {d: set() for d in expected}
    for pair in pairs:
        conds = pair.get('conditions')
        if not isinstance(conds, dict) or not conds or not present(pair.get('answer')):
            raise ValueError('配对缺少 conditions 或 answer。')
        for dim, cond in conds.items():
            if dim not in expected or not isinstance(cond, str) or cond not in expected[dim]:
                raise ValueError('配对条件与维度标注不一致。')
            covered[dim].add(cond)
        key = json.dumps(conds, ensure_ascii=False, sort_keys=True)
        if key in seen:
            raise ValueError('重复的条件配对。')
        seen.add(key)
    if covered != expected:
        raise ValueError('存在没有对应答案的条件。')


def convert(rows, contexts=None, dimension=None, term=None, require_table=False):
    result, ids = [], set()
    for index, row in enumerate(rows, 1):
        qid = row.get('id') or row.get('query_id')
        if not isinstance(qid, str) or not qid.strip() or qid in ids:
            raise ValueError(f'第{index}条：题目编号缺失、不是字符串或重复。')
        ids.add(qid)
        try:
            query, gold = make_gold(row, dimension, term)
            context = (contexts or {}).get(qid)
            table = row.get('table', '')
            source = None
            if context is not None:
                if not isinstance(context, dict) or 'table' not in context:
                    raise ValueError('contexts 条目必须是含 table 的对象。')
                table, source = context['table'], context.get('source')
            ready = validate_table(table)
            if require_table and not ready:
                raise ValueError('缺少独立 table/context，不能进入模型评测。')
            output = {'id': qid, 'query': query, 'table': table, 'gold': gold,
                      'evaluation_ready': ready,
                      'metadata': {'dataset': row.get('dataset') or row.get('domain'),
                                   'original_record': copy.deepcopy(row)}}
            if source is not None:
                output['metadata']['context_source'] = source
            result.append(output)
        except (ValueError, TypeError, KeyError) as exc:
            raise ValueError(f'{qid}: {exc}') from exc
    return result


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in rows), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--contexts', help='独立上下文 JSON：按题目 id 映射')
    parser.add_argument('--dimension')
    parser.add_argument('--term')
    parser.add_argument('--require-table', action='store_true')
    parser.add_argument('--model-inputs', help='另外输出不含 gold 的模型输入 JSONL；要求每题都有 table')
    args = parser.parse_args()
    paths = [Path(p).resolve() for p in [args.input, args.output, args.contexts, args.model_inputs] if p]
    if len(set(paths)) != len(paths):
        parser.error('输入、输出、上下文及模型输入路径必须不同，避免覆盖。')
    try:
        contexts = json.loads(Path(args.contexts).read_text(encoding='utf-8-sig')) if args.contexts else None
        if contexts is not None and not isinstance(contexts, dict):
            raise ValueError('contexts 必须是按 id 映射的 JSON 对象。')
        rows = convert(read_records(args.input), contexts, args.dimension, args.term, args.require_table or bool(args.model_inputs))
        write_jsonl(args.output, rows)
        if args.model_inputs:
            write_jsonl(args.model_inputs, [{k: r[k] for k in ('id', 'query', 'table')} for r in rows])
        ready = sum(r['evaluation_ready'] for r in rows)
        print(f'完成：{len(rows)}题，{sum(len(r["gold"]["condition_answer_pairs"]) for r in rows)}组配对；有上下文 {ready}题。')
        if ready != len(rows):
            print('格式已整理，但缺少独立上下文的题目还不能跑评测。请提供 --contexts，再用 --require-table 检查。')
        print('模型输入只能取 query/table，不得发送完整 gold 或 metadata。')
    except (ValueError, OSError, TypeError) as exc:
        parser.exit(1, f'错误：{exc}\n')


if __name__ == '__main__':
    main()

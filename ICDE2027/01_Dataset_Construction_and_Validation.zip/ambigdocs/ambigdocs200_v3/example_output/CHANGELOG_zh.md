# 旧200题到v3的修改记录

格式没有重做；改变的是问题/条件/答案的内容对应关系。

旧200题：保留 130，修订 28，整题剔除 42；新增同数替补，最终仍为200题。

## 剔除的题目

| 旧题号 | ID | 原因 |
|---|---|---|
| 3 | ambigdocs_61801 | 一个文档包含多个 Glob 角色及不同创作者，实体条件内部仍有歧义。 |
| 10 | ambigdocs_28916 | WVLA 片段说的是出售计划和运营协议，不能推出 Nexstar 是所有者。 |
| 15 | ambigdocs_64640 | 第三个片段中的 Michael Jackson 是被演绎作品的来源，不能证实该专辑表演者。 |
| 23 | ambigdocs_14366 | 两段证据主要是巡演和翻唱歌曲，不能直接证明专辑归属；暂不保留弱证据题。 |
| 32 | ambigdocs_32784 | 两个答案都指向 Micro Focus，产品与公司条件没有形成两个实质不同答案。 |
| 36 | ambigdocs_41090 | 12th Army 文档明确说成立两次，单一条件对应一个日期不足。 |
| 39 | ambigdocs_5235 | C3 的日期明确是晋升 major general，问题问 brigadier general。 |
| 41 | ambigdocs_52195 | 问题问年份，C1 只给年龄；C2 还是 senior panel 而非同一 debut 事件。 |
| 47 | ambigdocs_22882 | Romford 改名 West Ham 后的地点与原 gold 阶段不同；Hammers 与 Bombers 名称也不同。 |
| 49 | ambigdocs_29934 | 政治家条件的 2nd Amendment 不是运动项目。 |
| 56 | ambigdocs_3344 | C2 的 1865–1896 是法官任期，不是 Attorney General 任期。 |
| 59 | ambigdocs_17155 | C1 是 Civic 站；C4 日期是临时 Forth 站启用，不能当作同名目标站启用。 |
| 61 | ambigdocs_51047 | 答案是两家母出版公司的成立年，不是 Christy Ottaviano Books 成立年。 |
| 62 | ambigdocs_7355 | Larnaca 的 1972 是更名年，不是建校年；候选还混入修道院学校。 |
| 72 | ambigdocs_37004 | 条件混入演唱会巡演，问题却指定 album。 |
| 78 | ambigdocs_18258 | small group of lawyers 是剧情对象，不是故事发生地点。 |
| 82 | ambigdocs_41167 | Umar ibn Khattab 与 Umar ibn al-Khattab 是同一个人，未形成不同答案。 |
| 94 | ambigdocs_27478 | gold 混合计划开始年和整段运营期，当前片段不适合一致的历史事件问题。 |
| 96 | ambigdocs_47050 | C3 提供的是迁往纽约的历史位置，不支持未限定时间的当前地点问题。 |
| 110 | ambigdocs_15912 | 当前片段没有直接提供问题中的 Xiaocheng zhi chun 音译别名；暂不依赖外部知识。 |
| 111 | ambigdocs_570 | C3 只给局部作战事件的 23 August，不足以证实完整攻势开始日期。 |
| 114 | ambigdocs_62298 | 条件混入 barn，而问题指定 house。 |
| 119 | ambigdocs_51546 | gold 混合死亡年代、传说存活年代与思想史年代，证据和目标关系不一致。 |
| 121 | ambigdocs_12911 | Adams/Nixon 对应司法职务任命或提名，不是 Attorney General 的任命。 |
| 122 | ambigdocs_17302 | C1 是提名日，C2 是任命年；不混用 nomination 和 appointment。 |
| 123 | ambigdocs_51061 | main character 需要主次判断；当前任务采用更明确的事实关系题。 |
| 131 | ambigdocs_50297 | 第三个标题是 Antichrist Superstar；截取文本只有演出争议，不能证明目标专辑归属。 |
| 133 | ambigdocs_2197 | 1992 是开发系列的时间，不是游戏发行时间；还混入游戏系列条件。 |
| 139 | ambigdocs_11695 | 多个期刊都有 Journal of Science 字样，但未证明都以这个完整简称被指代。 |
| 143 | ambigdocs_62609 | Høilandet 和 Høiland 是不同名称；当前片段不支持把二者当同名实体。 |
| 148 | ambigdocs_24282 | Tia 和 Tiaa 名称不同，第二个答案也只给父亲而不是双亲。 |
| 151 | ambigdocs_46399 | 条件跨越专辑与 rogue opera/首幕录音，creator 角色不够统一。 |
| 162 | ambigdocs_52184 | gold 混合演员与角色，还带角色加演员括号，未回答同一个事实关系。 |
| 166 | ambigdocs_17111 | Froggen 的片段没有直接证实 Henrik Hansen 本名；不依赖外部知识补身份关系。 |
| 168 | ambigdocs_30358 | gold 混合组织和城市；候选也混合冠军头衔和推广组织。 |
| 174 | ambigdocs_28004 | 候选混合剧院建筑、剧团和广播节目；built/opened/founded 不能混当 established。 |
| 175 | ambigdocs_58637 | 出生地住宅并未在片段中被称为 Pearl S. Buck House。 |
| 184 | ambigdocs_27501 | C1 的 1972 是首次完整任期选举相关片段，不支持政治生涯开始年。 |
| 187 | ambigdocs_2060 | C2 明确还有 1694 任期，gold 漏掉一次任期。 |
| 193 | ambigdocs_54702 | C2 的 Elizabeth Alington 是该人物的母亲，不是配偶；C1 也有两次婚姻。 |
| 198 | ambigdocs_44014 | 问题用 the Sailors，条件却混入个人姓氏和球队，指代类型不一致。 |
| 199 | ambigdocs_55790 | 第四个条件是 Hillside Memorial Park，片段不证明它叫 Hillside Cemetery。 |

## 修订的题目

下面列明 query/答案/别名覆盖。答案编号1、2等对应原始文档顺序，不是正式 condition 标签。

### 旧第2题：ambigdocs_13940

```json
{
  "query": "In what period were the buildings in the Greenville Commercial Historic District constructed?"
}
```

### 旧第19题：ambigdocs_51355

```json
{
  "query": "In what year was Governor Bailey first elected governor?"
}
```

### 旧第35题：ambigdocs_51603

```json
{
  "query": "Who is the artist associated with the release \"Cunning Stunts\"?"
}
```

### 旧第37题：ambigdocs_37527

```json
{
  "answers": {
    "2": "1938"
  }
}
```

### 旧第48题：ambigdocs_24260

```json
{
  "query": "Who led the attacking forces during the Siege of Hulst?"
}
```

### 旧第50题：ambigdocs_48437

```json
{
  "query": "In what year was the album \"Aretha\" released?"
}
```

### 旧第53题：ambigdocs_41606

```json
{
  "answers": {
    "1": "1896 and 1900",
    "2": "1914"
  }
}
```

### 旧第73题：ambigdocs_37721

```json
{
  "query": "In what year was Bruce Thornton drafted into the NFL?",
  "answers": {
    "1": "2004",
    "2": "1979"
  }
}
```

### 旧第81题：ambigdocs_28029

```json
{
  "answers": {
    "2": "Lawrence Hyde I"
  }
}
```

### 旧第85题：ambigdocs_19885

```json
{
  "query": "Who is the artist of the album \"Distant Light\"?"
}
```

### 旧第86题：ambigdocs_66173

```json
{
  "answers": {
    "3": "July 14, 1922"
  }
}
```

### 旧第95题：ambigdocs_35352

```json
{
  "answers": {
    "1": "Newton, Massachusetts",
    "2": "Winchester, Massachusetts",
    "3": "Reading, Massachusetts"
  }
}
```

### 旧第99题：ambigdocs_34684

```json
{
  "query": "Who is the artist associated with \"Jump for Joy\"?"
}
```

### 旧第101题：ambigdocs_44226

```json
{
  "answers": {
    "1": "Varanasi",
    "2": "Kottayam",
    "3": "Motihari"
  },
  "aliases": {
    "1": [
      "Benaras"
    ]
  }
}
```

### 旧第102题：ambigdocs_2422

```json
{
  "answers": {
    "1": "1759",
    "2": "1776"
  }
}
```

### 旧第104题：ambigdocs_35275

```json
{
  "answers": {
    "1": "April 1685",
    "2": "1759"
  }
}
```

### 旧第126题：ambigdocs_13735

```json
{
  "answers": {
    "1": "1802"
  }
}
```

### 旧第130题：ambigdocs_61419

```json
{
  "answers": {
    "3": "c. 1878"
  }
}
```

### 旧第134题：ambigdocs_62273

```json
{
  "query": "When was Noarlunga established?"
}
```

### 旧第136题：ambigdocs_55574

```json
{
  "query": "Who is the artist of the album \"I Am the Greatest\"?",
  "answers": {
    "1": "A House",
    "2": "Cassius Clay"
  },
  "aliases": {
    "2": [
      "Muhammad Ali"
    ]
  }
}
```

### 旧第138题：ambigdocs_44120

```json
{
  "answers": {
    "2": "23 March 1990"
  }
}
```

### 旧第141题：ambigdocs_27512

```json
{
  "query": "In what year were the Vostok exercises held?"
}
```

### 旧第164题：ambigdocs_38358

```json
{
  "answers": {
    "2": "Oregon"
  }
}
```

### 旧第178题：ambigdocs_11802

```json
{
  "answers": {
    "1": "London, Ontario, Canada"
  }
}
```

### 旧第181题：ambigdocs_29783

```json
{
  "query": "According to the supplied documents, who is the head coach of the Texas A&M–Commerce Lions basketball team?"
}
```

### 旧第182题：ambigdocs_57617

```json
{
  "answers": {
    "1": "Autolux",
    "2": "Loadstar"
  }
}
```

### 旧第188题：ambigdocs_32192

```json
{
  "query": "Who is the artist of the \"Live in Detroit\" release?"
}
```

### 旧第189题：ambigdocs_56940

```json
{
  "query": "When was the vessel Greif commissioned?"
}
```

## 替补题

| ID | query |
|---|---|
| ambigdocs_1700 | Who is the artist of the album "Feel Good"? |
| ambigdocs_43133 | Who is the artist of the album "Civilian"? |
| ambigdocs_33554 | Who is the director of the film "My Father the Hero"? |
| ambigdocs_17854 | Who is the artist of the album "A Matter of Time"? |
| ambigdocs_51860 | Who is the director of the film "Angel Face"? |
| ambigdocs_27272 | Who is the artist of the album "No Love Lost"? |
| ambigdocs_43029 | Who is the artist of the album "Real Talk"? |
| ambigdocs_13766 | Who is the artist of the album "Swimming"? |
| ambigdocs_38167 | Who is the director of the film "Bedazzled"? |
| ambigdocs_44657 | Who is the artist of the album "By Request"? |
| ambigdocs_7728 | Who is the artist of the "Live in America" album? |
| ambigdocs_52888 | Who is the artist of the album "My Foolish Heart"? |
| ambigdocs_13578 | Who is the artist of the album "Easy Does It"? |
| ambigdocs_28516 | Who is the artist of the album "Up and Down"? |
| ambigdocs_53540 | Who is the artist of the album "Greatest Hits: From the Beginning"? |
| ambigdocs_3732 | Who is the artist of the album "Horse of a Different Color"? |
| ambigdocs_59166 | Who is the artist of "The Illusion of Safety"? |
| ambigdocs_29587 | Who directed the film "Adoration"? |
| ambigdocs_50956 | Who is the artist of the album "Just as I Am"? |
| ambigdocs_56977 | Who is the artist of the album "Round 2"? |
| ambigdocs_43247 | Who is the artist of the album "Christmas in My Heart"? |
| ambigdocs_54820 | Who is the artist of the album "Beatin' the Odds"? |
| ambigdocs_51344 | When was Deyo born? |
| ambigdocs_57863 | When was Edmund King born? |
| ambigdocs_46924 | When was William O'Neil born? |
| ambigdocs_16746 | When was Frank Sharp born? |
| ambigdocs_8403 | When was Stuart Elliott born? |
| ambigdocs_41190 | When was Phil Parkes born? |
| ambigdocs_559 | When was Philip Whitcombe born? |
| ambigdocs_21789 | When was Carpentier born? |
| ambigdocs_47514 | When was Admiral Bruce born? |
| ambigdocs_59326 | When was Dennis Isherwood born? |
| ambigdocs_32817 | When was Judge Kennamer born? |
| ambigdocs_7389 | When was Chris Robertson born? |
| ambigdocs_30366 | When was Other Windsor born? |
| ambigdocs_63652 | When was General Petrov born? |
| ambigdocs_21987 | When was Julia Dean born? |
| ambigdocs_2826 | When was Gordon Wallace born? |
| ambigdocs_12977 | When was Qilong born? |
| ambigdocs_17831 | When was Stephanie Edwards born? |
| ambigdocs_30744 | When was Cui Wei born? |
| ambigdocs_29972 | When was General Kozlov born? |

## 审核限制

这是单次助手文本审核，不是独立人工标注或外部事实核验。保留题仍需人核验；不要把本次自动检查或助手审核写作200题全部人工通过。别名只包含明确同义名称或同一日期的显示格式；不会把错误旧答案保留为可接受答案。未修改评分算法，评分器仍需实际支持 acceptable_answers 字段。
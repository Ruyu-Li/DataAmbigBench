# AmbigDocs v3：200题审核清单

字段与正式 JSONL 对应：query、gold.ambiguous_conditions 和 gold.condition_answer_pairs。table 是完整的文档上下文，展开各题证据即可查看。

这是助手基于供应文本的审核版，尚未完成独立人工核验，未调用模型。evaluation_ready 只表示有上下文。

## 第1题：ambigdocs_33809

**query：** Who is the artist of the album "No Going Back"?

**term：** No Going Back
**dimension：** Entity Disambiguation
**来源：** 旧第1题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| No Going Back (Johnny Coppin album) | Johnny Coppin | Johnny Coppin |
| No Going Back (Stiff Little Fingers album) | Stiff Little Fingers | Stiff Little Fingers |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>No Going Back (Johnny Coppin album)：完整供应证据</summary>

No Going Back (Johnny Coppin album) No Going Back is a folk/rock album by Johnny Coppin released in 1979, his second solo album. The album was produced by Johnny Coppin and engineered by John Acock and Mick Dolan. It was recorded at Millstream Studios, Cheltenham during the summer of 1979. It includes contributions from Coppin's road band members of the time, plus guests including former Decameron colleague Dik Cadbury. "No Going Back" was originally released by Rola Records as a vinyl LP, catalogue number R002 with sleeve artwork by Tony Price Studios and photography by Kenneth Griffiths. It has never

答案字符位置：[15, 28)。

</details>

<details>
<summary>No Going Back (Stiff Little Fingers album)：完整供应证据</summary>

No Going Back (Stiff Little Fingers album) No Going Back is the tenth studio album by punk band Stiff Little Fingers. It was released on March 15, 2014 for a limited time through PledgeMusic, a website where fans can pledge/donate money to purchase the album in various forms. The album was released to the general public on August 11, 2014 through the band's Rigid Digits label and elsewhere through Mondo Recordings/INgrooves. The album is the band's first studio release in eleven years since 2003's "Guitar and Drum". It reached #1 on BBC Radio 1's UK Top 40 Rock Album Charts

答案字符位置：[15, 35)。

</details>

## 第2题：ambigdocs_13940

**query：** In what period were the buildings in the Greenville Commercial Historic District constructed?

**term：** Greenville Commercial Historic District
**dimension：** Entity Disambiguation
**来源：** 旧第2题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Greenville Commercial Historic District (Greenville, Kentucky) | late 19th and early 20th centuries | late 19th and early 20th centuries |
| Greenville Commercial Historic District (Greenville, North Carolina) | about 1914 to 1952 | about 1914 to 1952 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Greenville Commercial Historic District (Greenville, Kentucky)：完整供应证据</summary>

Greenville Commercial Historic District (Greenville, Kentucky) The Greenville Commercial Historic District is a historic district located on two blocks of N. Main St. and E. Main Cross St. in Greenville, Kentucky. The district consists of thirteen commercial buildings, ten of which are contributing buildings. The buildings in the district are commercial buildings constructed in the late 19th and early 20th centuries. The oldest of the buildings are two Italianate buildings built in the 1870s. The district includes the First National Bank Building, a Beaux-Arts building constructed in 1901; a building at 121-123 N. Main with a metal facade and engaged

答案字符位置：[385, 419)。

</details>

<details>
<summary>Greenville Commercial Historic District (Greenville, North Carolina)：完整供应证据</summary>

Greenville Commercial Historic District (Greenville, North Carolina) Greenville Commercial Historic District is a national historic district located at Greenville, Pitt County, North Carolina. The district encompasses 51 contributing buildings in the central business district of Greenville. It includes buildings dated from about 1914 to 1952 and notable examples of Greek Revival and Queen Anne style architecture. Located in the district and listed separately are the Pitt County Courthouse (1911) by Milburn, Heister & Company and U.S. Post Office (1913). Other notable buildings include the Proctor Hotel (1911), Montgomery Ward Department Store (1929), Dail-Hodges Building (1919), Blount Building (1924), Greenville Bank

答案字符位置：[325, 343)。

</details>

## 第3题：ambigdocs_62005

**query：** When was Careca born?

**term：** Careca (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第4题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Careca | 5 October 1960 | 5 October 1960 / October 5, 1960 / October 5 1960 / 1960-10-05 |
| Leomir Silva Teles | August 17, 1989 | August 17, 1989 / 17 August 1989 / August 17 1989 / 1989-08-17 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Careca：完整供应证据</summary>

Careca Antônio de Oliveira Filho (born 5 October 1960), better known as Careca (), is a Brazilian former footballer, who was deployed as a forward. During his career Careca played for several clubs, he is most famous for his time with Italian side Napoli and also his contributions to the Brazilian national football team. Careca began his footballing career in his home state of São Paulo with local side Guarani in 1978. With his finishing ability and devastating pace quickly established himself as one of his country's best young strikers. With Guarani, he won the Brazilian Championship during his first

答案字符位置：[39, 53)。

</details>

<details>
<summary>Leomir Silva Teles：完整供应证据</summary>

Leomir Silva Teles Leomir Silva Teles, better known as Careca (born August 17, 1989), is a Brazilian footballer who plays as a striker for Red Bull Brasil. Born in Campo Grande, he started his career at age 17 in Seven Months of Mato Grosso do Sul in the same year he moved to Cene, where he played his first major trophy, the Cup of Brazil. Despite failing to help the club in a good position, was one of the highlights of the team. In 2007, the Bahia is hired where there is very leveraged and remains in Bahia club until

答案字符位置：[68, 83)。

</details>

## 第4题：ambigdocs_55013

**query：** When was Clark Field inaugurated?

**term：** Clark Field (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第5题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Clark Field (1887) | 1887 | 1887 |
| Clark Field (1928) | 1928 | 1928 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Clark Field (1887)：完整供应证据</summary>

Clark Field (1887) Clark Field, originally known as Varsity Athletic Field, was a stadium on the campus of the University of Texas at Austin. Clark Field hosted the Texas Longhorns football and track teams until they moved to the newly constructed Memorial Stadium in 1924. It also hosted the Texas baseball team until it moved to the second Clark Field in 1928 and the Texas Longhorns men's basketball team until it moved next door to the new Men's Gym in 1917. The stadium opened in 1887 on part of the land at the southeast corner of 24th Street and Speedway

答案字符位置：[13, 17)。

</details>

<details>
<summary>Clark Field (1928)：完整供应证据</summary>

appearances in 1952, 1957, 1961, 1962, 1963, 1965, 1966, 1968, 1969, 1970, 1972, 1973, and 1974 while calling Clark Field home. There have been three athletic facilities on the campus named for the university's influential early leader James Benjamin Clark. The first Clark Field, at the southeast corner of 24th Street and Speedway, operated from 1887 through 1927, then was closed for the construction of the Mechanical Engineering Building a.k.a. Taylor Hall. The field was located a couple of blocks northwest of Memorial Stadium. For 1928 the second and best-known Clark Field was inaugurated, north of Memorial Stadium, on the

答案字符位置：[539, 543)。

</details>

## 第5题：ambigdocs_30621

**query：** When was the Barlow House built?

**term：** Barlow House
**dimension：** Entity Disambiguation
**来源：** 旧第6题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Aaron Barlow House | 1730 | 1730 |
| Barlow House (Barlow, Kentucky) | 1903 | 1903 |
| William V. N. Barlow House | 1870s | 1870s |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Aaron Barlow House：完整供应证据</summary>

Aaron Barlow House The Aaron Barlow House is a historic house at the corner of Umpawaug and Station Roads in Redding, Connecticut. It is a 2-1/2 story wood frame structure, five bays wide, with twin chimneys. Built in 1730, it is important as a surviving example embodying "the characteristics of early Georgian style domestic architecture that became prominent in the Colonies beginning in the mid-18th century" and also for its association with Col. Aaron Barlow, Joel Barlow, and General Israel Putnam, all significant local figures in the American Revolutionary War. The house was listed on the National Register of Historic

答案字符位置：[218, 222)。

</details>

<details>
<summary>Barlow House (Barlow, Kentucky)：完整供应证据</summary>

Barlow House (Barlow, Kentucky) The Barlow House in Barlow, Kentucky is a two-story symmetrical Queen Anne-style house built in 1903. It was listed on the National Register of Historic Places in 1991. It is located at the intersection of Broadway and S. 5th St. The house is "the only documented example in Ballard County of a historic residential structure that was built according to plan obtained from an architectural patternbook. This fact accounts a great deal for the elegance and modernity of the house's design. The increased contact with the outside world provided through the new railroad connection would have

答案字符位置：[128, 132)。

</details>

<details>
<summary>William V. N. Barlow House：完整供应证据</summary>

William V. N. Barlow House The William V. N. Barlow House is on South Clinton Street in Albion, New York, United States. It is a brick building erected in the 1870s in an eclectic mix of contemporary architectural styles, including Second Empire, Italianate, and Queen Anne. Its interior features highly intricate Eastlake style woodwork. It was the home of a prominent local architect who designed many major buildings in Albion. In 1983 it and an accompanying barn, since converted into a garage, were added to the National Register of Historic Places. It is one of two houses in Albion so

答案字符位置：[159, 164)。

</details>

## 第6题：ambigdocs_46327

**query：** Who is the husband of Agnes, Queen of Aragon?

**term：** Agnes, Queen of Aragon
**dimension：** Entity Disambiguation
**来源：** 旧第7题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Agnes, wife of Ramiro I of Aragon | Ramiro I of Aragon | Ramiro I of Aragon |
| Agnes of Aquitaine, Queen of Aragon and Navarre | Peter I of Aragon and Navarre | Peter I of Aragon and Navarre |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Agnes, wife of Ramiro I of Aragon：完整供应证据</summary>

Agnes, wife of Ramiro I of Aragon Agnes (Aragonese: "Agnés") was a Queen of Aragon, the second wife of Ramiro I of Aragon. She is speculated to have been daughter of either William VI, Duke of Aquitaine or William VII, Duke of Aquitaine, and perhaps remarried to Peter I, Count of Savoy. Following the death of his wife Ermesinda of Bigorre, Ramiro I of Aragon next appears with a wife named Agnes. It is believed Agnes outlived her husband, who died on 8 May 1063 after they were married for about a decade. They don't seem to have had any

答案字符位置：[15, 33)。

</details>

<details>
<summary>Agnes of Aquitaine, Queen of Aragon and Navarre：完整供应证据</summary>

Agnes of Aquitaine, Queen of Aragon and Navarre Agnes of Aquitaine (end of 1072 – 6 June 1097) was a daughter of William VIII, Duke of Aquitaine, and his third wife, Hildegarde of Burgundy, and thus half-sister of Agnes of Aquitaine, Queen of Castile, with whom she is sometimes confused. In 1081, Agnes was betrothed to Peter I of Aragon and Navarre. During 1086 in Jaca the couple married, and upon Peter's succession, Agnes became queen of Aragon and Navarre. By him, Agnes had two children, both of whom predeceased their father: Peter (died 1103) and Isabella (died 1104). Agnes

答案字符位置：[321, 350)。

</details>

## 第7题：ambigdocs_14235

**query：** When did Pharasmanes rule?

**term：** Pharasmanes
**dimension：** Entity Disambiguation
**来源：** 旧第8题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Pharasmanes III of Iberia | 135–185 AD | 135–185 AD |
| Pharasmanes II of Iberia | AD 116–132 | AD 116–132 |
| Pharasmanes IV of Iberia | 406 to 409 | 406 to 409 |
| Pharasmanes V of Iberia | 547 to 561 | 547 to 561 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Pharasmanes III of Iberia：完整供应证据</summary>

Pharasmanes III of Iberia Pharasmanes III or P’arsman III () was a king of Iberia (Kartli, modern central and eastern Georgia), a contemporary of the Roman emperor Antoninus Pius (138–161). Professor Cyril Toumanoff suggests 135–185 AD as the possible years of Pharasmanes’ rule. According to the medieval Georgian chronicles, P’arsman was one year old at the death of his father, Ghadam (135), whom he succeeded on the throne, and ruled under the regency of his grandmother Ghadana of Armenia until he reached a legal age. The Classical sources evidence Pharasmanes’ friendly relations with Rome. According to Cassius Dio, he came

答案字符位置：[225, 235)。

</details>

<details>
<summary>Pharasmanes II of Iberia：完整供应证据</summary>

Pharasmanes II of Iberia Pharasmanes II the Valiant or the Brave () was a king of Iberia (Kartli) from the Pharnavazid dynasty, contemporary of the Roman emperor Hadrian (r. 117–138). Professor Cyril Toumanoff suggests AD 116–132 as the years of Pharasmanes’ reign. He features in several Classical accounts. The medieval Georgian annals report Pharasmanes' joint rule with Pharasmanes Avaz, diarchs (one source has the extra pair: Rok and Mihrdat), but several modern scholars consider the Iberian diarchy unlikely as it is not corroborated by the contemporary evidence. Pharasmanes is reported to have been the son of his predecessor, King Amazasp

答案字符位置：[219, 229)。

</details>

<details>
<summary>Pharasmanes IV of Iberia：完整供应证据</summary>

Pharasmanes IV of Iberia P'arsman IV (, sometimes Latinized as "Pharasmanes"), of the Chosroid Dynasty, was the king of Iberia (Kartli, eastern Georgia) from 406 to 409. According to the medieval Georgian chronicles, he was the son of King Varaz-Bakur II and the daughter of Trdat of Iberia. Characterized as a pious monarch and an exceptional warrior, he is reported to have rebelled against the Iranian hegemony and have withheld paying tribute to the shah. He is also credited with the construction of Bolnisi. P’arsman is identified by some scholars with the Pharasmanes of the Syriac "Vita Petri Iberi" who

答案字符位置：[158, 168)。

</details>

<details>
<summary>Pharasmanes V of Iberia：完整供应证据</summary>

Pharasmanes V of Iberia P'arsman V (, sometimes Latinized as "Pharasmanes"), of the Chosroid Dynasty, was the king of Iberia (Kartli, eastern Georgia) from 547 to 561. Parsman was the son and successor of Bakur II, and was succeeded by his nephew P'arsman VI. According to the medieval Armenian adaptation of the Georgian Chronicles, in the reign of Parsman, the Ossetians (Georgian designation for Alans) attacked and ravaged Kartli, prompting Parsman to place himself under the Persian protection on terms of paying tribute. However, this version differs from that given by the Georgian original in the "History of King Vakhtang

答案字符位置：[156, 166)。

</details>

## 第8题：ambigdocs_10255

**query：** When was the Socialist Workers Organization founded?

**term：** Socialist Workers Organization
**dimension：** Entity Disambiguation
**来源：** 旧第9题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Socialist Workers Organisation (Senegal) | 1973 | 1973 |
| Socialist Workers Organization (New Zealand) | 1994 | 1994 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Socialist Workers Organisation (Senegal)：完整供应证据</summary>

Socialist Workers Organisation (Senegal) The Socialist Workers Organisation () was a Trotskyist organisation in Senegal. It was founded in France by Sally Ndongo and Babacar Doudou in 1973, with the name Grouping of Revolutionary Workers ("Groupement des Ouvriers Révolutionnaires", GOR). They had previously been members of the first post-war Trotskyist organisation in Senegal, the Workers Avant-Garde, which had collapsed soon after expelling them. The GOR split in 1976, with a minority who had called for class struggle to be placed ahead of national liberation forming the Communist Workers League (LCT). The majority maintained the GOR, and in 1977 started activities

答案字符位置：[184, 188)。

</details>

<details>
<summary>Socialist Workers Organization (New Zealand)：完整供应证据</summary>

Socialist Workers Organization (New Zealand) The Socialist Workers Organization was a Trotskyist organisation based in New Zealand. It was part of the International Socialist Tendency, the British Socialist Workers Party's international tendency. The Socialist Workers Organization was established by the merger of the Communist Party of New Zealand and the International Socialist Organization in 1994. The former was the direct linear organisational continuation of the old Communist Party that had been founded as a part of the Communist International. Unlike most such official Communist parties that of New Zealand had aligned itself with Beijing after China and the Soviet Union

答案字符位置：[398, 402)。

</details>

## 第9题：ambigdocs_40355

**query：** Where is Kennett High School located?

**term：** Kennett High School
**dimension：** Entity Disambiguation
**来源：** 旧第11题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Kennett High School (New Hampshire) | North Conway, New Hampshire | North Conway, New Hampshire |
| Kennett High School (Pennsylvania) | Kennett Square, Pennsylvania, United States | Kennett Square, Pennsylvania, United States |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Kennett High School (New Hampshire)：完整供应证据</summary>

Kennett High School (New Hampshire) Kennett High School is a high school in North Conway, New Hampshire, near the village of Redstone. The present school building opened in 2007, replacing the former A. Crosby Kennett High School (built in 1923) located at 176 Main Street in Conway, which is now a middle school. Kennett High School serves the towns of Conway, Albany, Bartlett, Eaton, Freedom, Hart's Location, Jackson, Madison, and Tamworth. Kennett has several departments, including English, Mathematics, Foreign Languages, Science, and Arts. The school also has a Career-Tech department, which includes several shops and classrooms fitted with technology. These

答案字符位置：[76, 103)。

</details>

<details>
<summary>Kennett High School (Pennsylvania)：完整供应证据</summary>

Kennett High School (Pennsylvania) Kennett High School is the only public high school in the Kennett Consolidated School District and is located in Kennett Square, Pennsylvania, United States. The school averages around 1300 students and 100 faculty members. The Kennett Consolidated School District Office is located next to the high school. The Class of 2012 had 326 graduates who averaged a 3-part SAT score of 1540. The class contained 4 National Merit Finalists, 5 National Merit Semifinalists, and 10 National Merit Commended Scholars. The class also had 36 AP Scholars, 13 AP Scholars with Honor, 17 AP Scholars with Distinction,

答案字符位置：[148, 191)。

</details>

## 第10题：ambigdocs_24463

**query：** When was Kim Chang-hee born?

**term：** Kim Chang-hee
**dimension：** Entity Disambiguation
**来源：** 旧第12题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Kim Chang-hee (footballer, born 1986) | 5 December 1986 | 5 December 1986 / December 5, 1986 / December 5 1986 / 1986-12-05 |
| Kim Chang-hee (footballer, born 1987) | 8 June 1987 | 8 June 1987 / June 8, 1987 / June 8 1987 / 1987-06-08 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Kim Chang-hee (footballer, born 1986)：完整供应证据</summary>

Kim Chang-hee (footballer, born 1986) Kim Chang-Hee (; born 5 December 1986) is a South Korean football midfielder. He currently played for club PS Mojokerto Putra. Another player called Kim Chang-Hee (born 8 June 1987) also played in the K-League around the same time as this one, for Gangwon FC. Kim Chang-hee was drafted from Konkuk University for Daegu FC's 2009 season. He played a limited role in the season, participating in 11 games during the 2009 K-League. After failing to feature at all during the 2010 season, Kim was released. He subsequently joined Daejeon KHNP, who play in the

答案字符位置：[60, 75)。

</details>

<details>
<summary>Kim Chang-hee (footballer, born 1987)：完整供应证据</summary>

Kim Chang-hee (footballer, born 1987) Kim Chang-Hee (, born 8 June 1987) is a South Korean football player who plays as a midfielder. Kim spent his formative football years playing at university level for Yeungnam University. Nominating himself for the 2010 K-League draft, he wasn't selected by any K-League clubs. However, Kim joined Gangwon FC late in the preseason. His first K-League match was against Chunnam Dragons in Gangneung on 28 March 2010, resulting in a handy win 5 -2 for his club. Despite starting a number of matches for Gangwon in the first half of the season, he gradually

答案字符位置：[60, 71)。

</details>

## 第11题：ambigdocs_45044

**query：** Where is Forbes Creek located?

**term：** Forbes Creek
**dimension：** Entity Disambiguation
**来源：** 旧第13题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Forbes Creek (California) | Lake County, California | Lake County, California |
| Forbes Creek (Washington) | Kirkland, Washington | Kirkland, Washington |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Forbes Creek (California)：完整供应证据</summary>

Forbes Creek (California) Forbes Creek is a watercourse in Lake County, California which empties into Clear Lake at the city of Lakeport. In 1989, a major project was undertaken in the Forbes Creek basin by the city of Lakeport. A bypass pipe was installed between approximately Tunis and Main streets to divert flood flows from the Forbes Creek channel where it winds through a heavily populated residential and commercial area. Forbes Creek was analyzed in the "City of Lakeport General Plan 2020" to establish guidelines for land development within the city of Lakeport to protect riparian natural features as well

答案字符位置：[59, 82)。

</details>

<details>
<summary>Forbes Creek (Washington)：完整供应证据</summary>

Forbes Creek (Washington) Forbes Creek is a small, moderately sloping creek wholly within the city of Kirkland, Washington. From its headwaters on the Rose Hill moraine to its outlet at Juanita Bay is as the crow flies. The northern extent of its basin is a nearly east-west line at NE 116th Street; the eastern boundary is at the Rose Hill ridgeline, roughly north-south at 132nd Avenue NE. The southern extent is irregular trending roughly from Kirkland's high point at the northeast corner of Bridle Trails State Park (, ) through South Rose Hill Park, to Lake Washington at 16 ft

答案字符位置：[102, 122)。

</details>

## 第12题：ambigdocs_8969

**query：** Who is the director of the film "Green Eyes"?

**term：** Green Eyes
**dimension：** Entity Disambiguation
**来源：** 旧第14题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Green Eyes (1918 film) | Roy William Neill | Roy William Neill |
| Green Eyes (1934 film) | Richard Thorpe | Richard Thorpe |
| Green Eyes (1977 film) | John Erman | John Erman |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Green Eyes (1918 film)：完整供应证据</summary>

Green Eyes (1918 film) Green Eyes is a 1918 American silent drama film directed by Roy William Neill and written by Ella Stuart Carson, John Lynch and R. Cecil Smith. The film stars Dorothy Dalton, Jack Holt, Emory Johnson, Doris May, Robert McKim, and Clyde Benson. The film was released on August 11, 1918, by Paramount Pictures. It is not known whether the film currently survives. As described in a film magazine, hardly had Pearson Hunter (Holt) returned to the south with his young bride Shirley (Dalton) than he flew into a jealous rage because his wife knew one of

答案字符位置：[83, 100)。

</details>

<details>
<summary>Green Eyes (1934 film)：完整供应证据</summary>

Green Eyes (1934 film) Green Eyes is a 1934 American Pre-Code Chesterfield Pictures film directed by Richard Thorpe. During a masked party Stephen Kester (Claude Gillingwater) is found dead in the closet of his room, three stab wounds in his back. Suspicion falls on everyone at the party, especially Kester's granddaughter Jean (Shirley Grey) and her fiancé Cliff Miller (William Bakewell), who fled the house after disabling all of the other cars and cutting the phone lines. As Inspector Crofton (John Wray) and Detective Regan (Ben Hendricks Jr.) investigate they are shadowed and helped along by a mystery writer, Bill

答案字符位置：[101, 115)。

</details>

<details>
<summary>Green Eyes (1977 film)：完整供应证据</summary>

and took Trung back to the US with him. Green Eyes (1977 film) Green Eyes is a 1977 American television film directed by John Erman and written by Eugene Logan and David Seltzer. It is a "touching and moving story" about an Vietnam veteran Lloyd Dubeck (Paul Winfield) who went through a soul searching journey. The film was produced by Lorimar Productions and broadcast on ABC. The film won a Peabody Award and a Humanitas Prize in 1977. Lloyd Dubeck (Paul Winfield), "a Vietnam veteran wounded both physically and psychically. Released from a VA hospital, walking with a cane, he

答案字符位置：[121, 131)。

</details>

## 第13题：ambigdocs_47665

**query：** When did Senator Lumpkin start his service in the Senate?

**term：** Senator Lumpkin
**dimension：** Entity Disambiguation
**来源：** 旧第16题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Alva M. Lumpkin | July 22, 1941 | July 22, 1941 / 22 July 1941 / July 22 1941 / 1941-07-22 |
| Wilson Lumpkin | November 22, 1837 | November 22, 1837 / 22 November 1837 / November 22 1837 / 1837-11-22 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Alva M. Lumpkin：完整供应证据</summary>

the Eastern and Western Districts of South Carolina, to a seat vacated by J. Lyles Glenn. He was confirmed by the United States Senate on May 22, 1939, and received his commission on July 19, 1939. He resigned from the court when he was appointed on July 17, 1941 as a Democrat to the U.S. Senate to fill the vacancy caused by the resignation of James F. Byrnes. He started his service in the Senate on July 22, 1941, but he died only 10 days later in Washington, D.C., at the age of 54. Lumpkin was interred in Elmwood Cemetery,

答案字符位置：[403, 416)。

</details>

<details>
<summary>Wilson Lumpkin：完整供应证据</summary>

to fill the vacancy caused by the resignation of John P. King and served the remainder of his term from November 22, 1837, to March 3, 1841. While in the Senate, he was chairman of the Committee on Manufactures (Twenty-sixth Congress). He was appointed by the governor as a member of the State Board of Public Works. He died a few years after the end of the Civil War, in Athens in 1870; interment was in Oconee Hill Cemetery. Lumpkin's grandson, Middleton P. Barrow, also served in the U.S. Senate. Lumpkin's brother Joseph Henry Lumpkin was the first chief justice

答案字符位置：[104, 121)。

</details>

## 第14题：ambigdocs_13488

**query：** What sport is Tom Cahill associated with?

**term：** Tom Cahill
**dimension：** Entity Disambiguation
**来源：** 旧第17题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Thomas Cahill (soccer) | soccer | soccer / Soccer |
| Tom Cahill (baseball) | baseball | baseball / Baseball |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Thomas Cahill (soccer)：完整供应证据</summary>

1871. He was of Irish descent. He attended St. Louis University and built a reputation as one of the pre-eminent amateur athletes in the country. Originally favoring running and baseball, he became interested in soccer after witnessing a game involving a team visiting from Toronto. In 1897, Cahill founded St. Louis Shamrocks which competed in the St. Louis Association Foot Ball League. They won the league title in 1899 and 1900. Although he owned Shamrocks, he also managed several other team including St. Louis Spalding's in 1903-04 and Diel F.C. during the 1904-05 season. Cahill returned to the East Coast

答案字符位置：[212, 218)。

</details>

<details>
<summary>Tom Cahill (baseball)：完整供应证据</summary>

Tom Cahill (baseball) Thomas H. "Tom" Cahill (October, 1868 – December 25, 1894) was an American professional baseball player who played from 1888 to 1894. He played one season in Major League Baseball and had a career batting average of .253 with 109 hits, 17 doubles, 7 triples, 3 home runs, 44 RBIs, and 38 stolen bases. He was of Irish descent. Cahill was born in Fall River, Massachusetts in October, 1868. His father, also named Thomas Cahill, was born in Ireland and worked as a laborer. Cahill's mother was also born in Ireland. Cahill attended both the College of

答案字符位置：[12, 20)。

</details>

## 第15题：ambigdocs_52221

**query：** When was Peter Sinclair born?

**term：** Peter Sinclair
**dimension：** Entity Disambiguation
**来源：** 旧第18题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Peter Sinclair Jr. | 13 November 1887 | 13 November 1887 / November 13, 1887 / November 13 1887 / 1887-11-13 |
| Peter Sinclair Sr. | November 13, 1819 | November 13, 1819 / 13 November 1819 / November 13 1819 / 1819-11-13 |
| Peter J. N. Sinclair | 18 September 1946 | 18 September 1946 / September 18, 1946 / September 18 1946 / 1946-09-18 |
| Peter Sinclair (broadcaster) | 15 November 1937 | 15 November 1937 / November 15, 1937 / November 15 1937 / 1937-11-15 |
| Peter Sinclair (environmental activist) | 1953 | 1953 |
| Peter Sinclair (governor) | 16 November 1934 | 16 November 1934 / November 16, 1934 / November 16 1934 / 1934-11-16 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Peter Sinclair Jr.：完整供应证据</summary>

Peter Sinclair Jr. Peter Sinclair (13 November 1887 – 8 March 1938) was a Liberal party member of the House of Commons of Canada. He was born in Summerfield, Prince Edward Island and became a farmer. The son of Peter Sinclair and Margaret MacMurdo, Sinclair was educated in Springfield and farmed near Charlottetown. Sinclair was a Liberal member of the Legislative Assembly of Prince Edward Island from 1927 until his defeat in the 1931 election, at the 1st Queens riding. He was first elected to Parliament at the Queen's riding in the 1935 general election. Sinclair died on 8 March

答案字符位置：[35, 51)。

</details>

<details>
<summary>Peter Sinclair Sr.：完整供应证据</summary>

Peter Sinclair Sr. Peter Sinclair (November 13, 1819 – October 9, 1906) was a Scottish farmer and politician in Prince Edward Island. He represented Queen's County in the House of Commons of Canada from 1873 to 1878 as a Liberal member. He was born in Glendaruel, Argyleshire, the son of Peter Sinclair, and came to Queens County, Prince Edward Island in 1840 with his mother. He was an unsuccessful candidate for a seat in the provincial assembly in 1858. Sinclair represented 1st Queens in the Legislative Assembly of Prince Edward Island from 1867 to 1873 and from 1882 to 1900

答案字符位置：[35, 52)。

</details>

<details>
<summary>Peter J. N. Sinclair：完整供应证据</summary>

professor at the London School of Economics and University of Warwick, and chairman of the Royal Economic Society Easter School, and the International Economics Study Group. His non-economics interests include architecture, history and languages. Sinclair's most notable former student is David Cameron. Others include King Letsie III, Camilla Cavendish, Peter Conradi, Diane Coyle, Lieutenant General Michelle D. Johnson, Dave Ramsden and Guy Spier. Peter J. N. Sinclair Peter James Niven Sinclair (born 18 September 1946) is a British economist. He is Professor in Economics at the University of Birmingham. Previously, he was fellow and tutor at Brasenose College, Oxford. Sinclair

答案字符位置：[505, 522)。

</details>

<details>
<summary>Peter Sinclair (broadcaster)：完整供应证据</summary>

Easy Listening i98FM, hosting the popular "Lovesongs till Midnight" program. While still in Christchurch he helped raise money to build a Police Kiosk in Cathedral Square, for people who needed a safe place to go at all times of the day in case of emergencies. In his later years, he developed a passion for computers and was one of the first New Zealanders to become actively involved with the Internet. He wrote widely on internet issues, software developments and content. Sinclair died in Auckland on 8 August 2001, from leukaemia, aged 62. Peter Sinclair (broadcaster) Peter Sinclair (15 November 1937

答案字符位置：[590, 606)。

</details>

<details>
<summary>Peter Sinclair (environmental activist)：完整供应证据</summary>

interview with Jeff Masters of Weather Underground addressing arguments about cold temperatures disproving global warming, which was covered by the National Journal. In 2012, he successfully crowd-funded via a Kickstarter campaign for an expedition with the climate researchers Jason Box and Maurio Pelto, to assess the state of glaciers around Mount Baker, an active glaciated stratovolcano. In 2013, he went to Greenland with members of the Dark Snow Project and Bill McKibben, as their videographer, to document Greenland's surface melting. Peter Sinclair (environmental activist) Peter Sinclair from Midland, Michigan (born 1953), is an environmental activist whose focus is on climate

答案字符位置：[628, 632)。

</details>

<details>
<summary>Peter Sinclair (governor)：完整供应证据</summary>

Base. Peter Sinclair (governor) Rear Admiral Peter Ross Sinclair, (born 16 November 1934) is a retired senior officer of the Royal Australian Navy who served as the 35th Governor of New South Wales from 8 August 1990 to 1 March 1996. Born in Manly, New South Wales, he was educated North Sydney Boys High School before joining the navy through the Royal Australian Naval College. Over a 41-year career, Sinclair saw active service in Korea, Malaysia, Vietnam and in relief operations following Cyclone Tracy, and commanded the naval base . He later rose to high command, serving as Director of

答案字符位置：[72, 88)。

</details>

## 第16题：ambigdocs_51355

**query：** In what year was Governor Bailey first elected governor?

**term：** Governor Bailey
**dimension：** Entity Disambiguation
**来源：** 旧第19题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Carl Edward Bailey | 1936 | 1936 |
| Thomas L. Bailey | 1943 | 1943 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Carl Edward Bailey：完整供应证据</summary>

two-year term. In 1936, mobster Lucky Luciano was arrested in Hot Springs and offered Attorney General Bailey a $50,000 bribe if Bailey would not extradite him to New York. Bailey refused the bribe. In 1936, Bailey was elected to the first of his two terms as governor. In the general election, Bailey handily defeated the Republican Osro Cobb, who had represented Montgomery County in the Arkansas House of Representatives from 1927 to 1930. Cobb waged an active campaign, having stressed that he was born in Arkansas, whereas the Missouri-born Bailey was a "northern man". Cobb had proposed the creation of

答案字符位置：[18, 22)。

</details>

<details>
<summary>Thomas L. Bailey：完整供应证据</summary>

Thomas L. Bailey Thomas Lowry Bailey (January 6, 1888 – November 2, 1946) was an American politician from the state of Mississippi. He was born in Webster County, Mississippi and graduated from Millsaps College. Bailey was elected to the Mississippi House of Representatives as a Democratic candidate in 1915 and served from 1916 to 1940. He unsuccessfully ran for governor in 1939 but was elected in 1943. Bailey helped in the development of roads and ways to help farmers sell their products. During his term a four-year medical school at the University of Mississippi was initiated. He died of a

答案字符位置：[401, 405)。

</details>

## 第17题：ambigdocs_42868

**query：** Who is the composer of Symphony No. 32?

**term：** Symphony No. 32
**dimension：** Entity Disambiguation
**来源：** 旧第20题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Symphony No. 32 (Haydn) | Joseph Haydn | Joseph Haydn |
| Symphony No. 32 (Mozart) | Wolfgang Amadeus Mozart | Wolfgang Amadeus Mozart |
| Symphony No. 32 (Michael Haydn) | Michael Haydn | Michael Haydn |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Symphony No. 32 (Haydn)：完整供应证据</summary>

Symphony No. 32 (Haydn) The Symphony No. 32 in C major (Hoboken I/32) is a festive symphony by Joseph Haydn. The exact date of composition is unknown. It has been suggested by noted Haydn scholar H.C. Robbins Landon that it could have been written as early as 1757 and as late as 1763. More recent scholars have suggested it was composed in either 1760 or 1761 The work is in four movements and is scored for 2 oboes, bassoon, 2 horns, 2 trumpets, timpani, strings and continuo. The work is one of the few symphonies of the Classical era to

答案字符位置：[95, 107)。

</details>

<details>
<summary>Symphony No. 32 (Mozart)：完整供应证据</summary>

Symphony No. 32 (Mozart) The Symphony No. 32 in G major, K. 318, was written by Wolfgang Amadeus Mozart in 1779, after his return from Paris. \relative c { \tempo "Allegro spiritoso" \key g \major <g b, d, g,>4.\f g8 g4 r8. \times 2/3 { g32( a b } | c4) c,-. r r8. \times 2/3 { a'32( b cis } | d4) d,-. </score> The symphony, scored for strings, 2 flutes, 2 oboes, 2 bassoons, 4 horns, 2 trumpets, and timpani, is in the form of an Italian overture, consisting of three brief movements that follow one another without

答案字符位置：[80, 103)。

</details>

<details>
<summary>Symphony No. 32 (Michael Haydn)：完整供应证据</summary>

Symphony No. 32 (Michael Haydn) Michael Haydn's Symphony No. 32 in D major, Perger 23, Sherman 32, MH 420, was written in Salzburg in 1786. Scored for flute, 2 oboes, 2 bassoons, 2 horns, 2 trumpets, timpani and strings. It is Haydn's only symphony in two movements; this it has in common with Carl Nielsen's Symphony No. 5 but not much else (Delarte, 2006). The first movement, in , begins softly with a somewhat dancelike theme. At measure 20, a new theme is introduced forte with a more pronounced dance character. After the establishment of A major, the second subject

答案字符位置：[17, 30)。

</details>

## 第18题：ambigdocs_1379

**query：** Where is the Divine Mercy Sanctuary located?

**term：** Divine Mercy Sanctuary
**dimension：** Entity Disambiguation
**来源：** 旧第21题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| National Shrine of The Divine Mercy (Stockbridge, Massachusetts) | Stockbridge, Massachusetts | Stockbridge, Massachusetts |
| Sanctuary of the Divine Mercy, Vilnius | Vilnius | Vilnius |
| Divine Mercy Sanctuary (Płock) | Old Market Square in Płock | Old Market Square in Płock |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>National Shrine of The Divine Mercy (Stockbridge, Massachusetts)：完整供应证据</summary>

National Shrine of The Divine Mercy (Stockbridge, Massachusetts) The National Shrine of The Divine Mercy is a Roman Catholic shrine located in Stockbridge, Massachusetts. The priests and Roman Catholic and brothers of the Congregation of Marian Fathers of the Conception of the Most Blessed Virgin Mary have resided on Eden Hill in Stockbridge, since June 1944. Father Walter Pelczynski, MIC, with the assistance of local clergy and friends of the Marian community, initially purchased 50 of the that constituted the "Eden Hill" estate in November, 1943. The house was to serve as the novitiate for a newly formed province. An

答案字符位置：[37, 63)。

</details>

<details>
<summary>Sanctuary of the Divine Mercy, Vilnius：完整供应证据</summary>

Sanctuary of the Divine Mercy, Vilnius The Church of the Divine Mercy Sanctuary or the Holy Trinity Church in Vilnius, also called "God's Mercy Sanctuary" Lithuania () is a Roman Catholic shrine dedicated to the Divine Mercy devotion, originated by Saint Faustina Kowalska. On the site of the present church (Dominikonų St. 12) a Gothic single-nave church was built in the 15th century and named Holy Trinity Church. It was reconstructed after the 1748 and 1749 fires: a new presbytery and two towers were built on, and in a place of a Gothic apse a new portal was erected. The

答案字符位置：[31, 38)。

</details>

<details>
<summary>Divine Mercy Sanctuary (Płock)：完整供应证据</summary>

soul that will venerate this image will not perish." ("Diary" 47-48). The chapel is located at the Old Market Square in Płock. In 2009 the expansion of the sanctuary to a larger church begun. Divine Mercy Sanctuary (Płock) The Divine Mercy Sanctuary, is a Roman Catholic chapel, in Poland, dedicated to the Divine Mercy devotion, originated by Saint Faustina Kowalska. The chapel belongs to Zgromadzenie Sióstr Matki Bożej Miłosierdzia (the Congregation of the Sisters of Our Lady of Mercy). This is where Faustina reported her first vision of the Divine Mercy image. Jesus said then to her: "Paint an image

答案字符位置：[99, 125)。

</details>

## 第19题：ambigdocs_47224

**query：** When was General Altmayer born?

**term：** General Altmayer
**dimension：** Entity Disambiguation
**来源：** 旧第22题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Robert Altmayer | 1875 | 1875 |
| Victor Joseph Altmayer | 1844 | 1844 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Robert Altmayer：完整供应证据</summary>

Robert Altmayer Marie-Robert Altmayer (1875–1959) was a French army corps general. He was the eldest son of the divisional general Victor Joseph Altmayer (1844–1908) and elder brother of general René Altmayer. They were of German descent. He commanded cavalry in Algeria in 1929. He then became inspector general of cavalry from 14 October 1932 to 5 October 1936. He was retired on 30 July 1937 then re-mobilised on 21 May 1940 on the orders of general Maxime Weygand. On 24 May he was put in command of 10th Army, with which he tried to hold a front along the river

答案字符位置：[39, 43)。

</details>

<details>
<summary>Victor Joseph Altmayer：完整供应证据</summary>

Victor Joseph Altmayer Victor Joseph Altmayer (1844–1908) was a French general. He was the father of Robert Altmayer and René Altmayer, both also generals and were of German descent. He was made a knight of the Légion d'honneur on 7 February 1871, an officer of the order on 5 June 1892. He was promoted to brigadier general and put in command of the 48th Infantry Brigade and the subdivisions of the Angoulême and Magnac-Laval regions on 18 May 1895. He held those posts until 14 August 1900, when he was made commander of 33rd Infantry Division and the sub-divisions of

答案字符位置：[47, 51)。

</details>

## 第20题：ambigdocs_38868

**query：** Who is the director of the film "Struck by Lightning"?

**term：** Struck by Lightning
**dimension：** Entity Disambiguation
**来源：** 旧第24题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Struck by Lightning (1990 film) | Jerzy Domaradzki | Jerzy Domaradzki |
| Struck by Lightning (2012 film) | Brian Dannelly | Brian Dannelly |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Struck by Lightning (1990 film)：完整供应证据</summary>

Struck by Lightning (1990 film) Struck by Lightning is a 1990 Australian film directed by Jerzy Domaradzki. The film was nominated in 4 AFI Award categories, including Best Director and Best Film. It won the film award at the Human Rights Medal and Awards in 1990. Garry McDonald plays Ollie, a grumpy alcoholic workshop supervisor at a shelter called Saltmarsh. He hires Pat (Brian Vriends), a school teacher, to develop an experimental fitness program for the intellectually disabled young adults in the shelter. Pat teaches P.E and decides to try to get them involved in soccer, with some interesting results.

答案字符位置：[90, 106)。

</details>

<details>
<summary>Struck by Lightning (2012 film)：完整供应证据</summary>

Struck by Lightning (2012 film) Struck by Lightning is a 2012 American coming-of-age comedy-drama film directed by Brian Dannelly and written by and starring Chris Colfer. The film had its world premiere at the Tribeca Film Festival on April 21, 2012, and was released theatrically on January 11, 2013. It features the final screen appearance of actress Polly Bergen. On November 20, 2012, Colfer released a young adult novel based on the film, titled "Struck by Lightning: The Carson Phillips Journal". High school senior Carson Phillips (Chris Colfer) is randomly struck and killed by lightning and the rest of the

答案字符位置：[115, 129)。

</details>

## 第21题：ambigdocs_5065

**query：** Who is the artist associated with "The Winner's Journey"?

**term：** The Winner's Journey
**dimension：** Entity Disambiguation
**来源：** 旧第25题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| The Winner's Journey (Damien Leith album) | Damien Leith | Damien Leith |
| The Winner's Journey (Natalie Gauci album) | Natalie Gauci | Natalie Gauci |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>The Winner's Journey (Damien Leith album)：完整供应证据</summary>

The Winner's Journey (Damien Leith album) The Winner's Journey is a live album and DVD based on "Australian Idol 2006" winner Damien Leith's performances on the show. The full-length album features remastered versions of Leith's live performances from the show, along with the studio version of his debut single "Night of My Life" and two of his original tracks, "Come to Me" and "Sky". The album was certified platinum on its first week release, and was certified four times platinum on its second week. It remained the number one album on the ARIA Charts for five weeks, and remained in

答案字符位置：[22, 34)。

</details>

<details>
<summary>The Winner's Journey (Natalie Gauci album)：完整供应证据</summary>

The Winner's Journey (Natalie Gauci album) The Winner's Journey is the debut studio album by "Australian Idol 2007" winner Natalie Gauci. As opposed to the previous format of releasing the winner's album consisting of recordings of the winner's live performance on the show, the album is composed of full studio-recorded versions of songs performed by Gauci on the show, including her debut single "Here I Am". The album also includes a bonus DVD which features an "exciting in-depth interview" with John Foreman (producer) and Ross Fraser (Sony BMG A&R); as she tells her story of her journey to "Idol" fame

答案字符位置：[22, 35)。

</details>

## 第22题：ambigdocs_47510

**query：** When was George Dunn born?

**term：** George Dunn
**dimension：** Entity Disambiguation
**来源：** 旧第26题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| George Grundy Dunn | December 20, 1812 | December 20, 1812 / 20 December 1812 / December 20 1812 / 1812-12-20 |
| George Hedford Dunn | November 15, 1794 | November 15, 1794 / 15 November 1794 / November 15 1794 / 1794-11-15 |
| George Dunn (Australian politician) | 27 March 1859 | 27 March 1859 / March 27, 1859 / March 27 1859 / 1859-03-27 |
| George Dunn (actor) | November 23, 1914 | November 23, 1914 / 23 November 1914 / November 23 1914 / 1914-11-23 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>George Grundy Dunn：完整供应证据</summary>

George Grundy Dunn George Grundy Dunn (December 20, 1812 – September 4, 1857) was a U.S. Representative from Indiana. Born in Washington County, Kentucky, Dunn moved to Monroe County, Indiana. He completed preparatory studies and attended the Indiana University at Bloomington. He moved to Bedford, Indiana, in 1833, where he taught school. He studied law. He was admitted to the bar in 1835 and commenced practice in Bedford, Indiana. He served as prosecuting attorney of Lawrence County in 1842. Dunn was elected as a Whig to the Thirtieth Congress (March 4, 1847 – March 3, 1849). He was an unsuccessful

答案字符位置：[39, 56)。

</details>

<details>
<summary>George Hedford Dunn：完整供应证据</summary>

George Hedford Dunn George Hedford Dunn (November 15, 1794 – January 12, 1854) was a U.S. Representative from Indiana. He was born in New York City and moved to Lawrenceburg, Indiana in 1817 to study law. He was admitted to the bar in 1822 and commenced practice in Lawrenceburg, serving as member of the State house of representatives in 1828, 1832, and 1833. He was a promoter of the first railway in Indiana and was an unsuccessful candidate for election to the Twenty-fourth Congress. From March 4, 1837 to March 3, 1839, Dunn served on the Twenty-fifth Congress, but was

答案字符位置：[41, 58)。

</details>

<details>
<summary>George Dunn (Australian politician)：完整供应证据</summary>

the miller John Dunn who founded Mount Barker, John Dunn Jr. MHA, William Henry Dunn MHA, William Paltridge MHA, Herbert Charles Dunn MHA, agriculturist Charles Dunn (1796–1881) who founded Charleston, South Australia, the Rev. William Arthur Dunn, president of Prince Alfred College, architect Hedley Allen Dunn, and embezzler and arsonist Alfred Henry Dunn (c. 1845–1904). George Dunn (Australian politician) George Alexander Dunn (27 March 1859 – 18 July 1925) was an Australian politician who represented the South Australian House of Assembly multi-member seat of Murray from 1915 to 1918, when his colleagues were Maurice Parish and Harry D. Young. He

答案字符位置：[434, 447)。

</details>

<details>
<summary>George Dunn (actor)：完整供应证据</summary>

George Dunn (actor) George Dunn (November 23, 1914 – April 27, 1982) was an American actor, humorist, vaudeville performer, and satirist. He often portrayed Western characters in film and television. His homespun wit, rope tricks, and satirizing of American life, politics, and sports reflected the strong influence Will Rogers had on him as an entertainer. Born Ollen George Dunn in Brownwood, Texas, Dunn made his way to New York City to perform in vaudeville. From there, he went on to Hollywood, where he appeared in twenty five motion pictures and more than one hundred television shows. Some of his appearances

答案字符位置：[33, 50)。

</details>

## 第23题：ambigdocs_49177

**query：** Who directed the film Savithiri?

**term：** Savithiri
**dimension：** Entity Disambiguation
**来源：** 旧第27题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Savithiri (1941 film) | Y. V. Rao | Y. V. Rao |
| Savithiri (1980 film) | Bharathan | Bharathan |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Savithiri (1941 film)：完整供应证据</summary>

Savithiri (1941 film) Savithiri is a 1941 Tamil language film directed by Y. V. Rao. The film featured Y. V. Rao, Shanta Apte, V. A. Chellappa and M. S. Subbulakshmi in the lead roles. Savithiri is a beautiful and chaste princess. Princes in the neighbouring Kingdoms are intimidated by her beauty and purity and no one wants to marry her. Savithiri's father King Aswapati tells her to go out and find her own husband. She finds a young man, Sathyavan, who is the son of a blind king now living in the forest in exile. Savithiri brings the young man

答案字符位置：[74, 83)。

</details>

<details>
<summary>Savithiri (1980 film)：完整供应证据</summary>

Savithiri (1980 film) Savithiri is a 1980 Tamil language drama film directed by Bharathan. A remake of his Malayalam film "Prayanam", "Savithiri" marked his debut in Tamil cinema. The cast includes Vinoth, Menaka, J. V. Ramana Murthi, Manorama, Nanditha Bose and Master Suresh. The screenplay was written by Padmarajan who also scripted the original film. The music was composed by M. S. Viswanathan with lyrics by Kannadasan. The film was a commercial failure. The film became controversial upon release for the depiction of its principal characters who belong to the Brahmin community. This led to widespread protests by members of

答案字符位置：[80, 89)。

</details>

## 第24题：ambigdocs_20780

**query：** When was the Department of Science and Technology established?

**term：** Department of Science and Technology
**dimension：** Entity Disambiguation
**来源：** 旧第28题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Department of Science and Technology (Australia) | November 1980 | November 1980 |
| Department of Science and Technology (India) | May 1971 | May 1971 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Department of Science and Technology (Australia)：完整供应证据</summary>

Department of Science and Technology (Australia) The Department of Science and Technology was an Australian government department that existed between November 1980 and December 1984. The department was created by the Fraser Government, joining the Department of Productivity with the Department of Science and the Environment, having received advice from the Australian Science and Technology Council that there would be merit in merging the two departments. The department was abolished by the Hawke Government in December 1984, making way for the new Department of Industry, Technology and Commerce. Information about the department's functions and/or government funding allocation could be found

答案字符位置：[151, 164)。

</details>

<details>
<summary>Department of Science and Technology (India)：完整供应证据</summary>

Department of Science and Technology (India) The Department of Science and Technology (DST) is a department within the Ministry of Science and Technology in India. It was established in May 1971 to promote new areas of science and technology and to play the role of a nodal department for organising, coordinating and promoting Scientific and Technological activities in the country. It gives funds to various approved scientific projects in India. It also supports various researchers in India to attend conferences abroad and to go for experimental works. Minister of State Dr. Harsh Vardhan is head of the department, while Ashutosh

答案字符位置：[186, 194)。

</details>

## 第25题：ambigdocs_33274

**query：** Who is the artist associated with "On a Night Like This"?

**term：** On a Night Like This (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第29题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| On a Night Like This (Bob Dylan song) | Bob Dylan | Bob Dylan |
| On a Night Like This (concert tour) | Kylie Minogue | Kylie Minogue |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>On a Night Like This (Bob Dylan song)：完整供应证据</summary>

On a Night Like This (Bob Dylan song) "On a Night Like This" is a song written by Bob Dylan and recorded in November 1973. It first appeared on Dylan's 14th studio album, "Planet Waves", as the opening track. It was also released as the lead single from the album and reached #44 on the "Billboard Hot 100" The song later appeared on several Dylan compilation albums including "Biograph", in 1985, and "Dylan" (three-disc version), in 2007. According to Dylan, "On a Night Like This" was not a typical song for him to write, saying that it "comes off as

答案字符位置：[22, 31)。

</details>

<details>
<summary>On a Night Like This (concert tour)：完整供应证据</summary>

On a Night Like This (concert tour) On a Night Like This was the sixth concert tour by Australian recording artist Kylie Minogue, in support of her seventh studio album, "Light Years" (2000). The tour began on 3 March 2001 at the Clyde Auditorium in Glasgow, Scotland and concluded on 15 May 2001 at the Sydney Entertainment Centre in Sydney, Australia. After the success of Minogue's performances at the 2000 Sydney Olympics and the opening ceremony of the Paralympics soon after, details of the tour were announced. Tickets went on sale in November of the same year, establishing her as

答案字符位置：[115, 128)。

</details>

## 第26题：ambigdocs_15896

**query：** When was Bishop Smith elected to his office?

**term：** Bishop Smith
**dimension：** Entity Disambiguation
**来源：** 旧第30题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Harry Lester Smith | 1920 | 1920 |
| William Angie Smith | 1944 | 1944 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Harry Lester Smith：完整供应证据</summary>

Harry Lester Smith Harry Lester Smith was an American Bishop of the Methodist Episcopal Church and The Methodist Church. He was elected to this office by the 1920 M.E. General Conference. In his youth, H. Lester Smith felt the urge to abandon his early choice of an industrial career in the oil fields of Pennsylvania and turn his steps toward educational preparation for ordained ministry. Harry entered Allegheny College in 1900 and served in a student pastorate. The Rev. Harry Lester Smith entered the Pittsburgh Annual Conference of the M.E. Church also in 1900 as a Member On Trial. He

答案字符位置：[158, 162)。

</details>

<details>
<summary>William Angie Smith：完整供应证据</summary>

William Angie Smith William Angie Smith (21 December 1894 – 1974) was a Bishop of The Methodist Church and the United Methodist Church, elected in 1944. William was born 21 December 1894 in Elgin, Texas, the son of William Angie and Mary (Marrs) Smith. William (Jr) married Bess Owens 20 July 1920. They had children William Angie III, Bryant Wesley and Shelby Lee. William (Jr) earned the A.B. degree from Southwestern University in 1917. He was a member of the Kappa Alpha Society. He then studied theology at the Southern Methodist University School of Religion (for one year), the Union

答案字符位置：[147, 151)。

</details>

## 第27题：ambigdocs_10902

**query：** When was Senator Finley born?

**term：** Senator Finley
**dimension：** Entity Disambiguation
**来源：** 旧第31题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| David E. Finley | February 28, 1861 | February 28, 1861 / 28 February 1861 / February 28 1861 / 1861-02-28 |
| Hugh F. Finley | January 18, 1833 | January 18, 1833 / 18 January 1833 / January 18 1833 / 1833-01-18 |
| Jesse J. Finley | November 18, 1812 | November 18, 1812 / 18 November 1812 / November 18 1812 / 1812-11-18 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>David E. Finley：完整供应证据</summary>

David E. Finley David E. Finley (February 28, 1861 – January 26, 1917) was a United States Representative from South Carolina. He was born in Trenton, Arkansas. He attended the public schools of Rock Hill, South Carolina and Ebenezer, South Carolina and was graduated from the law department of South Carolina College (now the University of South Carolina) at Columbia, South Carolina in 1885. He was admitted to the bar in 1886 and commenced practice in York, South Carolina. Finley was member of the South Carolina House of Representatives 1890-1891. He also served in the South Carolina Senate 1892-1896. He

答案字符位置：[33, 50)。

</details>

<details>
<summary>Hugh F. Finley：完整供应证据</summary>

Hugh F. Finley Hugh Franklin Finley (January 18, 1833 – October 16, 1909) was a U.S. Representative from Kentucky, father of Charles Finley. Born at Tyes Ferry, Kentucky, Finley attended the common schools. He engaged in agricultural pursuits. He studied law. He was admitted to the bar in 1859 and commenced practice in Williamsburg, Kentucky. He served as member of the State house of representatives from 1861 to August 1862, when he resigned. Finley was elected Commonwealth attorney in 1862, and served until 1866, when he resigned. Finley was again elected in 1867, and re-elected in 1868 for six years.

答案字符位置：[37, 53)。

</details>

<details>
<summary>Jesse J. Finley：完整供应证据</summary>

Jesse J. Finley Jesse Johnson Finley (November 18, 1812 – November 6, 1904) was a member of the United States House of Representatives from Florida and the mayor of Memphis, Tennessee. He was also a brigadier general in the Confederate Army during the American Civil War. Finley was born near Lebanon, Tennessee. He pursued an academic course. He served as captain of mounted volunteers in the Seminole War in 1836. Finley studied law and was admitted to the bar in 1838. He moved to Mississippi County, Arkansas, in 1840, where he practiced law. Finley served in the State senate in

答案字符位置：[38, 55)。

</details>

## 第28题：ambigdocs_43841

**query：** Who is the artist of the album "Superwoman"?

**term：** Superwoman (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第33题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Superwoman (Paulini album) | Paulini | Paulini |
| Superwoman (Rebecca Ferguson album) | Rebecca Ferguson | Rebecca Ferguson |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Superwoman (Paulini album)：完整供应证据</summary>

Superwoman (Paulini album) Superwoman is the second studio album by Australian recording artist Paulini, released through Sony BMG Australia on 5 August 2006. It is the follow-up to her 2004 debut album, "One Determined Heart". Paulini recorded "Superwoman" in Sydney, London, Los Angeles and Barcelona, and worked with several songwriters and producers, including Matthew Gerrard, Fingaz, Ray Hedges, Colin Emmanuel, Steve Kipner and Jarrad Rogers, among others. The album failed to achieve the commercial success of its predecessor, debuting at number 72 on the ARIA Albums Chart. Its first two singles, "Rough Day" and "So Over You" both performed moderately

答案字符位置：[12, 19)。

</details>

<details>
<summary>Superwoman (Rebecca Ferguson album)：完整供应证据</summary>

Superwoman (Rebecca Ferguson album) Superwoman is the fourth studio album by English singer-songwriter Rebecca Ferguson, released on 14 October 2016 via Syco and Sony Music Entertainment. Prior to the announcement of the album, Ferguson had reportedly been working with producers such as Mark Ronson, Jonny Lattimer and Troy Miller. She is also set to embark on the Superwoman Tour to promote the album, which begins at the Venue Cymru in Llandudno on 23 October 2016. The lead single, "Bones", premiered on the "Ken Bruce" BBC Radio Two show on 1 September 2016. It was officially released on September 2, 2016.

答案字符位置：[12, 28)。

</details>

## 第29题：ambigdocs_8351

**query：** Where is Long Lake Provincial Park located?

**term：** Long Lake Provincial Park
**dimension：** Entity Disambiguation
**来源：** 旧第34题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Long Lake Provincial Park (Alberta) | Alberta, Canada | Alberta, Canada |
| Long Lake Provincial Park (Nova Scotia) | Halifax, Nova Scotia, Canada | Halifax, Nova Scotia, Canada |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Long Lake Provincial Park (Alberta)：完整供应证据</summary>

Long Lake Provincial Park (Alberta) Long Lake Provincial Park is a provincial park located in Alberta, Canada. Long Lake is located one and one half hours from Edmonton along Highway 831, south of the village of Boyle and northeast of the hamlet of Newbrook, within Thorhild County. The park is situated at an elevation of and has a surface of . It was established on March 25, 1957 and is maintained by the Alberta Parks Division of Alberta Environment and Sustainable Resource Development. Recreation activities available at the park include: Camping, Canoeing/Kayaking, Cross Country Skiing, Downhill Skiing, Fishing, Group Use,

答案字符位置：[94, 109)。

</details>

<details>
<summary>Long Lake Provincial Park (Nova Scotia)：完整供应证据</summary>

Long Lake Provincial Park (Nova Scotia) Long Lake Provincial Park is located in Halifax, Nova Scotia, Canada. It was initiated in 1981 by then Premier John Buchanan after Halifax's water supply had been shifted from the Spruce Hill/Long Lake/Chain Lakes watershed to the Pockwock Lake watershed near Hammonds Plains. The park itself constitutes the bulk of these former watershed lands - about 2100 hectares. Other portions were deeded to the municipality of Halifax, and the area around the Chain Lakes is still administered by the Halifax Regional Water Commission, since the Chain Lakes are still the official back-up water supply

答案字符位置：[80, 108)。

</details>

## 第30题：ambigdocs_51603

**query：** Who is the artist associated with the release "Cunning Stunts"?

**term：** Cunning Stunts
**dimension：** Entity Disambiguation
**来源：** 旧第35题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Cunning Stunts (Cows album) | Cows | Cows |
| Cunning Stunts (video) | Metallica | Metallica |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Cunning Stunts (Cows album)：完整供应证据</summary>

Cunning Stunts (Cows album) Cunning Stunts is the fifth studio album by the Minneapolis-based noise rock band Cows, released on September 9, 1992 by Amphetamine Reptile Records. It was their first album where they began developing real melodies and patterns instead of their usual blasts of noise. The switch to producer Iain Burgess brought an increase in sound quality from previous albums. It is no longer in print; however, it is available online at wmp.emusic.com, on Windows Media Player 10 and on iTunes. The title is a spoonerism of the term "stunning cunts". Adapted from the "Cunning Stunts" liner notes.

答案字符位置：[16, 20)。

</details>

<details>
<summary>Cunning Stunts (video)：完整供应证据</summary>

Cunning Stunts (video) Cunning Stunts is a concert video by heavy metal band Metallica released in 1998. It was released in DVD and VHS formats. The title is a spoonerism of the words "stunning cunts". The DVD features concert footage, band interviews, a documentary, behind the scenes footage, and a photo gallery consisting of approximately 1,000 photos. Three of the performances feature multiple angles. During the performance of the song "Enter Sandman", the entire stage is set to appear to collapse and explode, with pyrotechnics and a technician (referred to in the extras as the "Burning Dude") who runs across

答案字符位置：[77, 86)。

</details>

## 第31题：ambigdocs_37527

**query：** When was Permsky formed?

**term：** Permsky
**dimension：** Entity Disambiguation
**来源：** 旧第37题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Perm Krai | December 1, 2005 | December 1, 2005 / 1 December 2005 / December 1 2005 / 2005-12-01 |
| Perm Oblast | 1938 | 1938 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Perm Krai：完整供应证据</summary>

Perm Krai Perm Krai () is a federal subject of Russia (a krai) that came into existence on December 1, 2005 as a result of the 2004 referendum on the merger of Perm Oblast and Komi-Permyak Autonomous Okrug. The city of Perm is the administrative center. Population: 2,635,276 (2010 Census). Komi-Permyak Okrug retained its autonomous status within Perm Krai during the transitional period of 2006–2008. It also retained a budget separate from that of the krai, keeping all federal transfers. Starting in 2009, Komi-Permyak Okrug's budget became subject to the budgeting law of Perm Krai. The transitional period was implemented

答案字符位置：[91, 107)。

</details>

<details>
<summary>Perm Oblast：完整供应证据</summary>

Perm Oblast Until December 1, 2005, Perm Oblast () was a federal subject of Russia (an oblast) in Privolzhsky (Volga) Federal District. According to the results of the referendum held in October 2004, Perm Oblast was merged with Komi-Permyak Autonomous Okrug to form Perm Krai. It was established in 1938 as part of the RSFSR. From 1940 to 1957 it was named Molotov Oblast in honor of Vyacheslav Molotov. The oblast was named after its administrative center, the city of Perm. The oblast covered an area of 160,600 km², and as of the 2002 Census its population was 2,819,421. Before

答案字符位置：[300, 304)。

</details>

## 第32题：ambigdocs_50648

**query：** Who is the artist of the album "One Second"?

**term：** One Second
**dimension：** Entity Disambiguation
**来源：** 旧第38题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| One Second (Paradise Lost album) | Paradise Lost | Paradise Lost |
| One Second (Yello album) | Yello | Yello |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>One Second (Paradise Lost album)：完整供应证据</summary>

One Second (Paradise Lost album) One Second is the sixth album release by Paradise Lost. Following "Draconian Times", the album reflected the group's first complete departure from doom metal in favour of a more gothic direction. "One Second" is Paradise Lost's first album recorded in digital format. Two songs were written and left out for this album are "The Hour" & "Slave" have not been released on any of the reissues of this album, but are on the second version of the single "One Second". The song "Mercy" has been alternately covered by Orphaned Land, on multiple releases, but the

答案字符位置：[12, 25)。

</details>

<details>
<summary>One Second (Yello album)：完整供应证据</summary>

One Second (Yello album) One Second is Yello's fifth original studio album, having been preceded by a 'new mix' compilation the previous year. Released in 1987, the album is noteworthy for featuring both Billy MacKenzie and Shirley Bassey, the latter singing vocals on "The Rhythm Divine". The songs "Call It Love", "Si Senor The Hairy Grill", "Moon On Ice", "Hawaiian Chance" were used on episodes of "Miami Vice" and the song "Santiago" used as a sample from Dunya Yunis' "Abu Zeluf". A couple of songs were also used in the 1990 film "Nuns on the Run". The song "Si Senor

答案字符位置：[12, 17)。

</details>

## 第33题：ambigdocs_3600

**query：** When was the North Western Road Car Company formed?

**term：** North Western Road Car Company
**dimension：** Entity Disambiguation
**来源：** 旧第40题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| North Western Road Car Company (1923) | 1923 | 1923 |
| North Western Road Car Company (1986) | 1986 | 1986 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>North Western Road Car Company (1923)：完整供应证据</summary>

North Western Road Car Company (1923) The North Western Road Car Company was a bus company in Stockport, England, formed in 1923 from the existing bus services of the British Automobile Traction Company Limited (itself a subsidiary of the British Electric Traction Company Limited) in Macclesfield. The company operated bus services in five counties (Cheshire, Lancashire, West Riding of Yorkshire, Derbyshire and Staffordshire) through a combination of growth and the acquisition of other bus companies, such as the takeover in 1924 of the Mid-Cheshire Motor Bus Company Limited, which brought new operations in Northwich and Flixton. The company also operated

答案字符位置：[32, 36)。

</details>

<details>
<summary>North Western Road Car Company (1986)：完整供应证据</summary>

North Western Road Car Company (1986) North Western Road Car Company was a bus operator based in Liverpool, England. The company operated between 1986 and 1998. In the lead up to the privatisation of the National Bus Company, in 1986 the government stipulated that the larger business units be split to boost competition. Thus Ribble Motor Services whose operations stretched across North West England from Cumbria to the East Lancashire/West Yorkshire borders and Greater Manchester to West Lancashire/North Merseyside was one such company, and in the summer of 1986 its Merseyside - Aintree and Bootle, West Lancashire - Skelmersdale and

答案字符位置：[32, 36)。

</details>

## 第34题：ambigdocs_8893

**query：** What sport is Kevin Porter associated with?

**term：** Kevin Porter
**dimension：** Entity Disambiguation
**来源：** 旧第42题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Kevin Porter (American football) | American football | American football |
| Kevin Porter (basketball) | basketball | basketball / Basketball |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Kevin Porter (American football)：完整供应证据</summary>

Kevin Porter (American football) Kevin Porter (born April 11, 1966) is an American football coach and former player. He is the head football coach at Fort Valley State University in Fort Valley, Georgia, a position he had held since the 2016 season. Port played professionally as a defensive back for the Kansas City Chiefs and New York Jets in the National Football League (NFL). He served as the head coach for the Kansas City Brigade of the Arena Football League from 2006 to 2008, compiling a record of 13–20, including a 0–1 mark in the postseason. In 2010, he was

答案字符位置：[14, 31)。

</details>

<details>
<summary>Kevin Porter (basketball)：完整供应证据</summary>

Kevin Porter (basketball) Kevin Porter (born April 17, 1950) is a retired American professional basketball player. He played ten seasons in the National Basketball Association (NBA) and led the league in assists in four of those seasons. Born and raised in Chicago, Illinois, Porter graduated from DuSable High School, then played point guard at Saint Francis University in Loretto, Pennsylvania. He played ten seasons (1972–1981; 1982–1983) in the NBA as a member of the Baltimore/Capital/Washington Bullets, Detroit Pistons, and New Jersey Nets. One of the most talented passers in league history, Porter led the league in both assists per game

答案字符位置：[14, 24)。

</details>

## 第35题：ambigdocs_46309

**query：** When was the Red Covered Bridge constructed?

**term：** Red Covered Bridge
**dimension：** Entity Disambiguation
**来源：** 旧第43题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Red Covered Bridge (Morristown, Vermont) | 1896 | 1896 |
| Red Covered Bridge (Rosedale, Indiana) | 1880 | 1880 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Red Covered Bridge (Morristown, Vermont)：完整供应证据</summary>

Red Covered Bridge (Morristown, Vermont) The Red Covered Bridge is a historic covered bridge, carrying Cole Hill Road across Sterling Brook in Morristown, Vermont. Built in 1896, it is the only surviving 19th-century covered bridge in the town, and one of the last to be built during the historic period of covered bridge construction in the state. It is of queen post truss design, and was listed on the National Register of Historic Places in 1974. The Red Covered Bridge is located in a rural area of southwestern Morristown, just north of the junction of Cole Hill Road, Sterling Valley

答案字符位置：[173, 177)。

</details>

<details>
<summary>Red Covered Bridge (Rosedale, Indiana)：完整供应证据</summary>

Red Covered Bridge (Rosedale, Indiana) The Red Covered Bridge was east of Rosedale, Indiana. The double-span Burr Arch covered bridge structure was built by J. J. Daniels in 1880 and destroyed by arson on October 13, 1976. On March 10, 1880, the Parke County Commissioners advertised that they would be taking bids for a bridge to be built at Newcombs Ford in Florida Township. On May 14, 1880, the bids that had been turned in were opened. Richard Epperson had placed a bid for $8,700 and J. J. Daniels had placed two bids with different plans, plan #1 was for

答案字符位置：[174, 178)。

</details>

## 第36题：ambigdocs_4172

**query：** Where is the Douglas County School District located?

**term：** Douglas County School District (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第44题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Douglas County School District | Douglas County, Georgia, US | Douglas County, Georgia, US |
| Douglas County School District RE-1 | Douglas County, Colorado | Douglas County, Colorado |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Douglas County School District：完整供应证据</summary>

Douglas County School District Douglas County School District is a public school district in Douglas County, Georgia, US, based in Douglasville. It serves the communities of Austell, Douglasville, Lithia Springs, Villa Rica, and Winston, Georgia. The Douglas County School District is the seventeenth largest district in Georgia. The school district's central administrative offices are in Douglas County, where graduates can access their records and transcripts, and where all major decisions about the schools are made. Superintendent: Trent North Chief Academic Officer: Pam Nail Athletics: James Strong Financial Services: Greg Denney Community Relations: Karen Stroud & Portia Lake Asst. Superintendent of

答案字符位置：[93, 120)。

</details>

<details>
<summary>Douglas County School District RE-1：完整供应证据</summary>

Douglas County School District RE-1 Douglas County School District Re. 1 is a school district that serves Douglas County, Colorado. The district was formed in 1958 by the consolidation of 17 smaller school districts, adding the "Re. 1" to its name to note the district's first reorganization. In 2017, the district announced a partnership with Arapahoe Community College and Colorado State University to build a $40 million campus in Castle Rock, Colorado. The Douglas County School District is a central feature of the documentary "Education Inc.", which includes information on the pro-charter school and pro-voucher school board majority was elected

答案字符位置：[106, 130)。

</details>

## 第37题：ambigdocs_50017

**query：** Who is the artist of the "Baby I'm Yours" release?

**term：** Baby I'm Yours
**dimension：** Entity Disambiguation
**来源：** 旧第45题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Baby I'm Yours (EP) | Math and Physics Club | Math and Physics Club |
| Baby I'm Yours (album) | Maureen McGovern | Maureen McGovern |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Baby I'm Yours (EP)：完整供应证据</summary>

Baby I'm Yours (EP) Baby I'm Yours is the third EP from Seattle, Washington indie pop band Math and Physics Club. Producer/engineer Kevin Suggs at Avast! Studio produced the first three songs on the EP, the fourth was produced by the band's bassist Ethan Jones. The song "A Little Romance" from the "Matinee Hit Parade" compilation was also recorded during these EP sessions. A reviewer in Left Hip Magazine calls "Baby I'm Yours" "the finest Math and Physics Club release yet." A review of the album on the website Three Imaginary Girls states, "the band is the master of its

答案字符位置：[91, 112)。

</details>

<details>
<summary>Baby I'm Yours (album)：完整供应证据</summary>

Baby I'm Yours (album) Baby I'm Yours is Maureen McGovern's eighth studio album (and first in three years), released in 1992. This is a cover album of 15 songs from the years 1955 to 1970. Inside the album cover are notes that McGovern made about her youth in Youngstown, Ohio and specific notes on all of the selected songs on the album and how they are meaningful to her. The seventh track is a medley of two songs by the Beatles. Other songs include three songs by Burt Bacharach and Hal David (two of which were made popular by Dionne

答案字符位置：[41, 57)。

</details>

## 第38题：ambigdocs_43564

**query：** When was Zhang Xiaobin born?

**term：** Zhang Xiaobin
**dimension：** Entity Disambiguation
**来源：** 旧第46题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Zhang Xiaobin (footballer, born 1985) | February 14, 1985 | February 14, 1985 / 14 February 1985 / February 14 1985 / 1985-02-14 |
| Zhang Xiaobin (footballer, born 1993) | 23 October 1993 | 23 October 1993 / October 23, 1993 / October 23 1993 / 1993-10-23 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Zhang Xiaobin (footballer, born 1985)：完整供应证据</summary>

Zhang Xiaobin (footballer, born 1985) Zhang Xiaobin (; born February 14, 1985 in Zhangjiakou, Hebei) is a Chinese footballer. Zhang Xiaobin began his career as an attacking midfielder for the various Shaanxi Guoli youth teams. In 2001, when Shaanxi Guoli sent its youth team to train in Stockport, England, the club Stockport County F.C. would be impressed by the 16-year-old Zhang and take him on loan. While at Stockport Zhang spent three years rising through the youth and then reserve teams, however he was unable to break into the first team. After being unable to obtain a position on the

答案字符位置：[60, 77)。

</details>

<details>
<summary>Zhang Xiaobin (footballer, born 1993)：完整供应证据</summary>

Zhang Xiaobin (footballer, born 1993) Zhang Xiaobin (; born 23 October 1993) is a Chinese footballer who plays for Jiangsu Sainty in the Chinese Super League. Zhang Xiaobin started his football career with Jiangsu Sainty during the 2014 season after playing for Jiangsu Youth during the 2011 season and the 2012 season. On 23 July 2014, Zhang made his debut for Jiangsu Sainty in the 2014 Chinese FA Cup against Lijiang Jiayunhao, coming on as a substitute for Ji Xiang. On 26 October 2014, he made his Super League debut in the 2014 Chinese Super League against Shanghai East Asia.

答案字符位置：[60, 75)。

</details>

## 第39题：ambigdocs_24260

**query：** Who led the attacking forces during the Siege of Hulst?

**term：** Siege of Hulst
**dimension：** Entity Disambiguation
**来源：** 旧第48题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Siege of Hulst (1591) | Maurice of Orange | Maurice of Orange |
| Siege of Hulst (1596) | Archduke Albert | Archduke Albert |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Siege of Hulst (1591)：完整供应证据</summary>

Siege of Hulst (1591) The Siege of Hulst was a siege of the city of Hulst that took place between 20–24 September 1591 by a Dutch and English army under the leadership of Maurice of Orange during the Eighty Years' War and the Anglo–Spanish War. The siege was part of Maurice's famous campaign of 1591. In early 1591 Maurice with his army had launched a campaign against the cities of Zutphen, Deventer and Delfzijl having forced the Spanish garrisons there to surrender. The army included sixteen English ensigns under Sir Francis Vere and ten Scots ensigns under Colonel Balfour. The

答案字符位置：[171, 188)。

</details>

<details>
<summary>Siege of Hulst (1596)：完整供应证据</summary>

Siege of Hulst (1596) The Siege of Hulst of 1596 was a Spanish victory led by Archduke Albert that took place between mid-July and August 18, 1596, at the city of Hulst, Province of Zeeland, Low Countries (present-day the Netherlands), during the Eighty Years' War, the Anglo-Spanish War (1585–1604). After a short siege, during which Maurice of Orange launched a failed attempt to relieve the city – the garrison of Dutch and English troops fell into Spanish hands on August 18, 1596. From 1590 until 1594 the Dutch under the leadership of Maurice of Orange had achieved great military successes

答案字符位置：[78, 93)。

</details>

## 第40题：ambigdocs_48437

**query：** In what year was the album "Aretha" released?

**term：** Aretha (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第50题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Aretha (1980 album) | 1980 | 1980 |
| Aretha (1986 album) | 1986 | 1986 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Aretha (1980 album)：完整供应证据</summary>

Aretha (1980 album) Aretha is the twenty-sixth studio album by American singer Aretha Franklin. It was released on September 30, 1980 by Arista Records. This was the second album with this title to be released by the artist, and her first ever for Arista after a 12-year tenure with Atlantic Records Franklin's first Arista single release, "United Together", reached number 3 on the Soul chart and crossed over to number 56 on "Billboard"s Hot 100. The album itself peaked at number 47 and spent 30 weeks on the "Billboard" 200, eventually selling close to 350,000 copies.The disc's opening track, "Come

答案字符位置：[8, 12)。

</details>

<details>
<summary>Aretha (1986 album)：完整供应证据</summary>

Aretha (1986 album) Aretha is the thirty-first studio album by American singer Aretha Franklin, originally released in 1986, on Arista Records. It is the third album with the "Aretha" title to be released by Franklin, following her and 1980 album. As with Franklin's previous album, "Who's Zoomin' Who?", "Aretha" was produced mainly by Narada Michael Walden and includes her duet with George Michael, "I Knew You Were Waiting (For Me)", which became Franklin's first #1 Pop single since "Respect" in 1967, and would also be her last. The album also yielded three other hit singles: "Jimmy Lee", "Rock-A-Lott" and a

答案字符位置：[8, 12)。

</details>

## 第41题：ambigdocs_42466

**query：** What sport is Willie Jackson associated with?

**term：** Willie Jackson
**dimension：** Entity Disambiguation
**来源：** 旧第51题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Willie Jackson (American football) | football | football / Football |
| Willie Jackson (basketball) | basketball | basketball / Basketball |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Willie Jackson (American football)：完整供应证据</summary>

Willie Jackson (American football) Willie Bernard Jackson, Jr. (born August 16, 1971) is an American former professional football wide receiver in the National Football League (NFL) for the Dallas Cowboys, Jacksonville Jaguars, Cincinnati Bengals, New Orleans Saints, Atlanta Falcons and Washington Redskins. He played college football at the University of Florida. Jackson was born in Gainesville, Florida in 1971. He attended P. K. Yonge High School in Gainesville, where he was standout high school football player for the P. K. Yonge Blue Wave. He played as a quarterback, running back, wingback and defensive back. He received All-state honors as a

答案字符位置：[25, 33)。

</details>

<details>
<summary>Willie Jackson (basketball)：完整供应证据</summary>

Willie Jackson (basketball) Willie Jackson is an American former college basketball stand-out and current high school head coach. Jackson grew up in Webster Parish, Louisiana and attended Sibley High School from 1976–77 to 1979–80. During his junior and senior years, Sibley won 100 straight games, including a perfect 58–0 season in 1979–80 which ended with a state championship. Willie Jackson decided to stay in Louisiana and signed to play at Centenary College of Louisiana, an NCAA Division I institution. He played basketball all four seasons and graduated as the most prolific scorer in both school and Trans America Athletic Conference

答案字符位置：[16, 26)。

</details>

## 第42题：ambigdocs_11279

**query：** When was Billy Williamson born?

**term：** Billy Williamson
**dimension：** Entity Disambiguation
**来源：** 旧第52题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Billy Williamson (footballer, born 1922) | 1922 | 1922 |
| Billy Williamson (footballer, born 1952) | 29 September 1952 | 29 September 1952 / September 29, 1952 / September 29 1952 / 1952-09-29 |
| Billy Williamson (guitarist) | February 9, 1925 | February 9, 1925 / 9 February 1925 / February 9 1925 / 1925-02-09 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Billy Williamson (footballer, born 1922)：完整供应证据</summary>

Billy Williamson (footballer, born 1922) Billy Williamson (1922 – 2006) was a Scottish professional footballer, who played for Rangers, St Mirren and Stirling Albion. Williamson played for local junior clubs Kirkintilloch Rob Roy and Petershill before signing for Rangers in 1941. He served with the Royal Navy as a PE instructor during the Second World War, while also playing for Rangers and as a guest for Manchester City. He became a regular in the Rangers first team in the 1945/46 season. Williamson played and scored in the first Scottish League Cup final, in 1947. He also won two Scottish league

答案字符位置：[35, 39)。

</details>

<details>
<summary>Billy Williamson (footballer, born 1952)：完整供应证据</summary>

Billy Williamson (footballer, born 1952) William Davidson Williamson (born 29 September 1952) is a Scottish former professional footballer who played for Kirkconnel F.C., Aberdeen F.C., Dundee United and Dundee. Williamson played in two Scottish League Cup Finals winning the trophy once. Billy Williamson was born in Dumfries. He scored 25 goals in what he played for Kirkconnel F.C. in the 1969/70 season. Billy Williamson joined Aberdeen in 1969. In 1975 Billy Williamson scored a hat-trick for Aberdeen in the 3-2 win against Celtic when playing at the time in midfield. He became only the second player at the time to

答案字符位置：[75, 92)。

</details>

<details>
<summary>Billy Williamson (guitarist)：完整供应证据</summary>

and "Caroline's Pony". He co-wrote the song "Teenage Love Affair" for the Cook Brothers, who released it as a single on Arcade Records in 1960. Billy Williamson (guitarist) William F. Williamson (February 9, 1925 – March 22, 1996) was the American steel guitar player for Bill Haley and His Saddlemen, and its successor group Bill Haley & His Comets, from 1949 to 1963. A founding member of both the Saddlemen and the Comets, Williamson often acted as the band's emcee and comic relief during live concerts; he also played lead guitar on occasion. He was with the band when they

答案字符位置：[196, 212)。

</details>

## 第43题：ambigdocs_41606

**query：** When did the Atlantic League operate?

**term：** Atlantic League (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第53题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Atlantic League (1896–1900) | 1896 and 1900 | 1896 and 1900 |
| Atlantic League (1914) | 1914 | 1914 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Atlantic League (1896–1900)：完整供应证据</summary>

Atlantic League (1896–1900) "This article refers to the original incarnation of the Atlantic League, which operated between 1896 and 1900. For the modern league, see Atlantic League of Professional Baseball" The Atlantic League was a minor league baseball organization that operated between 1896 and 1900 in the Northeastern United States. The name has subsequently been reused twice, for another short-lived league in 1914, and for a modern, independent minor league. The first Atlantic League lasted from 1896–1900 and was the successor of the Pennsylvania State League, 1892-1895. In 1896 New Haven moved to Lancaster on July 3, while New York

答案字符位置：[124, 137)。

</details>

<details>
<summary>Atlantic League (1914)：完整供应证据</summary>

Atlantic League (1914) The second Atlantic League was a class D minor league baseball league which lasted one year in 1914. The league had been known as the New York–New Jersey League a season earlier. The title was won by the Poughkeepsie Honey Bugs. Internal politics and poor financial agreements hindered the league, which made it to the year's end, but folded before it could play another season. It was unrelated, except for name, to the first league with the name. The name has subsequently been used for a modern, independent minor league. Bloomfield-Long Branch moved to Asbury Park July

答案字符位置：[17, 21)。

</details>

## 第44题：ambigdocs_318

**query：** Who is the artist of the album "Little Victories"?

**term：** Little Victories
**dimension：** Entity Disambiguation
**来源：** 旧第54题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Little Victories (Beccy Cole album) | Beccy Cole | Beccy Cole |
| Little Victories (Strypes album) | The Strypes | The Strypes |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Little Victories (Beccy Cole album)：完整供应证据</summary>

Little Victories (Beccy Cole album) Little Victories is the third studio album by Australian country music singer Beccy Cole. It was released in January 2003 and peaked at number 29 on the ARIA Charts. The album was certified gold in 2005. At the ARIA Music Awards of 2003, the album was nominated for ARIA Award for Best Country Album, losing out to "Golden Road" by Keith Urban. Cole began work on "Little Victories" after winning her second Golden Guitar at the 2002 Country Music Awards of Australia. The success of "Wild at Heart" had meant the label had increased Cole's

答案字符位置：[18, 28)。

</details>

<details>
<summary>Little Victories (Strypes album)：完整供应证据</summary>

Little Victories (Strypes album) Little Victories is the second studio album by Irish rock band The Strypes, released on July 15, 2015. The album received moderate to negative reviews despite the success of their previous album Snapshot. Tim Jonze of the Guardian rated the album 2 out of 5 stars. In his review, Jonze said The Strypes had only advanced to 2005 in quality. Metacritic scored the album with a 61/100, based on 7 critical reviews. Q Magazine ranked the album positively with an 80. In their review, the writers at Q said, "It's their broadening of the musical palette

答案字符位置：[96, 107)。

</details>

## 第45题：ambigdocs_59545

**query：** Who is the artist of the album "Sonic Jihad"?

**term：** Sonic Jihad
**dimension：** Entity Disambiguation
**来源：** 旧第55题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Sonic Jihad (Paris album) | Paris | Paris |
| Sonic Jihad (Snake River Conspiracy album) | Snake River Conspiracy | Snake River Conspiracy |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Sonic Jihad (Paris album)：完整供应证据</summary>

Sonic Jihad (Paris album) Sonic Jihad is the fifth studio album by rapper Paris, released in 2003, recorded, mixed and mastered at Data Stream Studio in San Francisco. Bonus Track (The Deluxe Edition) In 2006 a fan of the video game "Battlefield 2", referring to himself as "SonicJihad" after Paris' album, posted a montage of clips from the game, edited with audio excerpts from the movie "" and other sources. The video was viewed with alarm by members of the United States House Permanent Select Committee on Intelligence, which held an open hearing on 4 May 2006 entitled "Terrorist Use

答案字符位置：[13, 18)。

</details>

<details>
<summary>Sonic Jihad (Snake River Conspiracy album)：完整供应证据</summary>

Sonic Jihad (Snake River Conspiracy album) Sonic Jihad is Snake River Conspiracy's only full-length album, released in 2000. It includes three cover songs: T-Ride's "You and Your Friend" (former band of co-producer Eric Valentine), The Cure's "Lovesong" and The Smiths' "How Soon Is Now." The album garnered mostly positive reviews from critics, who praised the album's lyrics and singer Tobey Torres's vocals. The album spawned three singles: "Vulcan," "How Soon is Now," and "Breed." The latter two charted in the US. The album has a Parental Advisory for obscenity and mature themes. "Breed" is featured in the 2001 film "Valentine"

答案字符位置：[13, 35)。

</details>

## 第46题：ambigdocs_43863

**query：** Where was Justice Knudson born?

**term：** Justice Knudson
**dimension：** Entity Disambiguation
**来源：** 旧第57题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Harvey B. Knudson | Finley, North Dakota | Finley, North Dakota |
| Oscar Knutson | Superior, Wisconsin | Superior, Wisconsin |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Harvey B. Knudson：完整供应证据</summary>

Harvey B. Knudson Harvey B. Knudson (June 26, 1903 – June 29, 1978) was an American attorney and Justice on the North Dakota Supreme Court from 1965 to 1975. Harvey Knudson was born in Finley, North Dakota. He was the son of Enok Knudson (1869-1946) and Josephine Emilia (Hansen) Knudson (1866-1950), both of whom were of Norwegian heritage. He attended elementary and high school in Finley. He received his law degree from the University of North Dakota School of Law in 1931 and started a practice in Finley, where he remained until 1937. In 1937 he moved to Mayville, North

答案字符位置：[185, 205)。

</details>

<details>
<summary>Oscar Knutson：完整供应证据</summary>

Oscar Knutson Oscar R. Knutson (October 9, 1899 – June 15, 1981) was an American lawyer and judge from Minnesota. Oscar Rudolph Knutson was born in Superior, Wisconsin. He was the son of Bottolf Knutson (1865-1940) and Rachel (Satren) Knutson (1864-1929), both of whom were immigrants from Norway. The son of immigrant parents, he did not learn to speak English until he entered school. He graduated from Warren, Minnesota High School in 1920 and attended St. Olaf College and the Northwestern School of Agriculture (now University of Minnesota Crookston), graduating from the University of Minnesota Law School in 1927. Knutson

答案字符位置：[148, 167)。

</details>

## 第47题：ambigdocs_23548

**query：** Who is the director of the film "Malombra"?

**term：** Malombra
**dimension：** Entity Disambiguation
**来源：** 旧第58题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Malombra (1917 film) | Carmine Gallone | Carmine Gallone |
| Malombra (1942 film) | Mario Soldati | Mario Soldati |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Malombra (1917 film)：完整供应证据</summary>

Malombra (1917 film) Malombra is a 1917 silent Italian drama film directed by Carmine Gallone. The film was shown as part of the Silent Divas of the Italian Cinema programme at the 38th New York Film Festival in 2000. It is an adaptation of the 1881 novel "Malombra" by Antonio Fogazzaro, which was later adapted into a 1942 film of the same name. Marina di Malombra (Borelli) lives in a castle prior to her wedding. She begins to read letters written by an ancestor called Cecilia. She finds out that Cecilia was driven to her death by her uncle. Marina

答案字符位置：[78, 93)。

</details>

<details>
<summary>Malombra (1942 film)：完整供应证据</summary>

Malombra (1942 film) Malombra is a 1942 Italian drama film directed by Mario Soldati and starring Isa Miranda, Andrea Checchi and Irasema Dilián. It is based on the novel "Malombra" by Antonio Fogazzaro, which had previously been adapted into a 1917 silent film of the same title. It was made at Cinecittà with sets designed by Gino Brosio. It was produced by Riccardo Gualino's Lux Film. The film is a gothic melodrama, set in the castle on the edge of Lake Como during the Nineteenth century. The movie was shot in the Villa Pliniana, Torno (Como). (Info by the Dizionario

答案字符位置：[71, 84)。

</details>

## 第48题：ambigdocs_1062

**query：** Who is the creator of Luck of the Draw?

**term：** Luck of the Draw
**dimension：** Entity Disambiguation
**来源：** 旧第60题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Luck of the Draw (album) | Bonnie Raitt | Bonnie Raitt |
| Luck of the Draw (board game) | Donald W. Scott | Donald W. Scott |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Luck of the Draw (album)：完整供应证据</summary>

Luck of the Draw (album) Luck of the Draw is the eleventh album by Bonnie Raitt, released in 1991. After being nominated for Grammy awards in four different categories for the album "Nick of Time", Raitt went for a creative retreat in Northern California to begin work on "Luck of the Draw". "I did it on purpose to see if I could come up with anything," Raitt said in 1991. "In case I won, I wanted to make sure that I had done some writing and didn't feel that "Nick of Time" was a fluke. I didn't want to win

答案字符位置：[67, 79)。

</details>

<details>
<summary>Luck of the Draw (board game)：完整供应证据</summary>

Luck of the Draw (board game) Luck of the Draw is a drawing game published in 2006. Distinguishing it from other games in the genre, all players draw the same subject and advancement is effected by voting for the most appropriate drawing in various categories rather than guessing a subject. Because the categories are not directly related to artistic skill, players with advanced drawing ability are not favored. The game was conceptualized by Donald W. Scott and is produced under license by Gamewright. Luck of the Draw includes: The objective is to collect the most category cards. Gameplay consists of

答案字符位置：[445, 460)。

</details>

## 第49题：ambigdocs_36715

**query：** Who is the artist of the album "Sound the Alarm"?

**term：** Sound the Alarm
**dimension：** Entity Disambiguation
**来源：** 旧第63题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Sound the Alarm (Howie Day album) | Howie Day | Howie Day |
| Sound the Alarm (Saves the Day album) | Saves the Day | Saves the Day |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Sound the Alarm (Howie Day album)：完整供应证据</summary>

Sound the Alarm (Howie Day album) Sound the Alarm is the third full-length album by American singer-songwriter Howie Day, and the follow-up to his million-selling second album "Stop All the World Now". It was recorded over a three-year period, during which he attended a rehabilitation center for alcohol abuse. The album was originally set for release in 2008 before being delayed and eventually released by Epic Records on September 8, 2009. In late 2008, Day uploaded the song "Everyone Loves to Love a Lie" onto his MySpace page. The album was also preceded by a three-song EP, entitled "Be There",

答案字符位置：[17, 26)。

</details>

<details>
<summary>Sound the Alarm (Saves the Day album)：完整供应证据</summary>

Sound the Alarm (Saves the Day album) Sound the Alarm is the fifth studio album by American rock band Saves the Day. After signing to major label DreamWorks Records, the band released "In Reverie" in late 2003. Shortly afterwards DreamWorks Records was absorbed by Interscope Records, resulting in the band being dropped from label. After completing some songs in early 2005, the band was aiming to record in May, hoping to release the album in the fall. Pre-production took place in early August with recording being done at the band's own studio, Electric Ladybug Studios with Steve Evetts as the

答案字符位置：[17, 30)。

</details>

## 第50题：ambigdocs_25103

**query：** When was Horizon High School established?

**term：** Horizon High School
**dimension：** Entity Disambiguation
**来源：** 旧第64题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Horizon High School (Scottsdale, Arizona) | 1980 | 1980 |
| Horizon High School (Texas) | 2002-2003 | 2002-2003 |
| Horizon High School (Thornton, Colorado) | 1988 | 1988 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Horizon High School (Scottsdale, Arizona)：完整供应证据</summary>

Horizon High School (Scottsdale, Arizona) Horizon High School is a public high school in Scottsdale, Arizona in the Paradise Valley Unified School District. The school was established in 1980. The current principal is Linda Ihnat. About 2,200 students are enrolled in the school. In 1978 the Paradise Valley Unified School District commissioned the Architecture Firm of Michael and Kemper Goodwin Ltd. to design the new 6 building campus. Construction began the following year and was undertaken by the Del E. Webb Corporation and was nearly completed when the school opened in August 1980. The school's Auditorium was constructed in 1983.

答案字符位置：[187, 191)。

</details>

<details>
<summary>Horizon High School (Texas)：完整供应证据</summary>

Horizon High School (Texas) Horizon High School is a public school in Horizon City, Texas (United States). It is part of the Clint Independent School District. Horizon High School is Located in Horizon City, Texas.The school first opened its doors as Horizon Middle School, In its first year 2002-2003.The campus served as a middle school with grades 7, 8, and 9. In the years 2003-2004, grade 10 was added to the school, becoming Horizon Middle/High School. Horizon gradually started becoming a high school by the year 2005-2006, when Horizon Middle School moved to its own location and now is serving

答案字符位置：[292, 301)。

</details>

<details>
<summary>Horizon High School (Thornton, Colorado)：完整供应证据</summary>

swimming, tennis, track and field, volleyball and wrestling. State championship titles: Horizon High School is known throughout the Adams 12 District for its drama program. The school features the second largest auditorium in the district, seating over 700 people. Since its opening in 1988, there have been almost 20 musicals performed, over 44 plays and several one-acts. Horizon High School is host to a student run newspaper, "The Horizon Profile". The paper features news, features, and opinion writing. The "Profile" is published monthly for seven months throughout the school year. It is offered as a class that is open to

答案字符位置：[286, 290)。

</details>

## 第51题：ambigdocs_47107

**query：** When was Matthew Walker born?

**term：** Matthew Walker
**dimension：** Entity Disambiguation
**来源：** 旧第65题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Matthew Walker (American actor) | October 13, 1968 | October 13, 1968 / 13 October 1968 / October 13 1968 / 1968-10-13 |
| Matthew Walker (Canadian actor) | 11 April 1942 | 11 April 1942 / April 11, 1942 / April 11 1942 / 1942-04-11 |
| Matthew Walker (English cricketer) | 2 January 1974 | 2 January 1974 / January 2, 1974 / January 2 1974 / 1974-01-02 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Matthew Walker (American actor)：完整供应证据</summary>

Matthew Walker (American actor) Mathew D. Walker (born October 13, 1968) is an American film and television actor and television director. Walker was born in Santa Monica, California. He has been acting professionally since the age of 17, when he appeared in a Disney Movie of the Week in 1986. Since then he has made his living appearing in numerous television shows, feature films, commercials and live venues across the country. At age 19 he was cast as a series regular on the ABC drama "Supercarrier", starring Wendie Malick, Paul Gleason and Richard Jaeckel. Co-starring roles soon followed in the

答案字符位置：[55, 71)。

</details>

<details>
<summary>Matthew Walker (Canadian actor)：完整供应证据</summary>

Matthew Walker (Canadian actor) Matthew Walker (born 11 April 1942) is an English film and television actor best known for his role in Little Women. He appeared in many Canadian television productions in the 1990s and 2000s. He played Father Mac in 22 episodes of the television series "Hope Island", and Max Asher in 11 episodes of "MythQuest". He also played the recurring character Ian MacLeod, the father of Duncan MacLeod in "", Father Perry in "Mysterious Ways" and Merlin in the "Stargate" television franchise. In 2007, he was nominated for a Leo Award for "Best Supporting Performance by a

答案字符位置：[53, 66)。

</details>

<details>
<summary>Matthew Walker (English cricketer)：完整供应证据</summary>

Matthew Walker (English cricketer) Matthew Jonathan Walker (born 2 January 1974), known as Matt Walker, is a retired English professional cricketer who is currently the head coach of Kent County Cricket Club. Walker was appointed as head coach in January 2017 having been assistant coach at the county since the 2014 season. He played for Kent for 16 seasons until 2008 and then for three seasons for Essex until he retired in 2011. Walker was born in Gravesend and, after enjoying a prolific school cricket record at The King's School, Rochester, made his first appearance for Kent in a Second

答案字符位置：[65, 79)。

</details>

## 第52题：ambigdocs_23753

**query：** When was Sultan Murad born?

**term：** Sultan Murad
**dimension：** Entity Disambiguation
**来源：** 旧第66题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Murad III | 4 July 1546 | 4 July 1546 / July 4, 1546 / July 4 1546 / 1546-07-04 |
| Murad IV | 26/27 July 1612 | 26/27 July 1612 |
| Murad I | 29 June 1326 | 29 June 1326 / June 29, 1326 / June 29 1326 / 1326-06-29 |
| Murad V | 21 September 1840 | 21 September 1840 / September 21, 1840 / September 21 1840 / 1840-09-21 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Murad III：完整供应证据</summary>

Murad III Murad III (Ottoman Turkish: مراد ثالث "Murād-i sālis", Turkish: "III.Murat") (4 July 1546 – 15/16 January 1595) was the Sultan of the Ottoman Empire from 1574 until his death in 1595. Born in Manisa on 4 July 1546, Şehzade Murad was the oldest son of Sultan Selim II and Afife Nurbanu Sultan. After his ceremonial circumcision in 1557, Murad was appointed "sancakbeyi" of Akşehir by Suleiman I (his grandfather) in 1558. At the age of 18 he was appointed "sancakbeyi" of Saruhan. Suleiman died when Murad was 22, and his father became the new sultan. Selim II broke

答案字符位置：[88, 99)。

</details>

<details>
<summary>Murad IV：完整供应证据</summary>

Murad IV Murad IV (, "Murād-ı Rābiʿ"; 26/27 July 1612 – 8 February 1640) was the Sultan of the Ottoman Empire from 1623 to 1640, known both for restoring the authority of the state and for the brutality of his methods. Murad IV was born in Istanbul, the son of Sultan Ahmed I (r. 1603–17) and the ethnic Greek Kösem Sultan. Brought to power by a palace conspiracy in 1623, he succeeded his uncle Mustafa I (r. 1617–18, 1622–23). He was only 11 when he took the throne. His reign is most notable for the Ottoman–Safavid War (1623–39), of which

答案字符位置：[38, 53)。

</details>

<details>
<summary>Murad I：完整供应证据</summary>

Murad I Murad I (; (nicknamed Hüdavendigâr, from Persian: خداوندگار, "Khodāvandgār", "the devotee of God" – but meaning "sovereign" in this context); 29 June 1326 – 15 June 1389) was the Ottoman Sultan from 1362 to 1389. He was a son of Orhan and the Valide Nilüfer Hatun. Murad I conquered Adrianople, renamed it to Edirne, and in 1363 made it the new capital of the Ottoman Sultanate. Then he further expanded the Ottoman realm in Southeast Europe by bringing most of the Balkans under Ottoman rule, and forced the princes of northern Serbia and Bulgaria as well as the

答案字符位置：[150, 162)。

</details>

<details>
<summary>Murad V：完整供应证据</summary>

Murad V Murad V () (21 September 1840 – 29 August 1904) was the 33rd Sultan of the Ottoman Empire who reigned from 30 May to 31 August 1876. He was born at the Çırağan Palace, Ortaköy, Istanbul. His father was Abdulmejid I. His mother, whom his father married in Constantinople on 1 August 1839, was Şevkefza Valide Sultan, an ethnic Circassian from the Ubykh tribe, daughter of Mehmed Bey Zaurum and his wife Cemile Hanım. Murad became the Sultan when his uncle Abdülaziz was deposed. He was highly influenced by French culture and was a liberal. He reigned for

答案字符位置：[20, 37)。

</details>

## 第53题：ambigdocs_10164

**query：** Who is the artist of the album "Sleepwalking"?

**term：** Sleepwalking (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第67题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Sleepwalking (Gerry Rafferty album) | Gerry Rafferty | Gerry Rafferty |
| Sleepwalking (Magnum album) | Magnum | Magnum |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Sleepwalking (Gerry Rafferty album)：完整供应证据</summary>

Sleepwalking (Gerry Rafferty album) Sleepwalking is the fifth studio album by Gerry Rafferty, released in 1982. It is the follow-up to the 1980 album "Snakes and Ladders". It would be Rafferty's last album for Liberty/United Artists, and his last for six years. "Sleepwalking" was co-produced by Rafferty and Christopher Neil who went on to become the producer for Mike + The Mechanics. Unlike the previous Rafferty albums such as "City to City" and "Night Owl" there is considerable use of synthesisers and drum programming, some of the latter done by Christopher Neil, along with contributions from British session musicians including

答案字符位置：[14, 28)。

</details>

<details>
<summary>Sleepwalking (Magnum album)：完整供应证据</summary>

Sleepwalking (Magnum album) Sleepwalking is the ninth studio album by the English rock band Magnum, released in 1992. Following the decision to leave Polydor, "Sleepwalking" was recorded within six months, and is the first self-produced album by Magnum since "The Eleventh Hour". Tony Clarkin was much happier acting as producer, following his working relationship with Keith Olsen on "Goodnight L.A.". Learning from Olsen, Clarkin had enough experience to produce Magnum's records on his own, this also being the best option to cut production costs for future albums. Clarkin and Catley commented that "Sleepwalking" represented a return to the classic Magnum

答案字符位置：[14, 20)。

</details>

## 第54题：ambigdocs_14869

**query：** Who is the composer of the Flute Sonata?

**term：** Flute Sonata
**dimension：** Entity Disambiguation
**来源：** 旧第68题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Flute Sonata (Poulenc) | Francis Poulenc | Francis Poulenc |
| Flute Sonata (Prokofiev) | Sergei Prokofiev | Sergei Prokofiev |
| Flute Sonata No. 4 (Ries) | Ferdinand Ries | Ferdinand Ries |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Flute Sonata (Poulenc)：完整供应证据</summary>

Flute Sonata (Poulenc) The Sonate pour flûte et piano (Flute Sonata), FP 164, by Francis Poulenc, for flute and piano, was written in 1957. It is dedicated to the memory of Elizabeth Sprague Coolidge, an American patron of chamber music. Poulenc composed it for the flautist Jean-Pierre Rampal, and he and Rampal gave the première in June 1957 at the Strasbourg Music Festival. It is now one of Poulenc's best known works and is a prominent feature in 20th century flute repertoire. Sources indicate that Poulenc had had the idea to compose a flute sonata for a long time, which

答案字符位置：[81, 96)。

</details>

<details>
<summary>Flute Sonata (Prokofiev)：完整供应证据</summary>

Flute Sonata (Prokofiev) The Flute Sonata in D, Op. 94, was a musical work that was composed by Sergei Prokofiev in 1943. It was initially made for flute and piano, but a later version of the piece used a violin instead of a flute. The piece contains four different movements. The Flute Sonata in D was completed in the summer of 1943. At that same time, Prokofiev was working on music for "Ivan the terrible". The flute sonata in D was first performed in Moscow, Russia on December 7, 1943 by Nicolai Kharkovsky (flute) and Sviatoslav Richter (piano). It was

答案字符位置：[96, 112)。

</details>

<details>
<summary>Flute Sonata No. 4 (Ries)：完整供应证据</summary>

Flute Sonata No. 4 (Ries) The Flute Sonata in G major, Op. 87 , is a composition for piano and flute by Ferdinand Ries that was published at The Regents Harmonic Institution in London in 1819. Little information about the works composition history is known as the composers manuscript is undated, but Alan Bradly in the preface to the score published by Artaria Editions indicates that the work may have been composed around 1815 along with a number of other works for the same instrumental combination. The work is in three movements: Unlike the composers earlier Clarinet sonata, this work

答案字符位置：[104, 118)。

</details>

## 第55题：ambigdocs_9280

**query：** Who is the artist of the Christmas Present album?

**term：** Christmas Present
**dimension：** Entity Disambiguation
**来源：** 旧第69题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Christmas Present (Andy Williams album) | Andy Williams | Andy Williams |
| Merle Haggard's Christmas Present | Merle Haggard | Merle Haggard |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Christmas Present (Andy Williams album)：完整供应证据</summary>

Christmas Present (Andy Williams album) Christmas Present is the third Christmas album by American pop singer Andy Williams (and his thirty-third studio album overall) that was released in October 1974 by Columbia Records and, apart from the title track, focused strictly on traditional carols. While his previous holiday LPs were released during the run of his variety series, which ended in 1971, this album was promoted the December following its release through one of his many Christmas specials. An article titled "MOR Artists Are Ailing" in "Billboard" magazine's November 23, 1974, issue describes the hopes that the record company had

答案字符位置：[19, 32)。

</details>

<details>
<summary>Merle Haggard's Christmas Present：完整供应证据</summary>

Merle Haggard's Christmas Present Merle Haggard's Christmas Present is the eighteenth studio album by American country singer Merle Haggard backed by The Strangers, released in 1973. The single, "If We Make It Through December" spent four weeks at No. 1 on the "Billboard magazine" Hot Country Singles chart in December 1973 and January 1974, and cracked the Top 30 of the "Billboard" Hot 100. "If We Make It Through December" was the No. 2 song of the year on "Billboard's" Hot Country Singles 1974 year-end chart. The original LP release of the album carries the subtitle "Something Old, Something New".

答案字符位置：[0, 13)。

</details>

## 第56题：ambigdocs_7022

**query：** Where is the Metropolitan Cathedral of the Immaculate Conception located?

**term：** Metropolitan Cathedral of the Immaculate Conception
**dimension：** Entity Disambiguation
**来源：** 旧第70题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Immaculate Conception Cathedral, Managua | Managua, Nicaragua | Managua, Nicaragua |
| Zamboanga Cathedral | Zamboanga City, Philippines | Zamboanga City, Philippines |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Immaculate Conception Cathedral, Managua：完整供应证据</summary>

Immaculate Conception Cathedral, Managua The Metropolitan Cathedral of the Immaculate Conception of Mary (Spanish: "Catedral Metropolitana de la Inmaculada Concepción de María"), referred to as the New Cathedral ("La Nueva Catedral"), is located in Managua, Nicaragua. It was dedicated to the Immaculate Conception of the Virgin Mary. The cathedral was built in 1991 to serve as a replacement for the Old Cathedral of Managua or St. James' Cathedral ("Catedral de Santiago"). The old cathedral was damaged and thought to be unrestoreable after a 1972 earthquake that destroyed 90% of the city. The new cathedral was designed by the Mexican architect

答案字符位置：[249, 267)。

</details>

<details>
<summary>Zamboanga Cathedral：完整供应证据</summary>

Zamboanga Cathedral The Metropolitan Cathedral of the Immaculate Conception, commonly known as simply the Zamboanga Cathedral, is a church located in Zamboanga City, Philippines. It is the seat of the Archdiocese of Zamboanga. The first church was originally located at the front of Plaza Pershing, where the present Universidad de Zamboanga stands. The church was designated a cathedral in 1910 when the diocese of Zamboanga was created. In 1943, the cathedral was one of the edifices bombarded by Japanese soldiers during World War II. In 1956, the cathedral was relocated beside Ateneo de Zamboanga University, formerly known as the Jardin

答案字符位置：[150, 177)。

</details>

## 第57题：ambigdocs_56626

**query：** Who is the artist of the album "If You Leave"?

**term：** If You Leave
**dimension：** Entity Disambiguation
**来源：** 旧第71题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| If You Leave... | Eleanor McEvoy | Eleanor McEvoy |
| If You Leave (Daughter album) | Daughter | Daughter |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>If You Leave...：完整供应证据</summary>

If You Leave... If You Leave... is Eleanor McEvoy's tenth studio album. It features eight new songs and four interpretations including "God only Knows", "True Colors", and "Lift the Wings" from Riverdance. Recorded live in the studio with some of Ireland’s finest players this album of soulful performances shows McEvoy in a bluesier neo-retro style. The overall feel is retro. Said McEvoy, "I'd been listening to a lot of 60s albums, Stones, Beatles, Beach Boys stuff like that and it was with the spirit of those albums in my musical soul that I entered the studio." On 18 March 2013

答案字符位置：[35, 49)。

</details>

<details>
<summary>If You Leave (Daughter album)：完整供应证据</summary>

flat and then just recorded in the studio, where a lot of parts came up". The band re-recorded a new version of the song "Youth" in a live setting. On 18 March 2013 Daughter released "If You Leave" and it reached #4 on the UK indie album chart, and #16 on the Top 100. Before the release of "If You Leave" they released the first single off the album "Smother" in October. It was playlisted by both BBC Radio 1 and 6Music, while being awarded Single of the Week by long-time supporter Huw Stephens. Later on the band released promotional

答案字符位置：[165, 173)。

</details>

## 第58题：ambigdocs_37721

**query：** In what year was Bruce Thornton drafted into the NFL?

**term：** Bruce Thornton
**dimension：** Entity Disambiguation
**来源：** 旧第73题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Bruce Thornton (cornerback) | 2004 | 2004 |
| Bruce Thornton (defensive lineman) | 1979 | 1979 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Bruce Thornton (cornerback)：完整供应证据</summary>

yards (18.4-yard average). Thornton was selected by the Dallas Cowboys in the fourth round (121st overall) of the 2004 NFL Draft. He only played one game in 2004, in which he returned two kickoffs for 43 yards, before tearing his ACL and being placed on the injured reserve list. He was waived on September 8, 2005. The San Francisco 49ers signed him to their practice squad on September 14, 2005. Injuries forced the 49ers to promote him to the active roster on September 30 and eventually named him the starter at left cornerback. In his first start he was matched

答案字符位置：[114, 118)。

</details>

<details>
<summary>Bruce Thornton (defensive lineman)：完整供应证据</summary>

the Big Ten Conference in sacks with 10. In his final year, he was moved to a backup role behind John Thiede, on a team that finished with a record of 1-8-2. He finished his college career with 32 sacks, placing him at the time fifth in school's history. Thornton was selected by the Dallas Cowboys in the eighth round (219th overall) of the 1979 NFL Draft, after dropping because of his diminished production as a college senior. As a rookie, he helped to compensate the loss of Ed "Too Tall" Jones to his boxing retirement, by coming on passing

答案字符位置：[342, 346)。

</details>

## 第59题：ambigdocs_35745

**query：** When was Senator Rivera born?

**term：** Senator Rivera
**dimension：** Entity Disambiguation
**来源：** 旧第74题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Cirilo Tirado Rivera | June 14, 1964 | June 14, 1964 / 14 June 1964 / June 14 1964 / 1964-06-14 |
| Luis A. Berdiel Rivera | October 8, 1962 | October 8, 1962 / 8 October 1962 / October 8 1962 / 1962-10-08 |
| George Rivera | 1948 | 1948 |
| Gustavo Rivera (politician) | November 19, 1975 | November 19, 1975 / 19 November 1975 / November 19 1975 / 1975-11-19 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Cirilo Tirado Rivera：完整供应证据</summary>

Cirilo Tirado Rivera Cirilo Tirado Rivera (born June 14, 1964 in Patillas, Puerto Rico) is a Puerto Rican politician and Senator. He has been a member of the Senate of Puerto Rico since 2000. Cirilo Tirado was born on June 14, 1964 in Patillas, Puerto Rico to Quintina Rivera Montañez, a teacher, and Cirilo Tirado Delgado, an attorney, and former Senator and Representative. He finished his studies in his hometown of Patillas, and then studied at the University of Puerto Rico at Cayey and Río Piedras. He finished his Bachelor's degree in Education, with a major in Mathematics. Cirilo Tirado

答案字符位置：[48, 61)。

</details>

<details>
<summary>Luis A. Berdiel Rivera：完整供应证据</summary>

Luis A. Berdiel Rivera Luis A. Berdiel Rivera (born October 8, 1962 in Adjuntas, Puerto Rico) is a Puerto Rican politician and was member of the Senate of Puerto Rico in 2009. He is affiliated with the pro-statehood New Progressive Party (PNP) and had also served as a Municipal Legislator in Adjuntas. Berdiel Rivera was born in Adjuntas, Puerto Rico on October 8, 1962. His parents were Miguel Berdiel and Paulina Rivera. He graduated from high school in 1981, with a certificate in vocational education in automobile repair and painting. He then received a Bachelor's degree from the Interamerican University

答案字符位置：[52, 67)。

</details>

<details>
<summary>George Rivera：完整供应证据</summary>

George Rivera George Rivera is a former member of the Colorado Senate elected in a September 10, 2013 recall election to replace Angela Giron. Rivera was elected from Colorado's State Senate District 3 which includes Pueblo, Colorado. Giron was the second ever Colorado legislator to be successfully recalled in the state's history. Rivera was born in Pueblo, Colorado in 1948 and grew up on the City's east side. His parents arrived in Pueblo in 1948 after crossing into the U.S. illegally from Mexico. In 1963 they returned to Mexico (along with Rivera's grandmother) to process their visas and returned to

答案字符位置：[372, 376)。

</details>

<details>
<summary>Gustavo Rivera (politician)：完整供应证据</summary>

Gustavo Rivera (politician) Gustavo Rivera (born November 19, 1975) is a New York state senator representing the 33rd Senate District, covering the Bronx neighborhoods of Kingsbridge Heights, Kingsbridge, Fordham, University Heights, Van Nest, Tremont, East Tremont, and parts of Morrisania and Parkchester. He received a B.A. in political science from the University of Puerto Rico in May 1998. Following graduation, Rivera moved to New York to begin a doctoral program in political science at the Graduate Center of the City University of New York. He taught courses at Hunter College until 2002, and served as an Assistant Professor of Political

答案字符位置：[49, 66)。

</details>

## 第60题：ambigdocs_53812

**query：** Who is the artist of "The Way I Feel"?

**term：** The Way I Feel
**dimension：** Entity Disambiguation
**来源：** 旧第75题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| The Way I Feel (Leonard Nimoy album) | Leonard Nimoy | Leonard Nimoy |
| The Way I Feel (Remy Shand album) | Remy Shand | Remy Shand |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>The Way I Feel (Leonard Nimoy album)：完整供应证据</summary>

The Way I Feel (Leonard Nimoy album) The Way I Feel is the third studio album by Leonard Nimoy. It was released in late 1968 by Dot Records, the same year "Two Sides" was released. Unlike the first two albums, Nimoy stepped away from his Mr. Spock persona on this album. There are no science fiction, Spock themed songs, or outer space sound effects featured on the album. The album consists of folk songs. However, it is believed that the spoken word tracks, "Consilium" and "Where It's At" loosely tie into the Spock persona. Review of "The Way I Feel"

答案字符位置：[16, 29)。

</details>

<details>
<summary>The Way I Feel (Remy Shand album)：完整供应证据</summary>

The Way I Feel (Remy Shand album) The Way I Feel is the only studio album by Canadian R&B musician Remy Shand. The album was released in in Shand's native Canada via Universal Records and on in the United States via Motown Records. Three singles were released from the album: "Take a Message", "The Way I Feel", and "Rocksteady". "Take a Message" was the only song from the album to chart on the "Billboard" Hot 100, peaking at #89. Shand wrote and produced all of the album's tracks. The album peaked at #1 on the Canadian Albums Chart and at

答案字符位置：[16, 26)。

</details>

## 第61题：ambigdocs_15480

**query：** Where is the Grafton Public Library located?

**term：** Grafton Public Library
**dimension：** Entity Disambiguation
**来源：** 旧第76题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Grafton Public Library (Grafton, Massachusetts) | Grafton, Massachusetts | Grafton, Massachusetts |
| Grafton Public Library (Grafton, Vermont) | 204 Main Street in Grafton, Vermont | 204 Main Street in Grafton, Vermont |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Grafton Public Library (Grafton, Massachusetts)：完整供应证据</summary>

Grafton Public Library (Grafton, Massachusetts) Grafton Public Library is located in Grafton, Massachusetts. The building was built in 1927 with money donated by Jerome Wheelock, a local inventor. The 2009 population estimate is over 17,700. According to its mission statement, GPL "strive[s] to provide our residents with equal opportunity to access resources that will satisfy individual educational, occupational, cultural, and recreational needs and interests." GPL belongs to Massachusetts Library System (MLS) and Central/Western Massachusetts Automated Resource Sharing, Inc. (C/W MARS). GPL offers storytimes; programs for all ages, community service opportunities, and a home delivery program for residents who cannot use

答案字符位置：[24, 46)。

</details>

<details>
<summary>Grafton Public Library (Grafton, Vermont)：完整供应证据</summary>

Grafton Public Library (Grafton, Vermont) The Grafton Public Library is located at 204 Main Street in Grafton, Vermont. It is located in the historic Butterfield House, an elegant early 19th-century house with later styling, that is listed on the National Register of Historic Places. The library offers books and other media for lending, including via interlibrary loan. Services include the use of computers and printers, and wireless internet access. Patrons may also remotely access a variety of online databases. The library is located on the south side of Main Street, in the eastern part of Grafton's village center. It is

答案字符位置：[83, 118)。

</details>

## 第62题：ambigdocs_19550

**query：** When was Walter Calverley born?

**term：** Walter Calverley (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第77题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Sir Walter Calverley, 1st Baronet | 1670 | 1670 |
| Walter Calverley-Blackett | 18 December 1707 | 18 December 1707 / December 18, 1707 / December 18 1707 / 1707-12-18 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Sir Walter Calverley, 1st Baronet：完整供应证据</summary>

Sir Walter Calverley, 1st Baronet Sir Walter Calverley, 1st Baronet (1670 – 15 October 1749) was an English aristocrat. He was the only son of Walter Calverley of Calverley, Yorkshire, and Frances Thompson, daughter and heiress of Henry Thompson of Esholt, Yorkshire. He was baptised on 16 January 1670 at Calverley, and matriculated at Queen's College, Oxford, on 30 June 1687, aged 17. He married Julia Blackett, eldest daughter of Sir William Blackett on 7 January 1707 at Newcastle. In about 1709, he completed the building of a new house at Esholt Hall, Esholt. He was created a baronet on

答案字符位置：[69, 73)。

</details>

<details>
<summary>Walter Calverley-Blackett：完整供应证据</summary>

Walter Calverley-Blackett Sir Walter Calverley-Blackett, 2nd Baronet (18 December 1707 – 14 February 1777) was a British baronet and politician who sat in the House of Commons from 1734 to 1777. He was born Walter Calverley at Otley, the only son of Sir Walter Calverley, 1st Baronet, and Julia Blackett, daughter of Sir William Blackett (1657-1705), 1st Baronet. He entered Balliol College, Oxford, aged 16 on 28 February 1724. In 1728, he inherited the substantial estates of his uncle Sir William Blackett, 2nd Baronet, at Cambo and Allendale, Northumberland, on condition that he married Elizabeth Orde (his uncle's natural daughter)

答案字符位置：[70, 86)。

</details>

## 第63题：ambigdocs_58590

**query：** When was Alan O'Neill born?

**term：** Alan O'Neill
**dimension：** Entity Disambiguation
**来源：** 旧第79题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Alan O'Neill (footballer, born 1957) | 2 July 1957 | 2 July 1957 / July 2, 1957 / July 2 1957 / 1957-07-02 |
| Alan O'Neill (footballer, born 1973) | 27 August 1973 | 27 August 1973 / August 27, 1973 / August 27 1973 / 1973-08-27 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Alan O'Neill (footballer, born 1957)：完整供应证据</summary>

Alan O'Neill (footballer, born 1957) Alan O'Neill (born 2 July 1957 in Dublin) is an Irish football goalkeeper who played in the League of Ireland in the 1970s, 1980s and 1990s. Son of Robert who played for Shelbourne, O'Neill made his League of Ireland debut for Shamrock Rovers at Milltown on Sunday the 28th of December 1975 in a 1–0 win over Cork Hibernians. In his second season under Sean Thomas he won his first medal, the FAI League Cup. After the departure of Thomas, Johnny Giles took over as manager at the start of the 1977–78 season. He played

答案字符位置：[56, 67)。

</details>

<details>
<summary>Alan O'Neill (footballer, born 1973)：完整供应证据</summary>

Alan O'Neill (footballer, born 1973) Alan O'Neill (born 27 August 1973) is an Irish former professional footballer who played in the Football League for Birmingham City. He also played in Ireland. O'Neill was born in Cork. A forward, he played in Ireland for Cork City and Cobh Ramblers before coming to England to sign for Birmingham City in February 1992 for a fee of £15,000. He made his debut in the Football League Third Division on 29 February 1992, coming on as a substitute in a home game against Stoke City which finished as a 1–1 draw. He played in

答案字符位置：[56, 70)。

</details>

## 第64题：ambigdocs_53327

**query：** Who is the composer of Symphony No. 21?

**term：** Symphony No. 21
**dimension：** Entity Disambiguation
**来源：** 旧第80题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Symphony No. 21 (Haydn) | Joseph Haydn | Joseph Haydn |
| Symphony No. 21 (Michael Haydn) | Michael Haydn | Michael Haydn |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Symphony No. 21 (Haydn)：完整供应证据</summary>

Symphony No. 21 (Haydn) The Symphony No. 21 in A major, Hoboken I/21, was composed by Joseph Haydn around the year 1764. The symphony’s movements have unusual structures that make their form hard to identify. The parts that pertain to sonata form are often hard to recognize immediately and are often identified “only in retrospect.” The symphony is in four movements and is scored for two oboes, two French horns in A, violins I and II, viola, cello and basso continuo. The entire first movement is slow, with the tempo marking adagio. It is uncommon for Haydn to have an

答案字符位置：[86, 98)。

</details>

<details>
<summary>Symphony No. 21 (Michael Haydn)：完整供应证据</summary>

Symphony No. 21 (Michael Haydn) Michael Haydn's Symphony No. 21 in D major, Perger 42, Sherman 21, MH 272, written in 1778, is believed to have been written in Salzburg. Scored for 2 oboes, 2 bassoons, 2 horns and strings, in three movements: This symphony is the first of four by Michael Haydn to include a slow introduction before the first movement (the others are Symphonies Nos. 22, 27, and 30). All four were written between 1778 and 1785 and attached to symphonies cast in three movements (without minuets). On the CPO label, this symphony is available on a CD

答案字符位置：[17, 30)。

</details>

## 第65题：ambigdocs_28029

**query：** Who is the father of Henry Hyde?

**term：** Henry Hyde (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第81题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Henry Hyde, 2nd Earl of Clarendon | Edward Hyde, 1st Earl of Clarendon | Edward Hyde, 1st Earl of Clarendon |
| Henry Hyde (died 1634) | Lawrence Hyde I | Lawrence Hyde I |
| Henry Baldwin Hyde | Henry Hazen Hyde | Henry Hazen Hyde |
| Henry Hyde | Henry Clay Hyde | Henry Clay Hyde |
| Henry Hyde, 4th Earl of Clarendon | 1st Earl of Rochester | 1st Earl of Rochester |
| Henry Hyde, Viscount Cornbury | 4th Earl of Clarendon | 4th Earl of Clarendon |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Henry Hyde, 2nd Earl of Clarendon：完整供应证据</summary>

Henry Hyde, 2nd Earl of Clarendon Henry Hyde, 2nd Earl of Clarendon, PC (2 June 163831 October 1709) was an English aristocrat and politician. He held high office at the beginning of the reign of his brother-in-law, King James II. He was the eldest son of Edward Hyde, 1st Earl of Clarendon, and his second wife, Frances Aylesbury. He was thus a brother of Anne Hyde, and maternal uncle to both Queen Mary II and Queen Anne. Both he and his brother Laurence Hyde were brought up partly at Antwerp and Breda, by their mother. Clarendon before 1660 made use

答案字符位置：[256, 290)。

</details>

<details>
<summary>Henry Hyde (died 1634)：完整供应证据</summary>

Henry Hyde (died 1634) Henry Hyde (c. 1563 – 29 September 1634) was an English politician and lawyer. He was the father of Edward Hyde, 1st Earl of Clarendon (1609–1674), and thus was great-grandfather of two British monarchs, Queen Mary II and Queen Anne. He lived at Dinton and later at Purton, Wiltshire. Hyde was born circa 1563, the son of Lawrence Hyde I (d.1590), MP, by his wife Anne Sybill. His brothers were Sir Nicholas Hyde (c.1572–1631), Lord Chief Justice of England (1627-1631) and Lawrence Hyde II (1562–1641), attorney-general to Anne of Denmark, wife of King James I. He

答案字符位置：[345, 360)。

</details>

<details>
<summary>Henry Baldwin Hyde：完整供应证据</summary>

Henry Baldwin Hyde Henry Baldwin Hyde, (February 15, 1834–May 2, 1899) was an American businessman. He is notable for having founded The Equitable Life Assurance Society of the United States in 1859. By the time of Hyde's death, The Equitable was the largest life insurance company in the world. Hyde was born in Catskill, New York on February 15, 1834, the son of Henry Hazen Hyde, a successful merchant. He attended the public schools of Catskill, and when he was 16 his teacher decided to move to New York City to join the growing life insurance industry. The teacher persuaded

答案字符位置：[365, 381)。

</details>

<details>
<summary>Henry Hyde：完整供应证据</summary>

Henry Hyde Henry John Hyde (April 18, 1924 – November 29, 2007), an American politician, was a Republican member of the United States House of Representatives from 1975 to 2007, representing the 6th District of Illinois, an area of Chicago's northwestern suburbs which included O'Hare International Airport. He chaired the Judiciary Committee from 1995 to 2001, and the House International Relations Committee from 2001 to 2007. Hyde was born in Chicago, Illinois, the son of Monica (Kelly) and Henry Clay Hyde. His father was English and his mother was Irish Catholic. His family supported the Democratic Party. He attended Duke

答案字符位置：[495, 510)。

</details>

<details>
<summary>Henry Hyde, 4th Earl of Clarendon：完整供应证据</summary>

Henry Hyde, 4th Earl of Clarendon Henry Hyde, 4th Earl of Clarendon and 2nd Earl of Rochester, PC (June 1672 – 10 December 1753) was an English nobleman and politician. He was styled Lord Hyde from 1682 to 1711. He was the son of the 1st Earl of Rochester and Lady Henrietta, daughter of the 1st Earl of Burlington. His education started at Eton where he studied from 1683 to 1687 and entered Oxford University in 1700. From 1687 to 1690 saw him travel abroad to Italy, Germany and the Dutch Republic. He was Tory MP for Launceston 15 November

答案字符位置：[234, 255)。

</details>

<details>
<summary>Henry Hyde, Viscount Cornbury：完整供应证据</summary>

1737, but had no children. Henry Hyde, Viscount Cornbury Henry Hyde, Viscount Cornbury (28 November 1710 – 28 May 1753), styled Viscount Hyde from 1711 until 1723 and Viscount Cornbury thereafter, also 5th Baron Hyde in his own right, was a British author and politician. The only son of Henry Hyde, 4th Earl of Clarendon, to survive to adulthood, Hyde was educated at Christ Church, Oxford, from which he received a DCL. He was an author of some talent, and both Swift and Pope praised his character. A Tory like the rest of his family, Cornbury involved himself in a

答案字符位置：[300, 321)。

</details>

## 第66题：ambigdocs_25035

**query：** When was the Independent Commission Against Corruption established?

**term：** Independent Commission Against Corruption
**dimension：** Entity Disambiguation
**来源：** 旧第83题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Fiji Independent Commission Against Corruption | 4 April 2007 | 4 April 2007 / April 4, 2007 / April 4 2007 / 2007-04-04 |
| Korea Independent Commission Against Corruption | 25 January 2002 | 25 January 2002 / January 25, 2002 / January 25 2002 / 2002-01-25 |
| Independent Commission Against Corruption (Hong Kong) | 15 February 1974 | 15 February 1974 / February 15, 1974 / February 15 1974 / 1974-02-15 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Fiji Independent Commission Against Corruption：完整供应证据</summary>

Fiji Independent Commission Against Corruption The Fiji Independent Commission Against Corruption (FICAC) is an anti – corruption agency in Fiji, charged with fighting against corruption in the Public Sector of Fiji. It was established on 4 April 2007 under the FICAC Promulgation 2007, and its role was confirmed by the 2013 Constitution of Fiji. It reports directly to the President of Fiji. The Fiji Independent Commission Against Corruption is headed by a Deputy Commissioner, currently George Westlake Langman. An anti-corruption commission was first proposed by the government of Timoci Bavadra in 1987. In 1999, the then Attorney General and Minister

答案字符位置：[239, 251)。

</details>

<details>
<summary>Korea Independent Commission Against Corruption：完整供应证据</summary>

Korea Independent Commission Against Corruption The Korea Independent Commission Against Corruption is an independent commission that reports to the President in its fight against corruption and the consequent promotion of the clean administration of South Korea. The Korea Independent Commission Against Corruption (KICAC) was established on 25 January 2002, under the Anti-Corruption Act of Korea, which was enacted by the Korean National Assembly on 24 July 2001, which sought to prevent corruption and promote transparency in Korean society. In a coordinated effort with other monitoring agencies, also known proverbially as watchdogs, the KICAC is involved in producing policies, orchestrating preventive

答案字符位置：[343, 358)。

</details>

<details>
<summary>Independent Commission Against Corruption (Hong Kong)：完整供应证据</summary>

and "I Corrupt All Cops" in 2009 that tell the history of the ICAC from the inception to how it adopted its interrogation methods. A number of television series have also been made about the Commission with the ICAC Investigators family of miniseries being based on actual ICAC cases and made with the full co-operation of the ICAC as part of its community education work. Independent Commission Against Corruption (Hong Kong) The Independent Commission Against Corruption (ICAC; ; previously known as the before 1997) of Hong Kong was established by Governor Sir Murray MacLehose on 15 February 1974, when Hong

答案字符位置：[584, 600)。

</details>

## 第67题：ambigdocs_7276

**query：** Where is Ram Head located?

**term：** Ram Head
**dimension：** Entity Disambiguation
**来源：** 旧第84题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Rame Head | Cornwall, United Kingdom | Cornwall, United Kingdom |
| Rame Head (Victoria) | eastern Victoria, Australia | eastern Victoria, Australia / Eastern Victoria, Australia |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Rame Head：完整供应证据</summary>

Rame Head Rame Head or Ram Head () is a coastal headland, southwest of the village of Rame in southeast Cornwall, United Kingdom. It is part of the larger Rame Peninsula. The natural site was used for a promontory fort ('cliff castle') in the Iron Age and the narrow neck of land was further excavated on the landward side with a central causeway, still visible. The eastern part retains traces of round house platforms, though damaged by wartime construction. The headland has a prominent chapel, dedicated to St Michael, as are many early Christian headland sites in the region, accessible

答案字符位置：[104, 128)。

</details>

<details>
<summary>Rame Head (Victoria)：完整供应证据</summary>

Rame Head (Victoria) Ram Head or since 1970 Rame Head () is a coastal headland in eastern Victoria, Australia. It is within the Croajingolong National Park. The local aboriginal people call the headland Konowee or Kouowee. James Cook (Captain Cook) named today's Rame Head as he passed by on 19 April 1770 [log date]. Cook named Rame Head Ram Head, after a point that can be seen going into Plymouth Sound, Cook wrote the name Ram in Modern English [as used today] and that spelling was adopted by Aaron Arrowsmith, George Bass, Matthew Flinders, James Grant, Louis de Freycinet and

答案字符位置：[82, 109)。

</details>

## 第68题：ambigdocs_19885

**query：** Who is the artist of the album "Distant Light"?

**term：** Distant Light
**dimension：** Entity Disambiguation
**来源：** 旧第85题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Distant Light (Alex Lloyd album) | Alex Lloyd | Alex Lloyd |
| Distant Light (The Hollies album) | The Hollies | The Hollies |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Distant Light (Alex Lloyd album)：完整供应证据</summary>

Distant Light (Alex Lloyd album) Distant Light is the third studio album by Australian singer-songwriter Alex Lloyd. Released in September 2003, it has been certified platinum in Australia and had three top 40 singles taken from it. On the Chaos Music website, Lloyd states that the album is based on homesickness after a long stretch on the road promoting his second album "Watching Angels Mend". "That was the headspace of where I was at the time. We went to a lot of strange places, maybe places I don’t want to revisit. It was a pretty lonely time. I think I’d

答案字符位置：[15, 25)。

</details>

<details>
<summary>Distant Light (The Hollies album)：完整供应证据</summary>

Distant Light (The Hollies album) Distant Light is a 1971 album released by The Hollies, the last UK album by the band to feature lead vocalist and founding member Allan Clarke, until their 1974 self-titled album, reputably to be the first album to come out of A.I.R. studios. The album spawned two hit singles, the Allan Clarke penned "Long Cool Woman in a Black Dress," which peaked at U.S. #2 and UK #32, and the Tony Hicks penned "Long Dark Road" US #26. The US released version of the album peaked at US #21. The summer scene that is shown

答案字符位置：[15, 26)。

</details>

## 第69题：ambigdocs_66173

**query：** When was John R. Brown born?

**term：** John R. Brown
**dimension：** Entity Disambiguation
**来源：** 旧第86题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| John Robert Brown (British Columbia politician) | February 19, 1862 | February 19, 1862 / 19 February 1862 / February 19 1862 / 1862-02-19 |
| John Robert Brown (Virginia politician) | January 14, 1842 | January 14, 1842 / 14 January 1842 / January 14 1842 / 1842-01-14 |
| John Ronald Brown | July 14, 1922 | July 14, 1922 / 14 July 1922 / July 14 1922 / 1922-07-14 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>John Robert Brown (British Columbia politician)：完整供应证据</summary>

John Robert Brown (British Columbia politician) John Robert Brown (February 19, 1862 – December 8, 1947) was a lawyer and political figure in British Columbia. He represented Greenwood in the Legislative Assembly of British Columbia from 1903 to 1907 as a Liberal. He was born in Sarnia township, Lambton County, Ontario, the son of Thomas W. Brown, a native of Ireland, and Mary McGregor, and was educated there. He went on to study law in the Sarnia law office of Judge Lister and at Osgoode Hall. In 1896, Brown was admitted to the Ontario bar and set up practice in

答案字符位置：[67, 84)。

</details>

<details>
<summary>John Robert Brown (Virginia politician)：完整供应证据</summary>

John Robert Brown (Virginia politician) John Robert Brown (January 14, 1842 – August 4, 1927) was a United States Representative from Virginia. Born near Snow Creek, Franklin County, Virginia, he attended private schools in Franklin and Henry Counties and entered the Confederate Army in 1861 as a private in Company D, Twenty-fourth Regiment of Virginia Volunteers. In 1870 he formed a partnership with his father in the tobacco business at Shady Grove; he moved to Martinsville, Virginia in 1882 and continued in the tobacco business. He also engaged in banking and was mayor of Martinsville from 1884 to 1888. Brown

答案字符位置：[59, 75)。

</details>

<details>
<summary>John Ronald Brown：完整供应证据</summary>

John Ronald Brown John Ronald Brown (July 14, 1922 – May 16, 2010) was an American surgeon who was convicted of second-degree murder after the death of a 79-year-old patient in his care. The son of a physician, Dr. Brown was born in 1922. He did well in school, graduating from high school by the age of 16. When drafted by the US Army during World War II, he scored exceptionally highly on the Army General Classification Test, with the result that the Army sent him to medical school. Brown graduated from University of Utah School of Medicine in 1947,

答案字符位置：[37, 50)。

</details>

## 第70题：ambigdocs_15420

**query：** When was Le Matin first published?

**term：** Le Matin
**dimension：** Entity Disambiguation
**来源：** 旧第87题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Le Matin (Acadian) | 11 August 1986 | 11 August 1986 / August 11, 1986 / August 11 1986 / 1986-08-11 |
| Le Matin (France) | 26 February 1884 | 26 February 1884 / February 26, 1884 / February 26 1884 / 1884-02-26 |
| Le Matin (Switzerland) | 1972 | 1972 |
| Le Matin de Paris | 1 March 1977 | 1 March 1977 / March 1, 1977 / March 1 1977 / 1977-03-01 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Le Matin (Acadian)：完整供应证据</summary>

Le Matin (Acadian) Le Matin was a French-language daily newspaper in Moncton, New Brunswick, Canada, founded on 11 August 1986 and disappearing on 29 June 1988. In the wake of the closure of "L'Évangéline" in October 1982 two Francophone daily papers were created in New Brunswick - "Le Matin" at Moncton and "l'Acadie Nouvelle" at Caraquet. Unlike its counterpart, "Le Matin" served the whole province. Despite this distribution on the provincial scale and despite subsidies, competition and the narrowness of the market, it did not achieve more than small circulation figures. Minimal advertising receipts brought its collapse barely two years

答案字符位置：[112, 126)。

</details>

<details>
<summary>Le Matin (France)：完整供应证据</summary>

Le Matin (France) Le Matin was a French daily newspaper first published in 1884 and discontinued in 1944. "Le Matin" was launched on the initiative of Chamberlain & Co., a group of American financiers and the American newspaper editor Samuel Selwyn Chamberlain, in 1883, on the model of the British daily "The Morning News". The direction of the project was entrusted to the French journalist Alfred Edwards, who launched the first issue on 26 February 1884. His home was then situated in the 10th arrondissement of Paris, at 6 boulevard Poissonnière, and his offices at numbers 3 to 9 on

答案字符位置：[441, 457)。

</details>

<details>
<summary>Le Matin (Switzerland)：完整供应证据</summary>

Le Matin (Switzerland) Le Matin (literally "The Morning") is a Swiss French-language daily newspaper published by Edipresse in Lausanne, Switzerland. The publication of the daily newspaper "Le Matin" was stopped on 21 July 2018. The Sunday and on-line versions continue. The newspaper was created in 1972 when "La Tribune de Lausanne" was renamed as "Le Matin". The paper is published in tabloid-format. Between 31 October 2005 and 25 September 2009, Edipresse also published "Le Matin Bleu", a free daily newspaper distributed in the most-populated areas of Romandy. However, despite the similar names between the new newspapers, they were edited independently.

答案字符位置：[300, 304)。

</details>

<details>
<summary>Le Matin de Paris：完整供应证据</summary>

"Observateur"), Philippe Viannay ("Observateur"'s editorial advisor) and, until his death in May 1979, Jacques Deshayes (technical advisor and member of the committee of direction of "Observateur"). This presence reinforced itself in April 1981 with the addition of Jean Daniel (editorial director of the "Observateur") and of Roger Priouret (editorial writer to RTL and to "Observateur"), with only Roger Colombani (chief editor, assisting with the morning edition of "France Soir") not historically linked to the newspaper of the rue d'Aboukir. Le Matin de Paris Le Matin de Paris was a French daily newspaper, founded on 1 March 1977 by Claude Perdriel,

答案字符位置：[624, 636)。

</details>

## 第71题：ambigdocs_10932

**query：** What state or territory did Justice Bonham serve on the Supreme Court of?

**term：** Justice Bonham
**dimension：** Entity Disambiguation
**来源：** 旧第88题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Benjamin F. Bonham | Oregon | Oregon |
| Milledge Lipscomb Bonham | South Carolina | South Carolina |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Benjamin F. Bonham：完整供应证据</summary>

Benjamin F. Bonham Benjamin F. Bonham (October 8, 1828 – June 2, 1906) was an American educator, politician, and judge in Oregon. He was the 9th Chief Justice of the Oregon Supreme Court. Overall he was on Oregon's highest court from 1870 to 1876. Prior to joining the court he was in the Oregon Territorial Legislature and the first State Legislature. Later the Tennessee native served as United States Consul General in Calcutta, India. Benjamin F. Bonham was born October 8, 1828 near Knoxville, Tennessee. His parents were John Bonham and the former Sarah Jones. Benjamin was raised in Knoxville

答案字符位置：[122, 128)。

</details>

<details>
<summary>Milledge Lipscomb Bonham：完整供应证据</summary>

newspaper editor. He first helped found the "Ninety Six Guardian" and then moved to Newberry, South Carolina where he was the editor of the "Newberry News". Only afterwards did he relocate to Abbeville, South Carolina, where he started practicing law. Bonham was made a state trial court judge on February 1, 1924; an associate justice of the South Carolina Supreme Court on February 17, 1931; and chief justice of the South Carolina Supreme Court on January 10, 1940. He was a hereditary member of the Aztec Club of 1847. Chief Justice Bonham died on June 23, 1943, in Anderson, South

答案字符位置：[94, 108)。

</details>

## 第72题：ambigdocs_12570

**query：** Where is the College of Science and Technology located?

**term：** College of Science and Technology
**dimension：** Entity Disambiguation
**来源：** 旧第89题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| College of Science and Technology (Bhutan) | Rinchending, Phuentsholing, Bhutan | Rinchending, Phuentsholing, Bhutan |
| College of Science and Technology (Rwanda) | Kigali, Rwanda | Kigali, Rwanda |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>College of Science and Technology (Bhutan)：完整供应证据</summary>

College of Science and Technology (Bhutan) The College of Science and Technology is an institute in Rinchending, Phuentsholing, Bhutan. It is the only engineering college in the country providing a degree level education. The college has successfully introduced Civil Engineering, Electrical Engineering, Electronics and Communication Engineering and Information Technology Engineering and Bachelor's degree in Architecture. The college provides extracurricular activities for the students to free their minds. The most popularly played sports are soccer (football) and basketball. The college football ground is seldom left free. The students are known for their cooperation where all wear a uniform dress and cheer

答案字符位置：[100, 134)。

</details>

<details>
<summary>College of Science and Technology (Rwanda)：完整供应证据</summary>

College of Science and Technology (Rwanda) College of Science and Technology - University of Rwanda, the former Kigali Institute of Science, Technology and Management (KIST, , ) in Kigali, Rwanda is the first technology-focused institution of higher education to be created by the Rwanda government. KIST was established in November, 1997. Major partners in its creation were the Ministry of Education, the UNDP Rwanda, and GTZ, a German enterprise. The College of Science and Technology (CST) was established by the Government of Rwanda LAW N° 71/2013 OF 10/09/2013 ESTABLISHING THE UNIVERSITY OF RWANDA (UR) AND DETERMINING ITS MISSION, POWERS, ORGANISATION

答案字符位置：[181, 195)。

</details>

## 第73题：ambigdocs_16197

**query：** Where is the Statue of Margaret Thatcher located?

**term：** Statue of Margaret Thatcher
**dimension：** Entity Disambiguation
**来源：** 旧第90题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Statue of Margaret Thatcher (London Guildhall) | Guildhall, London | Guildhall, London |
| Statue of Margaret Thatcher (Palace of Westminster) | inside the Houses of Parliament, London | inside the Houses of Parliament, London / Inside the Houses of Parliament, London |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Statue of Margaret Thatcher (London Guildhall)：完整供应证据</summary>

Statue of Margaret Thatcher (London Guildhall) The statue of Margaret Thatcher in the Guildhall, London, is a marble sculpture of Margaret Thatcher. It was commissioned in 1998 from the sculptor Neil Simmons by the Speaker's Advisory Committee on Works of Art; paid for by an anonymous donor, it was intended for a plinth among statues of former Prime Ministers of the United Kingdom in the Members' Lobby of the House of Commons. However as the House did not permit a statue to be erected there during its subject's lifetime, the work had been temporarily housed in Guildhall. It was unveiled

答案字符位置：[86, 103)。

</details>

<details>
<summary>Statue of Margaret Thatcher (Palace of Westminster)：完整供应证据</summary>

Statue of Margaret Thatcher (Palace of Westminster) The statue of Margaret Thatcher inside the Houses of Parliament, London, is a bronze sculpture of Margaret Thatcher, the first female Prime Minister of the United Kingdom. It was ordered in 2003 following a change in rules to allow the depiction of living Prime Ministers in Parliament under certain conditions. It was unveiled by the Speaker of the House of Commons, Michael Martin, on 21 February 2007. The statue is high, and made in bronze. The design of the statue is intended to show Margaret Thatcher during her final term as Prime Minister

答案字符位置：[84, 123)。

</details>

## 第74题：ambigdocs_11890

**query：** Who is the artist of the album "Expectations"?

**term：** Expectation
**dimension：** Entity Disambiguation
**来源：** 旧第91题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Expectations (Bebe Rexha album) | Bebe Rexha | Bebe Rexha |
| Expectations (Hayley Kiyoko album) | Hayley Kiyoko | Hayley Kiyoko |
| Expectations (Keith Jarrett album) | Keith Jarrett | Keith Jarrett |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Expectations (Bebe Rexha album)：完整供应证据</summary>

Expectations (Bebe Rexha album) Expectations is the debut studio album by American singer-songwriter Bebe Rexha. It was released on June 22, 2018, by Warner Bros. Records. The album was announced following the success of her collaboration with country duo Florida Georgia Line, "Meant to Be". "Expectations" went out for pre-order on April 13, 2018, with the release of two promotional singles: "Ferrari" and "2 Souls on Fire". The album includes the singles "I Got You" and "Meant to Be" from "" and "", respectively. It features appearances from rappers Quavo and Tory Lanez, and country music duo Florida Georgia Line.

答案字符位置：[14, 24)。

</details>

<details>
<summary>Expectations (Hayley Kiyoko album)：完整供应证据</summary>

Expectations (Hayley Kiyoko album) Expectations is the debut major label studio album by American singer and actress Hayley Kiyoko, released on March 30, 2018. The album title was announced along with its cover on January 1, 2018 through social media. The album was preceded by the singles "Sleepover", "Feelings" and "Curious". "Expectations" garnered mostly positive reviews from music critics. The album debuted within the top 40 of record charts in Ireland, New Zealand, United Kingdom and United States. "Expectations" was preceded by the release of three singles, as well as one promotional single. The first single called "Sleepover" was released

答案字符位置：[14, 27)。

</details>

<details>
<summary>Expectations (Keith Jarrett album)：完整供应证据</summary>

the label subsequently signed him to his own contract, but subsequently broke the contract by dropping Jarrett after the record's release. Expectations (Keith Jarrett album) Expectations is a 1972 album by the pianist, saxophonist and composer Keith Jarrett, released on Columbia Records. In addition to Jarrett, musicians on the recording include Dewey Redman (tenor saxophone), Charlie Haden (bass), Paul Motian (drums), Sam Brown (guitar), Airto Moreira (percussion), as well as brass and string sections whose members are not credited in the album information. "Expectations" was produced by George Avakian. "Expectations" was the only recording Jarrett made under his own name

答案字符位置：[153, 166)。

</details>

## 第75题：ambigdocs_63056

**query：** When was George Ritchie born?

**term：** George Ritchie
**dimension：** Entity Disambiguation
**来源：** 旧第92题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| George Ritchie (rugby union, born 1848) | 16 April 1848 | 16 April 1848 / April 16, 1848 / April 16 1848 / 1848-04-16 |
| George Ritchie (rugby union, born 1909) | 1909 | 1909 |
| George G. Ritchie | 25 September 1923 | 25 September 1923 / September 25, 1923 / September 25 1923 / 1923-09-25 |
| George Ritchie (politician) | 14 December 1864 | 14 December 1864 / December 14, 1864 / December 14 1864 / 1864-12-14 |
| George Stephen Ritchie | 30 October 1914 | 30 October 1914 / October 30, 1914 / October 30 1914 / 1914-10-30 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>George Ritchie (rugby union, born 1848)：完整供应证据</summary>

George Ritchie (rugby union, born 1848) George Ritchie (16 April 1848 - 31 January 1896) was a Scottish international rugby union player who played for Merchistons in Edinburgh. Born in Edinburgh in 1848, Ritchie played as a Forward. Ritchie played in the first ever rugby union international match for Scotland against England in 27 March 1871 at Raeburn Place, Edinburgh. In the match, he almost scored the first ever international try. He went over the try-line but a clutch of bodies were on top of him. An Englishman claimed to have control of the ball and the umpire decided it

答案字符位置：[56, 69)。

</details>

<details>
<summary>George Ritchie (rugby union, born 1909)：完整供应证据</summary>

George Ritchie (rugby union, born 1909) George Fraser Ritchie (1909–1993) was a Scottish rugby union player. George Ritchie was educated at the High School of Dundee and Strathallan School in Perthshire. He played his club rugby for Dundee HSFP and was captain for three years between 1928 and 1931. Ritchie was capped once in 1932 for at number eight. He was named in the Scottish trial team of January 1930 but had to wait two years before gaining his cap. Scotland lost to England 16-3 at Twickenham on 19 March. He was the grandfather of noted Scottish rugby player Andy

答案字符位置：[34, 38)。

</details>

<details>
<summary>George G. Ritchie：完整供应证据</summary>

George G. Ritchie Dr. George G. Ritchie, M.D. (25 September 1923 – 29 October 2007) held positions as president of the Richmond Academy of General Practice; chairman of the Department of Psychiatry of Towers Hospital; and founder and president of the Universal Youth Corps, Inc. for almost 20 years. In 1967 he entered private psychiatry practice in Charlottesville, Virginia, and in 1983 moved to Anniston, Alabama, to serve as head of the Department of Psychiatry at the Northeast Alabama Regional Medical Center. He returned to Richmond in 1986 to continue in private practice until retirement in 1992. At the age

答案字符位置：[47, 64)。

</details>

<details>
<summary>George Ritchie (politician)：完整供应证据</summary>

of Port Adelaide. Among their children were: He collapsed and died while assisting the gardener at his home in Flinders Street, Kent Town. Ritchie was knighted K.C.M.G. in June 1935 while Acting Premier in the absence of Richard Butler. George Ritchie (politician) Sir George Ritchie KCMG (14 December 1864 – 7 August 1944) was a South Australian politician. During his parliamentary career he held every ministerial position and was a minister in both Houses, a feat rarely equalled. Ritchie was the third son of Captain James Ritchie (1832 – 23 April 1881) and his wife Alison (12 August 1829 –

答案字符位置：[290, 306)。

</details>

<details>
<summary>George Stephen Ritchie：完整供应证据</summary>

George Stephen Ritchie Rear-Admiral George Stephen "Steve" Ritchie CB DSC (30 October 1914 – 8 May 2012) was a British admiral noted for his cartographic and hydrographic work. Ritchie was born in Burnley, 1914, of Scottish parents, Sir Douglas Ritchie and Lady Margaret Stephen Ritchie. He was educated at the Royal Naval College, Dartmouth from the age of 13, from where he went to sea at the age of 17. In 1936 he joined the Surveying Service, being appointed to the old coal-burning surveying ship, , operating in the South China Sea. During the Second World War the then Lieutenant

答案字符位置：[75, 90)。

</details>

## 第76题：ambigdocs_26459

**query：** When was Judge Hale born?

**term：** Judge Hale
**dimension：** Entity Disambiguation
**来源：** 旧第93题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Clarence Hale | April 15, 1848 | April 15, 1848 / 15 April 1848 / April 15 1848 / 1848-04-15 |
| David J. Hale | June 30, 1967 | June 30, 1967 / 30 June 1967 / June 30 1967 / 1967-06-30 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Clarence Hale：完整供应证据</summary>

Clarence Hale Clarence Hale (April 15, 1848 – April 9, 1934) was a United States federal judge. Born in Turner, Maine, Hale received an A.B. from Bowdoin College in 1869 and read law to enter the bar in 1871. He was in private practice in Portland, Maine from 1871 to 1902, also serving as a city solicitor, for Portland, Maine from 1879 to 1882, and as a Maine state representative from 1883 to 1886. On May 13, 1902, Hale was nominated by President Theodore Roosevelt to a seat on the United States District Court for the District of Maine vacated

答案字符位置：[29, 43)。

</details>

<details>
<summary>David J. Hale：完整供应证据</summary>

David J. Hale David Jason Hale (born June 30, 1967) is a United States District Judge of the United States District Court for the Western District of Kentucky and former United States Attorney for the Western District of Kentucky. Hale was born on June 30, 1967 at the United States Army hospital at Fort Campbell, Kentucky. He received a Bachelor of Arts degree in 1989 from Vanderbilt University. He received a Juris Doctor in 1992 from the University of Kentucky College of Law. From 1992 to 1994, he was an associate at the law firm of Brown, Todd and Heyburn.

答案字符位置：[37, 50)。

</details>

## 第77题：ambigdocs_35352

**query：** Where is the Brackett House located?

**term：** Brackett House
**dimension：** Entity Disambiguation
**来源：** 旧第95题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Brackett House (Newton, Massachusetts) | Newton, Massachusetts | Newton, Massachusetts |
| Edward A. Brackett House | Winchester, Massachusetts | Winchester, Massachusetts |
| Brackett House (Reading, Massachusetts) | Reading, Massachusetts | Reading, Massachusetts |
| E. William Brackett House | Yakima, Washington | Yakima, Washington |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Brackett House (Newton, Massachusetts)：完整供应证据</summary>

Brackett House (Newton, Massachusetts) The Brackett House is an historic house located at 621 Centre Street in the Newton Centre village of Newton, Massachusetts. Built about 1844, it is a prominent local example of Greek Revival architecture, with a four-column temple front. Extensively damaged by fire in 2010, a careful restoration was completed in 2013. It was listed on the National Register of Historic Places on October 4, 1986. The Brackett House is located in a residential area south of Newton Corner, at the northwest corner of Centre and Bellevue Streets. Centre Street is a historically old road, and is

答案字符位置：[16, 37)。

</details>

<details>
<summary>Edward A. Brackett House：完整供应证据</summary>

Edward A. Brackett House The Edward A. Brackett House is a historic octagon house at 290 Highland Avenue in Winchester, Massachusetts. Built in the early 1850s by sculptor Edward Augustus Brackett, and based on popular plans described by Orson Squire Fowler, it is Winchester's only octagonal house. The house was listed on the National Register of Historic Places in 1989. The Bracket House is set back from the east side of Highland Avenue, a north-south route through the east side of Winchester. The house, as built in the early 1850s, is a distinctive design made by Brackett, an eccentric artist

答案字符位置：[108, 133)。

</details>

<details>
<summary>Brackett House (Reading, Massachusetts)：完整供应证据</summary>

built in 1920, during a period of rapid growth of housing in the town. It was built as infill on farmland that had first seen residential subdivision late in the 19th century. It is the town's best example of Bungalow architecture. Brackett House (Reading, Massachusetts) The Brackett House is a historic house at 276 Summer Avenue in Reading, Massachusetts. Built during a local residential construction boom in 1920, it is Reading's best example of Bungalow style architecture. It was listed on the National Register of Historic Places in 1984. The Brackett House stands in a large residential area southwest of

答案字符位置：[248, 270)。

</details>

<details>
<summary>E. William Brackett House：完整供应证据</summary>

E. William Brackett House The E. William Brackett House, located in Yakima, Washington, was entered into the National Register of Historic Places in 1990. Originally located on 80 acres of orchards and farmland, the building is currently situated on a three-quarter acre lot, the remainder of the property having been subdivided mostly for single family homes. The interior is composed of 6,000 square feet of living space symmetrically arranged around a central entry hall. The home was built in 1917 for E. William Brackett, a prominent local citizen who was a pioneer of irrigation in the Yakima valley. Born in

答案字符位置：[68, 86)。

</details>

## 第78题：ambigdocs_1927

**query：** When did Matsuo cease to exist as an independent municipality?

**term：** Matsuo
**dimension：** Entity Disambiguation
**来源：** 旧第97题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Matsuo, Chiba | March 27, 2006 | March 27, 2006 / 27 March 2006 / March 27 2006 / 2006-03-27 |
| Matsuo, Iwate | September 1, 2005 | September 1, 2005 / 1 September 2005 / September 1 2005 / 2005-09-01 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Matsuo, Chiba：完整供应证据</summary>

Matsuo, Chiba Matsuo Village was formed on April 1, 1889 within Musha District. Musha District became part of Sanbu District from April 1, 1897. On August 31, 1898, Matsuo was raised to town status. It expanded through the annexation of the neighboring villages of Ohira and Toyooka on February 1, 1955. On March 27, 2006, Matsuo, along with the towns of Narutō and Sanbu, and the village of Hasunuma (all from Sanbu District), was merged to create the city of Sanmu, and thus no longer exists as an independent municipality. As of November 1, 2005, (the last census data prior

答案字符位置：[307, 321)。

</details>

<details>
<summary>Matsuo, Iwate：完整供应证据</summary>

Matsuo, Iwate The village of Matsuo was created on April 1, 1889 within Kita-Iwate District with the establishment of the municipality system. Kita-Iwate and Minami-Iwate Districts merged to form Iwate District on March 29, 1898. On September 1, 2005, Matsuo, along with the towns of Ashiro and Nishine (all from Iwate District), was merged to create the city of Hachimantai and no longer exists as an independent municipality. Matsuo was formerly known as the home of Japan's largest sulfur mine—the Matsuo Kōzan —and, later, as the home of the Matsugawa geothermal power plant. The iron and copper Matsuo mine was

答案字符位置：[233, 250)。

</details>

## 第79题：ambigdocs_7657

**query：** When was Mount Moriah Baptist Church built?

**term：** Mount Moriah Baptist Church
**dimension：** Entity Disambiguation
**来源：** 旧第98题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Mount Moriah Baptist Church (Middlesboro, Kentucky) | during 1918-21 | during 1918-21 |
| Mount Moriah Baptist Church and Cemetery | about 1908 | about 1908 |
| Mount Moriah Baptist Church (Port Orange, Florida) | 1911 | 1911 |
| Mount Moriah Missionary Baptist Church | 1935 | 1935 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Mount Moriah Baptist Church (Middlesboro, Kentucky)：完整供应证据</summary>

Mount Moriah Baptist Church (Middlesboro, Kentucky) Mt. Moriah Baptist Church is a historic church at 314 N. Main Street in Middlesboro, Kentucky. It was built during 1918-21 and added to the National Register of Historic Places in 1985. It is a brick building with brick laid in common bond. It was deemed significant as "The church building has played an important role in the history of the black community of Middlesboro and is a visible expression of the important role blacks have played in the settlement and later development of planned communities such as Middlesboro," which is the largest planned

答案字符位置：[160, 174)。

</details>

<details>
<summary>Mount Moriah Baptist Church and Cemetery：完整供应证据</summary>

marker that reads: "Mount Moriah Baptist Church. K-99. The members of Mount Moriah Baptist Church belong to one of the region's earliest African American congregations, originating in a Sunday school for slaves established in the mid-1800s by Dr. Charles L. Cocke, founder of Hollins College. The group gained permission in 1858 to build its first church. The present church, the congregation's third, was built about 1908. It was added to the National Register of Historic Places and the Virginia Landmarks Register in 1994. The nearby cemetery was expanded from a former slave burial ground." "There are many unmarked graves at

答案字符位置：[412, 422)。

</details>

<details>
<summary>Mount Moriah Baptist Church (Port Orange, Florida)：完整供应证据</summary>

Esther Hawks established Florida's first integrated school in the area. An annual Freeman Day Ceremony commemorates the heritage. The church was renovated in 1956. Mount Moriah Baptist Church (Port Orange, Florida) Mount Moriah Baptist Church was built in Port Orange, Florida in 1911. Built to serve black residents, it was located in an area that came to be known as Freemanville and is believed to be the last remaining building from the settlement. Freed blacks settled the area to work at a lumber company started by John Milton Hawks, but sandy soil, corruption, and planning issues led to a rapid

答案字符位置：[280, 284)。

</details>

<details>
<summary>Mount Moriah Missionary Baptist Church：完整供应证据</summary>

parsonage on West Comstock Avenue". “In 1935, the funds from the estate of William A Coursen enabled Mt. Moriah to build its present sanctuary. The edifice was built at a cost of $8,500. Rev. I.C. Nimmons, the Church’s seventh pastor, provided leadership over the building project. Rev. Nimmons instituted the first Missionary Society, the Junior Church, and the Junior Choir". Construction of the new church building was performed by the African-American Ford Construction Company of Orlando. Since many local citizens were employed by this company, the assembly of the building helped bring the community together and stir up enthusiasm for

答案字符位置：[40, 44)。

</details>

## 第80题：ambigdocs_34684

**query：** Who is the artist associated with "Jump for Joy"?

**term：** Jump for Joy
**dimension：** Entity Disambiguation
**来源：** 旧第99题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Jump for Joy (1941 revue) | Duke Ellington | Duke Ellington |
| Jump for Joy (Bobby Short album) | Bobby Short | Bobby Short |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Jump for Joy (1941 revue)：完整供应证据</summary>

Jump for Joy (1941 revue) Jump for Joy is a 1941 musical revue by Duke Ellington that opened on July 10, 1941 and ran for at the Mayan Theater of Los Angeles for nine weeks (122 performances). It included many hit songs by Ellington that became pop and jazz standards like "I Got It Bad (and That Ain't Good)" and "A Drum Is a Woman". The musical received rave reviews, and both Orson Welles and Charles Chaplin considered buying the show, but were refused, as the show was collaborative in nature and the writers did not want it to be

答案字符位置：[66, 80)。

</details>

<details>
<summary>Jump for Joy (Bobby Short album)：完整供应证据</summary>

Jump for Joy (Bobby Short album) Jump for Joy is a 1970 album by American singer and pianist Bobby Short. William Ruhlmann reviewed the album for Allmusic and wrote that "For once, the purveyors of the Great American Songbook were absent: no Porter or Gershwin or Rodgers. Instead, Short performed a combination of recent songs from Broadway and old, bluesy numbers. The latter seemed to draw the greatest enthusiasm from him as he revisited some tunes he might have played in Midwest roadhouses back in his youth, songs like "Romance in the Dark," "I'm Confessin' That I Love You," and

答案字符位置：[14, 25)。

</details>

## 第81题：ambigdocs_41879

**query：** Where is Greenwood Academy located?

**term：** Greenwood Academy
**dimension：** Entity Disambiguation
**来源：** 旧第100题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Greenwood Academy, Birmingham | Castle Vale, Birmingham, England | Castle Vale, Birmingham, England |
| Greenwood Academy, Dreghorn | Dreghorn, Ayrshire, Scotland | Dreghorn, Ayrshire, Scotland |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Greenwood Academy, Birmingham：完整供应证据</summary>

Greenwood Academy, Birmingham Greenwood Academy is a coeducational secondary school with academy status, located in Castle Vale, Birmingham, England. The school opened in new premises in 1967. The buildings were completed and officially opened in 1969. It was built to serve the large new housing estate which was in the final stages of construction at this time. Later the school gained Performing Arts College specialist status. The school converted to academy status in January 2013. The school is sponsored by the Academies Enterprise Trust (AET).The school suffered a lot of uncertainty when AET arranged a number of Head teachers. Then

答案字符位置：[116, 148)。

</details>

<details>
<summary>Greenwood Academy, Dreghorn：完整供应证据</summary>

Greenwood Academy, Dreghorn Greenwood Academy is a state maintained secondary school situated in Dreghorn, Ayrshire, Scotland. The school opened in August 1972, serving the areas of Dreghorn, Springside, Bourtreehill, Broomlands and the outer areas of Irvine, and moved into new buildings in October 2008. The Head Teacher is Christine McGuire. Greenwood Academy has over 1500 pupils drawn from a catchment area which includes Dreghorn Primary School, Elderbank Primary School, Glebe Primary School, Lawthorn Primary School and Springside Primary School. The school accepts pupils from other schools when space allows. The school provides tuition in the subjects required by the "Curriculum

答案字符位置：[97, 125)。

</details>

## 第82题：ambigdocs_44226

**query：** Where is Mahatma Gandhi University located?

**term：** Mahatma Gandhi University
**dimension：** Entity Disambiguation
**来源：** 旧第101题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Mahatma Gandhi Kashi Vidyapith | Varanasi | Varanasi / Benaras |
| Mahatma Gandhi University, Kerala | Kottayam | Kottayam |
| Mahatma Gandhi Central University | Motihari | Motihari |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Mahatma Gandhi Kashi Vidyapith：完整供应证据</summary>

Mahatma Gandhi Kashi Vidyapith Mahatma Gandhi Kashi Vidyapith is a public university located in Varanasi or Benaras, Uttar Pradesh, India. Established in 1921 as Kashi Vidyapith and later renamed, it is administered under the state legislature of the government of Uttar Pradesh. The university has more than 400+ affiliated colleges spread over six districts. It is one of the largest state universities in Uttar Pradesh, with hundreds of thousands of students, both rural and urban. It offers a range of professional and academic courses in arts, science, commerce, law, computing and management. Babu Shiv Prasad Gupta and Bhagwan Das established

答案字符位置：[96, 104)。

</details>

<details>
<summary>Mahatma Gandhi University, Kerala：完整供应证据</summary>

Mahatma Gandhi University, Kerala Mahatma Gandhi University (MG University or MGU) is an Indian state-related public university. It was established on Gandhi Jayanti, 2 October 1983 in the Kottayam district of Kerala, India. Mahatma Gandhi University (formerly Gandhiji University), has been approved by UGC and accredited (A) by the National Assessment and Accreditation Council of India. The university have around 300 affiliated colleges spread over five districts in central Kerala. The university offers around 300 academic programmes (Bachelor's, Master's, Doctoral degrees) in the fields of Pure and Applied Sciences, Technology, Paramedical Studies, Nursing, Management, Law, Engineering, Gandhian Thought, International Relations,

答案字符位置：[189, 197)。

</details>

<details>
<summary>Mahatma Gandhi Central University：完整供应证据</summary>

Central University is presently located within the Zila School Campus. The land for the permanent campus has been allotted by the Govt. of Bihar. Mahatma Gandhi Central University Mahatma Gandhi Central University is a public central university located in Motihari, Bihar. This is the second central university in Bihar after Central University of South Bihar in Gaya. The university came into functional existence after its first Vice Chancellor Prof.(Dr.) Arvind Agrawal joined on 3 February, 2016. 18 different departments have been established with undergraduate and postgraduate courses ranging from traditional disciplines like Hindi and English to advanced courses like Management

答案字符位置：[256, 264)。

</details>

## 第83题：ambigdocs_2422

**query：** When did Hugh Massy become a Member of Parliament?

**term：** Hugh Massy
**dimension：** Entity Disambiguation
**来源：** 旧第102题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Hugh Massy, 1st Baron Massy | 1759 | 1759 |
| Hugh Massy, 2nd Baron Massy | 1776 | 1776 |
| Sir Hugh Massy, 1st Baronet | 1783 | 1783 |
| Sir Hugh Massy, 2nd Baronet | 1797 | 1797 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Hugh Massy, 1st Baron Massy：完整供应证据</summary>

Hugh Massy, 1st Baron Massy Hugh Massy, 1st Baron Massy (1700 – 30 January 1788) was an Anglo-Irish peer and politician. Massy was the son of Colonel Hugh Massy and the elder brother of General Eyre Massey, 1st Baron Clarina. He married firstly Mary Dawson, daughter of Colonel James Dawson by who he had four children. He married secondly Rebecca Dunlap, daughter of Francis Dunlap of Antigua, and had a further seven children. He was appointed High Sheriff of County Limerick for 1739 and was a Member of the Irish House of Commons for Limerick County between 1759 and 1776.

答案字符位置：[562, 566)。

</details>

<details>
<summary>Hugh Massy, 2nd Baron Massy：完整供应证据</summary>

Hugh Massy, 2nd Baron Massy Hugh Massy, 2nd Baron Massy (14 April 1733 - 10 May 1790) was an Anglo-Irish politician and peer. Massy was the son of Hugh Massy, 1st Baron Massy and Mary Dawson. Massy served as High Sheriff of County Limerick in 1765. He was elected to the Irish House of Commons as the Member of Parliament for Askeaton in 1776 and sat until 1783. He succeeded to his father's title on 30 January 1788. He married Catherine Taylor, the daughter of Colonel Edward Taylor and Anne Maunsell, in September 1760. They had eight children. He was

答案字符位置：[338, 342)。

</details>

<details>
<summary>Sir Hugh Massy, 1st Baronet：完整供应证据</summary>

Baronet, of Donass in the County of Clare, in the Baronetage of Ireland. He was elected as the MP for Clare in 1783 and held the seat until 1790. He married Elizabeth Stacpoole, daughter of George John Baptista Stacpoole and Mary Massy, on 16 August 1766. He was a first cousin of Hugh Massy, 1st Baron Massy and Eyre Massey, 1st Baron Clarina. Sir Hugh Massy, 1st Baronet Sir Hugh Dillon Massy, 1st Baronet (1740 – 29 April 1807) was an Anglo-Irish politician and baronet. Massy was the son of the Very Reverend Charles Massy, Dean of Limerick and Ardfert.

答案字符位置：[111, 115)。

</details>

<details>
<summary>Sir Hugh Massy, 2nd Baronet：完整供应证据</summary>

29 April 1807 he succeeded to his father's baronetcy. He married Sarah Hankey, daughter of Thomas Hankey and Mary Wyver, on 14 May 1796. Sir Hugh Massy, 2nd Baronet Sir Hugh Dillon Massy, 2nd Baronet (9 November 1767 – 28 March 1842) was an Anglo-Irish politician and baronet. Massy was the son of Sir Hugh Massy, 1st Baronet and Elizabeth Stacpoole. In 1797 he was elected to the Irish House of Commons as the Member of Parliament for Clare, and sat for the seat until its abolition under the Acts of Union 1800. He was returned to the House of

答案字符位置：[354, 358)。

</details>

## 第84题：ambigdocs_30039

**query：** When was Judge Peck nominated for a seat on the United States District Court?

**term：** Judge Peck
**dimension：** Entity Disambiguation
**来源：** 旧第103题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| James H. Peck | March 29, 1822 | March 29, 1822 / 29 March 1822 / March 29 1822 / 1822-03-29 |
| John Weld Peck | October 30, 1919 | October 30, 1919 / 30 October 1919 / October 30 1919 / 1919-10-30 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>James H. Peck：完整供应证据</summary>

and in St. Louis, Missouri from 1818 to 1822. On March 29, 1822, Peck was nominated by President James Monroe to a new seat on the United States District Court for the District of Missouri created by 3 Stat. 653. He was confirmed by the United States Senate On April 5, 1822, and received his commission the same day. Peck was involved in several land claim cases arising out of the Louisiana territory purchase; in one such case in 1825 he ruled against the client of the lawyer Luke Lawless and published his opinion in a St. Louis newspaper the

答案字符位置：[49, 63)。

</details>

<details>
<summary>John Weld Peck：完整供应证据</summary>

John Weld Peck John Weld Peck (February 5, 1874 – August 10, 1937) was a United States federal judge. Born in Wyoming, Ohio, Peck received an A.B. from Harvard University in 1896 and an LL.B. from the University of Cincinnati College of Law in 1898. He was in private practice in Cincinnati, Ohio from 1898 to 1919. On October 30, 1919, Peck was nominated by President Woodrow Wilson to a seat on the United States District Court for the Southern District of Ohio vacated by Howard Clark Hollister. Peck was confirmed by the United States Senate on November 5, 1919,

答案字符位置：[319, 335)。

</details>

## 第85题：ambigdocs_35275

**query：** When did William Maynard become a Member of Parliament?

**term：** William Maynard
**dimension：** Entity Disambiguation
**来源：** 旧第104题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Sir William Maynard, 1st Baronet | April 1685 | April 1685 |
| Sir William Maynard, 4th Baronet | 1759 | 1759 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Sir William Maynard, 1st Baronet：完整供应证据</summary>

Sir William Maynard, 1st Baronet Sir William Maynard, 1st Baronet (6 October 1641 – 7 November 1685) was an English politician and baronet. He was the third and eldest surviving son of Charles Maynard and his wife Mary Corsellis, daughter of Zeager Corsellis, of London. His uncle was William Maynard, 1st Baron Maynard. On 1 February 1681, Maynard was created a Baronet, of Walthamstow, in the County of Essex. In April 1685, he entered the English House of Commons as a Member of Parliament (MP) for Essex, but died seven months later. He married Mary Baynbrigg, daughter of William Baynbrigg,

答案字符位置：[415, 425)。

</details>

<details>
<summary>Sir William Maynard, 4th Baronet：完整供应证据</summary>

Sir William Maynard, 4th Baronet Sir William Maynard, 4th Baronet (19 April 1721 – 18 January 1772)of Waltons, Ashdon, Essex was a British politician and baronet. He was the only son of Sir Henry Maynard, 3rd Baronet and his wife Catherine Gunter, daughter of George Gunter. In 1738, he succeeded his father as baronet. Maynard entered the British House of Commons as Member of Parliament (MP) for Essex in 1759, representing the constituency until 1772. On 13 August 1751, he married Charlotte Bisshopp, second daughter of Sir Cecil Bishopp, 6th Baronet, and by her he had four children, three sons

答案字符位置：[407, 411)。

</details>

## 第86题：ambigdocs_46145

**query：** What sport is the Singapore Open associated with?

**term：** Singapore Open
**dimension：** Entity Disambiguation
**来源：** 旧第105题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Singapore Open (badminton) | badminton | badminton / Badminton |
| Singapore Open (golf) | golf | golf / Golf |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Singapore Open (badminton)：完整供应证据</summary>

Singapore Open (badminton) The Singapore Open is an badminton event that has been held in Singapore annually since 1987, and which is now part of the BWF Super Series tournament that began 2007. As Aviva Open Singapore, the tournament restarted in 2004, officially organised by the Singapore Badminton Association. The event turned out successful and was continued over the years, with Aviva being the title sponsor. In 2007, Aviva Open Singapore achieved a milestone by elevating its status after being the first event to offer qualifying points for the 2008 Olympic Games in Beijing. The total prize purse is US$350,000.

答案字符位置：[16, 25)。

</details>

<details>
<summary>Singapore Open (golf)：完整供应证据</summary>

Singapore Open (golf) The Singapore Open is a golf tournament in Singapore that has been sanctioned by the Asian Tour from that tour's second season, 1996. The event was co-sanctioned with the European Tour from 2009 to 2012, and with the Japan Golf Tour since 2016. Prior to being an Asian Tour event it had been on the Australasian Tour from 1993 to 1995. It was founded in 1961 and was staged annually until 2001, when it was won by Thaworn Wiratchant. It was then cancelled for lack of sponsorship. Other winners in the years leading up to this included

答案字符位置：[16, 20)。

</details>

## 第87题：ambigdocs_25017

**query：** When was the Stanley House built?

**term：** Stanley House
**dimension：** Entity Disambiguation
**来源：** 旧第106题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Leonard W. Stanley House | 1855-56 | 1855-56 |
| Stanley-Woodruff-Allen House | about 1752 | about 1752 |
| Stanley House, Chelsea | 1691 | 1691 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Leonard W. Stanley House：完整供应证据</summary>

Leonard W. Stanley House The Leonard W. Stanley House is a historic house at 23–25 Taylor Street in Waltham, Massachusetts. The 2-1/2 story wood frame house was built in 1855-56 by Leonard Stanley, a policeman. It is one of the oldest houses on the South Side of Waltham, which the city purchased from Newton in 1849, and is an unusual local example of transitional Federal/Italianate styling. Its basic massing is somewhat typically Federalist, with a five bay facade and side gable roof. However, it has deep eaves and segmented-arch attic windows, typical Italianate features. The main block was extended with

答案字符位置：[170, 177)。

</details>

<details>
<summary>Stanley-Woodruff-Allen House：完整供应证据</summary>

Stanley-Woodruff-Allen House The Stanley-Woodruff-Allen House is a historic house at 37 Buena Vista Road in West Hartford, Connecticut. Built about 1752, it is one of West Hartford's oldest surviving buildings. It was listed on the National Register of Historic Places in 1986. It is now part of the suite of buildings of the West Hartford Art League. The Stanley-Woodruff-Allen House is located in western West Hartford, on the south side of Buena Vista Road, just east of the some of the town's athletic fields and the northern end of the Buena Vista Golf Course. It is set facing east near

答案字符位置：[142, 152)。

</details>

<details>
<summary>Stanley House, Chelsea：完整供应证据</summary>

Stanley House, Chelsea Stanley House at 550 King's Road is a 17th century house in Chelsea, London, the former house of Admiral Sir Charles Wager. It is a Grade II* listed building. The house was built for the Stanley family in 1691. In the early 18th century it was occupied by Thomas Arundell, son of Henry Arundell, 5th Baron Arundell of Wardour, before becoming the home of Admiral Sir Charles Wager who died there in 1743. It was acquired by the Countess of Strathmore in 1777 before coming into the ownership of Sir William Hamilton, British Envoy at the Court

答案字符位置：[228, 232)。

</details>

## 第88题：ambigdocs_7394

**query：** Who is the artist of the album "Tough All Over"?

**term：** Tough All Over
**dimension：** Entity Disambiguation
**来源：** 旧第107题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Tough All Over (Gary Allan album) | Gary Allan | Gary Allan |
| Tough All Over (Shelby Lynne album) | Shelby Lynne | Shelby Lynne |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Tough All Over (Gary Allan album)：完整供应证据</summary>

Tough All Over (Gary Allan album) Tough All Over is the sixth studio album by American country music artist Gary Allan. It was released in October 2005 via MCA Nashville. It has been certified gold by the RIAA. Recorded after his wife's suicide, this album is more somber than his previous ones, with several of its songs termed to be "excruciatingly sad." Two songs from the album were released as singles: "Best I Ever Had" (a cover of a 2001 Vertical Horizon song) and "Life Ain't Always Beautiful" . Both placed reached within the Top 10 on the U.S. "Billboard"

答案字符位置：[16, 26)。

</details>

<details>
<summary>Tough All Over (Shelby Lynne album)：完整供应证据</summary>

Tough All Over (Shelby Lynne album) Tough All Over is the second album by American country music songwriter Shelby Lynne. It was released in 1990 via Epic Records. It includes the singles "I'll Lie Myself to Sleep" and "Things Are Tough All Over". The album includes several cover songs: "Lonely Weekends" was originally released by Charlie Rich, "I Walk the Line" by Johnny Cash, and "Don't Get Around Much Anymore" by Duke Ellington. Thom Jurek of "Allmusic" rated the album 4 out of 5 stars, saying that "It just isn't a strictly country outing, but it's a truly fine pop-country

答案字符位置：[16, 28)。

</details>

## 第89题：ambigdocs_30598

**query：** When was the Lafayette County Courthouse built?

**term：** Lafayette County Courthouse
**dimension：** Entity Disambiguation
**来源：** 旧第108题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Lafayette County Courthouse (Missouri) | 1847 | 1847 |
| Lafayette County Courthouse (Wisconsin) | 1905 | 1905 |
| Lafayette County Courthouse (Florida) | 1908 | 1908 |
| Lafayette County Courthouse (Mississippi) | 1872 | 1872 |
| Old Lafayette County Courthouse | 1893-1894 | 1893-1894 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Lafayette County Courthouse (Missouri)：完整供应证据</summary>

Lafayette County Courthouse (Missouri) The Lafayette County Courthouse is a historic courthouse located at Lexington, Lafayette County, Missouri. It was built in 1847 and is the oldest courthouse in continuous use west of the Mississippi River. It is known far and wide for the cannonball embedded in the upper left column, a remnant of the Civil War Battle of Lexington I, fought on September 18, 19 and 20, 1861. In 1847, County Judges Thomas Gordon, Nathaniel Price, and Joseph W. Hall determined that a new Courthouse was needed to serve Lafayette County, Missouri. The judges chose a site on the

答案字符位置：[162, 166)。

</details>

<details>
<summary>Lafayette County Courthouse (Wisconsin)：完整供应证据</summary>

Lafayette County Courthouse (Wisconsin) The Lafayette County Courthouse is a Neoclassical building constructed in Darlington, Wisconsin in 1905. It was added to the National Register of Historic Places in 1978. An earlier county courthouse stood on the southeast corner of the same lot since 1861 - a three-story stone building. By 1900 more space was needed. Matt Murphy of Benton, Wisconsin was the remaining trustee of a fund to care for widows and others affected by the Civil War. The fund was not needed after the federal government took responsibility for those affected by the war, and after exploring other

答案字符位置：[139, 143)。

</details>

<details>
<summary>Lafayette County Courthouse (Florida)：完整供应证据</summary>

Lafayette County Courthouse (Florida) The Lafayette County Courthouse, built in 1908, is an historic courthouse building located in Mayo, Florida, It was designed by Atlanta-based architect Edward Columbus Hosford in the Classical Revival style, who designed other courthouses in Florida and other states. It was built of Indiana limestone by the Mutual Construction Company of Louisville, Kentucky. Because there was no railroad into Lafayette County, the limestone and other materials were shipped by rail to O'Brien in Suwannee, County and then transported by wagon to Mayo, crossing the Suwannee River via Grant's Ferry north of Troy Springs. It is Lafayette

答案字符位置：[80, 84)。

</details>

<details>
<summary>Lafayette County Courthouse (Mississippi)：完整供应证据</summary>

Lafayette County Courthouse (Mississippi) The Lafayette County Courthouse is located in Oxford, Mississippi and listed on the National Register of Historic Places. The current structure was constructed in 1872 to replace an earlier building burned during the Civil War by Union troops directed by General Andrew Jackson Smith. Spires Boling of the firm Willis, Sloan and Trigg was the courthouse's architect. Two subsequent expansions of the building were performed. In 1952 and 1953, the west and east bays were added. The structure was renovated in 1981. The Courthouse currently houses several judicial courtrooms and related offices, including the Third Circuit

答案字符位置：[205, 209)。

</details>

<details>
<summary>Old Lafayette County Courthouse：完整供应证据</summary>

in "A Guide to Florida's Historic Architecture", published by the University of Florida Press. Today it is an inn called the Chateau. Old Lafayette County Courthouse The Old Lafayette County Courthouse, built 1893-1894, is an historic former courthouse building located on State Road 51 at 136 Fletcher Avenue, North, corner of Bloxham Street in Mayo, Florida, It was Lafayette County's second courthouse, the first at New Troy having burned down New Year's Eve 1892. It was built on the courthouse square in Mayo but was moved across the street to make way for a fireproof building, the present Lafayette County

答案字符位置：[209, 218)。

</details>

## 第90题：ambigdocs_50702

**query：** Who is the artist of the "Live at Donte's" album?

**term：** Live at Donte's
**dimension：** Entity Disambiguation
**来源：** 旧第109题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Live at Donte's (Joe Pass album) | Joe Pass | Joe Pass |
| Live at Donte's (Lenny Breau album) | Lenny Breau | Lenny Breau |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Live at Donte's (Joe Pass album)：完整供应证据</summary>

Live at Donte's (Joe Pass album) Live at Donte's (or The Joe Pass Trio Live at Donte's) is a live album by American jazz guitarist Joe Pass that was released in 1974. After spending over ten years playing in relative obscurity, Pass released the critically acclaimed solo-guitar "Virtuoso" and also played on two Ella Fitzgerald albums. Writing for Allmusic, music critic Scott Yanow wrote of the album, "The performances are as excellent as one would expect. In fact, considering how many albums he did for Pablo (a few dozen), it is remarkable to realize that every one of them are

答案字符位置：[17, 25)。

</details>

<details>
<summary>Live at Donte's (Lenny Breau album)：完整供应证据</summary>

Live at Donte's (Lenny Breau album) Live at Donte's is a live album by Canadian guitarist Lenny Breau, recorded in 1969 and released in 2000. Music critic Stephen Howell was critical of the poor recording and production in his review for Allmusic. Of the performance, he wrote the release "does showcase Breau's ability to make one guitar sound like two, due to his mix of classical, country, flamenco, and jazz roots that he incorporates into his fingerpicking style... If you're looking to purchase a live CD of Breau, however, it is recommended that you pick up "The Velvet Touch of

答案字符位置：[17, 28)。

</details>

## 第91题：ambigdocs_65670

**query：** When was Jimmy Connor born?

**term：** Jimmy Connor
**dimension：** Entity Disambiguation
**来源：** 旧第112题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Jimmy Connor (footballer, born 1881) | 1881 | 1881 |
| Jimmy Connor (footballer, born 1909) | 1 June 1909 | 1 June 1909 / June 1, 1909 / June 1 1909 / 1909-06-01 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Jimmy Connor (footballer, born 1881)：完整供应证据</summary>

Jimmy Connor (footballer, born 1881) James Connor was a Scottish professional footballer. He spent his entire career at Blackpool in the early 1900s, making almost 300 Football League appearances for the club. Bathgate-born Connor made his debut for Blackpool in the opening game of the 1905–06 season, scoring both goals in their 2–0 victory over Burton United at Bloomfield Road. He went on to appear in 33 of Blackpool's 38 league games that season, scoring a further four goals. He also appeared in all five of the club's FA Cup ties. The following season, 1906–07, Connor's appearances were sporadic. After

答案字符位置：[31, 35)。

</details>

<details>
<summary>Jimmy Connor (footballer, born 1909)：完整供应证据</summary>

Jimmy Connor (footballer, born 1909) James Connor (1 June 1909 – 8 May 1980) was a Scottish footballer who played for Sunderland and the Scotland national football team as an outside left. He was born in Renfrew, Scotland. James "Jimmy" Connor was one of the most popular players ever in red and white. He was an outside-left who loved to move inside the full-back and hit a shot with his fierce left foot. In 1936 when Sunderland won Division 1 (now the Premiership) Connor had his greatest moment for Sunderland when he scored the winner in a 5-4 win against

答案字符位置：[51, 62)。

</details>

## 第92题：ambigdocs_57807

**query：** Who is the artist of the album "Dreaming My Dreams"?

**term：** Dreaming My Dreams
**dimension：** Entity Disambiguation
**来源：** 旧第113题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Dreamin' My Dreams (Marianne Faithfull album) | Marianne Faithfull | Marianne Faithfull |
| Dreamin' My Dreams (Patty Loveless album) | Patty Loveless | Patty Loveless |
| Dreaming My Dreams (Waylon Jennings album) | Waylon Jennings | Waylon Jennings |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Dreamin' My Dreams (Marianne Faithfull album)：完整供应证据</summary>

Dreamin' My Dreams (Marianne Faithfull album) Dreamin' My Dreams is the sixth studio album by English singer Marianne Faithfull. It was released in 1976 by NEMS Records and it is Faithfull's first and only record of country music. The album was re-released two years later in 1978 as Faithless. The main differences between the two albums are: the album art and "Faithless" including 4 more tracks and some tracks rearranged. The musicians on both versions of the album are The Grease Band. It was Faithfull's first album in almost a decade. The single "Dreamin' My Dreams" topped the charts in

答案字符位置：[20, 38)。

</details>

<details>
<summary>Dreamin' My Dreams (Patty Loveless album)：完整供应证据</summary>

Dreamin' My Dreams (Patty Loveless album) Dreamin' My Dreams is the fourteenth album of original recordings by Patty Loveless. Released in September 2005, the album debuted on the Billboard Top Country Albums chart on October 1, 2005 at #29 (its peak), staying on the charts for 8 weeks until November 26, 2005. This was the last album Loveless recorded for Epic Records before the label closed its Nashville division in 2005. As listed in liner notes. "Never Ending Song of Love" was recorded a duet with fellow Pikeville, Kentucky native Dwight Yoakam. The original version of “Never Ending Song of

答案字符位置：[20, 34)。

</details>

<details>
<summary>Dreaming My Dreams (Waylon Jennings album)：完整供应证据</summary>

Sun Records, producing Johnny Cash and Jerry Lee Lewis. Jennings later declared, "He was a sheer-out genius, all soul. If you got around him at the right moment, he could put the world back on track." As Rich Kienzle observes in the liner notes to the 2001 reissue of the album, Clement and the renegade Jennings were kindred spirits when it came to their outlook on recording: After Jack Clement married Waylon Jennings' sister-in-law, Clement invited him to a Thursday night demo session in his personal studio. Clement's friend, Allen Reynolds, gave Jennings his recently written song "I Recall a

答案字符位置：[405, 420)。

</details>

## 第93题：ambigdocs_35926

**query：** When was Port Elgin incorporated as a village?

**term：** Port Elgin
**dimension：** Entity Disambiguation
**来源：** 旧第115题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Port Elgin, New Brunswick | 1922 | 1922 |
| Port Elgin, Ontario | 1874 | 1874 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Port Elgin, New Brunswick：完整供应证据</summary>

area which was named Gaspareaux Town. Gaspareaux Town was renamed Port Elgin in 1847 in honour of Lord Elgin. The community was incorporated as a village in 1922, the first community in the province to do so. Throughout the 19th century and first half of the 20th century, Port Elgin experienced modest industrialization with a handful of small factories, tanneries, and sawmills. The village also saw some shipping activity with several wharves on a sheltered harbour at the mouth of the Gaspereau River. The New Brunswick and Prince Edward Island Railway was built through the village in the early 1880s,

答案字符位置：[157, 161)。

</details>

<details>
<summary>Port Elgin, Ontario：完整供应证据</summary>

was laid out. The enterprise of its businessmen, notably Henry Hilker, Samuel Bricker and John Stafford, contributed to the development of the settlement, which had a population of over 600 by 1867. The arrival of the Wellington, Grey and Bruce Railway in 1872 further stimulated the growth of the community and it was incorporated as a Village in 1874 with a population of about 950. Early industries included a steam sawmill, foundry, and woolen mill. By 1869 the population was 650 and there was connection by steamship to Southampton and to Goderich. The first shipping pier was built in 1857.

答案字符位置：[348, 352)。

</details>

## 第94题：ambigdocs_1261

**query：** When did the 2018 Indonesia earthquake occur?

**term：** 2018 Indonesia earthquake
**dimension：** Entity Disambiguation
**来源：** 旧第116题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| 19 August 2018 Lombok earthquake | 19 August 2018 | 19 August 2018 / August 19, 2018 / August 19 2018 / 2018-08-19 |
| 2018 West Java earthquake | 23 January 2018 | 23 January 2018 / January 23, 2018 / January 23 2018 / 2018-01-23 |
| 2018 East Java earthquake | 11 October 2018 | 11 October 2018 / October 11, 2018 / October 11 2018 / 2018-10-11 |
| 2018 Sulawesi earthquake and tsunami | 28 September 2018 | 28 September 2018 / September 28, 2018 / September 28 2018 / 2018-09-28 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>19 August 2018 Lombok earthquake：完整供应证据</summary>

19 August 2018 Lombok earthquake On 19 August 2018 a major earthquake struck with high intensity on the northeast corner of Lombok (Sambelia and Labuhan Lombok settlements) and northwest Sumbawa (Poto Tano settlement) at 22:56 local time, a few km to the east of the series of quakes that had been rocking the area for the past 3 weeks. It was measured at 6.9 (USGS), at a depth of 25.6 km. The Indonesian BMKG announced that it was a new major earthquake and it was not an aftershock. The earthquake occurred on the same overall structure, the Flores Back Arc

答案字符位置：[0, 14)。

</details>

<details>
<summary>2018 West Java earthquake：完整供应证据</summary>

2018 West Java earthquake On 23 January 2018, at 13:34:50 Western Indonesian Time (06:34:54 UTC), an earthquake struck the Indonesian island of Java near the city of Lebak. The earthquake, measured 5.9 on the , occurred approximately 40 kilometres south of the village of Binuangeun at a depth of 43.9 kilometres. The earthquake was categorized as a strong and shallow earthquake. Strong shaking were widely reported across Banten, Lampung, West Java, Central Java and Jakarta. The tremor in Jakarta was much harder than in other recent quakes. By the virtue of its distance from the Indo-Australian plate, the capital normally

答案字符位置：[29, 44)。

</details>

<details>
<summary>2018 East Java earthquake：完整供应证据</summary>

2018 East Java earthquake On 11 October 2018, an earthquake struck off the coast of East Java, Indonesia, with the epicentre located off the coast of Situbondo Regency. The earthquake, which struck at dawn, killed 4 people in addition to destroying or damaging hundreds of houses, mostly in the small island of Sapudi. The earthquake occurred at 18:44:55 UTC (01:44:55 WIB), with a strength of 6.0, 9 km depth and epicenter location of (USGS) or 6.3, 12 km depth and epicenter at (BMKG). The epicenter was located underwater, around 60 km northeast of the town of Situbondo. Indonesian Meteorology, Climatology,

答案字符位置：[29, 44)。

</details>

<details>
<summary>2018 Sulawesi earthquake and tsunami：完整供应证据</summary>

2018 Sulawesi earthquake and tsunami On 28 September 2018, a shallow, large earthquake struck in the neck of the Minahasa Peninsula, Indonesia, with its epicentre located in the mountainous Donggala Regency, Central Sulawesi. This wasn't at all out of the ordinary: Indonesia is a nation of islands born from very complex and deadly plate tectonics. Sulawesi is right in the path of a triple junction, where three major plates – the Australian, Philippine, and Sunda – converge. The island is stitched together from island arcs and continental fragments mashed together by colliding plates, plus volcanoes birthed by subduction. The area

答案字符位置：[40, 57)。

</details>

## 第95题：ambigdocs_63048

**query：** Who is the main actress in the film "And God Created Woman"?

**term：** And God Created Woman
**dimension：** Entity Disambiguation
**来源：** 旧第117题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| And God Created Woman (1956 film) | Brigitte Bardot | Brigitte Bardot |
| And God Created Woman (1988 film) | Rebecca De Mornay | Rebecca De Mornay |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>And God Created Woman (1956 film)：完整供应证据</summary>

And God Created Woman (1956 film) And God Created Woman () (1956) is a French drama film directed by Roger Vadim and starring Brigitte Bardot. Though not her first film, it is widely recognized as the vehicle that launched Bardot into the public spotlight and immediately created her "sex kitten" persona, making her an overnight sensation. When the film was released in the United States by distributor Kingsley-International Pictures in 1957, it pushed the boundaries of the representation of sexuality in American cinema, and most available prints of the film were heavily edited to conform with the prevailing censorial standards

答案字符位置：[126, 141)。

</details>

<details>
<summary>And God Created Woman (1988 film)：完整供应证据</summary>

And God Created Woman (1988 film) And God Created Woman is a 1988 film directed by Roger Vadim and starring Rebecca De Mornay, Vincent Spano and Frank Langella. It has the same title as the 1956 French film "Et Dieu… créa la femme" ("And God created woman") starring Brigitte Bardot, also directed by Vadim, but has a completely different story. Robin Shea (Rebecca De Mornay) is a convict in a New Mexico prison. She manages to escape, but mistakenly hitches a ride in the limo of James Tiernan (Frank Langella), a politician who was visiting the prison as part of

答案字符位置：[108, 125)。

</details>

## 第96题：ambigdocs_17424

**query：** When was Neville Stibbard born?

**term：** Neville Stibbard
**dimension：** Entity Disambiguation
**来源：** 旧第118题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Neville Stibbard (footballer, born 1923) | 11 December 1923 | 11 December 1923 / December 11, 1923 / December 11 1923 / 1923-12-11 |
| Neville Stibbard (footballer, born 1952) | 9 February 1952 | 9 February 1952 / February 9, 1952 / February 9 1952 / 1952-02-09 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Neville Stibbard (footballer, born 1923)：完整供应证据</summary>

Neville Stibbard (footballer, born 1923) Neville Stibbard (11 December 1923 – 3 May 1994) was an Australian rules footballer who played with South Melbourne and North Melbourne in the Victorian Football League (VFL). Stibbard spent four years with the South Melbourne seconds before getting his chance at league football. A follower known for his high marking ability, Stibbard made six appearances for South Melbourne, early in the 1946 VFL season. He was granted a clearance to Victorian Football Association club Oakleigh in June. After playing out the year with Oakleigh, Stibbard returned to the VFL in 1947, as one of

答案字符位置：[59, 75)。

</details>

<details>
<summary>Neville Stibbard (footballer, born 1952)：完整供应证据</summary>

Neville Stibbard (footballer, born 1952) Neville Stibbard (born 9 February 1952) is a former Australian rules footballer who played with South Melbourne in the Victorian Football League (VFL). Stibbard's father, also named Neville, played for South Melbourne and North Melbourne during the 1940s. Recruited from Ivanhoe Amateurs, Stibbard joined his twin brother Robert at South Melbourne in the 1973 VFL season and made 10 appearances in his first year. In 1974 he played 11 games for South Melbourne. He was one of his side's best in their round seven win over Melbourne at Lake Oval, with four goals and 20

答案字符位置：[64, 79)。

</details>

## 第97题：ambigdocs_28221

**query：** Who is the composer of Mass No. 1?

**term：** Mass No. 1
**dimension：** Entity Disambiguation
**来源：** 旧第120题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Mass No. 1 (Bruckner) | Anton Bruckner | Anton Bruckner |
| Mass No. 1 (Schubert) | Franz Schubert | Franz Schubert |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Mass No. 1 (Bruckner)：完整供应证据</summary>

Mass No. 1 (Bruckner) The Mass No. 1 in D minor, WAB 26 by Anton Bruckner, is a setting of the Mass ordinary for soloists, mixed choir and orchestra, and organ. After he had ended his eight-year study period with Sechter and Kitzler and he had composed a few smaller works, such as the Festive Cantata (1862) and Psalm 112 (1863), Bruckner composed his first grand Mass, the Mass in D minor. He completed the work on 29 September 1864. The premiere of the Mass in the old Linz Cathedral on 20 November 1864 was successful. A laudatory review in

答案字符位置：[59, 73)。

</details>

<details>
<summary>Mass No. 1 (Schubert)：完整供应证据</summary>

Mass No. 1 (Schubert) Mass No. 1 in F major, 105, is a mass composed by Franz Schubert in 1814. It is scored for two soprano soloists, two tenor soloists, alto and bass soloists, SATB choir, oboe, clarinet, bassoon, 2 horns, violin I and II, viola, and (cello, double bass and organ). It was the first of Schubert's masses to be performed, and is of the " type. The mass was composed for the centennial celebration of the parish church of Lichtental, now part of Vienna. The Schuberts' family church, it is also known as " (Schubert church). Schubert received

答案字符位置：[72, 86)。

</details>

## 第98题：ambigdocs_66784

**query：** Who directed the film "The Constant Nymph"?

**term：** The Constant Nymph
**dimension：** Entity Disambiguation
**来源：** 旧第124题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| The Constant Nymph (1928 film) | Adrian Brunel | Adrian Brunel |
| The Constant Nymph (1933 film) | Basil Dean | Basil Dean |
| The Constant Nymph (1943 film) | Edmund Goulding | Edmund Goulding |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>The Constant Nymph (1928 film)：完整供应证据</summary>

The Constant Nymph (1928 film) The Constant Nymph is a 1928 British silent film drama, directed by Adrian Brunel and starring Ivor Novello and Mabel Poulton. This was the first film adaptation of the 1924 best-selling and controversial novel "The Constant Nymph" by Margaret Kennedy. The theme of adolescent sexuality reportedly discomfited the British film censors, until they were reassured that lead actress Poulton was in fact in her 20s. Location filming took place in the Austrian Tyrol, and the film proved a commercial and critical success, being named the best British feature film of 1928. Jo Botting of the

答案字符位置：[99, 112)。

</details>

<details>
<summary>The Constant Nymph (1933 film)：完整供应证据</summary>

The Constant Nymph (1933 film) The Constant Nymph is a 1933 British drama film directed by Basil Dean and starring Victoria Hopper, Brian Aherne and Leonora Corbett. It is an adaptation of the novel "The Constant Nymph" by Margaret Kennedy. Dean tried to persuade Novello to reprise his appearance from the 1928 silent version "The Constant Nymph" but was turned down and cast Aherne in the part instead. The film is set in Tyrol, western Austria. Previously filmed in 1928, the sentimental Margaret Kennedy novel "The Constant Nymph" was sumptuously remade by Gaumont-British Picture Corporation in 1933. Victoria Hopper plays

答案字符位置：[91, 101)。

</details>

<details>
<summary>The Constant Nymph (1943 film)：完整供应证据</summary>

The Constant Nymph (1943 film) The Constant Nymph is a 1943 romantic drama film starring Charles Boyer, Joan Fontaine, Alexis Smith, Brenda Marshall, Charles Coburn, May Whitty, and Peter Lorre. It was adapted by Kathryn Scola from the Margaret Kennedy novel and play by Kennedy and Basil Dean, and directed by Edmund Goulding. Lewis Dodd (Charles Boyer) is a composer whose latest symphony flops in London. Seeking new inspiration, and to escape his critics, he travels to Switzerland to stay at the home of older friend Albert Sanger (Montagu Love) and his young wife, Lina. Sanger's four young daughters—Kate (Jean

答案字符位置：[311, 326)。

</details>

## 第99题：ambigdocs_26789

**query：** When was Hugh Gallacher born?

**term：** Hugh Gallacher
**dimension：** Entity Disambiguation
**来源：** 旧第125题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Hugh Gallacher (footballer, born 1870) | 11 May 1870 | 11 May 1870 / May 11, 1870 / May 11 1870 / 1870-05-11 |
| Hugh Gallacher (footballer, born 1930) | 26 November 1930 | 26 November 1930 / November 26, 1930 / November 26 1930 / 1930-11-26 |
| Hughie Gallacher | 2 February 1903 | 2 February 1903 / February 2, 1903 / February 2 1903 / 1903-02-02 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Hugh Gallacher (footballer, born 1870)：完整供应证据</summary>

Hugh Gallacher (footballer, born 1870) Hugh Morgan 'Paddy' Gallacher (11 May 1870 – 20 May 1941) was a Scottish footballer who played in the Football League for Leicester Fosse, Preston North End and Sheffield United. Born in Galston in East Ayrshire he started his career with local side Maybole and had a spell at Celtic before moving to play in England. After leaving Leicester Fosse he spent time with Nelson and New Brompton before retiring. Having started his career with Maybole Gallagher moved to Celtic in the summer of 1889, where he played in their second ever league game against

答案字符位置：[70, 81)。

</details>

<details>
<summary>Hugh Gallacher (footballer, born 1930)：完整供应证据</summary>

Hugh Gallacher (footballer, born 1930) Hugh 'Hughie' Gallacher (26 November 1930 - died 14 June 2013) was a Scottish footballer who played for Arbroath, Dumbarton, Clyde, Queen of the South and South Shields. Gallacher is best known for his time at Dumbarton where in less than eight seasons scored 205 goals in major competitions from 220 games for the club. He played a massive role in the revival of Dumbarton FC who had been relegated to C Division in 1954. After one season Dumbarton elected to Division B where, subsequently consistently finishing in the top half of the league for

答案字符位置：[64, 80)。

</details>

<details>
<summary>Hughie Gallacher：完整供应证据</summary>

1.2 goals per game from his 20 caps. Scotland won all 6 games when Gallacher and Alex James were both selected to play. This included the 1928 'Wembley Wizards' 5–1 defeat of England when James netted twice. Hughie Gallacher Hugh Kilpatrick Gallacher (2 February 1903 – 11 June 1957) was a Scottish football player in the 1920s and 1930s. In 624 senior games, Gallacher scored 463 goals, playing senior league football for Airdrieonians, Newcastle United, Chelsea, Derby County, Notts County, Grimsby Town and Gateshead. Prior to his he also played and scored for then non-league Queen of the South. He

答案字符位置：[252, 267)。

</details>

## 第100题：ambigdocs_13735

**query：** What year did the Battle of Tripoli Harbor take place?

**term：** Battle of Tripoli Harbor
**dimension：** Entity Disambiguation
**来源：** 旧第126题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| First Battle of Tripoli Harbor | 1802 | 1802 |
| Second Battle of Tripoli Harbor | 1804 | 1804 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>First Battle of Tripoli Harbor：完整供应证据</summary>

First Battle of Tripoli Harbor The First Battle of Tripoli Harbor was a naval battle fought on May 16, 1802 in Tripoli Harbor between a combined force consisting of the American frigate and two Swedish Navy frigates against several Tripolitan Barbary corsairs. The Swedish-American force was enforcing the blockade when an engagement broke out between it and Tripolitan forces. The Allied fleet damaged the Tripolitan squadron as well as the harbor fortifications before withdrawing and resuming the blockade. USS "Boston" under Captain McNeill had been sent to Tripoli to blockade the port and prevent any ships from entering or leaving.

答案字符位置：[103, 107)。

</details>

<details>
<summary>Second Battle of Tripoli Harbor：完整供应证据</summary>

Second Battle of Tripoli Harbor The Second Battle of Tripoli Harbor, was a naval action during a naval blockade which took place in Tripoli Harbor in 1804. The battle is part of the First Barbary War between forces of the United States and the forces of the Eyalet of Tripolitania. Commodore Edward Preble had assumed command of the U.S. Mediterranean Squadron in 1803. By October of that year Preble had begun a blockade of Tripoli harbor. The first significant action of the blockade came on 31 October when ran aground on an uncharted coral reef and the Tripolitan Navy was

答案字符位置：[150, 154)。

</details>

## 第101题：ambigdocs_15015

**query：** When was the Ferris House built?

**term：** Ferris House
**dimension：** Entity Disambiguation
**来源：** 旧第127题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Samuel Ferris House | about 1760 | about 1760 |
| Zachariah Ferris House | between 1718 and 1749 | between 1718 and 1749 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Samuel Ferris House：完整供应证据</summary>

Samuel Ferris House The Samuel Ferris House is a historic house at 1 Cary Street in Greenwich, Connecticut. Built about 1760 and enlarged about 1800, it is a well-preserved example of a Colonial period Cape, a rare survivor of the form to still stand facing the Boston Post Road in the town. It is also locally significant for its connections to the Ferris family, early settlers of the area. The house was listed on the U.S. National Register of Historic Places in 1989. The Samuel Ferris House stands in the Riverside neighborhood of eastern Greenwich, on a parcel bounded on

答案字符位置：[114, 124)。

</details>

<details>
<summary>Zachariah Ferris House：完整供应证据</summary>

Zachariah Ferris House Zachariah Ferris House is a historic home located at Wilmington, New Castle County, Delaware. It was built between 1718 and 1749, and was an example of an early farmhouse continually occupied by professional and working families. It is a two-story, brick dwelling measuring 29 feet wide and 18 feet deep with a gable roof. It features a panel of brickwork between the two windows of the second floor, where two rows of numerals and letters are built in with dark glazed headers. The house was owned by Congressman Louis McLane and U.S. Senator Outerbridge Horsey. It was

答案字符位置：[130, 151)。

</details>

## 第102题：ambigdocs_58755

**query：** When was Rotherham Town F.C. established?

**term：** Rotherham Town F.C.
**dimension：** Entity Disambiguation
**来源：** 旧第128题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Rotherham Town F.C. (1878) | 1878 | 1878 |
| Rotherham Town F.C. (1899) | 1899 | 1899 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Rotherham Town F.C. (1878)：完整供应证据</summary>

Rotherham Town F.C. (1878) Rotherham Town F.C. was a football club based in Rotherham, England. The club was a member of the Football League between 1893 and 1896. The original club was founded in 1878 as Lunar Rovers, becoming Rotherham in 1882, and eventually Rotherham Town. In 1889 the club became a founder member of the Midland League. They were champions in 1892 and 1893, and were subsequently elected to the Second Division of the Football League in 1893. The club's League tenure lasted just three seasons, finishing in 14th, 12th and 15th place (out of 16). At the end

答案字符位置：[21, 25)。

</details>

<details>
<summary>Rotherham Town F.C. (1899)：完整供应证据</summary>

Rotherham Town F.C. (1899) Rotherham Town F.C. was an English football club from Rotherham, Yorkshire. They merged with rivals Rotherham County in 1925 to form Rotherham United. In 1899, Rotherham Casuals and Rotherham Grammar School combined to form Rotherham F.C. On becoming a limited company in 1904 a new name of Rotherham Athletic was adopted, and a year later they changed their name again, to Rotherham Town (which had been the name of a former Football League club from the town). In 1903 the new club joined the Midland League, where they remained until 1925, when they merged with their

答案字符位置：[21, 25)。

</details>

## 第103题：ambigdocs_37042

**query：** When was the Heathcliff TV series released?

**term：** Heathcliff
**dimension：** Entity Disambiguation
**来源：** 旧第129题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Heathcliff (1980 TV series) | October 4, 1980 | October 4, 1980 / 4 October 1980 / October 4 1980 / 1980-10-04 |
| Heathcliff (1984 TV series) | September 5, 1984 | September 5, 1984 / 5 September 1984 / September 5 1984 / 1984-09-05 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Heathcliff (1980 TV series)：完整供应证据</summary>

Heathcliff (1980 TV series) Heathcliff is a 30-minute Saturday morning animated series based on the "Heathcliff" comic strip created by George Gately and produced by Ruby-Spears Productions. It premiered on ABC on October 4, 1980, with a total of 26 episodes produced under the titles "Heathcliff and Dingbat" and "Heathcliff and Marmaduke". The first season, called "Heathcliff and Dingbat", ran for 13 episodes and included backup segments with Dingbat and the Creeps, who were created for the show. "Dingbat and the Creeps" revolved around the adventures of three monstrous characters who were self-employed as "Odd Jobs, Inc." which consisted of

答案字符位置：[214, 229)。

</details>

<details>
<summary>Heathcliff (1984 TV series)：完整供应证据</summary>

Heathcliff (1984 TV series) Heathcliff ( Heathcliff and the Catillac Cats) is a French-Canadian-American animated television series that debuted on September 5, 1984. It was the second series based on the "Heathcliff" comic strip and was produced by DiC Audiovisuel. It ran in syndication until 1988 with a total of 86 episodes. The first show based on the comic strip was "Heathcliff and Dingbat / Heathcliff and Marmaduke", which debuted in 1980 and was produced by Ruby-Spears. The Catillacs Cats characters were created by Jean Chalopin and Bruno Bianchi. Animation was outsourced to many Japanese, Taiwanese, and Korean studios including

答案字符位置：[148, 165)。

</details>

## 第104题：ambigdocs_61419

**query：** When was Robert Baxter born?

**term：** Robert Baxter
**dimension：** Entity Disambiguation
**来源：** 旧第130题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Bobby Baxter (footballer, born 1911) | 23 January 1911 | 23 January 1911 / January 23, 1911 / January 23 1911 / 1911-01-23 |
| Bobby Baxter (footballer, born 1937) | 4 February 1937 | 4 February 1937 / February 4, 1937 / February 4 1937 / 1937-02-04 |
| Robert Baxter (executioner) | c. 1878 | c. 1878 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Bobby Baxter (footballer, born 1911)：完整供应证据</summary>

Bobby Baxter (footballer, born 1911) Robert Denholm Baxter (23 January 1911 – April 1991) was a Scottish footballer best known for his time with English club Middlesbrough. He was born in the Gilmerton area of Edinburgh. A dominating centre half and a great tackler, Baxter joined Middlesbrough from junior club "Musselburgh Bruntonians" in 1931 after being spotted by manager Peter McWilliam. The match McWilliam had been to Scotland to watch had been cancelled and after going to watch Musselburgh Bruntonians instead, he spotted the young defender and decided to sign him. Baxter went on to play 247 times for Middlesbrough,

答案字符位置：[60, 75)。

</details>

<details>
<summary>Bobby Baxter (footballer, born 1937)：完整供应证据</summary>

Bobby Baxter (footballer, born 1937) Robert Denholm "Bobby" Baxter (born 4 February 1937) is an English former professional footballer born in Redcar, Yorkshire, who played in the Football League for Darlington, Brighton & Hove Albion and Torquay United. He is the son and namesake of Scotland and Middlesbrough footballer Bobby Baxter. Baxter began his career by signing a professional contract on joining Darlington in November 1959. He began his professional career as a forward and was Darlington's top scorer for two seasons. After playing 64 league games and scoring 30 times he moved to Brighton & Hove Albion in June

答案字符位置：[73, 88)。

</details>

<details>
<summary>Robert Baxter (executioner)：完整供应证据</summary>

Robert Baxter (executioner) Robert Orridge Baxter (c. 1878 – 1961) was an English executioner from Hertfordshire. His career lasted from 1915 to 1935, during which he carried out 44 hangings and assisted at 53 others. Baxter worked at his first hanging, as an assistant to Thomas Pierrepoint, on 15 July 1915. He assisted both Pierrepoint and John Ellis sporadically over the next few years. On 12 August 1924, he participated in his first job as chief executioner when he hanged Frenchman Jean-Pierre Vaquier. He would, for the next decade, be the second-most active executioner in England, behind only Pierrepoint. They

答案字符位置：[51, 58)。

</details>

## 第105题：ambigdocs_26509

**query：** Who is the artist of the album "Today, Tomorrow, and Forever"?

**term：** Today, Tomorrow, and Forever
**dimension：** Entity Disambiguation
**来源：** 旧第132题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Today, Tomorrow, and Forever (Elvis Presley album) | Elvis Presley | Elvis Presley |
| Today, Tomorrow, and Forever (Patsy Cline album) | Patsy Cline | Patsy Cline |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Today, Tomorrow, and Forever (Elvis Presley album)：完整供应证据</summary>

Today, Tomorrow, and Forever (Elvis Presley album) Today, Tomorrow, and Forever is a 2002 Elvis Presley compilation album released by RCA Records. The album features songs from the early years of Presley on Sun Records to his movie career, 68' Comeback Special, Gospel, Vegas and later years. As indicated on the packaging, none of the tracks in this four-CD set had ever been released previously, as all tracks featured were either alternate studio takes or previously unreleased live performances. The title track of the collection is a (then-)recently discovered outtake from the soundtrack recording sessions for "Viva Las Vegas" featuring

答案字符位置：[30, 43)。

</details>

<details>
<summary>Today, Tomorrow, and Forever (Patsy Cline album)：完整供应证据</summary>

Today, Tomorrow, and Forever (Patsy Cline album) Today, Tomorrow, and Forever is an album released after Patsy Cline's death in 1963. Many albums were released following Cline's death, and this one was not the first. This album showed a handful of songs recorded from 1950s sessions working under the record company Four Star Records. It includes her lesser-known material from the label, including the title track, "Let the Teadrops Fall," and "I Love You Honey." The album contained both stereo and monophonic recordings. It was issued on a CD in 1988. The album was produced by Cline's original producer at

答案字符位置：[30, 41)。

</details>

## 第106题：ambigdocs_62273

**query：** When was Noarlunga established?

**term：** Noarlunga
**dimension：** Entity Disambiguation
**来源：** 旧第134题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| City of Noarlunga | 1856 | 1856 |
| Old Noarlunga, South Australia | 1850 | 1850 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>City of Noarlunga：完整供应证据</summary>

City of Noarlunga The City of Noarlunga was a local government area in South Australia from 1856 until 1997. The District Council of Noarlunga was established in 1856 following lobbying by residents at Noarlunga on either side of the Onkaparinga River. The council area was formed from part of the District Council of Willunga on the south bank and part of the District Council of Morphett Vale on the north bank. In May 1932, the remainder of Morphett Vale council was absorbed into Noarlunga, along with part of the District Council of Clarendon. In 1997 the Noarlunga council was amalgamated

答案字符位置：[92, 96)。

</details>

<details>
<summary>Old Noarlunga, South Australia：完整供应证据</summary>

Australian historians, but this has latterly been deemed unlikely by contemporary linguists. In 1850 the South Australia Company laid out the 'No-orlunga Township' at the 'Horseshoe', Onkaparinga River. In the early years of settlement, the surrounding area was cleared for wheat farming, and a flour mill was built in the town in 1843 along with wharves used to transport produce down the Onkaparinga River to Port Noarlunga via barge. The town still has a stone bridge across the Onkaparinga, making the town a focal point for travel further down the coast. 1856 saw the formation of the District Council of

答案字符位置：[96, 100)。

</details>

## 第107题：ambigdocs_2653

**query：** Who is the artist of the album "A Place in the Sun"?

**term：** A Place in the Sun
**dimension：** Entity Disambiguation
**来源：** 旧第135题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| A Place in the Sun (Lit album) | Lit | Lit |
| A Place in the Sun (Pablo Cruise album) | Pablo Cruise | Pablo Cruise |
| A Place in the Sun (Tim McGraw album) | Tim McGraw | Tim McGraw |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>A Place in the Sun (Lit album)：完整供应证据</summary>

A Place in the Sun (Lit album) A Place in the Sun is the second studio album by the American rock band Lit. Produced by Don Gilmore, the album was released on February 23, 1999, by RCA Records. It was the band's first release through a major label. The song "No Big Thing", which originally appeared on their previous album "Tripping the Light Fantastic", was re-recorded for this album. On December 9, 2013, the band announced on its Facebook page that it would perform a special 15th anniversary show for "A Place in the Sun", when the band would play

答案字符位置：[20, 23)。

</details>

<details>
<summary>A Place in the Sun (Pablo Cruise album)：完整供应证据</summary>

A Place in the Sun (Pablo Cruise album) A Place in the Sun is the third album by the California soft rock group Pablo Cruise. The album marked an entrance into the mainstream for the band, and the first single from the album, "Whatcha Gonna Do?" reached number 6 on the Pop Singles charts. The title track, "A Place in the Sun" was the second and less successful single on the album, reaching number 42, but remains the favorite among many fans of the band today. The track "Raging Fire" was released as the B-side of "I Go to Rio"

答案字符位置：[20, 32)。

</details>

<details>
<summary>A Place in the Sun (Tim McGraw album)：完整供应证据</summary>

Best Friend", "My Next Thirty Years" and "Some Things Never Change"; "Please Remember Me" was originally recorded by Rodney Crowell on his 1995 album "Jewel of the South", and was a #69 country hit for him that year. Except for the #7-peaking "Some Things Never Change", all the singles on this album reached number one on the Hot Country Songs charts; "Seventeen" and "Señorita Margarita" also reached the lower regions of that chart from unsolicited airplay. A Place in the Sun (Tim McGraw album) A Place in the Sun is the fifth studio album by American country music artist Tim

答案字符位置：[481, 491)。

</details>

## 第108题：ambigdocs_55574

**query：** Who is the artist of the album "I Am the Greatest"?

**term：** I Am the Greatest
**dimension：** Entity Disambiguation
**来源：** 旧第136题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| I Am the Greatest (A House album) | A House | A House |
| I Am the Greatest (Cassius Clay album) | Cassius Clay | Cassius Clay / Muhammad Ali |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>I Am the Greatest (A House album)：完整供应证据</summary>

I Am the Greatest (A House album) I Am the Greatest is the third album from Irish rock band A House and features the fan favorite track, "Endless Art". At the time of its release, "I Am the Greatest" was very well reviewed, but sometimes the album was also marvelled at for its very existence. After their second album, "I Want Too Much", had been a commercial failure (despite critical plaudits) A House had been dropped by their record label and many doubted that they could continue. However, they refused to give up and, helped out by Setanta Records, produced

答案字符位置：[19, 26)。

</details>

<details>
<summary>I Am the Greatest (Cassius Clay album)：完整供应证据</summary>

I Am the Greatest (Cassius Clay album) I Am the Greatest is a comedy album by boxer Cassius Clay, released in August 1963 – six months before he won the world heavyweight championship, publicly announced his conversion to Islam, and changed his name to Muhammad Ali. It was released by CBS Columbia. The album helped establish Ali's reputation as an eloquently poetic "trash talker". The album has also been identified as an early example of rap music and a precursor to hip hop music. The liner notes were written by the American poet Marianne Moore, a longstanding fan of Clay.

答案字符位置：[19, 31)。

</details>

## 第109题：ambigdocs_35661

**query：** Who is the artist of the song "Do Right"?

**term：** Do Right
**dimension：** Entity Disambiguation
**来源：** 旧第137题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Do Right (Glades song) | Glades | Glades |
| Do Right (Mario song) | Mario | Mario |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Do Right (Glades song)：完整供应证据</summary>

Do Right (Glades song) "Do Right" is a song by Australian electronica, indie pop band Glades. The song was released digitally on 15 December 2017 as the lead single from the band's debut studio album "To Love You" (2018) and peaked at number 51 on the ARIA Charts. The song is set in E♭ Major and has 107 beats per minute. In December 2017 in an interview with Press Play OK, band member Karina Wykes said "We wrote "Do Right" while we were on a writing trip in New York. At the time there were a lot of crazy and

答案字符位置：[10, 16)。

</details>

<details>
<summary>Do Right (Mario song)：完整供应证据</summary>

Do Right (Mario song) "Do Right" is an R&B song from Mario's third studio album "Go". It was released on December 11, 2007 as a promotional single. It was produced by Akon and written by Akon, LSG, Harold Lilly, Giorgio Tuinfort and Mario. This song is dedicated to his mother. The song did not peak any chart because it was to promote the show about his mother but the radios instantly turned the song into a hit. Mario also created a "Do Right" foundation. Aaron Fields from KSTW.com states "I absolutely love this song. I have played this song so

答案字符位置：[10, 15)。

</details>

## 第110题：ambigdocs_44120

**query：** When was Serhiy Kravchenko born?

**term：** Serhiy Kravchenko
**dimension：** Entity Disambiguation
**来源：** 旧第138题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Serhiy Kravchenko (footballer, born 1983) | 24 April 1983 | 24 April 1983 / April 24, 1983 / April 24 1983 / 1983-04-24 |
| Serhiy Kravchenko (footballer, born 1990) | 23 March 1990 | 23 March 1990 / March 23, 1990 / March 23 1990 / 1990-03-23 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Serhiy Kravchenko (footballer, born 1983)：完整供应证据</summary>

Serhiy Kravchenko (footballer, born 1983) Serhiy Kravchenko (; born 24 April 1983 in Donetsk, Ukraine) is a Ukrainian football midfielder who plays for SC Dnipro-1. He was also a regular of the Ukraine national football team. Kravchenko began his career in the Shakhtar Donetsk reserves and youth team in 2002. For the 2005–06 season, where he played for Qarabağ FK in the Azerbaijan Premier League. His club finished fifth at the end of the season. Kravchenko moved to Vorskla Poltava in March 2006. There, when new coach Mykola Pavlov arrived in 2007, Kravchenko began to shine exceptionally. In the 2007–08

答案字符位置：[68, 81)。

</details>

<details>
<summary>Serhiy Kravchenko (footballer, born 1990)：完整供应证据</summary>

Serhiy Kravchenko (footballer, born 1990) Serhiy Kravchenko (; born 23 March 1990 in Ukrainian SSR) is a professional Ukrainian football striker who currently plays for Ukrainian First League club MFC Mykolaiv. Kravchenko is the product of the UOR Donetsk and Metalurh Zaporizhzhya School Systems. He spent all his career as a player in different clubs of the Ukrainian First League and the Ukrainian Second League. He began in FC Hirnyk-Sport Komsomolsk in the Ukrainian Second League, and was signed by Ukrainian Premier League club Vorskla Poltava, but did not play in any game for this side. In July 2011 he

答案字符位置：[68, 81)。

</details>

## 第111题：ambigdocs_24361

**query：** Where is SARM located?

**term：** SARM
**dimension：** Entity Disambiguation
**来源：** 旧第140题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Sarm East Studios | Brick Lane in east London | Brick Lane in east London / Brick lane in east London |
| Sarm West Studios | Notting Hill, London | Notting Hill, London |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Sarm East Studios：完整供应证据</summary>

Sarm East Studios Sarm East Studios is a recording studio that was located on Osborne street at the southern end of Brick Lane in east London. The studio was established by Jill Sinclair and her brother John Sinclair with the help of engineers Mike Stone and Gary Lyons in 1973. It was previously called The City of London Recording Studios. The studio was at one time one of the foremost and famous recording Studios in London and has played host to artists such as Queen, Madonna, the Clash, Depeche Mode, Rush, Yes, ABC, INXS, Frankie Goes to Hollywood, Seal and

答案字符位置：[116, 141)。

</details>

<details>
<summary>Sarm West Studios：完整供应证据</summary>

Sarm West Studios SARM Studios (formerly known as SARM West Studios) is a recording studio located in Notting Hill, London. The studios were established by Chris Blackwell, the founder of Island Records, and were originally known as Basing Street Studios. It has also been known in the past as Island Studios. SARM is an acronym of Sound and Recording Mobiles. The studios were built inside a former church that had been deconsecrated. Blackwell recorded a number of artists there for Island Records, such as Iron Maiden, Bob Marley, Steve Winwood, Free, Bad Company, Robert Palmer, Jimmy Cliff, Nick Drake, Fairport

答案字符位置：[102, 122)。

</details>

## 第112题：ambigdocs_27512

**query：** In what year were the Vostok exercises held?

**term：** Vostok Exercises
**dimension：** Entity Disambiguation
**来源：** 旧第141题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Vostok 2010 | 2010 | 2010 |
| Vostok 2018 | 2018 | 2018 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Vostok 2010：完整供应证据</summary>

Vostok 2010 Vostok 2010 () was a large-scale Russian military exercise held in Siberia and the country's Far East from June 29 to July 8, 2010. The drill involved at least 20,000 troops, up to 70 warplanes and 30 warships. For the first time in Russia's modern history the military exercises involved the warships of three Russian fleets — the Black Sea Fleet, Pacific Fleet and Northern Fleets. Another first, was the redeployment of Sukhoi Su-24M frontline bombers and Su-34 multi-role fighters from bases in the European part of Russia 8,000 km away in non-stop flights with two in-flight refuellings.

答案字符位置：[7, 11)。

</details>

<details>
<summary>Vostok 2018：完整供应证据</summary>

Vostok 2018 Vostok 2018 () was a large-scale Russian military exercise, held from 11 to 17 September 2018, throughout Siberia and the country's Far East. The exercise involved units from the Army, Air Force and Navy. China, Mongolia, as well as NATO member Turkey, were invited to the exercise. In late August 2018, Russian Defense Minister Sergey Shoygu said the exercise will be the largest to be held in Russia since "Zapad-81" held by the Soviet Union in 1981. The Zapad exercises in 1981 involved about 100,000 to 150,000 troops and were the largest Soviet military exercises ever held. Shoygu

答案字符位置：[7, 11)。

</details>

## 第113题：ambigdocs_26719

**query：** When was the MWSA formed?

**term：** MWSA
**dimension：** Entity Disambiguation
**来源：** 旧第142题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Massachusetts Woman Suffrage Association | 1870 | 1870 |
| Minnesota Woman Suffrage Association | 1881 | 1881 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Massachusetts Woman Suffrage Association：完整供应证据</summary>

Massachusetts Woman Suffrage Association The Massachusetts Woman Suffrage Association (MWSA) was an American organization devoted to women's suffrage in Massachusetts. It was active from 1870 to 1919. The MWSA was founded in 1870 by suffrage activists Julia Ward Howe, Lucy Stone, Henry Browne Blackwell, and others. It was affiliated initially with the national American Woman Suffrage Association, which had been founded the previous year, and later became a chapter of the National American Woman Suffrage Association (NAWSA). One of its own affiliates was the Cambridge Political Equality Association. The MWSA lobbied for women to get the vote and the right

答案字符位置：[187, 191)。

</details>

<details>
<summary>Minnesota Woman Suffrage Association：完整供应证据</summary>

women wanted to vote in all elections. Seeing the need for a statewide agency, fourteen women formed the MWSA in Hastings in 1881. The Minnesota chapter was affiliated with the National American Woman Suffrage Association (NAWSA). Among the founders of the MWSA were Harriet Bishop and Sarah Burger Stearns. Stearns became the organization's first president. By 1882, the MWSA had grown to two hundred members. In 1885, MWSA-president Martha Ripley convinced NAWSA to hold their annual meeting in Minnesota. This national event demonstrated the importance of the Minnesota chapter to the larger organization. It also drew the attention of Minnesota's

答案字符位置：[125, 129)。

</details>

## 第114题：ambigdocs_1591

**query：** When was Meckel born?

**term：** Meckel
**dimension：** Entity Disambiguation
**来源：** 旧第144题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Johann Friedrich Meckel | 17 October 1781 | 17 October 1781 / October 17, 1781 / October 17 1781 / 1781-10-17 |
| Johann Friedrich Meckel, the Elder | July 31, 1724 | July 31, 1724 / 31 July 1724 / July 31 1724 / 1724-07-31 |
| August Albrecht Meckel | 1790 | 1790 |
| Christoph Meckel | 12 June 1935 | 12 June 1935 / June 12, 1935 / June 12 1935 / 1935-06-12 |
| Jakob Meckel | 28 March 1842 | 28 March 1842 / March 28, 1842 / March 28 1842 / 1842-03-28 |
| Philipp Friedrich Theodor Meckel | 30 April 1755 | 30 April 1755 / April 30, 1755 / April 30 1755 / 1755-04-30 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Johann Friedrich Meckel：完整供应证据</summary>

Johann Friedrich Meckel Johann Friedrich Meckel (17 October 1781 – 31 October 1833), often referred to as Johann Friedrich Meckel, the Younger, was a German anatomist born in Halle. He worked as a professor of anatomy, pathology and zoology at the University of Halle, Germany. In 1802, he received his medical doctorate from the University of Halle, defending his doctoral thesis "De cordis conditionibus abnormibus" on 8 April 1802. At Halle he had as instructors, Kurt Sprengel (1766-1833) and Johann Christian Reil (1759-1813). After graduation, Meckel continued his education in Würzburg, Vienna and Paris. In Paris, he assisted zoologist Georges

答案字符位置：[49, 64)。

</details>

<details>
<summary>Johann Friedrich Meckel, the Elder：完整供应证据</summary>

Johann Friedrich Meckel, the Elder Johann Friedrich Meckel the Elder (July 31, 1724 – September 18, 1774) was a German anatomist born in Wetzlar. He often has "the Elder" appended to his name to avoid confusion with his famous grandson Johann Friedrich Meckel (1781–1833), who was also an anatomist and often has "the Younger" included with his name. The elder Meckel's son, Philipp Friedrich Theodor Meckel (1755–1803) and another grandson, August Albrecht Meckel (1790–1829) were also anatomists. Meckel earned his medical doctorate from the University of Göttingen in 1748, and in his thesis, ""Tractatus anatomico physiologicus de quinto pare nervorum

答案字符位置：[70, 83)。

</details>

<details>
<summary>August Albrecht Meckel：完整供应证据</summary>

AO. August Albrecht Meckel August Albrecht Meckel (1790–1829) was a German physician. He was the grandson of Johann Friedrich Meckel the Elder and younger brother of Johann Friedrich Meckel. Albrecht Meckel came from an old medical family. His father Philipp Friedrich Theodor Meckel (1755-1803) taught him anatomy and surgery. His grandfather, Johann Friedrich Meckel the Elder (1724-1774), was professor of anatomy and obstetrics in Berlin and surgeon of Empress Catherine the Great. Meckel studied medicine at the universities of Jena and Halle. In 1807 he joined the Corps Saxonia Jena and 1810 the Corps Guestphalia Halle. During the Napoleonic Wars

答案字符位置：[51, 55)。

</details>

<details>
<summary>Christoph Meckel：完整供应证据</summary>

on each hand: that makes one hundred and forty strokes and then some. This put an end to the child's innocence. Whatever it was that happened in Paradise involving Adam, Eve, Lilith, the serpent, and the apple, the well-deserved Biblical thunderbolt of prehistoric times, the roar of the Almighty and His pointed finger signifying expulsion - I know nothing about all that. It was my father who drove me out of paradise. Meckel has received numerous literary prizes, including: Christoph Meckel Christoph Meckel (born 12 June 1935 in Berlin) is a German author and graphic artist. Christoph Meckel spent his

答案字符位置：[518, 530)。

</details>

<details>
<summary>Jakob Meckel：完整供应证据</summary>

Jakob Meckel Klemens Wilhelm Jacob Meckel (28 March 1842 – 5 July 1906) was a general in the Prussian army and foreign advisor to the government of Meiji period Japan. Meckel was born in Cologne, Rhine Province, Prussia. He graduated from the Prussian Army Staff College in 1867. He was a veteran of the Franco-Prussian War, during which he was decorated with the Iron Cross. After the government of Meiji period Japan decided to model the Imperial Japanese Army after the Prussian army, following the German victory over the French in the Franco-Prussian War, Meckel (with the rank of major

答案字符位置：[43, 56)。

</details>

<details>
<summary>Philipp Friedrich Theodor Meckel：完整供应证据</summary>

Philipp Friedrich Theodor Meckel Philipp Friedrich Theodor Meckel (30 April 1755, Berlin – 17 March 1803, Halle an der Saale) was a German anatomist, surgeon and obstetrician. He was the son of Johann Friedrich Meckel, a professor of anatomy in Berlin. Two of Philipp's sons also became anatomists, Johann Friedrich (1781–1833), a professor at the University of Halle, and August Albrecht (1790-1829), a professor in Bern. He studied medicine at the universities of Göttingen and Strasbourg, receiving his doctorate in 1777 with a dissertation on the labyrinth of the inner ear. Following graduation he took an extended study trip to

答案字符位置：[67, 80)。

</details>

## 第115题：ambigdocs_27982

**query：** Where is Harvest Christian Academy located?

**term：** Harvest Christian Academy
**dimension：** Entity Disambiguation
**来源：** 旧第145题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Harvest Christian Academy (Guam) | Barrigada, Guam | Barrigada, Guam |
| Harvest Christian Academy (Illinois) | Elgin, Illinois, United States | Elgin, Illinois, United States |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Harvest Christian Academy (Guam)：完整供应证据</summary>

Harvest Christian Academy (Guam) Harvest Christian Academy (HCA) is a private Christian school in Barrigada, Guam. The school offers open enrollment for grades K-12. HCA is administrated by and closely associated with Harvest Baptist Church (HBC). HBC was started in 1975 as a missionary church. The school was started the same year for the children of the congregation members. Over the years, the school's enrollment was opened to the community of Guam and now enrolls nearly 1,000 students each year in K3-12th grade. Harvest Ministries, Guam now also owns and operates KHMG radio station. The campus is spread out on

答案字符位置：[98, 113)。

</details>

<details>
<summary>Harvest Christian Academy (Illinois)：完整供应证据</summary>

Harvest Christian Academy (Illinois) Harvest Christian Academy is a private Christian school in Elgin, Illinois, United States. Harvest Christian Academy is a ministry of Harvest Bible Chapel, a church that is located on several campuses in the Chicago area. As of September 2014, the number of students enrolled at Harvest Christian Academy from preschool to grade 12 totaled 650, the number of full-time and part-time staff totaled 72, and the size of the facilities totaled 80 acres and over 200,000 square feet. The school was founded in August 2004. The ethnic diversity of Harvest Christian Academy is more homogenous than

答案字符位置：[96, 126)。

</details>

## 第116题：ambigdocs_14163

**query：** What year did Charles Douglas-Home inherit his father's titles and estates?

**term：** Charles Douglas-Home
**dimension：** Entity Disambiguation
**来源：** 旧第146题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Charles Douglas-Home, 12th Earl of Home | 1881 | 1881 |
| Charles Douglas-Home, 13th Earl of Home | 1918 | 1918 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Charles Douglas-Home, 12th Earl of Home：完整供应证据</summary>

Eton College and Trinity College, Cambridge. In 1877, he inherited the extensive Douglas and Angus estates from his mother. These included Douglas Castle, Bothwell Castle, and lands totalling some 104,000 acres, chiefly in Lanarkshire, Roxburghshire and Berwickshire. In 1877, his name was legally changed to Charles Alexander Douglas-Home by Royal Licence. He inherited his father's titles and Berwickshire estate at The Hirsel in 1881. He held the office of Lord Lieutenant of Berwickshire between 1879 and 1890. He served as aide-de-camp to Queen Victoria between 1887 and 1897. He served as Lord Lieutenant of Lanarkshire from 1890 to 1915. He

答案字符位置：[432, 436)。

</details>

<details>
<summary>Charles Douglas-Home, 13th Earl of Home：完整供应证据</summary>

Archers. He was invested as a Knight of the Order of the Thistle in 1930. He held the office of Lord Lieutenant of Berwickshire from 1930 until his death. He was awarded the honorary degree of Doctor of Law by the University of Glasgow. He died at his home The Hirsel on 11 July 1951. In 1918, Lord Home inherited extensive property and estates from his father, including Douglas Castle, Bothwell Castle, The Hirsel and lands (which totalled some 107,000 acres in 1878) chiefly in Lanarkshire, Roxburghshire and Berwickshire. The following year, he was forced to sell many historic pictures

答案字符位置：[288, 292)。

</details>

## 第117题：ambigdocs_66408

**query：** When was Senator Crowley born?

**term：** Senator Crowley
**dimension：** Entity Disambiguation
**来源：** 旧第147题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Miles Crowley | February 22, 1859 | February 22, 1859 / 22 February 1859 / February 22 1859 / 1859-02-22 |
| Richard Crowley | December 14, 1836 | December 14, 1836 / 14 December 1836 / December 14 1836 / 1836-12-14 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Miles Crowley：完整供应证据</summary>

Miles Crowley Miles Crowley (February 22, 1859 – September 22, 1921) was a U.S. Representative from Texas. Born in Boston, Massachusetts, Crowley attended the common schools. He was employed as a longshoreman. He moved to Galveston in the 1870s. He served as assistant chief of the Galveston Fire Department. He studied law and was admitted to the bar in 1892 and commenced practice. He served as member of the State house of representatives in 1892. He served in the State senate in 1893 and 1894. Crowley was elected as a Democrat to the Fifty-fourth Congress (March 4, 1895 – March

答案字符位置：[29, 46)。

</details>

<details>
<summary>Richard Crowley：完整供应证据</summary>

Richard Crowley Richard Crowley (December 14, 1836 – July 22, 1908) was a United States Representative from New York. He was born in Pendleton, New York. He attended the public schools and Lockport Union School. Later, he studied law, was admitted to the bar in 1860, and commenced practice in Lockport. Crowley was City Attorney of Lockport from 1865 to 1866. He was admitted to practice before the Supreme Court of the United States in 1865, and was a member of the New York State Senate (29th D.) in 1866, 1867, 1868 and 1869. He was appointed by President Ulysses

答案字符位置：[33, 50)。

</details>

## 第118题：ambigdocs_51511

**query：** Where is the Palazzo Comunale located?

**term：** Palazzo Comunale
**dimension：** Entity Disambiguation
**来源：** 旧第149题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Palazzo Comunale, San Gimignano | Piazza del Duomo | Piazza del Duomo |
| Palazzo d'Accursio | Piazza Maggiore | Piazza Maggiore |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Palazzo Comunale, San Gimignano：完整供应证据</summary>

Palazzo Comunale, San Gimignano The Palazzo Comunale (), also known as the Palazzo del Popolo () of San Gimignano has been the seat of the civic authority in the comune since the 13th century. It is located on the Piazza del Duomo close to the Collegiate Church of the Assumption of the Blessed Virgin Mary. The building and Collegiate Church are at the heart of the medieval town, and are part of the UNESCO World Heritage Site of the "Historic Centre of San Gimignano". The building contains important fresco decorations by Memmo di Filippuccio, Lippo Memmi and others, a museum

答案字符位置：[214, 230)。

</details>

<details>
<summary>Palazzo d'Accursio：完整供应证据</summary>

Palazzo d'Accursio Palazzo d'Accursio (or Palazzo Comunale) is a palace once formulated to house major administrative offices of the city of Bologna, region of Emilia-Romagna, Italy. It is located on the Piazza Maggiore, and is the city's Town Hall. The palace is also home to the Civic Art Collection, with paintings from the Middle Ages to the 19th century; the Museo Morandi, with the works by Giorgio Morandi; and the Biblioteca Salaborsa, the town libraries. The earliest structure of the Palazzo d'Accursio originally began as the residence of the jurist Accursius, but over time, it incorporated and expanded to include

答案字符位置：[204, 219)。

</details>

## 第119题：ambigdocs_38576

**query：** When did the Battle of Fort McAllister take place?

**term：** Battle of Fort McAllister
**dimension：** Entity Disambiguation
**来源：** 旧第150题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Battle of Fort McAllister (1863) | January 27 to March 3, 1863 | January 27 to March 3, 1863 |
| Battle of Fort McAllister (1864) | December 13, 1864 | December 13, 1864 / 13 December 1864 / December 13 1864 / 1864-12-13 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Battle of Fort McAllister (1863)：完整供应证据</summary>

Battle of Fort McAllister (1863) The First Battle of Fort McAllister was a series of naval attacks that took place from January 27 to March 3, 1863, in Bryan County, Georgia, during the American Civil War. The commander of the South Atlantic Blockading Squadron Rear Adm. Samuel F. Du Pont decided to test operation of new monitors against Fort McAllister before conducting a major naval operation against Charleston, South Carolina. Fort McAllister was a small earthen fort located along Genesis Point and armed with several heavy cannon to defend the Great Ogeechee River approach south of Savannah, Georgia. It was

答案字符位置：[120, 147)。

</details>

<details>
<summary>Battle of Fort McAllister (1864)：完整供应证据</summary>

Battle of Fort McAllister (1864) The Second Battle of Fort McAllister took place December 13, 1864, during the final stages of Maj. Gen. William T. Sherman's March to the Sea during the American Civil War. Union forces overwhelmed a small Confederate force defending the strategically important Fort McAllister near Savannah, Georgia, a major Federal objective. As Sherman's armies neared Savannah on December 10, following their lengthy march from Atlanta, his troops were in need of supplies. Just off the coast was Admiral John A. Dahlgren's fleet waiting with the needed supplies, as well as mail that had not been delivered

答案字符位置：[81, 98)。

</details>

## 第120题：ambigdocs_67148

**query：** Who is the artist of the album "Wild in the Streets"?

**term：** Wild in the Streets (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第152题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Wild in the Streets (Circle Jerks album) | Circle Jerks | Circle Jerks |
| Wild in the Streets (Helix album) | Helix | Helix |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Wild in the Streets (Circle Jerks album)：完整供应证据</summary>

Wild in the Streets (Circle Jerks album) Wild in the Streets is the second studio album by American hardcore punk band Circle Jerks. It was released on March 4, 1982 by Faulty Products, a sub-label of I.R.S. Records. In 1988, the album was remixed and reissued on Frontier Records, both on its own in cassette and vinyl formats, and paired with the band's debut as "Group Sex/Wild in the Streets" on CD. The album featured three cover songs, including the title track, originally by Garland Jeffreys; "Just Like Me", originally performed by Paul Revere & the Raiders; and "Put a

答案字符位置：[21, 33)。

</details>

<details>
<summary>Wild in the Streets (Helix album)：完整供应证据</summary>

Wild in the Streets (Helix album) Wild in the Streets was the sixth album by the rock band Helix, released in 1987. The album went gold in the band's native Canada, but only managed a disappointing #179 on the "Billboard" 200 in the United States. The band would lose their U.S. deal with Capitol Records soon after. The power ballad "Dream On" is a cover of a 1982 song by Nazareth. "She's Too Tough" was written in 1985 by Def Leppard vocalist Joe Elliott. Def Leppard's version of the song was intended at one time to be on their "Hysteria"

答案字符位置：[21, 26)。

</details>

## 第121题：ambigdocs_33620

**query：** When was the Stone County Courthouse constructed?

**term：** Stone County Courthouse
**dimension：** Entity Disambiguation
**来源：** 旧第153题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Stone County Courthouse (Arkansas) | 1922 | 1922 |
| Stone County Courthouse (Mississippi) | 1917-18 | 1917-18 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Stone County Courthouse (Arkansas)：完整供应证据</summary>

Stone County Courthouse (Arkansas) The Stone County Courthouse is located at Courthouse Square in the center of Mountain View, the county seat of Stone County, Arkansas. It is a 2-1/2 story stone structure, built out of native stone, with a hip roof that has exposed rafter ends. The building has a central section with flanking wings that project slightly, with the entrance at the center, sheltered by a portico with a hip roof, dentillated cornice, and square stone posts. The courthouse was built in 1922 to a design by Clyde A. Ferrell. The building was listed on the National Register

答案字符位置：[504, 508)。

</details>

<details>
<summary>Stone County Courthouse (Mississippi)：完整供应证据</summary>

Stone County Courthouse (Mississippi) The Stone County Courthouse was constructed in 1917-18 and serves as the seat of county government for Stone County, Mississippi. The courthouse was designated a Mississippi Landmark in 1996. Stone County was created by the Mississippi Legislature in 1916. One of the first acts by the new county’s Board of Supervisors was to award a contract for construction of the county courthouse. Constructed by Standard Construction Company of Meridian, Mississippi, the courthouse was completed in March 1918, at a cost of US$29,515.18 (). Within the two-story structure, the lower floor was divided into county offices, and

答案字符位置：[85, 92)。

</details>

## 第122题：ambigdocs_35135

**query：** When was Judge Underwood born?

**term：** Judge Underwood
**dimension：** Entity Disambiguation
**来源：** 旧第154题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Emory Marvin Underwood | December 11, 1877 | December 11, 1877 / 11 December 1877 / December 11 1877 / 1877-12-11 |
| Mell G. Underwood | January 30, 1892 | January 30, 1892 / 30 January 1892 / January 30 1892 / 1892-01-30 |
| John Curtiss Underwood | 1809 | 1809 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Emory Marvin Underwood：完整供应证据</summary>

Emory Marvin Underwood Emory Marvin Underwood (December 11, 1877 – August 28, 1960) was a United States federal judge. Born in Douglas County, Georgia, Underwood received a B.A. from Vanderbilt University in 1900 and an LL.B. from Vanderbilt University Law School in 1902. He was in private practice in Atlanta, Georgia from 1903 to 1914, an Assistant Attorney General of the United States from 1914 to 1917, a General counsel, Seaboard Air Line Company from 1917 to 1919, and a general solicitor for the U.S. Railroad Administration from 1919 to 1920. Returning to private practice in Atlanta from 1920 to

答案字符位置：[47, 64)。

</details>

<details>
<summary>Mell G. Underwood：完整供应证据</summary>

Mell G. Underwood Mell Gilbert Underwood (January 30, 1892 – March 8, 1972) was a United States Representative from Ohio and a United States federal judge. Born at Rose Farm in rural Morgan County, Ohio, Underwood attended the public schools. He was graduated from the New Lexington High School in 1911. He taught in the public schools of New Lexington for several years. Underwood studied law at the Ohio State University at Columbus, and then read law to be admitted to the bar in 1915. He entered private practice in New Lexington, Ohio from 1915 to 1923. He was a

答案字符位置：[42, 58)。

</details>

<details>
<summary>John Curtiss Underwood：完整供应证据</summary>

qualifications changed), 1882 (capitation tax stricken) and 1894 (criminal trial changes). The Library of Congress acquired some of his papers in 1919. The Library of Virginia has microfiche of other papers now held by the Huntington Library. John Curtiss Underwood John Curtiss Underwood (March 14, 1809 – December 7, 1873) was a lawyer, abolitionist politician, and federal judge. Underwood was born in Litchfield, New York. He graduated from Hamilton College in 1832, and was a founding member of Alpha Delta Phi. Underwood traveled to what was then western Virginia after graduation and taught children of the Jackson family in Clarksburg

答案字符位置：[300, 304)。

</details>

## 第123题：ambigdocs_15535

**query：** Who is the artist of the "Hotel Sessions" EP?

**term：** Hotel Sessions
**dimension：** Entity Disambiguation
**来源：** 旧第155题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Hotel Sessions (Lydia EP) | Lydia | Lydia |
| Hotel Sessions (Olivia Newton-John EP) | Olivia Newton-John | Olivia Newton-John |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Hotel Sessions (Lydia EP)：完整供应证据</summary>

Hotel Sessions (Lydia EP) Hotel Sessions is an unofficial limited edition tour EP released by Lydia. It features 4 songs acoustically re-recorded from their first album "This December; It's One More and I'm Free". The EP was handmade and sold at shows. There is no official cover art, as it was merely a CD-R demo. Singer Mindy White posted a blog detailing the making of the EP: "I know you guys are eager to hear it…. & we are excited as well. But some are more stoked to find it online to download it. I know it’s hard to get

答案字符位置：[16, 21)。

</details>

<details>
<summary>Hotel Sessions (Olivia Newton-John EP)：完整供应证据</summary>

Hotel Sessions (Olivia Newton-John EP) Hotel Sessions is an extended play (EP) by Australian recording artist Olivia Newton-John, released on 8 April 2014. It is her first EP focusing on unreleased songs and was released independently by ONJ Productions, Newton-John's own production company. It was also Newton-John’s last ever album released by that company, before she signed with Sony Music Australia. "Hotel Sessions" was first available at Summer Nights, Newton-John's nineteenth concert tour. Physical copies were later available from her official website, together with digital download versions at online shops. The EP is dedicated to Rona Newton-John, Olivia's sister and

答案字符位置：[16, 34)。

</details>

## 第124题：ambigdocs_61592

**query：** When was Judge Choate confirmed by the Senate?

**term：** Judge Choate
**dimension：** Entity Disambiguation
**来源：** 旧第156题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Emett Clay Choate | July 20, 1954 | July 20, 1954 / 20 July 1954 / July 20 1954 / 1954-07-20 |
| William Gardner Choate | March 25, 1878 | March 25, 1878 / 25 March 1878 / March 25 1878 / 1878-03-25 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Emett Clay Choate：完整供应证据</summary>

Choate was nominated by President Dwight D. Eisenhower on June 22, 1954, to the United States District Court for the Southern District of Florida, to a new seat authorized by 68 Stat. 8. He was confirmed by the United States Senate on July 20, 1954, and received his commission the same day. He assumed senior status on January 31, 1965. His service terminated on August 14, 1974, due to his death. Among his cases was that of Richard Paul Pavlick, a would-be-assassin stalking President-elect John F. Kennedy. Choate ruled that Pavlick was mentally ill and had him confined to a

答案字符位置：[235, 248)。

</details>

<details>
<summary>William Gardner Choate：完整供应证据</summary>

Blatchford. Choate was confirmed by the United States Senate on March 25, 1878, and received his commission the same day. Choate served on the court for only three years, resigning on June 1, 1881. He resumed his private practice in New York City from 1881 to 1920. He founded the Choate School (later Choate Rosemary Hall) in 1896, and from 1902 to 1903 he served as president of the New York City Bar Association. He died in Wallingford, Connecticut. His father's first cousin was Rufus Choate. He married Mary Lyman Atwater (1837–1920) on June 29, 1870. A brother of William

答案字符位置：[64, 78)。

</details>

## 第125题：ambigdocs_29082

**query：** Who is the manufacturer of the Bimax?

**term：** Bimax
**dimension：** Entity Disambiguation
**来源：** 旧第157题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Airfer Bimax | Airfer | Airfer |
| Houde Bimax | Patrice Houde | Patrice Houde |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Airfer Bimax：完整供应证据</summary>

Airfer Bimax The Airfer Bimax is a Spanish paramotor that was designed and produced by Airfer of Pontevedra for powered paragliding. Now out of production, when it was available the aircraft was supplied complete and ready-to-fly. The Bimax was designed as an aircraft for large pilots for two-place flying, to comply with the US FAR 103 Ultralight Vehicles rules as well as European regulations. It features a paraglider-style wing, single-place or two-place-in-tandem accommodation and a single Cors'Air M21Y engine in pusher configuration with a 2.6:1 ratio reduction drive and a diameter two-bladed composite propeller. The fuel tank capacity is .

答案字符位置：[0, 6)。

</details>

<details>
<summary>Houde Bimax：完整供应证据</summary>

Houde Bimax The Houde Bimax is a French ultralight aircraft, designed and produced by Patrice Houde, introduced at the Blois homebuilt aircraft fly-in in September 2010. The aircraft is supplied as a complete ready-to-fly-aircraft. The Bimax was designed to comply with the Fédération Aéronautique Internationale microlight rules. It features a cantilever low-wing, a two-seats-in-tandem enclosed cockpit under a bubble canopy, fixed conventional landing gear and a single engine in tractor configuration. The aircraft is made from wood, with its flying surfaces covered in doped aircraft fabric. Its span wing is detachable for ground transportation and storage. Standard engines available are

答案字符位置：[86, 99)。

</details>

## 第126题：ambigdocs_52851

**query：** Who is the founder of the Motherland Party?

**term：** Motherland Party
**dimension：** Entity Disambiguation
**来源：** 旧第158题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Motherland Party (Mongolia) | Badarchiin Erdenebat | Badarchiin Erdenebat |
| Motherland Party (Turkey) | Turgut Özal | Turgut Özal |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Motherland Party (Mongolia)：完整供应证据</summary>

Motherland Party (Mongolia) The Motherland Party (, ), sometimes also referred to as Mongolian Democratic New Socialist Party (, ) is a political party in Mongolia. It was founded by the owner of the Erel group, Badarchiin Erdenebat. There is a considerable overlap between employees of the Erel group and members of the Motherland party, and the party is popularly also known as Erel party. The party was a member of the 2004 Motherland Democratic Coalition, and held four seats in the State Great Khural from 2004 to 2008. It failed to win any seats in the 2008 parliamentary elections.

答案字符位置：[212, 232)。

</details>

<details>
<summary>Motherland Party (Turkey)：完整供应证据</summary>

Motherland Party (Turkey) The Motherland Party, (, abbreviated as ANAVATAN, formerly ANAP) is a political party in Turkey. It was founded in 1983 by Turgut Özal. It merged with Democratic Party, in October 2009, but in September 2011, the party was re-established. Its president is İbrahim Çelebi. The ANAP was considered a centre-right neoliberal and secular nationalist party that supported restrictions on the role that government can play in the economy and also supported private capital and enterprise and some public expressions of religion. The Turkish general election, 1983, was won by the new Motherland Party, led by Özal. Although

答案字符位置：[149, 160)。

</details>

## 第127题：ambigdocs_65067

**query：** When was the Battle of Kernstown fought?

**term：** Battle of Kernstown
**dimension：** Entity Disambiguation
**来源：** 旧第159题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| First Battle of Kernstown | March 23, 1862 | March 23, 1862 / 23 March 1862 / March 23 1862 / 1862-03-23 |
| Second Battle of Kernstown | July 24, 1864 | July 24, 1864 / 24 July 1864 / July 24 1864 / 1864-07-24 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>First Battle of Kernstown：完整供应证据</summary>

First Battle of Kernstown The First Battle of Kernstown was fought on March 23, 1862, in Frederick County and Winchester, Virginia, the opening battle of Confederate Maj. Gen. Thomas J. "Stonewall" Jackson's campaign through the Shenandoah Valley during the American Civil War. Attempting to tie down the Union forces in the Valley, under the overall command of Maj. Gen. Nathaniel P. Banks, Jackson received incorrect intelligence that a small detachment under Col. Nathan Kimball was vulnerable, but it was in fact a full infantry division more than twice the size of Jackson's force. His initial cavalry attack was forced back

答案字符位置：[70, 84)。

</details>

<details>
<summary>Second Battle of Kernstown：完整供应证据</summary>

Second Battle of Kernstown The Second Battle of Kernstown was fought on July 24, 1864, at Kernstown, Virginia, outside Winchester, Virginia, as part of the Valley Campaigns of 1864 in the American Civil War. The Confederate Army of the Valley under Lt. Gen. Jubal A. Early soundly defeated the Union Army of West Virginia under Brig. Gen. George Crook and drove it from the Shenandoah Valley back over the Potomac River into Maryland. As a result, Early was able to launch the Confederacy's last major raid into northern territory, attacking the Baltimore and Ohio Railroad in Maryland and West Virginia

答案字符位置：[72, 85)。

</details>

## 第128题：ambigdocs_5969

**query：** Where is Wallace High School located?

**term：** Wallace High School
**dimension：** Entity Disambiguation
**来源：** 旧第160题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Wallace High School, Lisburn | Lisburn, Northern Ireland | Lisburn, Northern Ireland |
| Wallace High School, Stirling | Causewayhead, Stirling, Scotland | Causewayhead, Stirling, Scotland |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Wallace High School, Lisburn：完整供应证据</summary>

Wallace High School, Lisburn The Wallace High School is a co-educational grammar school in Lisburn, Northern Ireland. The school educates pupils from ages 11-18 (4-18 if the Preparatory Department is included). It occupies a ~19 acre site (including playing fields) in the centre of Lisburn on Clonevin Avenue. It was founded in 1880 by a bequest from the estate of Sir Richard Wallace, local landowner, Unionist MP and philanthropist, and was originally named Lisburn Intermediate and University School. It was built on a site fronting the Antrim Road. A board of trustees took charge in 1900 to oversee the development

答案字符位置：[91, 116)。

</details>

<details>
<summary>Wallace High School, Stirling：完整供应证据</summary>

Wallace High School, Stirling Wallace High School in Causewayhead, Stirling, Scotland. It was founded in 1971 to serve northern and north-eastern Stirling. The catchment area is currently: Bridge of Allan, Castleview, Cornton, Fallin, Raploch and Riverside. The University of Stirling is in close proximity, and the school has formed strong links with the institution. Wallace High School is one of seven secondary schools in the Stirling Council area. In 2008 the school moved from its initial location on Dumyat Road to a new building on Airthrey Road which was funded by a public private partnership. It is located close to

答案字符位置：[53, 85)。

</details>

## 第129题：ambigdocs_51469

**query：** When was Judge Harper born?

**term：** Judge Harper
**dimension：** Entity Disambiguation
**来源：** 旧第161题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Roy Winfield Harper | July 26, 1905 | July 26, 1905 / 26 July 1905 / July 26 1905 / 1905-07-26 |
| Samuel Hadden Harper | 1783 | 1783 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Roy Winfield Harper：完整供应证据</summary>

Roy Winfield Harper "Roy" Winfield Harper (July 26, 1905 – February 13, 1994) was a Federal Judge of the United States District Court for the Eastern and Western Districts of Missouri. He was born in Dunklin County, Gibson, Missouri, and died in Saint Louis County, Chesterfield, Missouri. "Roy" Winfield Harper was the oldest child of Marvin H. Harper, Sr. and Minnie Belle Brooks. He married Ruth Butt on July 30, 1941 in Missouri, daughter of Arthur and Sara Butt. His wife was born on December 31, 1913 in Mississippi County, Blytheville, Arkansas, and died February 4, 2007 in Saint Louis

答案字符位置：[43, 56)。

</details>

<details>
<summary>Samuel Hadden Harper：完整供应证据</summary>

Samuel Hadden Harper Samuel Hadden Harper (1783 – July 19, 1837) was a United States federal judge. Born in Augusta County, Virginia, Harper was in private practice in New Orleans, Louisiana from 1808 to 1829. He also served in the United States Army during the War of 1812, was a member of the Louisiana State House of Representatives in 1814, and was a registrar in the land office of the Eastern District of Louisiana from 1821 to 1824. In 1825, he was a clerk to the U.S. District Court for the Eastern District of Louisiana, and a city councilman of

答案字符位置：[43, 47)。

</details>

## 第130题：ambigdocs_40729

**query：** When was the title of Lord Lovelace created?

**term：** Lord Lovelace
**dimension：** Entity Disambiguation
**来源：** 旧第163题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Baron Lovelace | 31 May 1627 | 31 May 1627 / May 31, 1627 / May 31 1627 / 1627-05-31 |
| Earl of Lovelace | 1838 | 1838 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Baron Lovelace：完整供应证据</summary>

Baron Lovelace Baron Lovelace, of Hurley in the County of Berks, was a title in the Peerage of England. It was created on 31 May 1627 for Sir Richard Lovelace, who had earlier represented Berkshire, Abingdon and Windsor in Parliament. The second Baron served as Lord Lieutenant of Berkshire. The third Baron sat as Member of Parliament for Berkshire. The fourth Baron was Governor of New York and New Jersey. The title became extinct on the early death of the sixth Baron in 1736. The Lovelace title was revived in 1838 when William King, 8th Baron King was made Earl

答案字符位置：[122, 133)。

</details>

<details>
<summary>Earl of Lovelace：完整供应证据</summary>

Earl of Lovelace Earl of Lovelace was a title in the Peerage of the United Kingdom. It was created in 1838 for William King-Noel, 8th Baron King, a title created in 1725. The King or Locke King family stems from the elevation of the son of Jerome King, a grocer, of Exeter, and his wife Anne, great-niece of the philosopher John Locke. This son was Sir Peter King, a prominent lawyer and politician who served as Lord Chief Justice of the Common Pleas from 1714 to 1725 and as Lord Chancellor from 1725 to 1733; as such in 1725 he

答案字符位置：[102, 106)。

</details>

## 第131题：ambigdocs_38358

**query：** Where is the Medford School District located?

**term：** Medford School District
**dimension：** Entity Disambiguation
**来源：** 旧第164题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Medford Public Schools | Medford, Massachusetts | Medford, Massachusetts |
| Medford School District (Oregon) | Oregon | Oregon |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Medford Public Schools：完整供应证据</summary>

Medford Public Schools Medford Public Schools is a school district located in Medford, Massachusetts. The district has 9 schools in the city serving grades K-12. It is led by Superintendent Roy E. Belson. The main office is located at 489 Winthrop Street, within the High School/Vocational-Technical High School building. Brooks Elementary School is located in the West Medford section of Medford, Massachusetts. It is named for John Brooks, who was born in Medford, became a Revolutionary War veteran, and was later Governor of Massachusetts from 1816 to 1823. Columbus Elementary School is located in the South Medford section of Medford,

答案字符位置：[78, 100)。

</details>

<details>
<summary>Medford School District (Oregon)：完整供应证据</summary>

Medford School District (Oregon) Medford School District (549C) is a school district in the U.S. state of Oregon. It is the largest school district of southern Oregon. The district is bordered directly to the north by the Central Point School District. (Other nearby districts include the Ashland School District, Grants Pass School District, and Klamath Falls City School District). Today, district 549C encompasses 14 primary schools, two secondary schools, and three high schools in three cities: Medford, Jacksonville, and Ruch. As of 2012, district enrollment stood at 13,177 students. The Medford School District passed a school bond in November 2006

答案字符位置：[25, 31)。

</details>

## 第132题：ambigdocs_32609

**query：** Who is the artist of the album "Small Change"?

**term：** Small change
**dimension：** Entity Disambiguation
**来源：** 旧第165题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Small Change (Prism album) | Prism | Prism |
| Small Change (Tom Waits album) | Tom Waits | Tom Waits |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Small Change (Prism album)：完整供应证据</summary>

Small Change (Prism album) Small Change is the fifth studio album by the Canadian rock band Prism. It was originally released in 1981, on the label Capitol. It was the first of two Prism studio albums with vocalist Henry Small, who had replaced Ron Tabak after his forced departure and the last album to feature guitarist and founding member Lindsay Mitchell. The album is generally regarded as the genesis of the smoother, more adult-oriented sound of the band's later work. The album peaked at No. 53 on the "Billboard 200". On release, the album was received favorably by the majority

答案字符位置：[14, 19)。

</details>

<details>
<summary>Small Change (Tom Waits album)：完整供应证据</summary>

Small Change (Tom Waits album) Small Change is the third studio album by Tom Waits, released in 1976 on Asylum Records. It was recorded in July 1976. "Small Change" was recorded, direct to 2-track stereo tape, July 15, 19–21 and 29, 1976 at the Wally Heider Recording Studio, in Hollywood, USA under the production of Bones Howe. The album featured famed drummer Shelly Manne, and was, like Waits' previous albums, heavily jazz-influenced, with a lyrical style that owed influence to Raymond Chandler and Charles Bukowski as well as a vocal delivery influenced by Louis Armstrong, Dr. John and Howlin' Wolf.

答案字符位置：[14, 23)。

</details>

## 第133题：ambigdocs_30837

**query：** Who was the mother of Henry, Earl of Lancaster?

**term：** Henry, Earl of Lancaster
**dimension：** Entity Disambiguation
**来源：** 旧第167题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Henry, 3rd Earl of Lancaster | Blanche of Artois | Blanche of Artois |
| Henry of Grosmont, 1st Duke of Lancaster | Maud de Chaworth | Maud de Chaworth |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Henry, 3rd Earl of Lancaster：完整供应证据</summary>

Henry, 3rd Earl of Lancaster Henry, 3rd Earl of Leicester and Lancaster (c. 1281 – 22 September 1345) was a grandson of King Henry III (1216–1272) of England and was one of the principals behind the deposition of King Edward II (1307–1327), his first cousin. He was the younger son of Edmund Crouchback, 1st Earl of Lancaster, Earl of Leicester, a son of King Henry III by his wife Eleanor of Provence. Henry's mother was Blanche of Artois, Queen Dowager of Navarre. Henry's elder brother Thomas, 2nd Earl of Lancaster, succeeded their father in 1296, but Henry was summoned to

答案字符位置：[422, 439)。

</details>

<details>
<summary>Henry of Grosmont, 1st Duke of Lancaster：完整供应证据</summary>

Earl of Lancaster (c.1278-1322) ("Thomas of Lancaster"), both sons of Edmund Crouchback, 1st Earl of Lancaster (1245-1296), second son of King Henry III (ruled 1216-1272), and younger brother of King Edward I (ruled 1272-1307). Henry of Grossmont was thus a first cousin once removed of king Edward II and a second cousin of King Edward III (ruled 1327-1377). His mother was Maud de Chaworth (1282-1322). Henry of Grosmont was the eventual heir of his wealthy uncle Thomas, 2nd Earl of Lancaster who through his marriage to Alice de Lacy, daughter and heiress of Henry de Lacy, 3rd Earl of Lincoln,

答案字符位置：[375, 391)。

</details>

## 第134题：ambigdocs_50971

**query：** When was Arthur Watts born?

**term：** Arthur Watts
**dimension：** Entity Disambiguation
**来源：** 旧第169题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Arthur Thomas Watts | August 31, 1837 | August 31, 1837 / 31 August 1837 / August 31 1837 / 1837-08-31 |
| Arthur Watts (politician) | 26 May 1897 | 26 May 1897 / May 26, 1897 / May 26 1897 / 1897-05-26 |
| Arthur Watts (barrister) | 14 November 1931 | 14 November 1931 / November 14, 1931 / November 14 1931 / 1931-11-14 |
| Arthur Watts (illustrator) | 1883 | 1883 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Arthur Thomas Watts：完整供应证据</summary>

Arthur Thomas Watts Arthur Thomas Watts (August 31, 1837 - June 28, 1921) was a Texan politician who served in the Texas House from 1873-1874. Watts was born on August 31, 1837 in Covington County, Mississippi to Patience Lott and William Watts. He was the middle child of 3 children. His parents moved to Texas in 1841 while he stayed in Mississippi. He would later move to Texas and was admitted to the bar in 1859. In 1861, he moved back to Mississippi to fight in the American Civil War. He fought alongside Stonewall Jackson for a bit. He was

答案字符位置：[41, 56)。

</details>

<details>
<summary>Arthur Watts (politician)：完整供应证据</summary>

Arthur Watts (politician) Arthur Frederick Watts (26 May 1897 – 8 June 1970) was an Australian politician who served in the Western Australian Legislative Assembly from 1935 to 1962, including as leader of the opposition (from 1942 to 1947) and deputy premier (from 1947 to 1953 and 1959 to 1962) of Western Australia. Born in London, Watts emigrated to Perth with his family in 1906, later moving to Katanning. Having boarded at Guildford Grammar School, he was admitted to the Supreme Court of Western Australia in 1920 as a barrister and solicitor. Watts was elected to parliament for the Country

答案字符位置：[50, 61)。

</details>

<details>
<summary>Arthur Watts (barrister)：完整供应证据</summary>

Arthur Watts (barrister) Sir Arthur Watts, KCMG, QC (14 November 1931 – 16 November 2007) was an international lawyer, diplomat and arbitrator. He was employed as a legal adviser at the Foreign Office between 1956 and 1991 being appointed the Chief Legal Adviser to the Foreign Office from 1987 to 1991. Arthur Watts was educated at Haileybury and the Royal Military Academy, Sandhurst. He read Economics and Law at Downing College, Cambridge. He was called to the Bar by Gray's Inn in 1957, while a junior legal adviser at the Foreign Office. Over the period of some 45 years he

答案字符位置：[53, 69)。

</details>

<details>
<summary>Arthur Watts (illustrator)：完整供应证据</summary>

a woman who died soon afterwards. When police attended they recovered a large amount of money and mail-bags. An investigation found that the storm in the area had been so violent that swollen rivers had swept away two bridges, the local power plant had been put out of action and that the weather had played a significant part in the accident. The dead were removed to a small chapel at San Giacomo to await instructions for their disposition. Articles and essays Books illustrated Arthur Watts (illustrator) Arthur George Watts DSO (1883–1935) was an illustrator and artist who was killed in

答案字符位置：[534, 538)。

</details>

## 第135题：ambigdocs_9342

**query：** When did Lupe start their professional boxing career?

**term：** Lupe
**dimension：** Entity Disambiguation
**来源：** 旧第170题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Lupe Aquino | 1981 | 1981 |
| Lupe Pintor | 1974 | 1974 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Lupe Aquino：完整供应证据</summary>

Lupe Aquino Isaias Guadalupe "Lupe" Aquino (born January 23, 1963 in Chihuahua, Mexico) was a professional boxer (170 cm height) in the super welterweight (154 lb) division. Aquino, known as "Lupe", turned pro in 1981 and won the WBC Light Middleweight Title in 1987 with a decision over Duane Thomas. He lost the title in his first defense via a close decision to Gianfranco Rosi. In 1988 Aquino took on John David Jackson for the inaugural WBO Light Middleweight Title. In the fight, Aquino was put down in 1st and retired after the 7th round. Aquino continued to fight until

答案字符位置：[213, 217)。

</details>

<details>
<summary>Lupe Pintor：完整供应证据</summary>

Lupe Pintor José Guadalupe Pintor Guzmán (born April 13, 1955), better known as Lupe Pintor, is a Mexican former professional boxer who competed from 1974 to 1995. He won the WBC bantamweight title in 1979 after defeating Carlos Zárate Serna, and made eight defenses. In 1985, Pintor defeated Juan Meza to win the WBC super bantamweight title, but lost to Samart Payakaroon in his first defense the following year. Lupe Pintor was born into a poor, working-class family in Cuajimalpa, just outside Mexico City in 1955 and is alleged to have had an extremely violent relationship with his father, eventually

答案字符位置：[150, 154)。

</details>

## 第136题：ambigdocs_15580

**query：** When was the CGMC founded?

**term：** CGMC
**dimension：** Entity Disambiguation
**来源：** 旧第171题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Chicago Gay Men's Chorus | 1983 | 1983 |
| Connecticut Gay Men's Chorus | 1986 | 1986 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Chicago Gay Men's Chorus：完整供应证据</summary>

Chicago Gay Men's Chorus The Chicago Gay Men's Chorus (CGMC) is a choral organization in Chicago, Illinois. Founded in 1983 with fifty-five singers, the chorus currently consists of approximately 150 singing members and over 200 members in total. The Chorus was organized in 1983 in response to an invitation to participate in the first National Gay and Lesbian Choral Festival, "Come Out! And Sing Together" (COAST). The event was staged at New York City's Lincoln Center and featured 1,200 individuals from twelve choruses from across the United States. The fifty-five singers from the Chicago Gay Men's Chorus representing the city

答案字符位置：[119, 123)。

</details>

<details>
<summary>Connecticut Gay Men's Chorus：完整供应证据</summary>

Connecticut Gay Men's Chorus The Connecticut Gay Men's Chorus (CGMC) is Connecticut's first and, until 2012, its only performing arts organization composed of openly gay men. It was begun in 1986 by a small group of gay men under the directorship of Robert Read and led by him until 1992. Since 1986 the Chorus has rehearsed in the gymnasium of St. Thomas's Episcopal Church in New Haven. From 1993 to 2007 the CGMC also performed in September in Provincetown, Massachusetts, a town with a large gay population. The shows, sponsored by the Provincetown Business Guild, were sold out every year

答案字符位置：[191, 195)。

</details>

## 第137题：ambigdocs_67073

**query：** Who is the creator of "The Life and Adventures of Santa Claus"?

**term：** The Life and Adventures of Santa Claus (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第172题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| The Life & Adventures of Santa Claus (2000 film) | Mike Young Productions | Mike Young Productions |
| The Life and Adventures of Santa Claus (1985 film) | Rankin/Bass Productions | Rankin/Bass Productions |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>The Life & Adventures of Santa Claus (2000 film)：完整供应证据</summary>

The Life & Adventures of Santa Claus (2000 film) The Life & Adventures of Santa Claus is a 2000 film created by Mike Young Productions and released by Universal Studios Home Entertainment. It is based on the 1902 L. Frank Baum novel of the same name. In the Forest of Burzee, where many immortals live (such as Knooks, fairies, and nymphs), their leader, Ak, the Master Woodsman of the World (governor of all forests), finds a human baby abandoned and places him in the care of the lioness, Shiegra. A wood nymph named Necile thereupon adopts the baby; later named

答案字符位置：[112, 134)。

</details>

<details>
<summary>The Life and Adventures of Santa Claus (1985 film)：完整供应证据</summary>

The Life and Adventures of Santa Claus (1985 film) The Life and Adventures of Santa Claus is a 1985 Christmas stop motion animated television special produced by Rankin/Bass Productions and based on the 1902 children's book "The Life and Adventures of Santa Claus" by L. Frank Baum, the writer of "The Wonderful Wizard of Oz". The special first aired December 17, 1985 on CBS in the United States, and December 24, 1986 on TV Asahi in Japan under the title Santa's Secret and Great Adventure (サンタの秘密と大冒険, lit. "Santa no Himitsu to Dai Bōken"). This was Rankin/Bass' final "Animagic" stop motion

答案字符位置：[162, 185)。

</details>

## 第138题：ambigdocs_14784

**query：** Where is Hermitage High School located?

**term：** Hermitage High School
**dimension：** Entity Disambiguation
**来源：** 旧第173题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Hermitage High School (Arkansas) | Hermitage, Arkansas, United States | Hermitage, Arkansas, United States |
| Hermitage High School (Virginia) | West End of Henrico County, Virginia | West End of Henrico County, Virginia |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Hermitage High School (Arkansas)：完整供应证据</summary>

Hermitage High School (Arkansas) Hermitage High School is an accredited comprehensive public high school serving students in grades nine through twelve in Hermitage, Arkansas, United States. The school supports families in Hermitage and nearby unincorporated communities in Bradley County and is the sole high school administered by the Hermitage School District. The Hermitage High School is accredited by the Arkansas Department of Education (ADE) and has been accredited by AdvancED since 1925. The assumed course of study follows the Smart Core curriculum developed the Arkansas Department of Education (ADE), which requires students to complete at least 24 credit units before

答案字符位置：[155, 189)。

</details>

<details>
<summary>Hermitage High School (Virginia)：完整供应证据</summary>

Hermitage High School (Virginia) Hermitage High is a public school located in the West End of Henrico County, Virginia. The mascot of Hermitage High School is the panther. Hermitage High School has athletic facilities with a concrete football stadium and a rubber-turf track. Initially, Hermitage High School began in 1936 as the Glen Allen High School, which was located at the present-day site of the Glen Allen Cultural Arts Center off Mountain Road. The building that is now George H. Moody Middle School was opened in 1951 as Hermitage High School. The current Hermitage High School was opened in 1972

答案字符位置：[82, 118)。

</details>

## 第139题：ambigdocs_43678

**query：** What sport is Chris Watson associated with?

**term：** Chris Watson (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第176题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Chris Watson (American football) | American football | American football |
| Chris Watson (basketball) | Basketball | Basketball |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Chris Watson (American football)：完整供应证据</summary>

Chris Watson (American football) Chris Watson (born June 30, 1977 in Chicago, Illinois) is a former American football cornerback in the National Football League. He played for the Denver Broncos, the Buffalo Bills, and the Detroit Lions. Chris attended Leo Catholic High School in Chicago, part of the Chicago Catholic League. Watson attended Eastern Illinois University as a student and a football standout. In football, he was a four-year letterman and a three-year starter. Watson was drafted 67th overall in the third round by the Denver Broncos of the 1999 NFL Draft, then the highest an Eastern Illinois player had

答案字符位置：[14, 31)。

</details>

<details>
<summary>Chris Watson (basketball)：完整供应证据</summary>

Holon in 2007-2008, and again in 2008-2009. He was selected to the Israeli Basketball Premier League All-Star Game in 2011. Watson has twice played on the Israel national basketball team. Watson was born in White Plains, New York. Watson attended White Plains High School, and then transferred to Archbishop Stepinac High School ('93). He married an Israeli woman, Roni, and in 2003 he became an Israeli citizen. He and his wife have a daughter, Dream. He attended Niagara University, where he played for the Purple Eagles basketball team in the Metro Atlantic Athletic Conference. He led the team in scoring

答案字符位置：[75, 85)。

</details>

## 第140题：ambigdocs_48365

**query：** Who is the composer of Symphony No. 34?

**term：** Symphony No. 34
**dimension：** Entity Disambiguation
**来源：** 旧第177题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Symphony No. 34 (Michael Haydn) | Michael Haydn | Michael Haydn |
| Symphony No. 34 (Mozart) | Wolfgang Amadeus Mozart | Wolfgang Amadeus Mozart |
| Symphony No. 34 (Haydn) | Joseph Haydn | Joseph Haydn |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Symphony No. 34 (Michael Haydn)：完整供应证据</summary>

Symphony No. 34 (Michael Haydn) Michael Haydn's Symphony No. 34 in E-flat major, Perger 26, Sherman 34, MH 473, written in Salzburg in 1788, is the last E-flat major symphony he wrote, the first of his final set of six symphonies. Scored for 2 oboes, 2 bassoons, 2 horns and strings, in three movements: The first and last movements begin the same way, only that the first movement uses the theme to launch a sonata form while the third movement uses it to preface a fugato. Like the other symphonies of the 1788 set of six, this one is in

答案字符位置：[17, 30)。

</details>

<details>
<summary>Symphony No. 34 (Mozart)：完整供应证据</summary>

Symphony No. 34 (Mozart) Symphony No. 34 in C major, K. 338, was written by Wolfgang Amadeus Mozart in 1780, and completed on 29 August. The work is scored for 2 oboes, 2 bassoons, 2 horns, 2 trumpets, timpani and strings. \relative c { </score> Although most symphonies have four movements, this symphony has only three, which was still common in the early classical period: The symphony features the fanfares and flourishes typical of the "festive symphony" or "trumpet symphony", which is characteristic of Austrian symphonic writing in C major. This is the first of Mozart's C-major symphonies to exhibit

答案字符位置：[76, 99)。

</details>

<details>
<summary>Symphony No. 34 (Haydn)：完整供应证据</summary>

Symphony No. 34 (Haydn) The Symphony No. 34 in D minor (Hoboken I/34) was written by Joseph Haydn. It was written in 1765, shortly before Haydn's Sturm und Drang period began in 1766, during his social withdrawel at <nowiki>Esterháza</nowiki>. It was the first minor key symphony he ever wrote. The scoring of the symphony is typical of Haydn in this period: two oboes, bassoon, two horns, strings and continuo. It is possible that this symphony is the one referred to in an inscription accompanying Haydn's Symphony No. 49 (La passione) which reads: "questa Sinfonia (i.e. 49) serve di Compagna a

答案字符位置：[85, 97)。

</details>

## 第141题：ambigdocs_11802

**query：** Where is St Peter's Seminary located?

**term：** St Peter's Seminary
**dimension：** Entity Disambiguation
**来源：** 旧第178题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| St. Peter's Seminary (Diocese of London, Ontario) | London, Ontario, Canada | London, Ontario, Canada |
| St Peter's Seminary, Cardross | near Cardross, Argyll and Bute, Scotland | near Cardross, Argyll and Bute, Scotland / Near Cardross, Argyll and Bute, Scotland |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>St. Peter's Seminary (Diocese of London, Ontario)：完整供应证据</summary>

St. Peter's Seminary (Diocese of London, Ontario) St. Peter's Seminary is a Roman Catholic seminary located in the Diocese of London, Ontario, Canada. The seminary is a fully accredited member of the Association of Theological Schools of the United States and Canada. St. Peter's Seminary is the major seminary of the Roman Catholic Diocese of London in Ontario. It is affiliated with King's University College, a Catholic affiliate of The University of Western Ontario. The current rector of St. Peter's Seminary is Stevan Wlusek. St. Peter’s Seminary is Canada's oldest English-speaking Roman Catholic diocesan seminary. Since it was founded by

答案字符位置：[126, 149)。

</details>

<details>
<summary>St Peter's Seminary, Cardross：完整供应证据</summary>

St Peter's Seminary, Cardross St. Peter's Seminary is a disused Roman Catholic seminary near Cardross, Argyll and Bute, Scotland. Designed by the firm of Gillespie, Kidd & Coia, it has been described by the international architecture conservation organisation DOCOMOMO as a modern "building of world significance". It is one of only 42 post-war buildings in Scotland to be listed at Category A, the highest level of protection for a building of "special architectural or historic interest". It has been abandoned since the end of the 1980s, and is currently in a ruinous state. It was announced in early 2015 that

答案字符位置：[88, 128)。

</details>

## 第142题：ambigdocs_18775

**query：** When was William Springer born?

**term：** William Springer
**dimension：** Entity Disambiguation
**来源：** 旧第179题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| William L. Springer | April 12, 1909 | April 12, 1909 / 12 April 1909 / April 12 1909 / 1909-04-12 |
| William McKendree Springer | May 30, 1836 | May 30, 1836 / 30 May 1836 / May 30 1836 / 1836-05-30 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>William L. Springer：完整供应证据</summary>

William L. Springer William Lee Springer (April 12, 1909 – September 20, 1992) was a U.S. Representative from Illinois. Born in Sullivan, Indiana, Springer attended the public schools and Sullivan and Culver Military Academy at Culver, Indiana. DePauw University, Greencastle, Indiana, B.A., 1931. He graduated from the law school of the University of Illinois, LL.B., in 1935. He was admitted to the bar in 1935 and commenced the practice of law in 1936 in Champaign, Illinois. He was the state's attorney of Champaign County, Illinois from 1940 to 1942. He served in the United States Navy from March 1942 as

答案字符位置：[42, 56)。

</details>

<details>
<summary>William McKendree Springer：完整供应证据</summary>

William McKendree Springer William McKendree Springer (May 30, 1836 – December 4, 1903) was a United States Representative from Illinois. He was born near New Lebanon, Sullivan County, Indiana, May 30, 1836; moved to Jacksonville, Illinois, with his parents in 1848; attended the public schools in New Lebanon and Jacksonville and the Illinois College at Jacksonville where he was a member of Phi Alpha Literary Society; graduated from Indiana University in 1858; studied law; was admitted to the bar in 1859 and practiced in Lincoln, Illinois and Springfield, Illinois; was secretary of the State constitutional convention in 1862 at the

答案字符位置：[55, 67)。

</details>

## 第143题：ambigdocs_39096

**query：** When did Edward Phelips die?

**term：** Edward Phelips
**dimension：** Entity Disambiguation
**来源：** 旧第180题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Edward Phelips (Royalist) | 5 February 1680 | 5 February 1680 / February 5, 1680 / February 5 1680 / 1680-02-05 |
| Edward Phelips (died 1797) | 1797 | 1797 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Edward Phelips (Royalist)：完整供应证据</summary>

1661, he was elected Member of Parliament for Somerset in the Cavalier Parliament. He became high steward of Ilchester in the same year and commissioner for corporations in Somerset in 1663. He was defeated at Somerset and lost out in a double return at Ilchester in the general election in 1679. He died on 5 February 1680 at the age of 67 and was buried at Montacute. Phelips married Anne Pye, daughter of Sir Robert Pye of Faringdon, Berkshire on 21 February 1632. He had four sons of whom Edward was also MP for Ilchester and two daughters. His brother

答案字符位置：[308, 323)。

</details>

<details>
<summary>Edward Phelips (died 1797)：完整供应证据</summary>

Edward Phelips (died 1797) Edward Phelips (1725–1797) was an English country landowner and politician who sat in the House of Commons from 1774 to 1780. Phelips was the eldest son of Edward Phelips MP of Montacute House, and his second wife Elizabeth Phelips, daughter of his uncle Sir Edward Phelips, MP. He succeeded his father to Montacute in 1734. He was educated at Westminster School from February 1737, and matriculated at Christ Church, Oxford on 23 April 1741, aged 16. He married. Maria Wright, daughter of William Wright in about.1747 Phelips was returned unopposed as Member of Parliament for Somerset

答案字符位置：[21, 25)。

</details>

## 第144题：ambigdocs_29783

**query：** According to the supplied documents, who is the head coach of the Texas A&M–Commerce Lions basketball team?

**term：** Texas A&M–Commerce Lions basketball
**dimension：** Entity Disambiguation
**来源：** 旧第181题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Texas A&M–Commerce Lions men's basketball | Sam Walker | Sam Walker |
| Texas A&M–Commerce Lions women's basketball | Jason Burton | Jason Burton |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Texas A&M–Commerce Lions men's basketball：完整供应证据</summary>

playoffs numerous times but since joining the NCAA they have not made it past the elite eight in the national tournament. The team is currently coached by Sam Walker who has coached the team since 2000 and has a combined record of 249–180, and 103–93 in conference games, he has more wins than any other basketball coach in the program's history. The team was featured as an opponent of Texas Western University's (now The University of Texas at El Paso) historic color barrier breaking team in the Walt Disney film "Glory Road" during the 1966 season. The game was shown

答案字符位置：[155, 165)。

</details>

<details>
<summary>Texas A&M–Commerce Lions women's basketball：完整供应证据</summary>

Texas A&M–Commerce Lions women's basketball The Texas A&M–Commerce Lions women's basketball team (formerly the East Texas State Lions) is the women's intercollegiate basketball program representing Texas A&M University–Commerce. The school competes in the Lone Star Conference (LSC) in Division II of the National Collegiate Athletic Association (NCAA). The A&M–Commerce women's basketball team plays its home games at the University Field House on the university campus in Commerce, Texas. The Lions have won one conference title and has once appeared in the NCAA tournament. The team is currently coached by Jason Burton. The women's team was formed in 1971 and played

答案字符位置：[610, 622)。

</details>

## 第145题：ambigdocs_57617

**query：** Who is the artist of the album "Future Perfect"?

**term：** Future perfect (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第182题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Future Perfect (Autolux album) | Autolux | Autolux |
| Future Perfect (Loadstar album) | Loadstar | Loadstar |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Future Perfect (Autolux album)：完整供应证据</summary>

Future Perfect (Autolux album) Future Perfect is the debut studio album by American alternative rock band Autolux, released November 21, 2004 on T-Bone Burnett's label, DMZ, via Columbia. "Future Perfect" was recorded at Sunset Sound in Los Angeles and was produced by Burnett. The album has been described as indie rock, shoegaze and noise pop. DMZ also released "Future Perfect" on vinyl as a two-LP set, which later went out of print. After the label's demise, Autolux reissued the album themselves (listed as Autolux Music Entertainment) in 2009 on one 180-gram LP via their website (with no edits or changes

答案字符位置：[16, 23)。

</details>

<details>
<summary>Future Perfect (Loadstar album)：完整供应证据</summary>

Future Perfect (Loadstar album) Future Perfect is the debut studio album by British production duo Loadstar. The album was released on 26 May 2013 through RAM Records. Loadstar appeared on DJ Target and MistaJam's BBC Radio 1Xtra shows to promote the album. They also hosted an Essential Mix on BBC Radio 1. The album charted at number 168 on the UK Albums Chart and also on the dance and indie charts. Some of the initial ideas for album tracks, such as "Eat My Tears", were created as early as 2010. "Losing You" was another of the first to be produced.

答案字符位置：[16, 24)。

</details>

## 第146题：ambigdocs_13348

**query：** Who is the composer of the Piano Sonata in B minor?

**term：** Piano Sonata in B minor
**dimension：** Entity Disambiguation
**来源：** 旧第183题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Piano Sonata in B minor (Liszt) | Franz Liszt | Franz Liszt |
| Piano Sonata in B minor (Strauss) | Richard Strauss | Richard Strauss |
| Piano Sonata No. 3 (Chopin) | Frédéric Chopin | Frédéric Chopin |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Piano Sonata in B minor (Liszt)：完整供应证据</summary>

Piano Sonata in B minor (Liszt) The Piano Sonata in B minor (), S.178, is a sonata for solo piano by Franz Liszt. It was completed in 1853 and published in 1854 with a dedication to Robert Schumann. Liszt noted on the sonata's manuscript that it was completed on February 2, 1853, but he had composed an earlier version by 1849. At this point in his life, Liszt's career as a traveling virtuoso had almost entirely subsided, as he had been influenced towards leading the life of a composer rather than a performer by Carolyne zu Sayn-Wittgenstein almost five years

答案字符位置：[101, 112)。

</details>

<details>
<summary>Piano Sonata in B minor (Strauss)：完整供应证据</summary>

Piano Sonata in B minor (Strauss) The Piano Sonata in B minor, Op.5, was written by Richard Strauss in 1881–82 when he was 17 years old. The Sonata is in the Romantic style of his teenage years. The first recording of the piece was the last recording made by the Canadian pianist Glenn Gould. The Piano Sonata is in four movements: The first movement and Finale are in Sonata form. The Adagio is in Ternary form with an ABA structure; the Scherzo is a "full fledged Scherzo in an expanded ABABA form . The first movement is notable for having

答案字符位置：[84, 99)。

</details>

<details>
<summary>Piano Sonata No. 3 (Chopin)：完整供应证据</summary>

in both of its appearances. The piece concludes in a jubilant B major coda. The sonata has been recorded many times. The first commercial electric recording was made by Percy Grainger in 1925. This has been described as "still one of the greatest accounts on disc ... The finale is simply dazzling". Notes Sources Piano Sonata No. 3 (Chopin) Frédéric Chopin composed his Piano Sonata No. 3 in B minor, Op. 58, in 1844 and dedicated it to Countess Émilie de Perthuis. Along with the previous sonata, this is considered to be one of Chopin's most difficult compositions, both technically

答案字符位置：[342, 357)。

</details>

## 第147题：ambigdocs_58289

**query：** Who is the artist of "The Great Unknown"?

**term：** The Great Unknown
**dimension：** Entity Disambiguation
**来源：** 旧第185题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| The Great Unknown (Rob Thomas album) | Rob Thomas | Rob Thomas |
| The Great Unknown (Sarah Geronimo album) | Sarah Geronimo | Sarah Geronimo |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>The Great Unknown (Rob Thomas album)：完整供应证据</summary>

The Great Unknown (Rob Thomas album) The Great Unknown is the third solo studio album by the Matchbox Twenty lead singer Rob Thomas, released on August 21, 2015, through Atlantic Records. Its lead single, "Trust You", premiered on "Entertainment Weekly"'s website on May 29, 2015. "The Great Unknown" received generally positive reviews from music critics. At Metacritic, which assigns a normalized rating out of 100 to reviews from mainstream critics, the album received an average score of 69 based on 4 reviews. In a positive review, Stephen Thomas Erlewine of AllMusic described the record as, "an album that deliberately side-steps

答案字符位置：[19, 29)。

</details>

<details>
<summary>The Great Unknown (Sarah Geronimo album)：完整供应证据</summary>

The Great Unknown (Sarah Geronimo album) The Great Unknown is the twelfth studio album by Filipino singer Sarah Geronimo. It was released in the Philippines on December 4, 2015, through Viva Records and debuted at number two in Philippines iTunes pop music album chart behind Adele's 25. It was made available for purchase on December 4, 2015 despite releasing new tracks from previous album, Perfectly Imperfect. On August 24, 2015, songwriter Yumi Lacsama posted a picture of her with Thyro and Sarah on her Instagram account. The picture showed all three them smiling with Thyro holding up a paper with

答案字符位置：[19, 33)。

</details>

## 第148题：ambigdocs_56141

**query：** Where is the Longsnout butterflyfish found?

**term：** Longsnout butterflyfish
**dimension：** Entity Disambiguation
**来源：** 旧第186题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Forcipiger longirostris | Indo-Pacific | Indo-Pacific |
| Prognathodes aculeatus | tropical Atlantic waters | tropical Atlantic waters / Tropical Atlantic waters |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Forcipiger longirostris：完整供应证据</summary>

Forcipiger longirostris Forcipiger longirostris, commonly known as the longnose butterflyfish or big longnose butterflyfish, is a species of butterflyfish found on coral reefs throughout the tropical waters of the Indo-Pacific. Even with its distinctive, point-like long nose, the longnose butterflyfish still can easily be confused with its more common cousin "F. flavissimus". Both species may be kept in aquariums. "F. longirostris" has a compressed yellow body with a black triangular region on its head, and as the name implies, a long, silvery snout. Usually 10 or 11 dorsal spines, a black spot on the anal fin, and rows of small

答案字符位置：[214, 226)。

</details>

<details>
<summary>Prognathodes aculeatus：完整供应证据</summary>

Prognathodes aculeatus Prognathodes aculeatus (longsnout butterflyfish) is a species of butterflyfish found in tropical Atlantic waters. It is also known as the "butterbun", the "Caribbean longsnout butterflyfish", or "Poey's butterflyfish". This species should not be confused with the banded longsnout butterflyfish or "Chelmon rostratus". The longsnout butterflyfish was first described in 1860 by two scientists: Felipe Poey y Aloy and Albert C. L. G. Günther. Between them the fish was given three separate scientific names each one in a different genus. It was again described in 1880 by Sauvage who gave it yet another scientific name. An average of 2

答案字符位置：[111, 135)。

</details>

## 第149题：ambigdocs_32192

**query：** Who is the artist of the "Live in Detroit" release?

**term：** Live in Detroit
**dimension：** Entity Disambiguation
**来源：** 旧第188题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Live in Detroit (The Doors album) | The Doors | The Doors |
| Live in Detroit (The Stooges album) | The Stooges | The Stooges |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Live in Detroit (The Doors album)：完整供应证据</summary>

Live in Detroit (The Doors album) Live in Detroit is a double CD live album by the American rock band the Doors. It was recorded at the Cobo Arena in Detroit on May 8, 1970 during the band's 1970 Roadhouse Blues Tour. It was released on October 23, 2000 on Rhino Records. The concert is one of the longest live performances by the Doors. Among the 25 songs played the group played eight blues standards such as "Back Door Man", Junior Parker's "Mystery Train" and "Crossroads" by Robert Johnson. The band were joined by Lovin' Spoonful's John Sebastian on guitar

答案字符位置：[17, 26)。

</details>

<details>
<summary>Live in Detroit (The Stooges album)：完整供应证据</summary>

Live in Detroit (The Stooges album) Live in Detroit a 2003 DVD release of a live performance by the band The Stooges. The surviving original members of the Stooges reunited in 2003—nearly thirty years after they had disbanded—and scheduled a handful of live shows, including an August 14 concert in their hometown of Detroit. The gig was postponed due to a widespread North America blackout, but the band played at the DTE Energy Music Theatre eleven days later. (The DVD's liner notes contain a facetious remark about the blackout being caused by Ron Asheton playing his guitar during soundcheck the

答案字符位置：[17, 28)。

</details>

## 第150题：ambigdocs_56940

**query：** When was the vessel Greif commissioned?

**term：** Greif
**dimension：** Entity Disambiguation
**来源：** 旧第189题，revised

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| German torpedo boat Greif | 15 July 1927 | 15 July 1927 / July 15, 1927 / July 15 1927 / 1927-07-15 |
| SMS Greif | 9 July 1887 | 9 July 1887 / July 9, 1887 / July 9 1887 / 1887-07-09 |
| Greif (brigantine) | August 2, 1951 | August 2, 1951 / 2 August 1951 / August 2 1951 / 1951-08-02 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>German torpedo boat Greif：完整供应证据</summary>

at the "Reichsmarinewerft Wilhelmshaven" (Navy Yard) on 5 October 1925 as yard number 104, launched on 15 July 1926 and commissioned on 15 July 1927. By the end of 1936 "Greif" was assigned to the 4th Torpedo Boat Flotilla and the boat made several deployments to Spain during the Spanish Civil War. Around June 1938, she was transferred to the newly formed 5th Torpedo Boat Flotilla. "Greif" was used in the North Sea mining operations that began on 3 September 1939. Together with three destroyers and her sisters and , "Greif" was tasked with anti-shipping patrols in the Kattegat and

答案字符位置：[136, 148)。

</details>

<details>
<summary>SMS Greif：完整供应证据</summary>

launch, and was completed by 9 July 1887, when she was commissioned into the German fleet. Following her commissioning, "Greif" served with the active duty fleet, though she saw little service, as she was an unsuccessful design. In 1897, "Greif" was assigned to the II Division of the Maneuver Squadron for the annual summer training exercises in August and September. After the conclusion of the maneuvers, the II Division returned to its home port in Kiel for the winter. In early 1898, "Gefion" returned to service in the II Division. In August and September 1900, "Greif" was assigned to the

答案字符位置：[29, 40)。

</details>

<details>
<summary>Greif (brigantine)：完整供应证据</summary>

for maritime youth education. It has participated in Hanse Sail, including Hanse Sail Rostock 2011. Greif (brigantine) Greif is a brigantine, owned by the town Greifswald in Mecklenburg-Vorpommern. It was built in 1951 at Warnowwerft, Warnemünde/Rostock with a steel hull. It was launched May 26, 1951 and commissioned August 2, 1951. It was the first steel vessel built after the war at the port, and was christened "Wilhelm Pieck" for the first president of the German Democratic Republic. In 1990 it would participate in the first German-German sail event. The ship was given to the town of Greifswald and overhauled

答案字符位置：[319, 333)。

</details>

## 第151题：ambigdocs_37992

**query：** When was Judge Matthews born?

**term：** Judge Matthews
**dimension：** Entity Disambiguation
**来源：** 旧第190题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Burnita Shelton Matthews | December 28, 1894 | December 28, 1894 / 28 December 1894 / December 28 1894 / 1894-12-28 |
| Clifton Mathews | February 12, 1880 | February 12, 1880 / 12 February 1880 / February 12 1880 / 1880-02-12 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Burnita Shelton Matthews：完整供应证据</summary>

Burnita Shelton Matthews Burnita Shelton Matthews (December 28, 1894 – April 25, 1988) was a judge of the United States District Court for the District of Columbia. From Copiah County, Mississippi, she was the first woman appointed to serve on a U.S. district court. Burnita Shelton was born near Hazlehurst, Mississippi on December 28, 1894. Her father was a planter and chancery court judge. She had a brother, John L. Shelton. After attending local schools, she went to the Cincinnati Conservatory of Music, as her father wanted her to be able to support herself by teaching music. Her brother was

答案字符位置：[51, 68)。

</details>

<details>
<summary>Clifton Mathews：完整供应证据</summary>

Clifton Mathews Clifton Mathews (February 12, 1880 – September 7, 1962) was a lawyer and a United States federal judge. Born in Concord, Georgia, Matthews read law to enter the bar in 1904; he was in private practice in Farmerville, Louisiana between 1904 and 1912. He was later in private practice in Roswell, New Mexico between 1913 and to 1915, then in Bisbee, Arizona until 1920, and then in Globe, Arizona until 1933. He was a Special assistant to State Attorney General of Arizona between 1929 and 1931 and then the United States Attorney for the District of Arizona between

答案字符位置：[33, 50)。

</details>

## 第152题：ambigdocs_581

**query：** Who directed the film adaptation of "The Winslow Boy"?

**term：** The Winslow Boy (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第191题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| The Winslow Boy (1948 film) | Anthony Asquith | Anthony Asquith |
| The Winslow Boy (1999 film) | David Mamet | David Mamet |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>The Winslow Boy (1948 film)：完整供应证据</summary>

The Winslow Boy (1948 film) The Winslow Boy is a 1948 British film adaptation of Terence Rattigan's play "The Winslow Boy". It was made by De Grunwald Productions and distributed by the British Lion Film Corporation. It was directed by Anthony Asquith and produced by Anatole de Grunwald with Teddy Baird as associate producer. The adapted screenplay was written by de Grunwald and Rattigan based on Rattigan's play. The music score was by William Alwyn and the cinematography by Freddie Young. The film stars Robert Donat, Sir Cedric Hardwicke and Margaret Leighton with Basil Radford, Kathleen Harrison, Francis L. Sullivan,

答案字符位置：[236, 251)。

</details>

<details>
<summary>The Winslow Boy (1999 film)：完整供应证据</summary>

had misjudged him all along. Shot in London, the film was directed by David Mamet who originally had thought of making a theatrical production of Rattigan's dramatic play, which had been previously filmed in 1948. After failing to find backers for the project, Mamet decided to adapt the play for the big screen. It was produced by Sarah Green with Sally French, Michael Barker and Tom Bernard as associate producers. The screenplay was adapted by Mamet based on Rattigan's play. The music score was by Alaric Jans and the cinematography by Benoît Delhomme. Neil North who played the title role

答案字符位置：[70, 81)。

</details>

## 第153题：ambigdocs_4459

**query：** When was Thomas Bowman elected as a bishop?

**term：** Thomas Bowman
**dimension：** Entity Disambiguation
**来源：** 旧第192题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Thomas Bowman (Evangelical Association bishop) | 1875 | 1875 |
| Thomas Bowman (Methodist Episcopal bishop) | 1872 | 1872 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Thomas Bowman (Evangelical Association bishop)：完整供应证据</summary>

Thomas Bowman (Evangelical Association bishop) Thomas Bowman (May 28, 1836 – 1923) was a bishop of the Evangelical Association, elected in 1875. He was born in Lehigh Township, Northampton County, Pennsylvania. He studied at the Vanderveers Seminary in Easton, Pennsylvania. He entered the traveling ministry of the Eastern Pennsylvania Annual Conference of the Evangelical Association in 1859. He served as a pastor of various congregations until 1875, serving as a presiding elder in the same conference, 1870–1875. He was elected to the episcopacy in 1875. Beginning in 1896 he also served as the principal of the Union Biblical Institute of

答案字符位置：[139, 143)。

</details>

<details>
<summary>Thomas Bowman (Methodist Episcopal bishop)：完整供应证据</summary>

Thomas Bowman (Methodist Episcopal bishop) Thomas Bowman (1817–1914) was an American bishop of the Methodist Episcopal Church, elected in 1872. He was born 15 July 1817 at Berwick, Pennsylvania. Bowman earned his B.A. degree from Dickinson College in 1837. Two years later he entered the traveling ministry of the Baltimore Annual Conference of the M.E. Church. He was ordained (deacon and elder) by Bishop Waugh. Bowman taught in the grammar-school of Dickinson College (1840–43), and five years later founded Dickinson Seminary in Williamsport, Pennsylvania (of which he was president until 1858). Bowman was then chosen as president (1858–1872) and later

答案字符位置：[138, 142)。

</details>

## 第154题：ambigdocs_34172

**query：** What sport is the Channel One Cup associated with?

**term：** Channel One Cup
**dimension：** Entity Disambiguation
**来源：** 旧第194题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Channel One Cup (football) | football | football / Football |
| Channel One Cup (ice hockey) | ice hockey | ice hockey / Ice Hockey |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Channel One Cup (football)：完整供应证据</summary>

Channel One Cup (football) The Channel One Cup (, "Kubok Pervogo Kanala") was an annual pre-season commercial football tournament, organized by Russian TV Channel One and Roman Abramovich's foundation, the National Football Academy. The participants were champions and runners-up of the Russian Premier League, Ukrainian Premier League and Israeli Premier League. The total prize fund was about two million dollars, with the winner getting one million. The cup rules specified that at least half of the prize money must be channeled into developing young players. The tournament was cancelled in 2009 due to a financial crisis. However, its legacy remained

答案字符位置：[17, 25)。

</details>

<details>
<summary>Channel One Cup (ice hockey)：完整供应证据</summary>

Channel One Cup (ice hockey) The Channel One Cup (, formerly Izvestia Trophy) is an annual ice hockey event held in Russia under the auspices of Channel One. It is an open tournament of teams representing various nations, composed of professionals playing in European professional hockey leagues. The tournament started in 1967 in Moscow in the Soviet Union. The first edition of the tournament was held in 1967, in honour of the 50th anniversary of the so-called Great October Socialist Revolution. It was the only time when the tournament was held in different cities at one time, namely in Moscow,

答案字符位置：[17, 27)。

</details>

## 第155题：ambigdocs_27913

**query：** Where is the Nieuwe Kerk located?

**term：** Nieuwe Kerk
**dimension：** Entity Disambiguation
**来源：** 旧第195题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Nieuwe Kerk (Delft) | Delft | Delft |
| Nieuwe Kerk (The Hague) | The Hague | The Hague |
| Nieuwe Kerk (Katwijk aan Zee) | Katwijk, the Netherlands | Katwijk, the Netherlands |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Nieuwe Kerk (Delft)：完整供应证据</summary>

Nieuwe Kerk (Delft) The Nieuwe Kerk (; ) is a Protestant church in the city of Delft in the Netherlands. The building is located on Delft Market Square (Markt), opposite to the City Hall (Dutch: "Stadhuis"). In 1584, William the Silent was entombed here in a mausoleum designed by Hendrick and Pieter de Keyser. Since then members of the House of Orange-Nassau have been entombed in the royal crypt. The latest are Queen Juliana and her husband Prince Bernhard in 2004. The private royal family crypt is not open to the public. The church tower, designed by Pierre Cuypers and

答案字符位置：[13, 18)。

</details>

<details>
<summary>Nieuwe Kerk (The Hague)：完整供应证据</summary>

Nieuwe Kerk (The Hague) The Nieuwe Kerk (; ) is a church in The Hague, located across from the modern city hall on the Spui. It was built in 1649 after the Great Church had become too small. Construction was completed in 1656. The church was designed by the architect Peter Noorwits, who was assisted by the painter and architect Bartholomeus van Bassen. The church is considered a highlight of the early Protestant church architecture in the Netherlands. Like many churches of that time was the New Church, a central building. Unlike other central building, the church is no simple

答案字符位置：[13, 22)。

</details>

<details>
<summary>Nieuwe Kerk (Katwijk aan Zee)：完整供应证据</summary>

Nieuwe Kerk (Katwijk aan Zee) The Nieuwe Kerk ("New Church") in Katwijk, the Netherlands, is the oldest and best known work of the architect H.J. Jesse (1860–1943). It was built to replace the nearby Andreaskerk, which had become too small. Plans for building a new church were first considered in 1850. The search for a suitable location for the church began in 1883. The church authorities held a design contest, and about 53 designs were sent in. They chose the design of H.J. Jesse. Construction started in 1885, with the first stone being laid by the Baroness Van Wassenaer van

答案字符位置：[64, 88)。

</details>

## 第156题：ambigdocs_31118

**query：** Who is the artist of "The Complete Studio Recordings"?

**term：** The Complete Studio Recordings
**dimension：** Entity Disambiguation
**来源：** 旧第196题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| The Complete Studio Recordings (ABBA album) | ABBA | ABBA |
| The Complete Studio Recordings (Led Zeppelin album) | Led Zeppelin | Led Zeppelin |
| The Complete Studio Recordings (The Doors album) | The Doors | The Doors |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>The Complete Studio Recordings (ABBA album)：完整供应证据</summary>

The Complete Studio Recordings (ABBA album) The Complete Studio Recordings is a box set of all of the studio material released by the Swedish pop group ABBA. It was released on 7 November 2005 and consists of 9 CDs and 2 DVDs, plus a full colour booklet with timeline and photos. Another booklet containing the complete lyrics was also included. There is one CD for each original studio album. These CDs also include bonus tracks in the form of non-album tracks and non-English versions. The final CD contains additional rare tracks, primarily material released after the group's final studio album.

答案字符位置：[32, 36)。

</details>

<details>
<summary>The Complete Studio Recordings (Led Zeppelin album)：完整供应证据</summary>

The Complete Studio Recordings (Led Zeppelin album) The Complete Studio Recordings is a ten compact disc box set by the English rock group Led Zeppelin, released by Atlantic Records on 24 September 1993. It contains all nine of the original Led Zeppelin studio albums digitally remastered, plus an expanded version of the posthumous release "Coda". The discs are physically paired together in double-disc booklets and arranged in chronological order, with the exception of "Presence" (placed between "Houses of the Holy" and "Physical Graffiti") being paired with "Houses of the Holy" in order to keep the two discs of "Physical Graffiti"

答案字符位置：[32, 44)。

</details>

<details>
<summary>The Complete Studio Recordings (The Doors album)：完整供应证据</summary>

The Complete Studio Recordings (The Doors album) The Complete Studio Recordings is a seven compact disc box set by American rock group The Doors, released by Elektra on November 9, 1999. It contains six of the original nine Doors albums, digitally remastered with 24 bit, with the inclusion of stray previously unreleased tracks that had surfaced on "", on disc seven. The albums are placed in chronological order. While the title of the box set suggests this is a collection of all the studio recordings by the band, there are some notable exceptions. The set does not include the three

答案字符位置：[32, 41)。

</details>

## 第157题：ambigdocs_43069

**query：** When was St. Mary of the Assumption Church built?

**term：** St. Mary of the Assumption Church
**dimension：** Entity Disambiguation
**来源：** 旧第197题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| St. Mary of the Assumption Catholic Church, School and Grottoes | 1914 | 1914 |
| St. Mary of the Assumption Church and School | 1884 | 1884 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>St. Mary of the Assumption Catholic Church, School and Grottoes：完整供应证据</summary>

St. Mary of the Assumption Catholic Church, School and Grottoes The St. Mary of the Assumption Catholic Church, School and Grottoes of Dwight, Nebraska, located at 336 W. Pine St., is a historic complex dating to 1914. It includes Late Gothic Revival architecture. Also known as Assumption Catholic Church and denoted as BU06-001, the site was listed on the National Register of Historic Places in 2008. The listing included four contributing buildings and three contributing objects. The main part of the church, built in 1914, is about in dimension. It was designed by Omaha architect J.M. Nachtigal and built by

答案字符位置：[213, 217)。

</details>

<details>
<summary>St. Mary of the Assumption Church and School：完整供应证据</summary>

St. Mary of the Assumption Church and School The Saint Mary of the Assumption Church and School in Park City, Utah is the oldest extant Roman Catholic church in Utah. The present church was built in 1884 after a fire destroyed an earlier church during July 4 celebrations. The first church was built in 1881 to serve Park City's largely non-Mormon mining community, an anomaly in the Mormon-dominated state. The mining boom in the area around Park City brought miners, many of them Catholic, from all parts of the country. The church and school are located next to each other

答案字符位置：[199, 203)。

</details>

## 第158题：ambigdocs_45207

**query：** Who is the director of the film "Black Arrow"?

**term：** Black Arrow (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 旧第200题，retained

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Black Arrow (1985 film) | John Hough | John Hough |
| The Black Arrow (film) | Gordon Douglas | Gordon Douglas |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Black Arrow (1985 film)：完整供应证据</summary>

Black Arrow (1985 film) Black Arrow is a Disney made-for-television romantic adventure film filmed in 1984 and released in 1985, based on the novel by Robert Louis Stevenson, "". It was a Panatlantic Pictures release directed by John Hough, who had directed a filmatisation of another Stevenson novel, "Treasure Island", in 1972. It was released on 6 January 1985, for broadcast on The Disney Channel and distribution on Disney Home Video VHS. During the Wars of the Roses Sir Daniel is a powerful, unscrupulous knight, surrounded by equally treacherous retainers, Oates, Sykes, Appleyard, and Scar. Since the white rose of

答案字符位置：[229, 239)。

</details>

<details>
<summary>The Black Arrow (film)：完整供应证据</summary>

The Black Arrow (film) The Black Arrow is a 1948 American swashbuckler film. directed by Gordon Douglas and starring Louis Hayward, Janet Blair and Paul Cavanagh It is an adaptation of the 1888 novel " by Robert Louis Stevenson. A knight returns home after the War of the Roses and discovers his evil uncle has murdered his father. In 1947 Edward Small signed a contract with Columbia to make two films, "The Black Arrow" and "D'Artagnan, the Kingmaker", an adaptation of one of the sequels to "The Three Musketeers". Only the former was made but Small made a number of

答案字符位置：[89, 103)。

</details>

## 第159题：ambigdocs_1700

**query：** Who is the artist of the album "Feel Good"?

**term：** Feel Good
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Feel Good (Che'Nelle album) | Che'Nelle | Che'Nelle |
| Feel Good (The Internet album) | The Internet | The Internet |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Feel Good (Che'Nelle album)：完整供应证据</summary>

Feel Good (Che'Nelle album) Feel Good is the second studio album by Australian recording artist Che'Nelle. It was first released on 10 February 2010 by EMI Music Japan. It is a follow-up to her internationally released debut album "Things Happen for a Reason" (2007). The singer's manager Sir Charles Dixon served as the album's executive producer. "Feel Good" contains songs which were written by Che'Nelle herself and features production from Jason Gill, Toshinobu Kubota and The Insomniax. The album features collaborations with Jamaican artist Shaggy, the American signer Colby O'Donis and Japanese act Lecca. Two songs originally featured on her

答案字符位置：[11, 20)。

</details>

<details>
<summary>Feel Good (The Internet album)：完整供应证据</summary>

Feel Good (The Internet album) Feel Good is the second studio album by hip hop soul band, The Internet. After releasing a few tracks early on SoundCloud, the album was released on iTunes on September 24, 2013, and released physically four days later. "Feel Good" received generally positive reviews, much better than the reviews for their previous effort, "Purple Naked Ladies". Bruce Smith of HipHopDX gave the album a 4/5 rating, stating it "is an upgrade from the group's debut album, "Purple Naked Ladies" across the board, resulting in an album that needs to be heard." It also peaked at

答案字符位置：[11, 23)。

</details>

## 第160题：ambigdocs_43133

**query：** Who is the artist of the album "Civilian"?

**term：** Civilian (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Civilian (Gentle Giant album) | Gentle Giant | Gentle Giant |
| Civilian (Wye Oak album) | Wye Oak | Wye Oak |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Civilian (Gentle Giant album)：完整供应证据</summary>

Civilian (Gentle Giant album) Civilian is the eleventh and final studio album by British band Gentle Giant, released in 1980. It was recorded at Sound City Studios in the Van Nuys neighborhood of Los Angeles with former Beatles engineer Geoff Emerick. Consisting mostly of short rock songs, it is closer to a hard rock sound than the progressive style for which the band is best known. The album also marked a return to Columbia Records in the U.S. and Canada after an eight-year hiatus; the band's last album released with Columbia had been 1972's "Octopus". Soon after the album's release,

答案字符位置：[10, 22)。

</details>

<details>
<summary>Civilian (Wye Oak album)：完整供应证据</summary>

Civilian (Wye Oak album) Civilian is the third studio album by indie band Wye Oak. It was released on March 8, 2011 by Merge Records in the United States and City Slang in Europe. "The A.V. Club" named "Civilian" the best album of 2011. An edited version of the title track of "Civilian" was featured in the 2011 trailer for the second season of "The Walking Dead" and also the closing scene of the second season episode "18 Miles Out" (2012). "Civilian" was also featured in the final scene of the 13th episode of the North American remake of "Being

答案字符位置：[10, 17)。

</details>

## 第161题：ambigdocs_33554

**query：** Who is the director of the film "My Father the Hero"?

**term：** My Father the Hero
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| My Father the Hero (1991 film) | Gérard Lauzier | Gérard Lauzier |
| My Father the Hero (1994 film) | Steve Miner | Steve Miner |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>My Father the Hero (1991 film)：完整供应证据</summary>

My Father the Hero (1991 film) My Father the Hero (original French title: "Mon père, ce héros") is a 1991 French film directed by Gérard Lauzier. An English language remake of the movie was made in 1994 . The name of the film comes from a famous poem by the French poet Victor Hugo, ""Mon père, ce héros"," published in 1859. The story introduces André (Gérard Depardieu), a Frenchman who is divorced from his wife. He takes his beautiful teenage daughter, Véronique (Marie Gillain), on vacation to a paradise island with him. She is desperate to appear as a woman

答案字符位置：[130, 144)。

</details>

<details>
<summary>My Father the Hero (1994 film)：完整供应证据</summary>

My Father the Hero (1994 film) My Father the Hero is a 1994 French-American comedy-drama directed by Steve Miner and starring Gérard Depardieu and Katherine Heigl. It is an English-language remake of the 1991 French film "Mon père, ce héros," which also starred Depardieu. André Arnel (Gérard Depardieu), a Frenchman divorced from his wife, takes his teenage daughter, Nicole (Katherine Heigl), on vacation with him to The Bahamas. She is desperate to appear as a woman and not a girl, so in order to impress a local boy Ben (Dalton James), she makes up more and more ridiculous stories, starting

答案字符位置：[101, 112)。

</details>

## 第162题：ambigdocs_17854

**query：** Who is the artist of the album "A Matter of Time"?

**term：** A Matter of Time
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| A Matter of Time (Hilltop Hoods album) | Hilltop Hoods | Hilltop Hoods |
| A Matter of Time (Jason Sellers album) | Jason Sellers | Jason Sellers |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>A Matter of Time (Hilltop Hoods album)：完整供应证据</summary>

A Matter of Time (Hilltop Hoods album) A Matter of Time is the debut album by Australian hip hop group Hilltop Hoods, released in 1999. The promotion, manufacturing and marketing of the album was funded by a grant from the band's local government and resulted in the band once it became successful setting up its own grant scheme for South Australian hip hop musicians. The album is currently out of press, but is available as a free download from the Hilltop Hoods official site. The quote used in the song, "A Matter of Time", is taken from the 1994 movie

答案字符位置：[18, 31)。

</details>

<details>
<summary>A Matter of Time (Jason Sellers album)：完整供应证据</summary>

A Matter of Time (Jason Sellers album) A Matter of Time is the second and final album released by American country music artist Jason Sellers. Its title track was a Top 40 hit for him on the "Billboard" Hot Country Songs charts in 1999. One day after the album's release, Sellers exited BNA Records' roster. The track "That's Not Her Picture" was later recorded by John Michael Montgomery on his 2000 album "Brand New Me", while "Bad Case of Missing You" would later be recorded by The Oak Ridge Boys on their 2004 album "The Journey", from which it was

答案字符位置：[18, 31)。

</details>

## 第163题：ambigdocs_51860

**query：** Who is the director of the film "Angel Face"?

**term：** Angel Face
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Angel Face (1998 film) | Pablo Torre | Pablo Torre |
| Angel Face (2018 film) | Vanessa Filho | Vanessa Filho |
| Angel Face (1953 film) | Otto Preminger | Otto Preminger |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Angel Face (1998 film)：完整供应证据</summary>

Angel Face (1998 film) Angel Face () is a 1998 Argentine film, written and directed by Pablo Torre. The film features Virginia Innocenti, Mario Pasik, Enrique Pinti, among others. The director, Pablo Torre, dedicated the film to the approximately 30,000 people who "disappeared" during Argentina's military dictatorship between 1976 and 1983. The story takes place during the period of the ruling military "junta" in Argentina from the mid-seventies to the early eighties, focusing on one particular family. The story is told from the viewpoint of Nicolas, a young boy. By mistake the mother of the family is killed by right-wing

答案字符位置：[87, 98)。

</details>

<details>
<summary>Angel Face (2018 film)：完整供应证据</summary>

Angel Face (2018 film) Angel Face () is a 2018 French drama film directed by Vanessa Filho, from a screenplay by Filho and Diastéme, in her directorial debut. It stars Marion Cotillard, Ayline Aksoy-Etaix, Alban Lenoir, Amélie Daure and Stéphane Rideau. It had its world premiere at the 2018 Cannes Film Festival in May. It is scheduled to be released on 23 May 2018, by Mars Distribution. In September 2017, it was announced Marion Cotillard, Ayline Aksoy-Etaix, Alban Lenoir, Amélie Daure had joined the cast of the film, with Vanessa Filho directing from a screenplay she wrote alongside Diastéme. Carole

答案字符位置：[77, 90)。

</details>

<details>
<summary>Angel Face (1953 film)：完整供应证据</summary>

"The Hollywood Reporter", "Motion Picture Herald" and "Variety". Nowadays the film receives mostly positive reviews. Dave Kehr from the "Chicago Reader" writes: "This intense Freudian melodrama by Otto Preminger (1953) is one of the forgotten masterworks of film noir... The film is a disturbingly cool, rational investigation of the terrors of sexuality...The sets, characters, and actions are extremely stylized, yet Preminger's moving camera gives them a frightening unity and fluidity, tracing a straight, clean line to a cliff top for one of the most audacious endings in film history." Film critic Paul Brenner writes, "Preminger transforms a second rate James

答案字符位置：[197, 211)。

</details>

## 第164题：ambigdocs_27272

**query：** Who is the artist of the album "No Love Lost"?

**term：** No Love Lost
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| No Love Lost (Joe Budden album) | Joe Budden | Joe Budden |
| No Love Lost (The Rifles album) | The Rifles | The Rifles |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>No Love Lost (Joe Budden album)：完整供应证据</summary>

No Love Lost (Joe Budden album) No Love Lost is the sixth studio album by American rapper Joe Budden. The album was released on February 5, 2013, under E1 Music. The album features guest appearances from French Montana, Fabolous, Lil Wayne, Lloyd Banks, Juicy J, Slaughterhouse, Tank, Kirko Bangz, Wiz Khalifa, Twista, and Omarion among others. The album's release was supported by two singles: "She Don't Put It Down" featuring Lil Wayne and Tank, and "NBA" featuring Wiz Khalifa and French Montana. Budden has stated that the album is actually the final piece of the four album concept, which includes

答案字符位置：[14, 24)。

</details>

<details>
<summary>No Love Lost (The Rifles album)：完整供应证据</summary>

No Love Lost (The Rifles album) No Love Lost is the debut album by English indie rock band The Rifles, which was released on July 17, 2006. The album reached the #26 spot on the UK charts. The album spawned five singles: "Peace & Quiet", "When I'm Alone", "Local Boy", "Repeated Offender", and "She's Got Standards". In an interview, Joel Stoker explained how the name of track 7, "Robin Hood", got its title from the band's guitarist, Luke Crowther, and a trip on "Soccer AM": On June 1, 2015, "No Love Lost" was digitally remastered at Abbey Road Studios and

答案字符位置：[14, 24)。

</details>

## 第165题：ambigdocs_43029

**query：** Who is the artist of the album "Real Talk"?

**term：** Real Talk
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Real Talk (Fabolous album) | Fabolous | Fabolous |
| Real Talk (Man Overboard album) | Man Overboard | Man Overboard |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Real Talk (Fabolous album)：完整供应证据</summary>

Real Talk (Fabolous album) Real Talk is the third studio album by American rapper Fabolous. The album was released on November 9, 2004, by Desert Storm Records and Atlantic Records. It was received lukewarm from a critical standpoint, but was a commercial success. It peaked at #6 on the "Billboard" 200 with 179,000 copies sold in 1 week & had 2 charting singles. The 2 charting singles are "Breathe" which is produced by Just Blaze & "Baby" which is produced by Flame Throwers and contains guest vocals from Mike Shorey. Videos were created for the singles "Do the Damn Thing"

答案字符位置：[11, 19)。

</details>

<details>
<summary>Real Talk (Man Overboard album)：完整供应证据</summary>

Real Talk (Man Overboard album) Real Talk is the debut studio album by American rock band Man Overboard. Man Overboard was founded by vocalist/bassist Nik Bruzzese and lead guitarist Wayne Wildrick in 2008. The pair brought in vocalist/guitarist Zac Eisenstein, and the group went to work on what would be their first release, "Hung Up on Nothing". The band soon toured across the U.S. On November 5, 2009, it was announced they signed to Run for Cover. Following the release of a few more EPs, the band went to work on their debut album. "Real Talk" was released on July

答案字符位置：[11, 24)。

</details>

## 第166题：ambigdocs_13766

**query：** Who is the artist of the album "Swimming"?

**term：** Swimming (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Swimming (Mac Miller album) | Mac Miller | Mac Miller |
| Swimming (The Names album) | The Names | The Names |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Swimming (Mac Miller album)：完整供应证据</summary>

Swimming (Mac Miller album) Swimming is the fifth studio album by American rapper Mac Miller and the last album during his lifetime. It was released on August 3, 2018, by REMember Music and Warner Bros. Records. Production on the album was handled by Miller himself, as well as Dev Hynes, J. Cole, Dâm-Funk, DJ Dahi, Tae Beast, Flying Lotus and Cardo, among others. The album has no credited features, but contains vocal contributions from Dâm-Funk, Dev Hynes, Snoop Dogg, Syd, Thundercat and J.I.D. "Swimming" was supported by three singles: "Small Worlds", "Self Care" and "What's the Use?" The album received

答案字符位置：[10, 20)。

</details>

<details>
<summary>Swimming (The Names album)：完整供应证据</summary>

Swimming (The Names album) Swimming is the debut studio album by Belgian post-punk band the Names, released in 1982 by record label Les Disques du Crépuscule. It was produced by Martin Hannett. The album was released as an LP by Crépuscule in 1982. It was reissued by Factory Benelux in 1991 on CD as "Swimming + Singles", by LTM Recordings in 2000 on CD as "Swimming + Singles", and again by Factory Benelux in 2013 on LP and CD as "Swimming". AllMusic wrote: ""Swimming" isn't the sharpest arrow in infamous producer Martin Hannett's quiver, and the Belgian group indeed wallowed

答案字符位置：[10, 19)。

</details>

## 第167题：ambigdocs_38167

**query：** Who is the director of the film "Bedazzled"?

**term：** Bedazzled
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Bedazzled (1967 film) | Stanley Donen | Stanley Donen |
| Bedazzled (2000 film) | Harold Ramis | Harold Ramis |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Bedazzled (1967 film)：完整供应证据</summary>

Bedazzled (1967 film) Bedazzled is a 1967 British comedy DeLuxe Color film directed and produced by Stanley Donen in Panavision format. It was written by comedian Peter Cook and starred both Cook and his comedy partner Dudley Moore. It is a comic retelling of the Faust legend, set in the Swinging London of the 1960s. The Devil (Peter Cook) offers an unhappy young man (Moore) seven wishes in return for his soul, but twists the spirit of the wishes to frustrate the man's hopes. Stanley Moon (Moore) works as a cook in a Wimpy's restaurant and is infatuated with the

答案字符位置：[100, 113)。

</details>

<details>
<summary>Bedazzled (2000 film)：完整供应证据</summary>

Bedazzled (2000 film) Bedazzled is a 2000 black comedy film directed by Harold Ramis and starring Brendan Fraser and Elizabeth Hurley. It is a remake of the 1967 film of the same name, written by Peter Cook and Dudley Moore, which was itself a comic retelling of the Faust legend. The Devil runs a computer simulation to analyze souls to determine individual weaknesses to exploit. The program settles on Elliot Richards, a geeky, over-zealous man working a dead-end job in a San Francisco computer company. He has no friends and his co-workers avoid him. He has a crush on colleague

答案字符位置：[72, 84)。

</details>

## 第168题：ambigdocs_44657

**query：** Who is the artist of the album "By Request"?

**term：** By Request
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| By Request (Boyzone album) | Boyzone | Boyzone |
| By Request (George Jones album) | George Jones | George Jones |
| By Request (Perry Como album) | Perry Como | Perry Como |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>By Request (Boyzone album)：完整供应证据</summary>

By Request (Boyzone album) By Request is the first greatest hits album by Irish boy band Boyzone. It was released on 31 May 1999 by Universal. The album has sold over 4 million copies worldwide. The album contains all of the band's singles release since the start of their career in 1994, with the exception of the Irish-only single "Working My Way Back to You", the Japanese only-single "Believe in Me", the American-only single "Mystical Experience", which appears as a bonus track on the Australian release, "Te Garder Pres De Moi", which appears as a bonus track on the French

答案字符位置：[12, 19)。

</details>

<details>
<summary>By Request (George Jones album)：完整供应证据</summary>

By Request (George Jones album) By Request is an album by American country music artist George Jones released in 1984 on the Epic Records label. The album collects many of Jones's recent Epic hits (including three number ones) basically it is a "Greatest Hits of the 80s" album, ironically it doesn't concist of "He stopped loving her today" Jones's signature hit in 1980 and features several other country stars, including the Oak Ridge Boys and Merle Haggard. "By Request" also marks the first time that "We Didn't See A Thing" appeared on a Jones album, his top ten country hit

答案字符位置：[12, 24)。

</details>

<details>
<summary>By Request (Perry Como album)：完整供应证据</summary>

By Request (Perry Como album) By Request is Perry Como's Ninth RCA Victor 12" long-play album. The title made it sound like a number of his earlier LPs, again with the implication that the song choices were made by his audience rather than himself. But where previous records like "We Get Letters" and "Sing to Me Mr. C" consisted of old standards (in contrast to the new compositions that made up his single releases), "By Request" was, for the most part, a collection of recent material. In many cases, Como was borrowing songs associated with his competitors: Jack Jones had

答案字符位置：[12, 22)。

</details>

## 第169题：ambigdocs_7728

**query：** Who is the artist of the "Live in America" album?

**term：** Live in America
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Live in America (Jorn album) | Jørn Lande | Jørn Lande / Jorn |
| Live in America (Transatlantic album) | Transatlantic | Transatlantic |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Live in America (Jorn album)：完整供应证据</summary>

Live in America (Jorn album) Live in America! is the first live album by Jørn Lande. It was released under his stage name "Jorn" on September 24, 2007. Jorn's solo band's line-up is the same as in the last albums "The Duke" and "Unlocking the Past", with the exception of bassist Morty Black who was replaced by Pagan's Mind bassist Steinar Krokmo (who contributed to Jorn's solo records in the past). The album was recorded on the first show Jorn ever did in the US, on 16 September 2006 where he headlined the Progpower USA festival in Atlanta. The album

答案字符位置：[73, 83)。

</details>

<details>
<summary>Live in America (Transatlantic album)：完整供应证据</summary>

Live in America (Transatlantic album) Live in America is the first live album by the progressive rock supergroup Transatlantic. Released in 2001, it documents the United States tour in support of their album . Because the group had only released one studio album at the time, numerous cover songs are present on the album. The live album was recorded at the 930 Club in Washington D.C on June 24, 2000. The accompanying live video was recorded on June 21, 2000 at the Theater of the Living Arts, Philadelphia, Pennsylvania, which features some slight variations from the DC show featured on

答案字符位置：[17, 30)。

</details>

## 第170题：ambigdocs_52888

**query：** Who is the artist of the album "My Foolish Heart"?

**term：** My Foolish Heart
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| My Foolish Heart (Keith Jarrett album) | Keith Jarrett's "Standards Trio" | Keith Jarrett's "Standards Trio" |
| My Foolish Heart (Ralph Towner album) | Ralph Towner | Ralph Towner |
| My Foolish Heart (Don Friedman album) | Don Friedman | Don Friedman |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>My Foolish Heart (Keith Jarrett album)：完整供应证据</summary>

My Foolish Heart (Keith Jarrett album) My Foolish Heart is a double live album by American pianist Keith Jarrett's "Standards Trio" featuring Gary Peacock and Jack DeJohnette recorded in concert in July 2001 at the Montreux Jazz Festival in Switzerland and released on the ECM label in 2007. The Allmusic review by Thom Jurek awarded the album 4½ stars and states, "this document is a mindblower from start to finish, and there are moments when all you can do in response is look at the box slack-jawed and wonder if what you just heard really happened. It did and it

答案字符位置：[99, 131)。

</details>

<details>
<summary>My Foolish Heart (Ralph Towner album)：完整供应证据</summary>

My Foolish Heart (Ralph Towner album) My Foolish Heart is a solo album by American guitarist Ralph Towner recorded in 2017 and released on the ECM label. Towner had long wanted to record the jazz standard, "My Foolish Heart", stating in an interview with National Public Radio "It's one of the first tunes I'd heard that combination of Bill Evans, Scott LaFaro and Paul Motian play. So that tune had a lot of meaning for me and was very important for me starting out as a jazz musician." The composition "Blues As In Bley" is dedicated to the jazz pianist

答案字符位置：[18, 30)。

</details>

<details>
<summary>My Foolish Heart (Don Friedman album)：完整供应证据</summary>

My Foolish Heart (Don Friedman album) My Foolish Heart is an album by American jazz pianist Don Friedman recorded in 2000 and released on the Danish SteepleChase label in 2003. Chris Kelsey of Allmusic stated "while Friedman has in the past recorded with more fire, this is a well-executed and rewarding set by a musician who embraces (and exemplifies) the best jazz has to offer". On All About Jazz, Derek Taylor observed "Sweeping accolades and fame may not be in the cards for Friedman, but based on the strengths of this session the situation doesn’t seem to matter much. He’ll

答案字符位置：[18, 30)。

</details>

## 第171题：ambigdocs_13578

**query：** Who is the artist of the album "Easy Does It"?

**term：** Easy Does It
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Easy Does It (Al Kooper album) | Al Kooper | Al Kooper |
| Easy Does It (Jake Owen album) | Jake Owen | Jake Owen |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Easy Does It (Al Kooper album)：完整供应证据</summary>

Easy Does It (Al Kooper album) Easy Does It is the third solo album by American singer-songwriter Al Kooper, recorded and released in 1970 for Columbia Records. A double album, "Easy Does It" featured Kooper on an expanded number of instruments, including sitar (used to effect on the country-tinged "Sad, Sad Sunshine"), vibes and electronic effects. While mostly backed by Bretheren rhythm section Stu Woods and Rick Marotta, Kooper also utilized groups in Nashville and Los Angeles to record the tracks for the album. Two tracks were also featured on the soundtrack to the counter-culture film "The Landlord", "Brand New

答案字符位置：[14, 23)。

</details>

<details>
<summary>Easy Does It (Jake Owen album)：完整供应证据</summary>

Easy Does It (Jake Owen album) Easy Does It is the second studio album by American country music singer Jake Owen. It was released on February 24, 2009, by RCA Records Nashville. It includes the Top 10 hits "Don't Think I Can't Love You" and "Eight Second Ride." As with his first album, "Easy Does It" is produced by Jimmy Ritchey, with whom Owen co-wrote several of the songs. It has sold 120,000 copies as of November 2009. Owen co-wrote eight of the ten songs on the album. Among the co-writes are the lead-off single "Don't Think I Can't Love

答案字符位置：[14, 23)。

</details>

## 第172题：ambigdocs_28516

**query：** Who is the artist of the album "Up and Down"?

**term：** Up and Down
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Up and Down (Liane Carroll album) | Liane Carroll | Liane Carroll |
| Up and Down (Opus album) | Opus | Opus |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Up and Down (Liane Carroll album)：完整供应证据</summary>

Up and Down (Liane Carroll album) Up and Down is a studio album by English jazz pianist/vocalist Liane Carroll. Released in June 2011, and launched on 27 June at the Hideaway jazz club in Streatham, south London, it was the winner in the Jazz Album of the Year category at the 2012 Parliamentary Jazz Awards in May 2012. The album entered iTunes's jazz charts at no. 8 and reached the no.1 spot in its first week of release. It received a four-starred review in "The Guardian" and a 4.5-starred review from "All About Jazz". Recorded in London, Hastings, Brighton, Prague

答案字符位置：[13, 26)。

</details>

<details>
<summary>Up and Down (Opus album)：完整供应证据</summary>

Up and Down (Opus album) Up and Down is the fourth studio album by Austrian pop rock band Opus. It was released in 1984 by the label OK Musica in Austria and the rest of the world by the label Polydor. The tracks released by Polydor are different from the original version. In Canada and United States, the song "Live is Life" was included, because the live album "Live Is Life" wasn't released in these countries. The single "Up and Down" charted at #65 on the Canadian music chart. The track "She Loves You" was sampled by rapper Big Pooh,

答案字符位置：[13, 17)。

</details>

## 第173题：ambigdocs_53540

**query：** Who is the artist of the album "Greatest Hits: From the Beginning"?

**term：** Greatest Hits: From the Beginning
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Greatest Hits: From the Beginning (The Miracles album) | The Miracles | The Miracles |
| Greatest Hits: From the Beginning (Travis Tritt album) | Travis Tritt | Travis Tritt |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Greatest Hits: From the Beginning (The Miracles album)：完整供应证据</summary>

Greatest Hits: From the Beginning (The Miracles album) Greatest Hits from the Beginning is a compilation double LP by The Miracles released in 1965. This was the first double album ever released by the Motown Record Corporation (Tamla TS2-254). It covers most of the group's hits from their pre-1965 albums, such as "Shop Around", "Who's Lovin’ You", "You've Really Got A Hold On Me" and "Mickey's Monkey", as well as the non-album singles from 1964: "I Like It Like That" and "That's What Love Is Made Of" (with its B-side ballad "Would I Love You"). The album was a success,

答案字符位置：[35, 47)。

</details>

<details>
<summary>Greatest Hits: From the Beginning (Travis Tritt album)：完整供应证据</summary>

Greatest Hits: From the Beginning (Travis Tritt album) Greatest Hits: From the Beginning is the title of the first greatest hits compilation issued by American country music singer Travis Tritt. Released in 1995 on Warner Bros. Records, the album features fifteen tracks from Tritt's first four studio albums "Country Club" (1990), "It's All About to Change" (1991), "T-R-O-U-B-L-E" (1992), and "Ten Feet Tall and Bulletproof" (1994). Two songs were newly recorded for this album as well: the Steve Earle-penned "Sometimes She Forgets", and a rendition of the pop standard "Only You (And You Alone)". The former was released as a

答案字符位置：[35, 47)。

</details>

## 第174题：ambigdocs_3732

**query：** Who is the artist of the album "Horse of a Different Color"?

**term：** Horse of a Different Color
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Horse of a Different Color (Big & Rich album) | Big & Rich | Big & Rich |
| Horse of a Different Color (Willy DeVille album) | Willy DeVille | Willy DeVille |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Horse of a Different Color (Big & Rich album)：完整供应证据</summary>

Horse of a Different Color (Big & Rich album) Horse of a Different Color is the debut studio album by the American country music duo Big & Rich. It was released in 2004 on Warner Bros. Records and it contains the hit singles "Wild West Show", "Save a Horse (Ride a Cowboy)", "Holy Water", and "Big Time". Respectively, these reached No. 21, No. 11, No. 15, and No. 20 on the "Billboard" Hot Country Songs charts. The album was certified 3× Platinum by the RIAA for shipments of three million copies. "Horse of a Different Color" features several guest musicians,

答案字符位置：[28, 38)。

</details>

<details>
<summary>Horse of a Different Color (Willy DeVille album)：完整供应证据</summary>

Horse of a Different Color (Willy DeVille album) Horse of a Different Color is a 1999 album by Willy DeVille. The album consists of original compositions and remakes of traditional Black music titles such as Fred McDowell's “Going over the Hill,” and Andre Williams' "Bacon Fat." The album was recorded at Ardent Studios in Memphis. It was produced by Jim Dickinson, who brought along his son Luther to play guitar and his son Cody to play drums. Allmusic called the album "the most consistent and brilliant recording of Willy DeVille's long career": DeVille recorded another version of “Across the Borderline“

答案字符位置：[28, 41)。

</details>

## 第175题：ambigdocs_59166

**query：** Who is the artist of "The Illusion of Safety"?

**term：** The Illusion of Safety
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| The Illusion of Safety (The Hoosiers album) | The Hoosiers | The Hoosiers |
| The Illusion of Safety (Thrice album) | Thrice | Thrice |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>The Illusion of Safety (The Hoosiers album)：完整供应证据</summary>

The Illusion of Safety (The Hoosiers album) The Illusion of Safety is the second album released by the London based indie pop band The Hoosiers. It was released in the UK on 16 August 2010 and was preceded by the lead single, "Choices" which was released on 1 August 2010. The second single taken from the album was originally expected to be "Unlikely Hero", but Irwin has stated on the Hoosiers' Twitter feed that this plan has been changed, and stated that the band "will let you know what soon." The album was not as successful as the band's first

答案字符位置：[24, 36)。

</details>

<details>
<summary>The Illusion of Safety (Thrice album)：完整供应证据</summary>

The Illusion of Safety (Thrice album) The Illusion of Safety is the second album by American rock band Thrice. The album was recorded in Beltsville, Maryland. It was released in February 2002 through Sub City Records. A portion of the proceeds from the release of the album were donated to "A Place Called Home", a non-profit youth center in South Central Los Angeles. In February and March, the group went on tour with Anti-Flag and Against All Authority. In late March, the group performed a few shows with Further Seems Forever, Hot Rod Circuit and Recover. In April and May,

答案字符位置：[24, 30)。

</details>

## 第176题：ambigdocs_29587

**query：** Who directed the film "Adoration"?

**term：** Adoration (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Adoration (1928 film) | Frank Lloyd | Frank Lloyd |
| Adoration (2008 film) | Atom Egoyan | Atom Egoyan |
| Adoration (2013 film) | Anne Fontaine | Anne Fontaine |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Adoration (1928 film)：完整供应证据</summary>

Adoration (1928 film) Adoration is a 1928 American synchronized sound drama film with a Vitaphone musical score and sound effects. The film was released by First National Pictures, a subsidiary of Warner Bros., and directed by Frank Lloyd. It stars Billie Dove, Antonio Moreno, Emile Chautard and Lucy Doraine. The film was also issued in a shorter silent version for theatres that were not yet wired for sound. Russian prince (Antonio Moreno), upon returning from the front, sees his wife (Billie Dove) in the company of a blackguard count. Prince becomes jealous, and, later, while attempting to break into the

答案字符位置：[227, 238)。

</details>

<details>
<summary>Adoration (2008 film)：完整供应证据</summary>

Adoration (2008 film) Adoration is a 2008 Canadian drama film directed by Atom Egoyan and starring Rachel Blanchard, Scott Speedman and Devon Bostick. It is Egoyan's first feature film since "Where the Truth Lies". The film was first shown at the 2008 Cannes Film Festival. "Adoration" won the Prize of the Ecumenical Jury and was nominated for the Palme d'Or. It won "Best Canadian Feature Film – Special Jury Citation" at the 2008 Toronto International Film Festival. The film had its U.S. premiere in April 2009 at the San Francisco International Film Festival and went into U.S. release on May

答案字符位置：[74, 85)。

</details>

<details>
<summary>Adoration (2013 film)：完整供应证据</summary>

also shot in Sydney. Adoration (2013 film) Adoration, titled Adore in North America and the UK, is a 2013 Australian-French drama film directed by Anne Fontaine. The film is based on a novella by British writer Doris Lessing called "". The film premiered at the 2013 Sundance Film Festival under its original title Two Mothers. In New South Wales, childhood friends Roz and Lil and their families live next door to each other. Roz's son Tom and Lil's son Ian, who are both 18, are also best friends, and the four of them spend all their time together. Roz’s husband

答案字符位置：[147, 160)。

</details>

## 第177题：ambigdocs_50956

**query：** Who is the artist of the album "Just as I Am"?

**term：** Just as I Am
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Just as I Am (Brantley Gilbert album) | Brantley Gilbert | Brantley Gilbert |
| Just as I Am (Guy Sebastian album) | Guy Sebastian | Guy Sebastian |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Just as I Am (Brantley Gilbert album)：完整供应证据</summary>

Just as I Am (Brantley Gilbert album) Just as I Am is the third studio album by American country rock singer Brantley Gilbert. It was released on May 19, 2014 via Valory Music Group. The album includes the number one singles "Bottoms Up" and "One Hell of an Amen". Gilbert wrote or co-wrote all 11 tracks. "Just as I Am" met with generally positive reception from music critics. At AllMusic, Stephen Thomas Erlewine rated the album four stars out of five, writing that Gilbert is "an outlaw with no desire to rebel, an insider who doesn't belong, so his music

答案字符位置：[14, 30)。

</details>

<details>
<summary>Just as I Am (Guy Sebastian album)：完整供应证据</summary>

Just as I Am (Guy Sebastian album) Just as I Am is the debut album by the first "Australian Idol" winner Guy Sebastian. Given the relative popularity of "Australian Idol" in late 2003, BMG Australia subsequently contracted Sebastian for a record before Christmas 2003. He wanted to record a mixture of pop and R&B material. Guy Sebastian co-wrote three of the songs on the album "All I Need Is You", "I 4 U" and "Something Don't Feel Right". He says on his web page: "I think the credibility in having your own stuff makes you as an artist. Credibility is

答案字符位置：[14, 27)。

</details>

## 第178题：ambigdocs_56977

**query：** Who is the artist of the album "Round 2"?

**term：** Round 2
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Round 2 (J. Holiday album) | J. Holiday | J. Holiday |
| Round 2 (The Stylistics album) | The Stylistics | The Stylistics |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Round 2 (J. Holiday album)：完整供应证据</summary>

Round 2 (J. Holiday album) Round 2 is the second studio album by American recording artist J. Holiday, it was released on March 10, 2009, by Music Line Group and Capitol Records. It is the follow-up to his debut album, "Back of My Lac'", which was released in 2007. This record would later be his final studio release with Capitol. The album was supported by the lone single, "It's Yours", which achieved moderate chart success. Upon release, "Round 2" received critical acclaim from music critics, who complimented its production and songwriting. The first single "It's Yours", was released on December

答案字符位置：[9, 19)。

</details>

<details>
<summary>Round 2 (The Stylistics album)：完整供应证据</summary>

Round 2 (The Stylistics album) Round 2 is the second studio album recorded by American R&B group The Stylistics, released in October 1972 on the Avco label. It was produced by Thom Bell and recorded at Sigma Sound Studios in Philadelphia. The album reached #32 on the "Billboard" 200 and #3 on the R&B albums chart. It features the hit singles "Break Up to Make Up", "I'm Stone in Love with You", and "You'll Never Get to Heaven (If You Break My Heart)". All three singles reached the top-ten on the R&B charts. "Break Up to Make Up" and "I'm

答案字符位置：[9, 23)。

</details>

## 第179题：ambigdocs_43247

**query：** Who is the artist of the album "Christmas in My Heart"?

**term：** Christmas in My Heart
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Christmas in My Heart (Connie Francis album) | Connie Francis | Connie Francis |
| Christmas in My Heart (Sarah Connor album) | Sarah Connor | Sarah Connor |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Christmas in My Heart (Connie Francis album)：完整供应证据</summary>

Christmas in My Heart (Connie Francis album) Christmas in My Heart is a studio album of Christmas music recorded by Connie Francis. The album features popular songs of the season on the A-side and the sacred music of Christmas on the B-side. It was re-released as Connie's Christmas in 1966. "Christmas in My Heart" was recorded in August 1959 at EMI's famous Abbey Road Studios in London under the musical direction of Geoff Love and was released in November 1959. The album was repackaged with a new cover design and re-released in October 1962. Another repackaging and re-release followed in

答案字符位置：[23, 37)。

</details>

<details>
<summary>Christmas in My Heart (Sarah Connor album)：完整供应证据</summary>

Christmas in My Heart (Sarah Connor album) Christmas in My Heart is the first Christmas album and the fifth studio album by German recording artist Sarah Connor. Released by X-Cell Records on , the album features cover versions of popular Christmas tunes and original material. Connor worked with frequent collaborators Rob Tyger and Kay Denar on the album. "Christmas in My Heart" peaked at number six on the Austrian, German, and Swiss Albums Chart. In 2006 after a baby break Sarah decided to reissue "Christmas in my heart" with a new lead single "Best side of life". "The Best side

答案字符位置：[23, 35)。

</details>

## 第180题：ambigdocs_54820

**query：** Who is the artist of the album "Beatin' the Odds"?

**term：** Beatin' the Odds
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Beatin' the Odds (Eddie Rabbitt album) | Eddie Rabbitt | Eddie Rabbitt |
| Beatin' the Odds (Molly Hatchet album) | Molly Hatchet | Molly Hatchet |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Beatin' the Odds (Eddie Rabbitt album)：完整供应证据</summary>

Beatin' the Odds (Eddie Rabbitt album) Beatin' the Odds is the fourteenth studio album by country artist Eddie Rabbitt, released in 1997 by Intersound Records. The album was recorded by Rabbitt after undergoing chemotherapy and having had a part of his lung removed to combat cancer. It was released eight months before his death. It included six new songs and six re-recordings of past hits including "I Love a Rainy Night" and "Drivin' My Life Away" from "Horizon", "On Second Thought" and "American Boy" from "Jersey Boy", "Two Dollars in the Jukebox" from "Rocky Mountain Music" and "Suspicions" from "Loveline".

答案字符位置：[18, 31)。

</details>

<details>
<summary>Beatin' the Odds (Molly Hatchet album)：完整供应证据</summary>

Beatin' the Odds (Molly Hatchet album) Beatin' the Odds is the third studio album by American southern rock band Molly Hatchet, released in 1980. This is the first album with new vocalist Jimmy Farrar, who replaced Danny Joe Brown. A remastered edition of the album was issued in 2008 by Rock Candy Records, with four live bonus tracks and extensive liner notes. The remastering was directed by famous British producer Jon Astley. The album was also reissued under the SPV/Steamhammer label in 2013 and only included the original tracks. The cover art for the album was "Conan the Conqueror" by

答案字符位置：[18, 31)。

</details>

## 第181题：ambigdocs_51344

**query：** When was Deyo born?

**term：** Senator Deyo
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Abraham A. Deyo | June 25, 1793 | June 25, 1793 / 25 June 1793 / June 25 1793 / 1793-06-25 |
| Martin W. Deyo | December 12, 1902 | December 12, 1902 / 12 December 1902 / December 12 1902 / 1902-12-12 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Abraham A. Deyo：完整供应证据</summary>

Abraham A. Deyo Abraham A. Deyo (June 25, 1793 – March 20, 1873) was an American politician from New York. He was the son of Capt. Abraham Deyo (1736–1805) and Maria (née LeFevre, widowed LeFevre) Deyo (1756–1793). On June 10, 1812, he married Margaret T. Deyo, and they had four children, among them Abraham A. Deyo (1819–1883) who was Sheriff of Ulster County. He lived in Modena, New York. He was an associate judge of the Ulster County Court. He was for many years Supervisor of the Town of Plattekill. He was a member of the New York State Senate

答案字符位置：[33, 46)。

</details>

<details>
<summary>Martin W. Deyo：完整供应证据</summary>

Martin W. Deyo Martin Weld Deyo (December 12, 1902 – October 20, 1951) was an American lawyer and politician from New York. He was born on December 12, 1902, in Binghamton, Broome County, New York, the son of Assemblyman Israel T. Deyo (1854–1953) and Edith Austin (Weld) Deyo (1863–1944). He attended Binghamton Central High School, and graduated from Amherst College in 1925. In 1928, he married Amy G. Sleeper (1902–1975). He graduated from Columbia Law School, was admitted to the bar in 1931, and practiced in Binghamton. Deyo was a member of the New York State Assembly (Broome Co., 2nd

答案字符位置：[33, 50)。

</details>

## 第182题：ambigdocs_57863

**query：** When was Edmund King born?

**term：** Edmund King
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Edmund King (cricketer, born 1906) | 26 March 1906 | 26 March 1906 / March 26, 1906 / March 26 1906 / 1906-03-26 |
| Edmund King (cricketer, born 1907) | 21 January 1907 | 21 January 1907 / January 21, 1907 / January 21 1907 / 1907-01-21 |
| Edmund King (physician) | c.1630 | c.1630 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Edmund King (cricketer, born 1906)：完整供应证据</summary>

Edmund King (cricketer, born 1906) Edmund Hugh King (26 March 1906 – 25 November 1981) was an English cricketer. King was a right-handed batsman who bowled off break. He was born at Birmingham, Warwickshire, and was educated at Ampleforth College. King made his first-class debut for Warwickshire against Sussex in the 1928 County Championship. He made six further first-class appearances for the county, the last of which came against Glamorgan in the 1932 County Championship. In his total of seven first-class matches, he scored 84 runs at an average of 8.40, with a high score of 24. King worked as

答案字符位置：[53, 66)。

</details>

<details>
<summary>Edmund King (cricketer, born 1907)：完整供应证据</summary>

Edmund King (cricketer, born 1907) Edmund Poole King (21 January 1907 – 11 September 1990) was an English cricketer. King was a right-handed batsman. He was born at Clifton, Bristol, and was educated at Winchester College, where he represented the college cricket team. King made his first-class debut for Gloucestershire against Glamorgan in the 1927 County Championship. He made 2 further first-class appearances, both in 1927, against Kent and Sussex. His 3 first-class matches were without success, with him scoring 14 runs at an average of 3.50, with a high score of 6. He died at Bampton, Devon, on 11

答案字符位置：[54, 69)。

</details>

<details>
<summary>Edmund King (physician)：完整供应证据</summary>

Edmund King (physician) Sir Edmund King (c.1630–1709), also Edmund Freeman, Edmond King, was an English surgeon and physician. He is known as an experimentalist, and also for his attendance on Charles II of England. He was the eldest son of Edmond King (Kinge, Freeman) of Northampton, a surgeon and physician, baptised in 1630. He practised, after apprenticeship, as a surgeon in London. He lived at first in Little Britain, London, and had a museum in his house which he took pleasure in showing to students. He used to keep dried specimens, such as the ileocecal valve, pressed in a large

答案字符位置：[41, 47)。

</details>

## 第183题：ambigdocs_46924

**query：** When was William O'Neil born?

**term：** William O'Neil (disambiguation)
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| William O'Neil (Wisconsin politician) | September 20, 1848 | September 20, 1848 / 20 September 1848 / September 20 1848 / 1848-09-20 |
| William T. O'Neil | February 7, 1850 | February 7, 1850 / 7 February 1850 / February 7 1850 / 1850-02-07 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>William O'Neil (Wisconsin politician)：完整供应证据</summary>

William O'Neil (Wisconsin politician) William O'Neil (1848–1917) was a member of the Wisconsin Legislature. O'Neil was born in the town of Scott, Columbia County, Wisconsin on September 20, 1848. In the fall of 1861 he enlisted in the 13th U.S. Infantry, in which he served until March 1862, when he was discharged for disability. In June 1862, he enlisted in the 20th Wisconsin Volunteer Infantry Regiment, and served until the end of Civil War, participating in all engagements in which that regiment took part. From 1865 to 1872 he traveled throughout the country, finally settling at Chippewa Falls, Wisconsin. In

答案字符位置：[176, 194)。

</details>

<details>
<summary>William T. O'Neil：完整供应证据</summary>

William T. O'Neil William Thomas O'Neil (February 7, 1850, in Brighton, Franklin County, New York – May 5, 1909, in St. Regis Falls, New York) was an American politician from New York. He attended the common schools and Fort Edward Collegiate Institute. Then he engaged in the lumber business and farming. He lived in St. Regis Falls, a hamlet in the town of Waverly. O'Neil was Supervisor of the town of Waverly in 1881; and a member of the New York State Assembly (Franklin Co.) in 1882, 1883, 1884 and 1885. He was a member of the New York State

答案字符位置：[41, 57)。

</details>

## 第184题：ambigdocs_16746

**query：** When was Frank Sharp born?

**term：** Frank Sharp
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Frank Sharp (footballer, born 1899) | 26 April 1899 | 26 April 1899 / April 26, 1899 / April 26 1899 / 1899-04-26 |
| Frank Sharp (footballer, born 1947) | 28 May 1947 | 28 May 1947 / May 28, 1947 / May 28 1947 / 1947-05-28 |
| Frank Chapman Sharp | July 30, 1866 | July 30, 1866 / 30 July 1866 / July 30 1866 / 1866-07-30 |
| Frank Sharp (land developer) | 18 March 1906 | 18 March 1906 / March 18, 1906 / March 18 1906 / 1906-03-18 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Frank Sharp (footballer, born 1899)：完整供应证据</summary>

Frank Sharp (footballer, born 1899) Frank William Sharp (26 April 1899 – 15 March 1963) was an English professional footballer who played in the Football League for Birmingham and Chesterfield. He played as an inside forward. Sharp was born in Tintwistle, which was then part of Cheshire. He worked in a steelworks and played football part-time for Barton BSC and for Mossley before turning professional with Birmingham in 1922. He made his debut in the First Division on 6 September 1922, deputising for Jackie Whitehouse in an away game against Newcastle United which finished goalless. He kept his place until

答案字符位置：[57, 70)。

</details>

<details>
<summary>Frank Sharp (footballer, born 1947)：完整供应证据</summary>

Frank Sharp (footballer, born 1947) Frank Sharp (born 28 May 1947) is a Scottish former footballer who scored 13 goals in 231 league games in a ten-year career in the Football League and Scottish Football League. A Winger, he played for Heart of Midlothian, Carlisle United, Cardiff City, Barnsley, Grimsby Town, Port Vale, and Northwich Victoria. Sharp began his career at junior side Tynecastle Athletic before turning professional with Tommy Walker's Heart of Midlothian. Hearts finished seventh and 11th in the First Division in 1965–66 and 1966–67. He appeared in just six league games at Tynecastle, scoring one goal. In

答案字符位置：[54, 65)。

</details>

<details>
<summary>Frank Chapman Sharp：完整供应证据</summary>

Frank Chapman Sharp Frank Chapman Sharp (July 30, 1866 – May 4, 1943) was an American philosopher who specialized in ethics, including business ethics and the ethical conduct of war. He received his BA from Amherst College in 1887 and his Ph.D. at the Konigliche-Friedrich-Wilhelms University of Berlin in 1892. His thesis, "The Aesthetic Element in Morality and Its Place in a Utilitararian Theory of Morals", was published in book form in both English and German in 1893. His entire teaching career was spent on the philosophy faculty at the University of Wisconsin, where he was made a full professor

答案字符位置：[41, 54)。

</details>

<details>
<summary>Frank Sharp (land developer)：完整供应证据</summary>

Frank Sharp (land developer) Frank Wesley Sharp (18 March 1906 – 2 April 1993) was a land developer in Houston, Texas, United States who was responsible for creating several large post-World War II housing developments. Sharp's largest projects included "Oak Forest" in 1946 and "Sharpstown" in 1955. Sharp also created "Royden Oaks" in the early 1970s. Sharp later was a central figure in the Sharpstown scandal, and as a result he was convicted of violating federal banking and securities laws and was sentenced to three years' probation and a $5,000 fine. Frank W. Sharp, usually known as simply Frank Sharp,

答案字符位置：[49, 62)。

</details>

## 第185题：ambigdocs_8403

**query：** When was Stuart Elliott born?

**term：** Stuart Elliott
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Stuart Elliott (footballer, born 1977) | 27 August 1977 | 27 August 1977 / August 27, 1977 / August 27 1977 / 1977-08-27 |
| Stuart Elliott (footballer, born 1978) | 23 July 1978 | 23 July 1978 / July 23, 1978 / July 23 1978 / 1978-07-23 |
| Stuart Elliott (drummer) | 22 May 1953 | 22 May 1953 / May 22, 1953 / May 22 1953 / 1953-05-22 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Stuart Elliott (footballer, born 1977)：完整供应证据</summary>

Stuart Elliott (footballer, born 1977) Stuart Thomas Elliott (born 27 August 1977) is an English semi-professional footballer who plays as a midfielder for Northern League Division One club Ashington. Elliott started his career as a schoolboy at Arsenal, and after being released by the club he signed an apprenticeship with Newcastle United in 1995. He spent five years with the club, during which time he was loaned out seven times. He never made a first-team appearance for Newcastle, but appeared on the substitutes' bench on six occasions and eventually became captain of the reserve team. He left the club in

答案字符位置：[67, 81)。

</details>

<details>
<summary>Stuart Elliott (footballer, born 1978)：完整供应证据</summary>

Stuart Elliott (footballer, born 1978) Stuart Elliott (born 23 July 1978) is a Northern Irish former professional footballer who played as a midfielder from 1998 to 2013. Elliott notbaly made a name for himself whilst with Motherwell and Hull City as well as being capped 38 times by Northern Ireland. He also played professionally for Glentoran, Doncaster Rovers, Grimsby Town, Hamilton Academical and Stirling Albion. He had initially retired in 2010 but came out of retirement to return to Glentoran for the 2012–13 season. Born in Belfast, Elliott started his career at St Andrews FC, from Belfast, then moved on

答案字符位置：[60, 72)。

</details>

<details>
<summary>Stuart Elliott (drummer)：完整供应证据</summary>

Stuart Elliott (drummer) Stuart Elliott (born Stuart Alexander Elliott, 22 May 1953, London, England) is an English drummer, composer and producer. He was the original drummer for Steve Harley and Cockney Rebel and during his time with this band he became a session drummer playing for top artists such as Kate Bush, Al Stewart, The Alan Parsons Project, Roger Daltrey, Paul McCartney, Claudio Baglioni among others. Elliott started to be interested in playing drums at the age of three by watching his father who was a jazz drummer. "Until I was fifteen, I was educated at St. Michael's School, Belgravia.

答案字符位置：[72, 83)。

</details>

## 第186题：ambigdocs_41190

**query：** When was Phil Parkes born?

**term：** Phil Parkes
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Phil Parkes (footballer, born 1947) | 14 July 1947 | 14 July 1947 / July 14, 1947 / July 14 1947 / 1947-07-14 |
| Phil Parkes (footballer, born 1950) | 8 August 1950 | 8 August 1950 / August 8, 1950 / August 8 1950 / 1950-08-08 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Phil Parkes (footballer, born 1947)：完整供应证据</summary>

Phil Parkes (footballer, born 1947) Phil Parkes (born 14 July 1947 in West Bromwich) is an English former professional football goalkeeper. He was Wolverhampton Wanderers' first-choice keeper for much of the late 1960s and early 1970s. Nicknamed "Lofty" for his booming kicks upfield, Parkes joined Wolves in 1962 straight from school and turned professional two years later. After several years in the reserve league, he made his first-team debut on 19 November 1966, saving a penalty in a 3-2 win over Preston North End. For the following nine seasons, Parkes missed few Wolves games and — over the 1971–72 and

答案字符位置：[54, 66)。

</details>

<details>
<summary>Phil Parkes (footballer, born 1950)：完整供应证据</summary>

Phil Parkes (footballer, born 1950) Philip Benjamin Neil Frederick Parkes (born 8 August 1950, Sedgley, Staffordshire, England) is a former football goalkeeper. He was a pupil at Dormston School from September 1961 to December 1965. Beginning his football career at Walsall, turning professional in 1968, he made over 50 appearances in the Black Country before moving to London, signing for Queens Park Rangers for £15,000 in June 1970. His QPR debut was on Saturday 22 August 1970 in a 3–1 defeat at home to Leicester City. Parkes was part of the QPR team that reached the last eight of the

答案字符位置：[80, 93)。

</details>

## 第187题：ambigdocs_559

**query：** When was Philip Whitcombe born?

**term：** Philip Whitcombe
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Philip Arthur Whitcombe | 23 April 1923 | 23 April 1923 / April 23, 1923 / April 23 1923 / 1923-04-23 |
| Philip John Whitcombe | 11 November 1928 | 11 November 1928 / November 11, 1928 / November 11 1928 / 1928-11-11 |
| Philip Sidney Whitcombe | 3 October 1893 | 3 October 1893 / October 3, 1893 / October 3 1893 / 1893-10-03 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Philip Arthur Whitcombe：完整供应证据</summary>

Philip Arthur Whitcombe Philip Arthur Whitcombe (23 April 1923 – 11 August 2015) was a first-class cricketer who played in England from 1947 to 1960. He was educated at Winchester, where he was a contemporary of Hubert Doggart, a future England cricketer. During the war he served with the Royal Horse Artillery before going up to Christ Church, Oxford. He played in the Oxford University team from 1947 to 1949 and won a Blue three years running. He worked for P&O as a shipping agent, while working in India, when he met his wife-to-be, Rosemary, daughter of Lord Clydesmuir, the

答案字符位置：[49, 62)。

</details>

<details>
<summary>Philip John Whitcombe：完整供应证据</summary>

Philip John Whitcombe Philip John Whitcombe (born 11 November 1928) is a former English first-class cricketer who played 34 matches between 1949 and 1953. 26 of these were for Oxford University, and eight for Worcestershire. He was a wicket-keeper, though he did play in some games as a batsman only. Whitcombe made his first-class debut for Worcestershire against Cambridge University at Worcester in June 1949. In a drawn game, he held three catches and scored 4 and 8*. The following season, he appeared seven times for Oxford and claimed 11 dismissals, as well as scoring three half-centuries, the highest of

答案字符位置：[50, 66)。

</details>

<details>
<summary>Philip Sidney Whitcombe：完整供应证据</summary>

which he served as Deputy Assistant of Supplies and Transport with the BEF, Whitcombe was Assistant Adjutant and QMG in Gibraltar 1940–1941 and Brigadier i/c Administration 1941–1942. Deputy Adjutant and QMG with British troops in Northern Ireland 1942–1943, he was Major General i/c Administration Eastern Commabnd 1943–1947 Appointed CB in 1944 and retired from the army in 1947, Whitcombe, a member of the MCC, was a JP in Wiltshire from 1948." Philip Sidney Whitcombe Major General Philip Sidney Whitcombe (3 October 1893 – 9 August 1989) was an English cricketer active from 1922 to 1931 who played for Essex and

答案字符位置：[511, 525)。

</details>

## 第188题：ambigdocs_21789

**query：** When was Carpentier born?

**term：** Senator Carpentier
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Charles F. Carpentier | September 19, 1896 | September 19, 1896 / 19 September 1896 / September 19 1896 / 1896-09-19 |
| Donald D. Carpentier | January 21, 1931 | January 21, 1931 / 21 January 1931 / January 21 1931 / 1931-01-21 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Charles F. Carpentier：完整供应证据</summary>

Charles F. Carpentier Charles Francis Carpentier (September 19, 1896 – April 3, 1964) was an American businessman and politician. Born in Moline, Illinois on September 19, 1896. Carpentier served in the United States Army during World War I. He went to St. Ambrose University. With his brother, he owned and operated movie and drive-in theatres in the Quad Cities area. In 1924, Carpentier was elected to the East Moline, Illinois city council and then in 1929 was elected mayor of East Moline, Illinois. In 1938, Carpentier was elected to the Illinois State Senate as a Republican. Then, in 1952, Carpentier

答案字符位置：[50, 68)。

</details>

<details>
<summary>Donald D. Carpentier：完整供应证据</summary>

Donald D. Carpentier Donald Dee Carpentier (January 21, 1931 – October 19, 1982) was an American businessman and politician. He was born on January 21, 1931 in Moline, Illinois. Carpentier went to the Moline public and parochial schools. He then went to St. Ambrose University. Carpentier owned a drive-in theatre and a laundromat. He was also in the insurance business. Carpentier served in the Illinois Senate from 1963 to 1973 and was a Republican. His father Charles F. Carpentier also served in the Illinois General Assembly and served as Illinois Secretary of State. Carpentier was convicted in the United States

答案字符位置：[44, 60)。

</details>

## 第189题：ambigdocs_47514

**query：** When was Admiral Bruce born?

**term：** Admiral Bruce
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Henry Bruce (Royal Navy officer) | 8 May 1862 | 8 May 1862 / May 8, 1862 / May 8 1862 / 1862-05-08 |
| Henry Bruce (Royal Navy officer, born 1792) | 2 February 1792 | 2 February 1792 / February 2, 1792 / February 2 1792 / 1792-02-02 |
| James Andrew Thomas Bruce | 15 July 1846 | 15 July 1846 / July 15, 1846 / July 15 1846 / 1846-07-15 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Henry Bruce (Royal Navy officer)：完整供应证据</summary>

Henry Bruce (Royal Navy officer) Admiral Sir Henry Harvey Bruce KCB MVO (8 May 1862 – 14 September 1948) was a British Royal Navy officer. Bruce was born in Stoke Damerel, Devonport, Devon, the son of Commander Sir Thomas Bruce, who later became Superintendent of Packets at Dover. He followed his father into the Navy as a Cadet at HMS "Britannia" in 1875. His first sea service was in HMS "Black Prince", flagship of the Channel Squadron and the second ironclad battleship in the Royal Navy. He then joined the frigate HMS "Raleigh" in the Mediterranean as a Midshipman, followed

答案字符位置：[73, 83)。

</details>

<details>
<summary>Henry Bruce (Royal Navy officer, born 1792)：完整供应证据</summary>

Henry Bruce (Royal Navy officer, born 1792) Admiral Sir Henry William Bruce (2 February 1792 – 14 December 1863) was a Royal Navy officer who went on to be Commander-in-Chief, Portsmouth. Born the son of Sir Henry Hervey Aston Bruce, 1st Baronet, Bruce joined the Royal Navy in 1803. He took part in the Battle of Trafalgar in 1805. He also took part in the War of 1812. He became Captain of HMS "Britannia" in 1823, of HMS "Imogene" in 1836, of HMS "Agincourt" in 1842 and of HMS "Queen" in 1847. In 1851 he was appointed Commodore of the

答案字符位置：[77, 92)。

</details>

<details>
<summary>James Andrew Thomas Bruce：完整供应证据</summary>

Olive Christian married Algernon Samuel Wigmore of Cobham and Stoke D'Abernon, Surrey, in 1898. She died, aged 52, on 21 November 1926. Olive Christian Wigmore is interred in the Churchyard of Stoke D'Abernon. James Andrew Thomas Bruce Admiral Sir James Andrew Thomas Bruce, KCMG (15 July 1846 – 25 May 1921) was an officer in the Royal Navy, who was second in command of the British fleet on the China Station during the Boxer Rebellion. Bruce was born on 15 July 1846, the son of Rt. Hon. Sir Sir Henry Hervey Bruce, 3rd Baronet and Marianne Margaret Clifton. He served

答案字符位置：[281, 293)。

</details>

## 第190题：ambigdocs_59326

**query：** When was Dennis Isherwood born?

**term：** Dennis Isherwood
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Dennis Isherwood (footballer, born 1924) | 9 January 1924 | 9 January 1924 / January 9, 1924 / January 9 1924 / 1924-01-09 |
| Dennis Isherwood (footballer, born 1947) | 20 January 1947 | 20 January 1947 / January 20, 1947 / January 20 1947 / 1947-01-20 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Dennis Isherwood (footballer, born 1924)：完整供应证据</summary>

Dennis Isherwood (footballer, born 1924) Dennis Isherwood (9 January 1924 – February 1974) was an English footballer who played as a forward in the Football League for Chester after World War II. He later played non-league football for Northwich Victoria, Wellington Town, Winsford United, Macclesfield Town, Runcorn, Congleton Town and Stafford Rangers. Isherwood was signed with Rochdale during World War II and guested for Crewe Alexandra and Wolverhampton Wanderers, before signing for Wrexham. With the war still raging he guested for Port Vale on 9 May 1945 in a Potteries derby war match which was lost 4–2. After the war

答案字符位置：[59, 73)。

</details>

<details>
<summary>Dennis Isherwood (footballer, born 1947)：完整供应证据</summary>

Dennis Isherwood (footballer, born 1947) Dennis Isherwood (born 20 January 1947) is an English former professional footballer who played in the Football League for Birmingham City. Isherwood was born in Brierley Hill, Staffordshire. He played representative football for Brierley Hill Schools before joining Birmingham City when he left school in 1962. He turned professional two years later, and made his debut in the Second Division on 31 December 1966 in a 3–3 draw away to Norwich City. Ray Martin had been injured for some weeks, and Isherwood played at right back to allow Martin's regular deputy Bert Murray to switch

答案字符位置：[64, 79)。

</details>

## 第191题：ambigdocs_32817

**query：** When was Judge Kennamer born?

**term：** Judge Kennamer
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Charles Brents Kennamer | November 25, 1874 | November 25, 1874 / 25 November 1874 / November 25 1874 / 1874-11-25 |
| Franklin Elmore Kennamer | January 12, 1879 | January 12, 1879 / 12 January 1879 / January 12 1879 / 1879-01-12 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Charles Brents Kennamer：完整供应证据</summary>

Charles Brents Kennamer Charles Brents Kennamer (November 25, 1874 – June 3, 1955) was a United States federal judge. Born in Kennamer Cove, Alabama, Kennamer attended Georgetown University, and read law to enter the bar in 1903. He entered private practice in Guntersville, Alabama in 1903. He was a County solicitor, Marshall County, Alabama from 1905 to 1906. He was an Assistant United States Attorney of the Northern District of Alabama from 1907 to 1914, and then a special Assistant United States Attorney of the Northern District of Alabama from 1914 to 1916, finally becoming the United States Attorney for

答案字符位置：[49, 66)。

</details>

<details>
<summary>Franklin Elmore Kennamer：完整供应证据</summary>

Franklin Elmore Kennamer Franklin Elmore Kennamer (January 12, 1879 – May 1, 1960) was a United States federal judge and a former Justice of the Oklahoma State Supreme Court. Franklin Elmore Kennamer was born in Kennamer Cove, Marshall County, Alabama on January 12, 1879, to Seaborn F. Kennamer (1830 - 1915) and his wife, Nancy Elizabeth Mitchell Kennamer (1848 - 1898). Kennamer was a Colonel in the United States Army during the Spanish–American War, and then read law in 1905, to pass the Bar examination and qualify as a lawyer.. He was a city attorney for Madill, Oklahoma from 1915

答案字符位置：[51, 67)。

</details>

## 第192题：ambigdocs_7389

**query：** When was Chris Robertson born?

**term：** Chris Robertson
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Chris Robertson (footballer, born 1957) | 25 December 1957 | 25 December 1957 / December 25, 1957 / December 25 1957 / 1957-12-25 |
| Chris Robertson (footballer, born 1986) | 11 October 1986 | 11 October 1986 / October 11, 1986 / October 11 1986 / 1986-10-11 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Chris Robertson (footballer, born 1957)：完整供应证据</summary>

Chris Robertson (footballer, born 1957) Chris Robertson (born 25 December 1957) is a Scottish former professional football player who is best known for his time with Hearts and Meadowbank Thistle Born in Edinburgh, Watson started his career a Salvesen's Boys Club and moved to Rangers in 1976. He stayed at the club for three years before moving on to Hearts for two seasons. Robertson was then to have the first of two spells at Meadowbank Thistle, which had stints with Cowdenbeath and Raith Rovers separating them. In 1983, he joined Thistle permanently and went on to make close to 100

答案字符位置：[62, 78)。

</details>

<details>
<summary>Chris Robertson (footballer, born 1986)：完整供应证据</summary>

Chris Robertson (footballer, born 1986) Christopher Robertson (born 11 October 1986) is a Scottish professional footballer who plays as a defender for EFL League Two club Swindon Town. He turned professional at Sheffield United in July 2005, but was released by the club after two brief loan spells at Leigh RMI and Chester City. He joined Torquay United in March 2007, and went on to spend five years with the club, helping them to win the 2009 Conference play-off final. He was sold to Preston North End for an undisclosed fee in January 2012, but left the club at the

答案字符位置：[68, 83)。

</details>

## 第193题：ambigdocs_30366

**query：** When was Other Windsor born?

**term：** Other Windsor
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Other Windsor, 2nd Earl of Plymouth | 27 August 1679 | 27 August 1679 / August 27, 1679 / August 27 1679 / 1679-08-27 |
| Other Windsor, 4th Earl of Plymouth | 12 May 1731 | 12 May 1731 / May 12, 1731 / May 12 1731 / 1731-05-12 |
| Other Windsor, 5th Earl of Plymouth | 30 May 1751 | 30 May 1751 / May 30, 1751 / May 30 1751 / 1751-05-30 |
| Other Windsor, 6th Earl of Plymouth | 2 July 1789 | 2 July 1789 / July 2, 1789 / July 2 1789 / 1789-07-02 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Other Windsor, 2nd Earl of Plymouth：完整供应证据</summary>

Other Windsor, 2nd Earl of Plymouth Other Windsor, 2nd Earl of Plymouth (27 August 1679 – 26 December 1727) was a British peer, styled Lord Windsor from his father's death in 1684 to 1687. The son of Other Windsor, Lord Windsor and Elizabeth Turvey, he succeeded his grandfather as Earl of Plymouth in 1687. His unusual first name is a variant of Otho. On 12 April 1706, he was awarded a DCL by Oxford. He was appointed Custos Rotulorum of Worcestershire in 1710, and Lord Lieutenant of Cheshire and the counties of North Wales in 1713, but lost all his

答案字符位置：[73, 87)。

</details>

<details>
<summary>Other Windsor, 4th Earl of Plymouth：完整供应证据</summary>

Other Windsor, 4th Earl of Plymouth Other Lewis Windsor, 4th Earl of Plymouth (12 May 1731 – 21 April 1771) was a British peer, styled Lord Windsor until 1732. He succeeded his father Other Windsor, 3rd Earl of Plymouth, as Earl of Plymouth at the age of one, and was educated at Eton and The Queen's College, Oxford. In March 1750, he was appointed Constable of Flint Castle, Comptroller of the records in the counties of Chester and Flint, and Comptroller of the Pleas, Fine and Amerciaments in county Caernarvon. He obtained his Master of Arts in July. In 1753,

答案字符位置：[79, 90)。

</details>

<details>
<summary>Other Windsor, 5th Earl of Plymouth：完整供应证据</summary>

Other Windsor, 5th Earl of Plymouth Other Hickman Windsor, 5th Earl of Plymouth FRS (30 May 1751 - 12 June 1799), styled Lord Windsor until 1771, was an English nobleman. Styled Lord Windsor from birth, he was the eldest son of Other Windsor, 4th Earl of Plymouth and the Honourable Catherine, daughter of Thomas Archer, 1st Baron Archer. He was elected a Fellow of the Royal Society on 22 April 1773. He was Colonel of the Glamorganshire Militia, 6 August 1779. Lord Plymouth married his first cousin the Honourable Sarah, daughter of Andrew Archer, 2nd Baron Archer, on 20 May

答案字符位置：[85, 96)。

</details>

<details>
<summary>Other Windsor, 6th Earl of Plymouth：完整供应证据</summary>

Other Windsor, 6th Earl of Plymouth Other Archer Windsor, 6th Earl of Plymouth (2 July 1789 – 20 July 1833, Deptford) was an English nobleman, the eldest and only surviving son of the 5th Earl of Plymouth by his wife and cousin, Hon. Sarah Archer, daughter and eventual co-heiress of the 2nd Baron Archer. He was the sixth Earl of Plymouth of the 1682 creation. He was born the only son, and had two sisters Lady Mary Windsor, who married the Marquess of Downshire and Lady Harriet Windsor, who married the Hon. Robert Clive, a son of the Earl of

答案字符位置：[80, 91)。

</details>

## 第194题：ambigdocs_63652

**query：** When was General Petrov born?

**term：** General Petrov
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Ivan Yefimovich Petrov | September 18, 1896 | September 18, 1896 / 18 September 1896 / September 18 1896 / 1896-09-18 |
| Mikhail Petrovich Petrov (general) | 15 January 1898 | 15 January 1898 / January 15, 1898 / January 15 1898 / 1898-01-15 |
| Racho Petrov | 3 March 1861 | 3 March 1861 / March 3, 1861 / March 3 1861 / 1861-03-03 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Ivan Yefimovich Petrov：完整供应证据</summary>

Ivan Yefimovich Petrov Ivan Yefimovich Petrov (; September 18, 1896 – April 7, 1958) was a Soviet Army General from 1941. Born in Trubchevsk in 1896, he began his military service in the Red Army in 1918, the year when he also joined the Bolshevik Party. Petrov fought in the Russian Civil war near Samara, the Polish Soviet War of 1920 and the Basmachi rebellion in 1922. In the late 1920s and 1930s Petrov served in Central Asia. During World War II, Petrov participated in the Battle of Odessa, Battle of Sevastopol and was noted for heading the Separate Coastal

答案字符位置：[49, 67)。

</details>

<details>
<summary>Mikhail Petrovich Petrov (general)：完整供应证据</summary>

Mikhail Petrovich Petrov (general) Mikhail Petrovich Petrov (; 15 January 1898 October/November 1941) was a Red Army major general and a Hero of the Soviet Union. Born to a peasant family, he moved to Petrograd and became a metalworker at the Putilov Plant, where he became a Red Guard squad leader and fought in the storming of the Winter Palace. He joined the Red Army and fought in the Russian Civil War. During the interwar period Petrov became an armored corps officer and fought as a tank battalion commander during the Spanish Civil War. For his leadership, he received the

答案字符位置：[63, 78)。

</details>

<details>
<summary>Racho Petrov：完整供应证据</summary>

Racho Petrov Racho Petrov Stoyanov () (3 March 1861 – 22 January 1942) was a leading Bulgarian general and politician. Petrov was born in Shumen. A talented soldier, he was appointed Chief of General Staff at the age of 24 and was Minister of Defence at 27. His stature was increased by the leading role he took in suppressing an army mutiny in 1887. He married Sultana Pantaleeva Minchovich in 1887, with whom he had 3 children. After an unhappy marriage, they divorced in 1919. Both Petrov and his wife were personally close to Tsar Ferdinand I of Bulgaria and

答案字符位置：[39, 51)。

</details>

## 第195题：ambigdocs_21987

**query：** When was Julia Dean born?

**term：** Julia Dean
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Julia Dean (actress, born 1830) | July 22, 1830 | July 22, 1830 / 22 July 1830 / July 22 1830 / 1830-07-22 |
| Julia Dean (actress, born 1878) | May 13, 1878 | May 13, 1878 / 13 May 1878 / May 13 1878 / 1878-05-13 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Julia Dean (actress, born 1830)：完整供应证据</summary>

Julia Dean (actress, born 1830) Julia Dean (July 22, 1830 – March 6, 1868) was an American actress who made her New York debut at 16 in a starring role with the James Sheridan Knowles comedy, "The Hunchback". Her performance was met with such praise that she continued to star in productions of "The Hunchback" over much of her twenty-year career. Although she began and ended her career on the East coast, Dean’s greatest popularity was achieved in tours of the American South and the Far West. Dean was married twice; she was the mother of four children, but died

答案字符位置：[44, 57)。

</details>

<details>
<summary>Julia Dean (actress, born 1878)：完整供应证据</summary>

Julia Dean (actress, born 1878) Julia Dean (May 13, 1878 – October 17, 1952) was a stage and film actress who began her career in the 1890s. Julia Dean was born to Albert Clay Dean and Susan Jane Morton in St. Paul, Minnesota, in 1878. She had a sister Eloise and a brother. She made her Broadway debut December 1, 1902 in "The Altars of Friendship". She toured with Joseph Jefferson and James Neill. In 1907 she appeared with Maclyn Arbuckle in "The Round-Up". She worked for producers William A. Brady and David Belasco. She began making silent pictures in

答案字符位置：[44, 56)。

</details>

## 第196题：ambigdocs_2826

**query：** When was Gordon Wallace born?

**term：** Gordon Wallace
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Gordon Wallace (footballer, born 1943) | 20 June 1943 | 20 June 1943 / June 20, 1943 / June 20 1943 / 1943-06-20 |
| Gordon Wallace (footballer, born 1944) | 13 June 1944 | 13 June 1944 / June 13, 1944 / June 13 1944 / 1944-06-13 |
| Gordon Wallace (judge) | 22 January 1900 | 22 January 1900 / January 22, 1900 / January 22 1900 / 1900-01-22 |
| Gordon Wallace (professor) | 9 June 1958 | 9 June 1958 / June 9, 1958 / June 9 1958 / 1958-06-09 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Gordon Wallace (footballer, born 1943)：完整供应证据</summary>

Gordon Wallace (footballer, born 1943) George Gordon Wallace (born 20 June 1943) is a Scottish former professional football player and coach. Wallace was a record-setting goal-scorer in the Scottish league, and was named Scottish Football Writers' Player of the Year for 1967-68. Wallace is currently employed in an advisory position with Dundee F.C.. A native of Dundee, Wallace began his career in 1961 with Montrose. He went on to play for Raith Rovers, Dundee, and Dundee United. He also played in the NASL for two seasons with the Seattle Sounders, 1976 and 1978. Wallace once held the Scottish record of

答案字符位置：[67, 79)。

</details>

<details>
<summary>Gordon Wallace (footballer, born 1944)：完整供应证据</summary>

Gordon Wallace (footballer, born 1944) Gordon Wallace (born 13 June 1944 in Lanark) is a Scottish former footballer, who played for Liverpool during the 1960s. Wallace was raised in Wales after his father Dougie, also a footballer, transferred to Llanelli Town in 1949. Gordon attended school with future rugby union star Barry John and had trials with Huddersfield Town while Bill Shankly was the Yorkshire club's manager. Shankly moved to Liverpool in late 1959, and soon brought in the teenage Wallace as an apprentice. During his spell at Anfield, his main claims to fame were netting the opening goal in

答案字符位置：[60, 72)。

</details>

<details>
<summary>Gordon Wallace (judge)：完整供应证据</summary>

Gordon Wallace (judge) Sir Gordon Wallace QC, born Gordon Isaacs (22 January 1900 – 11 December 1987) was an Australian judge. Wallace was born at Redfern in Sydney to coachbuilder Jacob Albert Clarke Isaacs and Euphemia, "née" Wallace. He attended Sydney Boys High School from 1912 to 1915, and in 1916 entered the Royal Military College, Duntroon, as a staff cadet. He graduated as a lieutenant on 10 December 1919 and worked for the British Army before joining the Australian Staff Corps (1920–1922). After his resignation he served in the Citizen Military Forces, becoming a major by 1929. He also

答案字符位置：[66, 81)。

</details>

<details>
<summary>Gordon Wallace (professor)：完整供应证据</summary>

was elected as a Fellow of the Australian Academy of Science In September 2008, Professor Wallace’s team moved to research facilities at the University of Wollongong’s new Innovation Campus based at North Wollongong. He was instrumental in developing the vision and securing the funding for the Processing and Device Fabrication Facility opened in 2012. The significance of Professor Wallace’s contributions to electrochemistry and polymer science has been recognised with a number of awards. A selection of these awards and distinctions are listed here: Gordon Wallace (professor) Gordon Wallace, AO, FAA, FTSE, FIOP, FRACI (born 9 June 1958 in Belfast, Northern

答案字符位置：[631, 642)。

</details>

## 第197题：ambigdocs_12977

**query：** When was Qilong born?

**term：** Qilong
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Tan Qilong | 3 January 1913 | 3 January 1913 / January 3, 1913 / January 3 1913 / 1913-01-03 |
| Zhang Qilong | 1900 | 1900 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Tan Qilong：完整供应证据</summary>

Tan Qilong Tan Qilong (; 3 January 1913 – 22 January 2003) was a politician of the People's Republic of China. Over his long career he served as the Communist Party Chief, the top government official, of four different provinces: Zhejiang (twice), Shandong, Qinghai, and Sichuan. He also served as Governor of Zhejiang, Shandong, and Qinghai. Tan was born in Yongxin County, Jiangxi province on 3 January 1913 and joined the Communist Party of China in 1933. He was persecuted during the Cultural Revolution but was rehabilitated in 1970 and served in Fujian province. He died on 22 January 2003

答案字符位置：[25, 39)。

</details>

<details>
<summary>Zhang Qilong：完整供应证据</summary>

Zhang Qilong Zhang Qilong (; 1900 – June 3, 1987) was a People's Republic of China politician. He was born in Liuyang, Hunan Province. He joined the Communist Party of China in 1926 and participated in the Autumn Harvest Uprising of 1927. He was a member of the Chinese Workers' and Peasants' Red Army during the Chinese Civil War, the Eighth Route Army and the People's Liberation Army. In 1933, his party membership was revoked and he divorced his then wife, Li Zhen, to avoid implicating her in his disgrace. He was allowed back into the party in 1936. After

答案字符位置：[29, 33)。

</details>

## 第198题：ambigdocs_17831

**query：** When was Stephanie Edwards born?

**term：** Stephanie Edwards
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Sparkle (singer) | May 13, 1975 | May 13, 1975 / 13 May 1975 / May 13 1975 / 1975-05-13 |
| Stephanie Edwards (singer) | November 5, 1987 | November 5, 1987 / 5 November 1987 / November 5 1987 / 1987-11-05 |
| Stephanie Edwards (television personality) | November 8, 1943 | November 8, 1943 / 8 November 1943 / November 8 1943 / 1943-11-08 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Sparkle (singer)：完整供应证据</summary>

Sparkle (singer) Stephanie Edwards (born May 13, 1975), better known by her stage name Sparkle is an American R&B singer. She began her career in 1998 as a protégé of fellow Chicago native R. Kelly. Edwards is probably best known for her 1998 R&B debut hit single "Be Careful". Sparkle first started singing in her family's gospel music group. Sparkle met singer R. Kelly in while he was working on a male artist in 1989. Sparkle was the first and only successful artist to release an album on Kelly's Rockland label. Sparkle's début album, the self-titled "Sparkle", was released on

答案字符位置：[41, 53)。

</details>

<details>
<summary>Stephanie Edwards (singer)：完整供应证据</summary>

Stephanie Edwards (singer) Stephanie Edwards (born November 5, 1987) is an American singer and was the eleventh-place finalist on sixth season of "American Idol". She is from Savannah, Georgia and first began singing around the age of two or three. After graduating from Windsor Forest High School, Edwards pursued vocal instruction for a month and then went on to appear at the Apollo Theatre in New York when she competed in "It's Showtime at the Apollo". Prior to "American Idol", she had won most singing contests she had entered, including "Savannah Star" in 2005. Edwards first auditioned for the reality

答案字符位置：[51, 67)。

</details>

<details>
<summary>Stephanie Edwards (television personality)：完整供应证据</summary>

Stephanie Edwards (television personality) Stephanie Ann Edwards (born November 8, 1943) is an American actress and television personality. Born in Kenyon, Minnesota, Edwards began her career as an actress, but became widely known as an on-air personality in the 1970s. She co-hosted ABC-TV's "AM America" jointly with Bill Beutel, the forerunner to "Good Morning America". (She continued to be with GMA, often substituting for Joan Lunden.) Previously, she had hosted a similar west coast news and talk program in Southern California named AM Los Angeles along with Ralph Story. Edwards was nominated in 1979 for a Daytime Emmy Award as

答案字符位置：[71, 87)。

</details>

## 第199题：ambigdocs_30744

**query：** When was Cui Wei born?

**term：** Cui Wei
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Cui Wei (footballer, born 1983) | April 7, 1983 | April 7, 1983 / 7 April 1983 / April 7 1983 / 1983-04-07 |
| Cui Wei (footballer, born 1994) | 16 August 1994 | 16 August 1994 / August 16, 1994 / August 16 1994 / 1994-08-16 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Cui Wei (footballer, born 1983)：完整供应证据</summary>

Cui Wei (footballer, born 1983) Cui Wei (Chinese:崔威; born April 7, 1983) is a Chinese football player who currently plays as a Defender for Beijing BIT. Cui Wei began his club career with the Beijing Guoan youth team in 1998 and was considered to be a rising prospect that was good enough to be loaned out to Eintracht Frankfurt youth team in 1999. In 2003, he graduated into the senior Beijing Guoan squad where he played for them for several season. However, he was unable to establish himself within the squad and transferred to Changchun Yatai. At the beginning of

答案字符位置：[58, 71)。

</details>

<details>
<summary>Cui Wei (footballer, born 1994)：完整供应证据</summary>

Cui Wei (footballer, born 1994) Cui Wei (; born 16 August 1994) is a Chinese footballer who currently plays for China League One club Meizhou Hakka. Cui Wei started his football career when he played for China League Two side Shandong Youth in 2011 and 2012. In August 2013, he was loaned to Campeonato de Portugal side Loures for one season. Cui was promoted to Shandong Luneng's first team squad by Cuca in the 2015 season. On 4 May 2016, he made his debut for Shandong in the last group match of 2016 AFC Champions League against Buriram United with

答案字符位置：[48, 62)。

</details>

## 第200题：ambigdocs_29972

**query：** When was General Kozlov born?

**term：** General Kozlov
**dimension：** Entity Disambiguation
**来源：** 替补题；已核对供应文本

| conditions（实体名称） | answer（原文短答案） | acceptable_answers |
|---|---|---|
| Dmitry Timofeyevich Kozlov | October 23 (November 4) 1896 | October 23 (November 4) 1896 |
| Oleg Kozlov | April 20, 1963 | April 20, 1963 / 20 April 1963 / April 20 1963 / 1963-04-20 |

人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。

<details>
<summary>Dmitry Timofeyevich Kozlov：完整供应证据</summary>

Dmitry Timofeyevich Kozlov Dmitry Timofeyevich Kozlov (October 23 (November 4) 1896, Razgulyayka, now in Nizhny Novgorod Oblast – December 6, 1967, Minsk) was a Soviet military commander. Born in the village of Razgulyayka, he left school in 1915 and joined the Russian Army at the rank of Praporshchik. He served in the First World War and graduated from officer training school in 1917. He moved to the Red Army in 1918, commanding a battalion then a regiment in the Russian Civil War. In December 1922 he became the commander of the 4th Turkestan Regiment, then of the 109th Regiment in

答案字符位置：[55, 83)。

</details>

<details>
<summary>Oleg Kozlov：完整供应证据</summary>

Oleg Kozlov Major General Oleg Aleksandrovich Kozlov (; born April 20, 1963) is a Russian military officer and recipient of the Hero of the Russian Federation, which he received in 1996 for "courage and heroism in the performance of special assignments" during the First Chechen War during which he commanded a regiment of motorized infantry. Kozlov was born in the village of Arzgir in Stavropol Krai in what was at that time the Soviet Union in 1963 to a family of workers. He graduated from School №1 in Arzgir in 1980, following which he entered the military academy. After graduating

答案字符位置：[61, 75)。

</details>

#!/usr/bin/env python3
"""Rebuild the fixed, source-reviewed v3 sample from original dev.json. Python 3.9+."""
import argparse, hashlib, importlib.util, json, re
from collections import Counter
from pathlib import Path
DIMENSION='Entity Disambiguation'

def locate(answer,text):
    return re.search(r'(?<!\w)'+r'\s+'.join(re.escape(w) for w in answer.split())+r'(?!\w)',text,re.I)

def norm(s):return re.sub(r'\W+',' ',s.casefold()).strip()

def date_aliases(s):
    months=['January','February','March','April','May','June','July','August','September','October','November','December']
    p='('+'|'.join(months)+')'
    a=re.fullmatch(r'(\d{1,2}) '+p+r' (\d{4})',s,re.I)
    b=re.fullmatch(p+r' (\d{1,2}),? (\d{4})',s,re.I)
    if not (a or b):return []
    day,month,year=(a[1],a[2],a[3]) if a else (b[2],b[1],b[3])
    month=month.title();day=str(int(day));mi=months.index(month)+1
    return [f'{day} {month} {year}',f'{month} {day}, {year}',f'{month} {day} {year}',f'{year}-{mi:02d}-{int(day):02d}']

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',required=True)
    p.add_argument('--outdir',default='ambigdocs_200_v3')
    p.add_argument('--manifest',default=str(Path(__file__).with_name('review_manifest.json')))
    a=p.parse_args()
    try:
        source=Path(a.input).resolve();out=Path(a.outdir).resolve()
        if source==out or out in source.parents:raise ValueError('输入和输出目录必须分开')
        if out.exists() and (not out.is_dir() or any(out.iterdir())):raise ValueError('输出目录非空；请换一个新目录')
        manifest=json.loads(Path(a.manifest).read_text(encoding='utf-8'))
        if hashlib.sha256(source.read_bytes()).hexdigest()!=manifest['source_sha256']:raise ValueError('原始 dev.json 与本次审核版本不一致；不会把审核修改套用到别的数据')
        data=json.loads(source.read_text(encoding='utf-8-sig'))
        sp=importlib.util.spec_from_file_location('standardizer',Path(__file__).with_name('standardize_benchmark.py'))
        m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
        intermediate=[];audit=[];original=[]
        for e in manifest['entries']:
            r=data[e['source_index']]
            if str(r['qid'])!=e['qid']:raise ValueError('qid/source_index不一致')
            docs=r['documents'];pairs=[];extractions=[]
            for j,d in enumerate(docs,1):
                requested=e['answer_overrides'].get(str(j),d['answer'])
                match=locate(requested,d['text'])
                if not match:raise ValueError(f'{e["qid"]} C{j}: 修改后的答案不在对应原文中')
                answer=match.group()
                if len(answer.split())>6 or len(answer)>60:raise ValueError('答案超过6词或60字符')
                # Retain the old answer as an alias only when it differs in case/whitespace.
                aliases=[answer]
                if norm(requested)==norm(d['answer']) and requested.split()==d['answer'].split():aliases.append(d['answer'].strip())
                aliases+=date_aliases(answer)+e['aliases'].get(str(j),[])
                aliases=list(dict.fromkeys(aliases))
                if any(not isinstance(v,str) or not v.strip() or len(v)>80 for v in aliases):raise ValueError('别名为空或过长')
                pairs.append({'conditions':{DIMENSION:d['title']},'answer':answer,'acceptable_answers':aliases})
                extractions.append({'title':d['title'],'pid':d['pid'],'original_answer':d['answer'],'source_span':answer,'start':match.start(),'end':match.end()})
            if len({norm(pair['answer']) for pair in pairs})<2:raise ValueError('答案在规范化后完全相同')
            # Never append answer fields to the evidence context.
            context='\n\n'.join('Document '+str(j)+'\nTitle: '+d['title']+'\nText: '+d['text'] for j,d in enumerate(docs,1))
            intermediate.append({'id':'ambigdocs_'+e['qid'],'query':e['query'],'dataset':'AmbigDocs','table':context,'gold':{'ambiguous_conditions':[{'term':r['ambiguous_entity'],'dimension':DIMENSION,'conditions':[d['title'] for d in docs]}],'condition_answer_pairs':pairs}})
            audit.append((e,r,extractions));original.append(r)
        rows=m.convert(intermediate,require_table=True)
        for row,(e,r,extractions) in zip(rows,audit):
            row['metadata'].update({'source_split':'dev','source_qid':r['qid'],'source_index_zero_based':e['source_index'],'original_query':r['question'],'old_review_number':e['old_number'],'revision_status':e['status'],'document_pids':[d['pid'] for d in r['documents']],'answer_extraction':extractions,'revision':'v3_source_review','dimension_status':'project_assigned','context_modality':'text_documents','quality_status':'assistant_source_reviewed_pending_independent_human_review'})
            m.validate_gold(row['gold'])
        if len(rows)!=200:raise ValueError('审核清单不是200题')
        out.mkdir(parents=True,exist_ok=True)
        m.write_jsonl(out/'ambigdocs_eval_standard.jsonl',rows)
        m.write_jsonl(out/'model_inputs.jsonl',[{k:r[k] for k in ('id','query','table')} for r in rows])
        (out/'sample_original.json').write_text(json.dumps(original,ensure_ascii=False,indent=2),encoding='utf-8')
        md=['# AmbigDocs v3：200题审核清单','','字段与正式 JSONL 对应：query、gold.ambiguous_conditions 和 gold.condition_answer_pairs。table 是完整的文档上下文，展开各题证据即可查看。','','这是助手基于供应文本的审核版，尚未完成独立人工核验，未调用模型。evaluation_ready 只表示有上下文。','']
        def esc(s):return s.replace('|','\\|').replace('\n',' ')
        for n,(row,(e,r,extractions)) in enumerate(zip(rows,audit),1):
            md += [f'## 第{n}题：{row["id"]}','',f'**query：** {row["query"]}','',f'**term：** {r["ambiguous_entity"]}',f'**dimension：** {DIMENSION}',f'**来源：** '+(f'旧第{e["old_number"]}题，{e["status"]}' if e['old_number'] else '替补题；已核对供应文本'),'', '| conditions（实体名称） | answer（原文短答案） | acceptable_answers |','|---|---|---|']
            for pair in row['gold']['condition_answer_pairs']:md.append('| '+esc(pair['conditions'][DIMENSION])+' | '+esc(pair['answer'])+' | '+esc(' / '.join(pair['acceptable_answers']))+' |')
            md += ['','人工核验：问题自然____；实体指代成立____；事实关系和答案完整____；答案实质不同____。','']
            for d,x in zip(r['documents'],extractions):md += ['<details>','<summary>'+esc(d['title'])+'：完整供应证据</summary>','',d['text'],'',f'答案字符位置：[{x["start"]}, {x["end"]})。','','</details>','']
        (out/'review_200.md').write_text('\n'.join(md),encoding='utf-8')
        counts=Counter(x['decision'] for x in manifest['old_200_decisions'])
        report=['# 旧200题到v3的修改记录','','格式没有重做；改变的是问题/条件/答案的内容对应关系。','','旧200题：保留 '+str(counts['retain'])+'，修订 '+str(counts['revise'])+'，整题剔除 '+str(counts['exclude'])+'；新增同数替补，最终仍为200题。','','## 剔除的题目','','| 旧题号 | ID | 原因 |','|---|---|---|']
        for d in manifest['old_200_decisions']:
            if d['decision']=='exclude':report.append(f'| {d["old_number"]} | ambigdocs_{d["qid"]} | {d["reason"]} |')
        report+=['','## 修订的题目','','下面列明 query/答案/别名覆盖。答案编号1、2等对应原始文档顺序，不是正式 condition 标签。','']
        for d in manifest['old_200_decisions']:
            if d['decision']=='revise':report += [f'### 旧第{d["old_number"]}题：ambigdocs_{d["qid"]}','', '```json',json.dumps(d['patch'],ensure_ascii=False,indent=2),'```','']
        report+=['## 替补题','','| ID | query |','|---|---|']
        for e in manifest['entries']:
            if e['status']=='replacement':report.append('| ambigdocs_'+e['qid']+' | '+esc(e['query'])+' |')
        report+=['','## 审核限制','','这是单次助手文本审核，不是独立人工标注或外部事实核验。保留题仍需人核验；不要把本次自动检查或助手审核写作200题全部人工通过。别名只包含明确同义名称或同一日期的显示格式；不会把错误旧答案保留为可接受答案。未修改评分算法，评分器仍需实际支持 acceptable_answers 字段。']
        (out/'CHANGELOG_zh.md').write_text('\n'.join(report),encoding='utf-8')
        summary={'selected_queries':len(rows),'condition_answer_pairs':sum(len(r['gold']['condition_answer_pairs']) for r in rows),'old_sample_decisions':dict(counts),'replacements':sum(e['status']=='replacement' for e in manifest['entries']),'source_sha256':manifest['source_sha256'],'selection':'fixed source-reviewed manifest; no fresh random sampling','review_basis':manifest['review_basis'],'human_validation_complete':False,'model_evaluation_run':False,'scoring_algorithm_changed':False,'max_answer_words':6,'max_answer_chars':60}
        (out/'validation_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
        print(f'完成：{len(rows)}个问题，{summary["condition_answer_pairs"]}组条件答案。')
        print('修改记录：'+str(out/'CHANGELOG_zh.md'))
        print('人工核验：'+str(out/'review_200.md'))
        print('正式评分：'+str(out/'ambigdocs_eval_standard.jsonl'))
        print('助手源文本审核已完成；独立人工核验和模型评测尚未完成。')
    except (ValueError,OSError,KeyError,TypeError) as e:p.exit(1,'错误：'+str(e)+'\n')
if __name__=='__main__':main()

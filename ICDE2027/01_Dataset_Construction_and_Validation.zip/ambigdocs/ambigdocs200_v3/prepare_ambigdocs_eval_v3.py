#!/usr/bin/env python3
"""Build no-gold model input manifests and a no-API preflight for AmbigDocs V3."""
from __future__ import annotations
import argparse, json, math, statistics
from pathlib import Path

SYSTEM = "You evaluate ambiguous question answering over supplied documents. Use only the documents. Return valid JSON only."
DIMENSION = "Entity Disambiguation"

def read_jsonl(p: Path):
    return [json.loads(line) for line in p.read_text(encoding='utf-8').splitlines() if line.strip()]
def write_jsonl(p: Path, rows):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(''.join(json.dumps(x, ensure_ascii=False)+'\n' for x in rows), encoding='utf-8')
def dimension_prompt(s):
    return f'''Task: Dimension Identification\nIdentify the ambiguous name/entity mention and list the plausible entities supported by the documents. The ambiguity dimension label for this dataset is exactly "{DIMENSION}". Do not answer the question.\nReturn JSON: {{"ambiguous_conditions":[{{"term":"...","dimension":"{DIMENSION}","possible_conditions":["entity title/name", "..."]}}]}}\n\nDocuments:\n{s['table']}\n\nQuery:\n{s['query']}'''
def condition_prompt(s, cond):
    return f'''Task: Gold-condition Answering\nAnswer the query using only the supplied documents and the given entity interpretation. Do not reconsider or replace the given interpretation. Return the shortest answer supported by the document, preserving names as written.\nReturn JSON: {{"answer":"..."}}\n\nDocuments:\n{s['table']}\n\nQuery:\n{s['query']}\n\nEntity interpretation ({DIMENSION}):\n{cond}'''
def e2e_prompt(s):
    return f'''Task: End-to-End Ambiguous QA\nIdentify the ambiguous name/entity, classify it as "{DIMENSION}", list the plausible entities supported by the documents, then answer the query under each entity interpretation. Use only the supplied documents.\nReturn JSON: {{"ambiguous_conditions":[{{"term":"...","dimension":"{DIMENSION}","possible_conditions":["entity title/name", "..."]}}],"answers":[{{"conditions":{{"{DIMENSION}":"entity title/name"}},"answer":"..."}}]}}\n\nDocuments:\n{s['table']}\n\nQuery:\n{s['query']}'''
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--standard',type=Path,required=True)
    ap.add_argument('--outdir',type=Path,required=True)
    a=ap.parse_args()
    rows=read_jsonl(a.standard)
    if len(rows)!=200: raise SystemExit(f'Expected 200 standard rows; got {len(rows)}')
    ids=[r['id'] for r in rows]
    if len(set(ids))!=200: raise SystemExit('Duplicate IDs found')
    di=[]; ca=[]; e2e=[]; gold=[]; prompt_chars={'dimension_identification':[],'condition_answering':[],'e2e':[]}
    for r in rows:
        if r.get('evaluation_ready') is not True: raise SystemExit(f"Not marked evaluation_ready: {r['id']}")
        g=r.get('gold',{})
        if len(g.get('ambiguous_conditions',[]))!=1 or g['ambiguous_conditions'][0].get('dimension')!=DIMENSION:
            raise SystemExit(f"Unexpected gold ambiguity schema/dimension for {r['id']}")
        di.append({'id':r['id'],'query':r['query'],'table':r['table']})
        e2e.append({'id':r['id'],'query':r['query'],'table':r['table']})
        gold.append(r)
        prompt_chars['dimension_identification'].append(len(SYSTEM)+len(dimension_prompt(r)))
        prompt_chars['e2e'].append(len(SYSTEM)+len(e2e_prompt(r)))
        pairs=g.get('condition_answer_pairs',[])
        if not pairs: raise SystemExit(f"No condition-answer pairs for {r['id']}")
        for j,p in enumerate(pairs):
            cond=p.get('conditions',{}).get(DIMENSION)
            if not cond: raise SystemExit(f"Missing {DIMENSION} condition for {r['id']} pair {j}")
            # Gold answer intentionally excluded from model input.
            ca.append({'id':r['id'],'pair_index':j,'query':r['query'],'table':r['table'],'dimension':DIMENSION,'condition':cond})
            prompt_chars['condition_answering'].append(len(SYSTEM)+len(condition_prompt(r,cond)))
    if len(ca)!=479: raise SystemExit(f'Expected 479 condition-answer inputs; got {len(ca)}')
    base=a.outdir; base.mkdir(parents=True,exist_ok=True)
    write_jsonl(base/'dimension_identification_inputs.jsonl',di)
    write_jsonl(base/'gold_condition_answer_inputs.jsonl',ca)
    write_jsonl(base/'end_to_end_inputs.jsonl',e2e)
    write_jsonl(base/'gold_for_scoring_only.jsonl',gold)
    sizes={k:{'calls':len(v),'min_prompt_chars':min(v),'median_prompt_chars':int(statistics.median(v)),'max_prompt_chars':max(v),'estimated_input_tokens_char_proxy_total':sum(math.ceil(x/3) for x in v)} for k,v in prompt_chars.items()}
    summary={'dataset':'AmbigDocs','version':'v3-source-reviewed','dimension':DIMENSION,'query_count':len(rows),'condition_answer_pairs':len(ca),'calls_per_model_by_task':{'dimension_identification':len(di),'gold_condition_answering':len(ca),'end_to_end':len(e2e)},'calls_per_model_total':len(di)+len(ca)+len(e2e),'estimated_prompt_size':sizes,'token_estimator':'ceil((system + user prompt characters)/3); rough preflight only, actual provider usage is authoritative','api_calls_made':0,'manual_review_basis':'V3 source-based review; independent human validation not completed per project decision'}
    (base/'preflight_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__': main()

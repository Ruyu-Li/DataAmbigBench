# AmbigDocs 200 v3：文本审核修订版

先打开 example_output/CHANGELOG_zh.md 看修订结果，再打开 example_output/review_200.md 核验。

最终200题、479组条件答案。旧200题保留130题、修订28题、剔除42题；逐一审查供应文本后补入42个候选。没有保留任何入选题的部分条件：入选题仍使用原始全部文档、标题和实体条件。

正式文件使用之前的统一格式：id、query、table、gold、evaluation_ready、metadata。gold 内保留 ambiguous_conditions（term、dimension、conditions）及 condition_answer_pairs（conditions、answer），每个 pair 增加 acceptable_answers。标准化脚本保持不变。review_200.md 只是方便阅读的展开版本，明确显示 query、term、dimension、conditions、answer 和 acceptable_answers；C1/C2 不再用作展示标签。

## 直接使用现成结果

example_output/ambigdocs_eval_standard.jsonl：评分用；包含gold。
example_output/model_inputs.jsonl：模型只读取此文件；仅包含id、query、table。
example_output/review_200.md：人工核验用；每题保留完整供应文档和原文答案位置。
example_output/CHANGELOG_zh.md：旧题剔除原因、修订内容和替补列表。

## 在Colab复现

上传本ZIP和与v2相同的原始dev.json，运行：

```python
!unzip -o /content/AmbigDocs_200_source_reviewed_v3.zip -d /content
!python3 /content/ambigdocs200_v3/build_ambigdocs_200.py --input /content/dev.json --outdir /content/ambigdocs_200_v3
```

如输出目录已存在且非空，换一个 --outdir。脚本使用固定 review_manifest.json 重建已审核样本，不再随机抽取不同候选；会核对整个原始dev.json的SHA256，输入版本不同就停止。只需要Python3.9+标准库，无模型调用，无API key。

## 改动原则

排除答案与问题的事实关系不对应、条件内部仍有多个答案、供应证据不足、不同答案实际同义的题。只在原文支持明确时修正问题/答案。所有canonical答案必须是对应文档的原文片段，最多6词、60字符，不做前缀截断。规范名称和日期显示格式可以作为acceptable_answers；不会把错误的原答案保留为别名。

新增别名包括供应原文明确说明的Jorn / Jørn Lande、Cassius Clay / Muhammad Ali、Varanasi / Benaras，以及同一完整日期的日月年、月日年、ISO显示格式。不会自动把完整生日简化为只有年份的别名。别名增加不代表已修改评分器；现有评分器必须实际读取acceptable_answers。原有normalization和numeric equivalence算法不变。

此次修订后的数据与v2不同，旧模型输出不能直接当作新版结果，需要重新评测。

## 审核状态

已完成的是助手基于供应文本的审核和程序一致性检查，尚未完成独立人工核验、外部事实验证或模型评测。evaluation_ready仅表示存在上下文。仍需人核验问题自然度、实体指代、答案关系和完整性、不同条件答案的实质差异；本包不能作为200题全部人工通过的证据。

Entity Disambiguation条件选择同名名称所指的具体实体。Legal-Scope条件选择适用法条或法律范围；答案恰好是机构名并不自动使它成为Entity Disambiguation。该包只修订AmbigDocs。

# Dataset construction and checks

Each dataset has its own directory. Archived benchmark inputs and outputs are included where available. See FILE_MANIFEST.tsv for the exact source of every file.

| Directory | Entry points and version notes |
| --- | --- |
| sec | The multimodel archive supplies a 200-row input. An earlier standardized input is also included. The original SEC construction, gold-answer generation, and sampling scripts remain to be located. |
| tatqa | Start with the archived 200-row sample and tatqa_repair_workflow.py. The original temporal builder, sampling notebook, and final repaired evaluation-input version remain to be confirmed. |
| online_retail_ii | The fixed builder and earlier Colab notebook are included along with the archived clean-pilot inputs. The final clean-pilot notebook cells remain to be confirmed. |
| ambigdocs | See build_ambigdocs_200.py and prepare_ambigdocs_eval_v3.py, plus the original run-preparation README. |
| opinionqa | The original, revision, and v3 builders are included alongside v3 outputs. Check the v3 builder for its input paths before running. |
| us_code | The repaired v3 package contains construction, revision, and standardization scripts, plus archived inputs and outputs. |
| sf311 | The initial builder, v2 revision, and answer-fix packages retain their original directory layouts. The answer-fix 200-row file and the multimodel archive's SF311 input differ byte-for-byte. Confirm the exact input for the run you wish to reproduce. |
| nyc311_geography | The V1 generator and 200-row outputs are grouped together. The alternate builder is included in its own directory. |
| shared | Standardization, format conversion, input audit/TAT-QA evidence preparation, and human-review sampling. The human-review archive includes its original input files. |

Some builders expect separately obtained raw datasets or original Colab/Drive paths. Check the original instructions and source before running.

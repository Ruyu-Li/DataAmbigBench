#!/usr/bin/env python3
"""DataAmbigBench: audit fixed 200-query inputs and restore TAT-QA evidence.

Offline preparation only. Never calls a model or changes an original input.
Example:
  python dataambig_prepare_all.py --inputs /content/inputs --out /content/drive/MyDrive/DataAmbigBench_supplemental/preparation

Expected TAT files (names may have Colab (1) suffix):
  TAT_QA_200_sampled_v1.jsonl, tatqa_temporal_main_train_dev.json,
  tatqa_dataset_train.json, tatqa_dataset_dev.json.
The other datasets are optional for auditing; their filenames are mapped in FILE_PREFIXES.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

FILE_PREFIXES = {
    "sec": ("SEC_200_sampled_v1",),
    "nasa": ("NASA_POWER_200_sampled_v1",),
    "tatqa": ("TAT_QA_200_sampled_v1",),
    "retail": ("online_retail_unit_200_standard", "retail"),
    "ambigdocs": ("ambigdocs_eval_standard", "ambigdocs"),
    "opinionqa": ("opinionqa_eval_standard", "opinionqa"),
    "usc": ("usc_eval_standard", "usc"),
    "sf311": ("sf311_event_status_200_standard", "sf311"),
    "nyc311": ("nyc311_geography_200_standard", "nyc311"),
}

def norm(s):
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", str(s or "")).casefold()).strip()

def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def read_jsonl(path):
    result = []
    for n, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        if line.strip():
            try:
                result.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path.name}:{n}: {exc}") from exc
    return result

def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

def write_csv(path, rows, columns):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=columns)
        w.writeheader()
        w.writerows(rows)

def locate(directory, prefixes, suffix, required=False):
    matches = [p for p in directory.rglob(f"*{suffix}")
               if any(p.name.lower().startswith(pre.lower()) for pre in prefixes)]
    # Colab renames duplicate uploads; silently picking the first would be unsafe.
    if len(matches) > 1:
        hashes = {hashlib.sha256(p.read_bytes()).hexdigest() for p in matches}
        if len(hashes) != 1:
            raise ValueError(f"Conflicting copies of {prefixes}: {[str(p) for p in matches]}")
    if not matches and required:
        raise FileNotFoundError(f"Missing {prefixes} (*{suffix}) under {directory}")
    return sorted(matches)[0] if matches else None

def render_table(matrix):
    if not isinstance(matrix, list) or not matrix:
        raise ValueError("Missing original TAT-QA table")
    width = max(map(len, matrix))
    def cells(row):
        return "| " + " | ".join(str(v).replace("|", "∣").replace("\n", " ")
                                 for v in list(row) + [""] * (width - len(row))) + " |"
    return "\n".join([cells(matrix[0]), "|" + "---|" * width] +
                     [cells(row) for row in matrix[1:]])

def build_tat_context(context):
    table = context["table"]["table"]
    paras = sorted(context.get("paragraphs", []), key=lambda x: x.get("order", 0))
    return "Financial table:\n" + render_table(table) + "\n\nRelated paragraphs:\n" + (
        "\n".join(f"[{p.get('order', i + 1)}] {p.get('text', '')}" for i, p in enumerate(paras))
        if paras else "(none)")

def audit(ds, rows, source):
    issues = []
    ids, question_context = defaultdict(list), defaultdict(list)
    for index, r in enumerate(rows):
        sid = r.get("id")
        ids[str(sid)].append(index)
        query = r.get("query")
        t = r.get("table")
        gold = r.get("gold")
        if not isinstance(query, str) or not query.strip(): issues.append((sid, "missing_query"))
        if not isinstance(t, dict) or not t.get("content") and not t.get("rows"):
            issues.append((sid, "missing_table"))
        if not isinstance(gold, dict) or not isinstance(gold.get("ambiguous_conditions"), list):
            issues.append((sid, "missing_gold_dimensions"))
        pairs = gold.get("condition_answer_pairs") if isinstance(gold, dict) else None
        if not isinstance(pairs, list) or not pairs: issues.append((sid, "missing_pairs"))
        else:
            for j, p in enumerate(pairs):
                if not isinstance(p, dict) or not isinstance(p.get("conditions"), dict) or not p["conditions"] or p.get("answer") is None:
                    issues.append((sid, f"malformed_pair_{j}"))
        # Include all table fields for transaction tables; IDs alone are never a dedup key.
        question_context[(norm(query), norm(json.dumps(t, ensure_ascii=False, sort_keys=True)))].append(sid)
    dup_ids = {k: v for k, v in ids.items() if len(v) > 1}
    dup_context = {k: v for k, v in question_context.items() if len(v) > 1 and k[0]}
    lookup = sum(bool(re.search(r"\|\s*condition\s*\|\s*answer\s*\|", str((r.get("table") or {}).get("content", "")), re.I)) for r in rows)
    summary = {"dataset": ds, "file": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
               "queries": len(rows), "ids_unique": len(ids), "duplicate_id_groups": len(dup_ids),
               "duplicate_query_context_groups": len(dup_context), "answer_lookup_tables": lookup,
               "issues": len(issues)}
    detail = [{"dataset": ds, "id": sid, "issue": msg} for sid, msg in issues]
    detail += [{"dataset": ds, "id": ",".join(map(str, v)), "issue": "duplicate_id"} for v in dup_ids.values()]
    detail += [{"dataset": ds, "id": ",".join(map(str, v)), "issue": "duplicate_query_and_context"} for v in dup_context.values()]
    return summary, detail

def restore_tat(sample_path, upstream_path, train_path, dev_path, out):
    samples = read_jsonl(sample_path)
    upstream = read_json(upstream_path)
    originals = {"train": read_json(train_path), "dev": read_json(dev_path)}
    if len(samples) != 200 or len({r.get("id") for r in samples}) != 200:
        raise ValueError("TAT-QA sample must have exactly 200 unique IDs")
    if len(upstream) != 610:
        raise ValueError(f"Expected 610 upstream TAT-QA records, got {len(upstream)}")
    # Original IDs are generated sequentially; check query before trusting the index.
    by_question = defaultdict(list)
    for x in upstream:
        by_question[(norm(x.get("ambiguous_question")), norm(x.get("original_question")))].append(x)
    rebuilt, report = [], []
    for sample in samples:
        meta = sample.get("metadata") or {}
        original_meta = meta.get("metadata") or {}
        key = (norm(sample.get("query")), norm(meta.get("original_query")))
        candidates = by_question.get(key, [])
        context_idx = meta.get("context_idx", original_meta.get("context_idx"))
        candidates = [x for x in candidates if x.get("split") == meta.get("split", x.get("split")) and
                      (context_idx is None or x.get("context_idx") == context_idx)]
        # The generated tatqa_000NNN ID points to the corresponding entry in
        # the 610-record construction file. Check every identifying field before use.
        m = re.fullmatch(r"tatqa_(\d{6})", str(sample.get("id", "")))
        if len(candidates) != 1 and m and int(m.group(1)) < len(upstream):
            by_id = upstream[int(m.group(1))]
            if by_id in candidates and norm(by_id.get("ambiguous_question")) == key[0] and \
               norm(by_id.get("original_question")) == key[1] and \
               (context_idx is None or by_id.get("context_idx") == context_idx):
                candidates = [by_id]
        status, x, context = "", None, None
        if len(candidates) != 1:
            status = f"upstream_match_count_{len(candidates)}"
        else:
            x = candidates[0]
            split, idx = x["split"], x["context_idx"]
            if not isinstance(idx, int) or not 0 <= idx < len(originals[split]):
                status = "bad_context_idx"
            else:
                context = originals[split][idx]
                qs = [q for q in context.get("questions", []) if norm(q.get("question")) == norm(x.get("original_question"))]
                if len(qs) != 1:
                    status = f"original_question_match_count_{len(qs)}"
                else:
                    matrix = context["table"]["table"]
                    evidence = [row for c in x.get("conditions", [])
                                for row in ([c["evidence_row"]] if "evidence_row" in c else c.get("evidence_rows", []))]
                    if not evidence or any(row not in matrix for row in evidence):
                        status = "evidence_row_missing"
                    else:
                        # Compare condition sets and rendered gold answers with the fixed input.
                        gold_pairs = sample["gold"]["condition_answer_pairs"]
                        gold_cond = [norm(v) for p in gold_pairs for v in p["conditions"].values()]
                        upstream_cond = [norm(c["condition"]) for c in x["conditions"]]
                        expected_pairs = Counter((norm(c["condition"]), norm(
                            str(c.get("answer", "")) + (" " + str(c["scale"]) if c.get("scale") else "")))
                            for c in x["conditions"])
                        actual_pairs = Counter((norm(next(iter(p["conditions"].values()), "")), norm(p.get("answer", "")))
                                               for p in gold_pairs)
                        if Counter(gold_cond) != Counter(upstream_cond):
                            status = "gold_conditions_differ"
                        elif actual_pairs != expected_pairs:
                            status = "gold_answers_differ"
                        else:
                            status = "matched"
        record = {"id": sample.get("id"), "status": status,
                  "split": x.get("split") if x else None,
                  "context_idx": x.get("context_idx") if x else None,
                  "table_uid": context["table"].get("uid") if context else None,
                  "original_question": x.get("original_question") if x else meta.get("original_query"),
                  "query": sample.get("query"), "pairs": len(sample.get("gold", {}).get("condition_answer_pairs", []))}
        report.append(record)
        if status == "matched":
            r = dict(sample)
            r["table"] = {"type": "text", "content": build_tat_context(context)}
            r["metadata"] = dict(meta, evidence_source="TAT-QA train/dev", source_split=x["split"],
                                 source_context_idx=x["context_idx"], source_table_uid=context["table"].get("uid"))
            rebuilt.append(r)
    write_csv(out / "tatqa_recovery_report.csv", report,
              ["id", "status", "split", "context_idx", "table_uid", "original_question", "query", "pairs"])
    counts = Counter(r["status"] for r in report)
    if len(rebuilt) == 200:
        write_jsonl(out / "candidate" / "tatqa.jsonl", rebuilt)
    (out / "tatqa_recovery_summary.json").write_text(json.dumps({"statuses": dict(counts),
        "candidate_created": len(rebuilt) == 200, "note": "Candidate changes the evidence context; validate answer correctness and run comparable models on the same version."},
        ensure_ascii=False, indent=2), encoding="utf-8")
    return counts

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inputs", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    inp, out = args.inputs, args.out
    out.mkdir(parents=True, exist_ok=True)
    summaries, issues = [], []
    found = {}
    for ds, prefixes in FILE_PREFIXES.items():
        path = locate(inp, prefixes, ".jsonl")
        if path:
            found[ds] = path
            summary, detail = audit(ds, read_jsonl(path), path)
            summaries.append(summary)
            issues.extend(detail)
        else:
            summaries.append({"dataset": ds, "file": "MISSING"})
    write_csv(out / "all_dataset_audit.csv", summaries,
              ["dataset", "file", "sha256", "queries", "ids_unique", "duplicate_id_groups",
               "duplicate_query_context_groups", "answer_lookup_tables", "issues"])
    write_csv(out / "all_dataset_issues.csv", issues, ["dataset", "id", "issue"])
    u = locate(inp, ("tatqa_temporal_main_train_dev",), ".json")
    train = locate(inp, ("tatqa_dataset_train",), ".json")
    dev = locate(inp, ("tatqa_dataset_dev",), ".json")
    if "tatqa" in found and all((u, train, dev)):
        counts = restore_tat(found["tatqa"], u, train, dev, out)
        print("TAT-QA recovery:", dict(counts))
    else:
        print("TAT-QA recovery needs fixed TAT_QA_200_sampled_v1.jsonl + upstream train_dev + original train/dev JSON")
    if "nasa" in found:
        print("NASA blocked: existing 200 only has condition-answer lookup; original coordinates, parameter IDs, unit and aggregation must be recovered before rebuilding gold.")
    if "nyc311" in found:
        print("NYC311 audit only: use Geography v2 scorer for its E2E; original paper scorer cannot match concise borough conditions reliably.")
    print("Audit:", out / "all_dataset_audit.csv", "Issues:", out / "all_dataset_issues.csv")

if __name__ == "__main__":
    main()

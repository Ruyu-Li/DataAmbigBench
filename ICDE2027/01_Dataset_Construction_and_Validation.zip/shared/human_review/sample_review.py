"""Python 3, standard library only. python sample_review.py [--n 20 | --all]."""
import argparse
import hashlib
import html
import json
import random
from pathlib import Path

SOURCES = ['SEC', 'NASA_POWER', 'TAT_QA', 'Online_Retail_II', 'AmbigDocs', 'OpinionQA', 'US_Code', 'SF311']
FIELDS = {'natural': '问题表达自然、清楚', 'ambiguous': '存在至少两种合理且有证据支持的解释', 'dimension': '歧义维度标注正确', 'conditions': '所有条件合理、有证据支持且明确对应解释', 'coverage': '标注覆盖了上下文中明显的合理解释', 'answers': '所有条件对应的答案均正确'}

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def display(value):
    if isinstance(value, dict) and value.get('type') == 'markdown':
        value = value['content']
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, indent=2)
    return '<pre>' + html.escape(value) + '</pre>'

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data', type=Path, default=Path(__file__).parent / 'data')
    ap.add_argument('--output', type=Path, default=Path(__file__).parent / 'review_160')
    ap.add_argument('--seed', type=int, default=42)
    group = ap.add_mutually_exclusive_group()
    group.add_argument('--n', type=int, default=20, help='Number of queries per source')
    group.add_argument('--all', action='store_true', help='Include every query, without sampling')
    args = ap.parse_args()
    if args.n < 1:
        ap.error('--n must be positive')
    if args.output.exists():
        ap.error('Output already exists. Choose a new --output directory to preserve previous reviews.')
    selected, manifest = [], {'seed': args.seed, 'mode': 'all' if args.all else 'random_without_replacement_per_source', 'sources': {}}
    for source in SOURCES:
        path = args.data / (source + '.jsonl')
        rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
        ids = [r['id'] for r in rows]
        if len(set(ids)) != len(ids):
            raise ValueError(f'{source}: duplicate IDs')
        for r in rows:
            if not all(r.get(k) for k in ['id', 'query', 'table', 'gold']):
                raise ValueError(f'{source}: missing input/gold for {r.get("id")}')
            if not r['gold'].get('ambiguous_conditions') or not r['gold'].get('condition_answer_pairs'):
                raise ValueError(f'{source}: missing gold conditions/answers')
        rows.sort(key=lambda r: r['id'])
        if not args.all and len(rows) < args.n:
            raise ValueError(f'{source}: fewer than {args.n} queries')
        # Independent source seeds: adding another source does not change existing samples.
        source_seed = int(hashlib.sha256(f'{args.seed}:{source}'.encode()).hexdigest(), 16)
        chosen = rows if args.all else random.Random(source_seed).sample(rows, args.n)
        for r in chosen:
            r['review_key'] = source + '::' + r['id']
        selected.extend(chosen)
        manifest['sources'][source] = {'population': len(rows), 'sample_size': len(chosen), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'selected_ids': [r['id'] for r in chosen]}
    args.output.mkdir(parents=True)
    dump(args.output / 'sampling_manifest.json', manifest)
    (args.output / 'sampled_records.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in selected), encoding='utf-8')
    cards, blank = [], []
    for i, r in enumerate(selected):
        key = r['review_key']
        blank.append({'review_key': key, 'source': r['source'], 'id': r['id'], 'reviewer': '', **{f: '' for f in FIELDS}, 'independent_interpretations': '', 'notes': '', 'pair_checks': [{'pair_index': j + 1, 'condition_ok': '', 'answer_ok': '', 'notes': ''} for j in range(len(r['gold']['condition_answer_pairs']))]})
        selects = ''.join(f'<label>{html.escape(label)} <select data-field="{f}"><option value="">待审核</option><option>是</option><option>否</option><option>不确定</option></select></label>' for f, label in FIELDS.items())
        pairs = ''.join('<div class="pair">' + display(p) + f'<label>条件判断 <select data-pair="{j}" data-pfield="condition_ok"><option value="">待审核</option><option>是</option><option>否</option><option>不确定</option></select></label><label>答案判断 <select data-pair="{j}" data-pfield="answer_ok"><option value="">待审核</option><option>是</option><option>否</option><option>不确定</option></select></label><textarea data-pair="{j}" data-pfield="notes" placeholder="该条件/答案的问题及证据位置"></textarea></div>' for j, p in enumerate(r['gold']['condition_answer_pairs']))
        supplemental = '<details><summary>补充：TAT-QA 原始上下文（不是替换实验输入）</summary>' + display(r['supplemental_original_context']) + '</details>' if 'supplemental_original_context' in r else ''
        cards.append(f'<article data-index="{i}"><h2>{i+1}. {html.escape(key)}</h2><h3>{html.escape(r["query"])}</h3><h4>实验输入中的证据</h4>{display(r["table"])}<label>先记录自己的解释<textarea data-field="independent_interpretations"></textarea></label><details><summary>完成初步判断后展开 gold 标注</summary>{display(r["gold"]["ambiguous_conditions"])}{pairs}</details>{supplemental}<div class="checks">{selects}</div><label>问题说明、证据位置、修改建议<textarea data-field="notes"></textarea></label></article>')
    dump(args.output / 'review_blank.json', blank)
    initial = json.dumps(blank, ensure_ascii=False).replace('<', '\\u003c')
    token = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()[:16]
    page = '''<!doctype html><html lang="zh"><meta charset="utf-8"><title>人工审核</title>
<style>body{font:16px/1.6 system-ui;margin:0;background:#f3f5f7;color:#243449}header,main{max-width:1100px;margin:auto;padding:24px}header{position:sticky;top:0;background:#eaf0f6;z-index:2}article{background:white;padding:24px;margin:24px 0;border-radius:10px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.6 monospace;background:#f6f8fa;padding:16px}label{display:block;margin:12px 0}select,button,input{padding:8px;font:inherit}textarea{display:block;width:98%;min-height:70px;font:inherit}summary{cursor:pointer;font-weight:bold;padding:12px;background:#edf2f7}.pair{border-left:3px solid #789;padding:12px;margin:12px 0}.checks{display:grid;grid-template-columns:1fr 1fr;gap:12px}</style>
<header><strong>人工审核 · 每条题目检查所有条件与答案</strong><br><input id="reviewer" placeholder="审核人姓名"><button onclick="downloadReview()">导出审核结果 JSON</button><label>恢复已导出的结果 <input type="file" id="restore" accept=".json"></label><span id="status"></span></header><main><p>先看问题与实验输入证据，记录自己的解释，再展开 gold。是＝通过；否＝有问题；不确定＝无法判断。所有判断初始留空。SEC/NASA 的源数据提取正确性不在本包可验证范围内。请经常导出结果；浏览器本地保存不能代替下载备份。</p>''' + ''.join(cards) + '</main><script>const initial=' + initial + ';const storageKey="human-review-' + token + '";'
    page += '''let state=structuredClone(initial);try{const old=JSON.parse(localStorage.getItem(storageKey));if(old&&old.length===state.length&&old.every((r,i)=>r.review_key===state[i].review_key))state=old}catch(e){}
function status(){document.getElementById('status').textContent=state.filter(r=>['natural','ambiguous','dimension','conditions','coverage','answers'].every(k=>r[k])&&r.pair_checks.every(p=>p.condition_ok&&p.answer_ok)).length+' / '+state.length+' 条已填写全部判断'}
function persist(){try{localStorage.setItem(storageKey,JSON.stringify(state))}catch(e){}status()}
function render(){document.getElementById('reviewer').value=state[0]?.reviewer||'';document.querySelectorAll('article').forEach(a=>{const r=state[+a.dataset.index];a.querySelectorAll('[data-field]').forEach(el=>el.value=r[el.dataset.field]||'');a.querySelectorAll('[data-pair]').forEach(el=>el.value=r.pair_checks[+el.dataset.pair][el.dataset.pfield]||'')});status()}
document.querySelectorAll('article').forEach(a=>a.addEventListener('input',e=>{const el=e.target,r=state[+a.dataset.index];if(el.dataset.field)r[el.dataset.field]=el.value;if(el.dataset.pair!==undefined)r.pair_checks[+el.dataset.pair][el.dataset.pfield]=el.value;persist()}));
document.getElementById('reviewer').addEventListener('input',e=>{state.forEach(r=>r.reviewer=e.target.value);persist()});
function downloadReview(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(state,null,2)],{type:'application/json'}));a.download='human_review_results.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
document.getElementById('restore').addEventListener('change',async e=>{try{const x=JSON.parse(await e.target.files[0].text());if(x.length!==initial.length||!x.every((r,i)=>r.review_key===initial[i].review_key&&Array.isArray(r.pair_checks)&&r.pair_checks.length===initial[i].pair_checks.length))throw Error('样本不匹配');state=x;render();persist()}catch(err){alert('导入失败：'+err.message)}});render();</script></html>'''
    (args.output / 'review.html').write_text(page, encoding='utf-8')
    print(f'Created {len(selected)} queries / {sum(len(r["gold"]["condition_answer_pairs"]) for r in selected)} condition-answer pairs in {args.output}')

if __name__ == '__main__':
    main()

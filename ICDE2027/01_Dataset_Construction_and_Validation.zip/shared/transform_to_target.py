"""
Transform raw CondAmbigQA samples into SCDDR target format.

Input:  examples/samples_raw.json     (student's current format)
Output: examples/samples_target.json  (our target format)

What this does:
1. Compress long condition → short condition (1-2 sentences)
2. Extract short answer from long answer paragraph
3. Assign query_type (selection/aggregation/ranking/comparison)
4. Assign state_dimensions (from our 8-category taxonomy)
5. Flag problematic entries (e.g., same answer across conditions)

Usage:
    set OPENAI_API_KEY=sk-...
    python transform_to_target.py

    # Dry run (no API calls, rule-based extraction only):
    python transform_to_target.py --dry-run
"""

import json
import os
import re
import sys
import time
from pathlib import Path

#  Config 
INPUT_PATH  = Path(__file__).parent / "samples_raw.json"
OUTPUT_PATH = Path(__file__).parent / "samples_target_generated.json"

VALID_QUERY_TYPES = ["selection", "aggregation", "ranking", "comparison"]
VALID_DIMENSIONS  = [
    "Temporal", "Definition-Metric", "Geography",
    "Entity Disambiguation", "Version-Policy-Standard",
    "Perspective", "Event Status", "Granularity"
]

#  LLM Prompt 
TRANSFORM_PROMPT = """You are restructuring a QA dataset entry. Given the raw fields, produce the target format.

**Raw input:**
- query: {query}
- condition (long): {condition}
- answer (long): {answer}

**Your task — produce a JSON with these fields:**

1. "short_condition": Rewrite the condition as a short phrase (max 80 chars). Just state what analytical choice is being made. No background, no explanation, no answer leakage.
   Good: "Founded as an institution"
   Bad:  "The question refers to the founding date of the California Academy of Sciences as an institution, not the construction date of its physical buildings."

2. "short_answer": Extract ONLY the core factual answer (a name, number, or short phrase, max 30 words). No explanation.
   Good: "1853"
   Bad:  "Under this condition, the California Academy of Sciences was 'built' in the sense of being founded in 1853. This year marks..."

3. "source": Just put "TBD" as a placeholder. This will be filled in during human verification.

4. "query_type": One of: selection, aggregation, ranking, comparison
   - selection: "which / what / who / where / when?"
   - aggregation: "how many / how much / total / average?"
   - ranking: "top N / greatest / longest / most?"
   - comparison: "A vs B / is X bigger than Y?"

5. "state_dimensions": A list from: {dims}
   Pick the one(s) that best describe WHY the condition changes the answer.

Respond in JSON only:
{{"short_condition": "...", "short_answer": "...", "source": "...", "query_type": "...", "state_dimensions": [...]}}"""


#  Rule-based fallback (no API) 

def extract_short_answer_rule(answer: str) -> str:
    """Try to extract a short answer from the long paragraph using heuristics."""
    # Look for patterns like "was founded in 1853", "is voiced by X", "answer is X"
    patterns = [
        r"(?:was|were|is|are)\s+(?:founded|built|completed|established|released)\s+(?:in|on)\s+(\d{4})",
        r"(?:voiced?\s+by|played?\s+by|portrayed?\s+by)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,3})",
        r"(?:is|was|are|were)\s+(?:called|named|known\s+as)\s+[\"']?([^\"'.]+)[\"']?",
        r"(?:holds?\s+the\s+title|is\s+noted\s+as).+?(?:is|with)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,3})",
        r"(\d[\d,.]+(?:\s*(?:million|billion|%|meters?|km))?\b)",
    ]
    for pat in patterns:
        m = re.search(pat, answer, re.IGNORECASE)
        if m:
            return m.group(1).strip()
    # Fallback: first sentence, truncated
    first_sent = answer.split(".")[0].strip()
    if len(first_sent) > 100:
        first_sent = first_sent[:100] + "..."
    return first_sent


def shorten_condition_rule(condition: str) -> str:
    """Shorten condition using simple heuristics."""
    # Remove common prefixes
    prefixes = [
        r"^The question (?:refers to|focuses on|could (?:refer|be interpreted))\s+",
        r"^The account with the greatest.*?(?:,\s*)",
        r"^(?:Under this (?:condition|interpretation),?\s*)",
        r"^(?:Identify|Consider|Focus on)\s+",
    ]
    short = condition
    for p in prefixes:
        short = re.sub(p, "", short, flags=re.IGNORECASE)

    # Truncate if still too long
    if len(short) > 80:
        # Try to cut at a natural boundary
        for sep in [",", ";", " not ", " focusing on "]:
            idx = short.find(sep)
            if 15 < idx < 80:
                short = short[:idx]
                break
        else:
            short = short[:77] + "..."
    return short.strip().rstrip(".")


def guess_query_type(query: str) -> str:
    """Heuristic query_type assignment."""
    q = query.lower()
    if any(w in q for w in ["how many", "how much", "total", "average", "cost", "rate"]):
        return "aggregation"
    if any(w in q for w in ["greatest", "most", "longest", "largest", "top", "best", "highest"]):
        return "ranking"
    if any(w in q for w in [" or ", "vs", "compare", "bigger", "more than"]):
        return "comparison"
    return "selection"


def guess_state_dimensions(condition: str, query: str) -> list:
    """Heuristic state_dimension assignment."""
    c = (condition + " " + query).lower()
    dims = []
    if any(w in c for w in ["founded", "built", "construction", "current form", "original", "definition", "measure", "metric", "meaning"]):
        dims.append("Definition-Metric")
    if any(w in c for w in ["version", "edition", "english", "language", "standard", "policy", "maori"]):
        dims.append("Version-Policy-Standard")
    if any(w in c for w in ["fictional", "filming location", "setting", "perspective", "viewpoint", "brand", "individual", "personal"]):
        dims.append("Perspective")
    if any(w in c for w in ["time", "year", "date", "when", "period", "as of", "2023", "2022"]):
        dims.append("Temporal")
    if any(w in c for w in ["region", "country", "city", "location", "area", "geographic"]):
        dims.append("Geography")
    if any(w in c for w in ["nickname", "person", "plant", "refers to a", "disambiguation"]):
        dims.append("Entity Disambiguation")
    if any(w in c for w in ["phase", "status", "stage", "ongoing", "completed"]):
        dims.append("Event Status")
    if any(w in c for w in ["per capita", "household", "individual level", "daily", "monthly", "aggregate"]):
        dims.append("Granularity")
    return dims if dims else ["Definition-Metric"]


#  LLM-based transform 

def transform_with_llm(query: str, condition: str, answer: str, api_key: str) -> dict:
    """Use OpenAI to compress and classify."""
    try:
        import openai
    except ImportError:
        print("ERROR: pip install openai"); sys.exit(1)

    client = openai.OpenAI(api_key=api_key)
    prompt = TRANSFORM_PROMPT.format(
        query=query, condition=condition, answer=answer,
        dims=", ".join(VALID_DIMENSIONS)
    )
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        temperature=0,
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"},
    )
    return json.loads(resp.choices[0].message.content)


#  Main 

def transform_entry(entry: dict, api_key: str = None, dry_run: bool = False) -> dict:
    """Transform one raw entry into target format."""
    query = entry["query"]

    # Get query_type and state_dimensions from first pass (same for all instances)
    if dry_run or not api_key:
        query_type = guess_query_type(query)
        state_dims = guess_state_dimensions(
            " ".join(inst["condition"] for inst in entry["instances"]), query
        )
    else:
        # Use first instance to determine query-level fields
        first_result = transform_with_llm(query, entry["instances"][0]["condition"],
                                           entry["instances"][0]["answer"], api_key)
        query_type = first_result.get("query_type", guess_query_type(query))
        state_dims = first_result.get("state_dimensions", ["Definition-Metric"])

    # Build instances
    instances = []
    for inst in entry["instances"]:
        if dry_run or not api_key:
            short_cond = shorten_condition_rule(inst["condition"])
            short_ans  = extract_short_answer_rule(inst["answer"])
            source     = "TBD"
        else:
            result = transform_with_llm(query, inst["condition"], inst["answer"], api_key)
            short_cond = result.get("short_condition", shorten_condition_rule(inst["condition"]))
            short_ans  = result.get("short_answer", extract_short_answer_rule(inst["answer"]))
            source     = result.get("source", "Wikipedia")
            time.sleep(0.5)

        instances.append({
            "cond_id": inst["cond_id"],
            "condition": short_cond,
            "answer": short_ans,
            "gold_long": inst["answer"],
            "source": source,
        })

    # Validate: flag if all answers are the same
    answers = [inst["answer"] for inst in instances]
    note = None
    if len(set(answers)) < 2:
        note = f"FLAGGED: all conditions yield the same answer ('{answers[0]}'). Consider removing."

    result = {
        "query_id": entry["query_id"],
        "query": query,
        "query_type": query_type if query_type in VALID_QUERY_TYPES else "selection",
        "state_dimensions": [d for d in state_dims if d in VALID_DIMENSIONS] or ["Definition-Metric"],
        "instances": instances,
    }
    if note:
        result["note"] = note
    return result


def validate(entries: list[dict]) -> None:
    """Validate all entries and print warnings."""
    print("\n=== Validation ===")
    errors = 0
    for e in entries:
        qid = e["query_id"]
        # Check query_type
        if e["query_type"] not in VALID_QUERY_TYPES:
            print(f"  ERROR {qid}: invalid query_type '{e['query_type']}'")
            errors += 1
        # Check state_dimensions
        for d in e["state_dimensions"]:
            if d not in VALID_DIMENSIONS:
                print(f"  ERROR {qid}: invalid dimension '{d}'")
                errors += 1
        # Check instances
        if len(e["instances"]) < 2:
            print(f"  ERROR {qid}: only {len(e['instances'])} instance(s), need >= 2")
            errors += 1
        # Check answer uniqueness
        answers = [inst["answer"] for inst in e["instances"]]
        if len(set(answers)) < 2:
            print(f"  WARNING {qid}: all answers identical -> '{answers[0]}'")
            errors += 1
        # Check condition length
        for inst in e["instances"]:
            if len(inst["condition"]) > 150:
                print(f"  WARNING {qid} cond={inst['cond_id']}: condition too long ({len(inst['condition'])} chars)")
                errors += 1
            if len(inst["answer"]) > 200:
                print(f"  WARNING {qid} cond={inst['cond_id']}: answer too long ({len(inst['answer'])} chars)")
                errors += 1
    print(f"  Total: {len(entries)} entries, {errors} issue(s)")


def print_summary(entries: list[dict]) -> None:
    """Print a summary table of all entries."""
    print("\n=== Summary ===")
    print(f"{'ID':<30} {'Type':<14} {'Dims':<30} {'#Inst':<6} {'Answers'}")
    print("-" * 120)
    for e in entries:
        answers = " | ".join(inst["answer"][:40] for inst in e["instances"])
        dims = ", ".join(e["state_dimensions"])
        flag = " ** SAME ANSWER **" if "note" in e else ""
        print(f"{str(e['query_id']):<30} {e['query_type']:<14} {dims:<30} {len(e['instances']):<6} {answers}{flag}")

    # Dimension coverage
    print("\n=== Dimension Coverage ===")
    dim_counts = {}
    for e in entries:
        for d in e["state_dimensions"]:
            dim_counts[d] = dim_counts.get(d, 0) + 1
    for d in VALID_DIMENSIONS:
        count = dim_counts.get(d, 0)
        bar = "#" * count
        status = "OK" if count > 0 else "MISSING"
        print(f"  {d:<30} {count:>3}  {bar}  {status}")


def main():
    dry_run = "--dry-run" in sys.argv

    # Support --api-key=sk-... so user doesn't need env var
    api_key = None
    for arg in sys.argv:
        if arg.startswith("--api-key="):
            api_key = arg.split("=", 1)[1]
    if not api_key:
        api_key = os.environ.get("OPENAI_API_KEY")

    if not dry_run and not api_key:
        print("No API key found. Use --api-key=sk-... or set OPENAI_API_KEY env var.")
        print("Running in --dry-run mode (rule-based only).")
        dry_run = True

    # Load
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        raw_entries = json.load(f)
    print(f"Loaded {len(raw_entries)} raw entries from {INPUT_PATH.name}")

    # Transform
    results = []
    for i, entry in enumerate(raw_entries):
        print(f"\n[{i+1}/{len(raw_entries)}] {entry['query'][:60]}...")
        target = transform_entry(entry, api_key, dry_run)
        results.append(target)
        # Show what was produced
        for inst in target["instances"]:
            print(f"  cond={inst['cond_id']}: \"{inst['condition']}\" -> \"{inst['answer']}\"")

    # Validate & summarize
    validate(results)
    print_summary(results)

    # Write
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"\nWritten to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()

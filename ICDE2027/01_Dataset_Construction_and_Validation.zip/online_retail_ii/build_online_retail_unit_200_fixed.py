#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build audited 200-query Unit ambiguity subset from Online Retail II.

Two JSONL contracts:
  *_standard.jsonl: each record has id/query/table/gold, plus legacy evaluator aliases.
  *_model_inputs.jsonl: id/query/table ONLY (no gold, labels or answers).
  *_condition_inputs.jsonl: id/query/table/condition/condition_query ONLY, no answers.

Gold answers are ALWAYS derived from the exact table in each model input.
No API / model inference occurs in this builder. Human QA remains necessary.
"""
import argparse
import json
import math
import re
from collections import Counter
from pathlib import Path
import numpy as np
import pandas as pd

CONDITIONS = ["by day", "by week", "by month", "by quarter", "by year-sheet"]
N_PER_FAMILY = 25
N_ROWS = 84
MIN_ROWS = 64
TABLE_COLUMNS = ["Invoice", "StockCode", "Description", "Quantity", "InvoiceDate", "Price", "CustomerID", "Country", "source_sheet"]
FAMILY_CONFIG = [
    ("revenue_extremes", ["revenue_max", "revenue_min"]),
    ("transaction_activity", ["invoices_max", "invoices_min"]),
    ("product_assortment", ["sku_count_max", "top_product_share_min"]),
    ("customer_reach", ["customers_max", "identified_invoice_count_max"]),
    ("invoice_economics", ["avg_invoice_value_max", "avg_invoice_value_min"]),
    ("basket_composition", ["avg_units_per_invoice_max", "avg_skus_per_invoice_max"]),
    ("single_product_performance", ["revenue_max", "quantity_max"]),
    ("revenue_change", ["revenue_increase_max", "revenue_decrease_max"]),
]

METRIC_META = {
    "revenue_max": ("total sales", "highest", "Total sales = sum(Quantity × Price)", "total revenue"),
    "revenue_min": ("total sales", "lowest", "Total sales = sum(Quantity × Price)", "total revenue"),
    "invoices_max": ("distinct invoice count", "highest", "Number of distinct Invoice identifiers per period", "distinct invoices"),
    "invoices_min": ("distinct invoice count", "lowest", "Number of distinct Invoice identifiers per period", "distinct invoices"),
    "sku_count_max": ("product variety", "highest", "Number of distinct StockCode values per period", "distinct products"),
    "top_product_share_min": ("largest-product sales share", "lowest", "Maximum individual StockCode revenue divided by period total revenue", "top product revenue share"),
    "customers_max": ("unique purchasing customers", "highest", "Number of distinct nonmissing CustomerID values per period", "unique customers"),
    "identified_invoice_count_max": ("invoices from identified customers", "highest", "Count distinct Invoice where CustomerID is nonmissing", "invoices from identified customers"),
    "avg_invoice_value_max": ("average invoice value", "highest", "Total sales in period / distinct invoices in period", "average invoice value"),
    "avg_invoice_value_min": ("average invoice value", "lowest", "Total sales in period / distinct invoices in period", "average invoice value"),
    "avg_units_per_invoice_max": ("average units per invoice", "highest", "Sum(Quantity) in period / distinct invoices in period", "average units per invoice"),
    "avg_skus_per_invoice_max": ("average unique products per invoice", "highest", "Mean distinct StockCodes per invoice within each period", "average distinct products per invoice"),
    "quantity_max": ("total quantity sold", "highest", "Sum(Quantity) per period", "total units sold"),
    "revenue_increase_max": ("increase in total sales from the previous observed period", "largest", "Current period sales minus previous observed period sales", "revenue increase"),
    "revenue_decrease_max": ("decrease in total sales from the previous observed period", "largest", "Previous observed period sales minus current period sales", "revenue decrease"),
}


def normalize_missing(x):
    if pd.isna(x) or str(x).strip().lower() in {"", "nan", "none", "nat", "<na>"}:
        return None
    return str(x).strip()


def load_source(source: Path):
    if not source.exists():
        raise FileNotFoundError(f"Cannot find source: {source}")
    print("[1/5] Loading source:", source)
    if source.suffix.lower() == ".xlsx":
        sheets = pd.read_excel(source, sheet_name=None)
        arr = []
        for sn, frame in sheets.items():
            frame = frame.copy()
            frame["source_sheet"] = sn
            arr.append(frame)
        df = pd.concat(arr, ignore_index=True)
    elif source.suffix.lower() == ".parquet":
        df = pd.read_parquet(source)
    else:
        df = pd.read_csv(source, low_memory=False)

    # The original UCI Online Retail II workbook uses "Customer ID" (with a space),
    # while downstream code expects "CustomerID". Accept formatting variations
    # across all required columns, without changing their data or meanings.
    canonical = {re.sub(r"[^a-z0-9]", "", c.lower()): c for c in TABLE_COLUMNS}
    rename_map = {}
    used = set()
    for original in df.columns:
        normalized = re.sub(r"[^a-z0-9]", "", str(original).strip().lower())
        target = canonical.get(normalized)
        if target is not None:
            if target in used:
                raise ValueError(f"Multiple input columns map to the same field {target!r}; original columns: {list(df.columns)}")
            used.add(target)
            if str(original) != target:
                rename_map[original] = target
    if rename_map:
        print("    Normalized column names:", rename_map)
        df = df.rename(columns=rename_map)

    needed = set(TABLE_COLUMNS) - set(df.columns)
    if needed:
        raise ValueError(f"Required columns absent: {sorted(needed)}. Original sheet labels are essential.")
    df = df[TABLE_COLUMNS].copy()
    df["Invoice"] = df["Invoice"].astype("string").str.strip()
    df["StockCode"] = df["StockCode"].astype("string").str.strip()
    df["Description"] = df["Description"].astype("string").fillna("").str.strip()
    df["Country"] = df["Country"].astype("string").str.strip()
    df["source_sheet"] = df["source_sheet"].astype("string").str.strip()
    df["CustomerID"] = df["CustomerID"].map(normalize_missing)
    df["CustomerID"] = df["CustomerID"].map(lambda x: re.sub(r"\.0$", "", x) if x is not None else None)
    df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")
    df["Price"] = pd.to_numeric(df["Price"], errors="coerce")
    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"], errors="coerce")
    valid = (
        df["InvoiceDate"].notna() & df["Invoice"].notna() & df["StockCode"].notna()
        & df["Country"].notna() & df["source_sheet"].notna()
        & df["Quantity"].gt(0) & df["Price"].gt(0)
        & ~df["Invoice"].str.upper().str.startswith("C", na=False)
    )
    df = df.loc[valid].copy()
    df["Revenue"] = df["Quantity"] * df["Price"]
    df["day_key"] = df["InvoiceDate"].dt.strftime("%Y-%m-%d")
    sheets = sorted(df["source_sheet"].dropna().unique())
    if len(sheets) != 2:
        raise ValueError(f"Expected 2 original year-sheets, found {sheets}; by year-sheet needs two source sheets.")
    print("    Clean rows:", len(df), "| countries:", df["Country"].nunique(), "| sheets:", sheets)
    return df, sheets


def select_context(pool, sheets, rng, nrows=N_ROWS):
    """Sample real transactions, balanced over two original sheets and spread over dates.
    The sample table, not the full workbook, defines the QA universe.
    """
    pivot = int(rng.choice([35, 37, 39, 43, 45, 47]))
    targets = [pivot, nrows - pivot]
    picks = []
    for sheet, target in zip(sheets, targets):
        sub = pool.loc[pool["source_sheet"] == sheet]
        if len(sub) < target:
            return None
        groups = sub.groupby("day_key", sort=True).indices
        keys = np.array(sorted(groups.keys()), dtype=object)
        if len(keys) < 5:
            return None
        # Prefer a moderate number of observed dates, rather than 84 single-line dates.
        # Randomized date selection creates different, reproducible source-table contexts.
        n_dates = min(len(keys), int(rng.integers(7, 15)))
        eligible = sorted(keys, key=lambda k: len(groups[k]), reverse=True)
        strong = [k for k in eligible if len(groups[k]) >= 2]
        if len(strong) >= n_dates:
            selection = rng.choice(np.asarray(strong, dtype=object), size=n_dates, replace=False)
        else:
            selection = rng.choice(keys, size=n_dates, replace=False)
        chosen = []
        by_day_indices = {}
        for k in selection:
            pos = np.asarray(groups[str(k)], dtype=int)
            rng.shuffle(pos)
            by_day_indices[str(k)] = list(sub.iloc[pos].index)
        active = [str(k) for k in selection]
        rng.shuffle(active)
        while len(chosen) < target:
            progressed = False
            rng.shuffle(active)
            for k in active:
                if by_day_indices[k]:
                    chosen.append(by_day_indices[k].pop())
                    progressed = True
                    if len(chosen) == target:
                        break
            if not progressed:
                break
        if len(chosen) < target:
            # Fill from other real rows in this sheet if the selected dates were too sparse.
            extra = sub.index.difference(pd.Index(chosen)).to_numpy()
            if len(extra) < target - len(chosen):
                return None
            chosen.extend(rng.choice(extra, size=target - len(chosen), replace=False).tolist())
        picks.extend(chosen)
    out = pool.loc[picks, TABLE_COLUMNS].copy()
    out = out.sort_values(["InvoiceDate", "Invoice", "StockCode"], kind="stable").reset_index(drop=True)
    return out


def encode_table(tab, title):
    records = []
    for x in tab[TABLE_COLUMNS].to_dict(orient="records"):
        row = {}
        for k, v in x.items():
            if k == "InvoiceDate":
                row[k] = pd.Timestamp(v).strftime("%Y-%m-%d %H:%M:%S")
            elif k == "Quantity":
                row[k] = int(v) if float(v).is_integer() else float(v)
            elif k == "Price":
                row[k] = float(v)
            else:
                row[k] = normalize_missing(v)
        records.append(row)
    return {"title": title, "header": TABLE_COLUMNS, "rows": records}


def decode_table(table):
    out = pd.DataFrame(table["rows"])
    out["InvoiceDate"] = pd.to_datetime(out["InvoiceDate"])
    out["Quantity"] = pd.to_numeric(out["Quantity"])
    out["Price"] = pd.to_numeric(out["Price"])
    out["Revenue"] = out["Quantity"] * out["Price"]
    out["CustomerID"] = out["CustomerID"].map(normalize_missing)
    return out


def periods(df, cond):
    d = pd.to_datetime(df["InvoiceDate"])
    if cond == "by day":
        return d.dt.strftime("%Y-%m-%d")
    if cond == "by week":
        iso = d.dt.isocalendar()
        return iso["year"].astype(str) + "-W" + iso["week"].astype(str).str.zfill(2)
    if cond == "by month":
        return d.dt.strftime("%Y-%m")
    if cond == "by quarter":
        return d.dt.to_period("Q").astype(str)
    if cond == "by year-sheet":
        return df["source_sheet"].astype(str)
    raise ValueError(cond)


def computed_metric(grp, code):
    if code in {"revenue_max", "revenue_min", "revenue_increase_max", "revenue_decrease_max"}:
        return float((grp["Quantity"] * grp["Price"]).sum())
    if code == "quantity_max":
        return float(grp["Quantity"].sum())
    if code in {"invoices_max", "invoices_min"}:
        return float(grp["Invoice"].nunique())
    if code == "sku_count_max":
        return float(grp["StockCode"].nunique())
    if code == "customers_max":
        return float(grp["CustomerID"].dropna().nunique())
    if code == "identified_invoice_count_max":
        return float(grp.loc[grp["CustomerID"].notna(), "Invoice"].nunique())
    if code in {"avg_invoice_value_max", "avg_invoice_value_min"}:
        denom = grp["Invoice"].nunique()
        return float(grp["Revenue"].sum() / denom) if denom else float("nan")
    if code == "avg_units_per_invoice_max":
        denom = grp["Invoice"].nunique()
        return float(grp["Quantity"].sum() / denom) if denom else float("nan")
    if code == "top_product_share_min":
        by_sku = grp.groupby("StockCode")["Revenue"].sum()
        return float(by_sku.max() / by_sku.sum()) if by_sku.sum() else float("nan")
    if code == "avg_skus_per_invoice_max":
        return float(grp.groupby("Invoice")["StockCode"].nunique().mean())
    raise ValueError(code)


def calculate_answers(tab, metric_code):
    """Compute each unit's answer FROM the provided table, rejecting ambiguous ties.
    Sorting by period labels is chronological for ISO weeks/months/quarters and
    for source-year sheets (Year 2009-2010, Year 2010-2011).
    """
    answers = []
    is_change = metric_code in {"revenue_increase_max", "revenue_decrease_max"}
    is_min = metric_code.endswith("_min")
    for cond in CONDITIONS:
        x = tab.copy()
        x["Revenue"] = x["Quantity"] * x["Price"]
        x["period"] = periods(x, cond)
        vals = []
        for p, g in x.groupby("period", sort=True):
            val = computed_metric(g, metric_code)
            if math.isfinite(val):
                vals.append((str(p), float(val)))
        vals.sort(key=lambda z: z[0])
        if len(vals) < 2:
            return None
        if is_change:
            processed = []
            for i in range(1, len(vals)):
                prev, cur = vals[i-1][1], vals[i][1]
                delta = cur - prev if metric_code == "revenue_increase_max" else prev - cur
                processed.append((vals[i][0], delta))
            vals = processed
        if not vals:
            return None
        values = np.array([v for _, v in vals], dtype=float)
        best = float(np.min(values) if is_min else np.max(values))
        # For greatest increase / decrease, require a strictly positive actual change.
        if is_change and best <= 0:
            return None
        tol = max(1e-9, abs(best) * 1e-10)
        if int(np.isclose(values, best, atol=tol, rtol=0).sum()) != 1:
            return None
        winner = next(p for p, v in vals if abs(v - best) <= tol)
        answers.append({"condition": cond, "answer": winner, "answer_value": round(best, 6),
                        "num_time_buckets": len(vals) + (1 if is_change else 0)})
    return answers


def make_question(code, country, product, style):
    product_clause = f" for StockCode {product}" if product else ""
    where = f" in {country}" if country else ""
    scope = " in the provided transaction table"
    specs = {
        "revenue_max": "total sales",
        "revenue_min": "total sales",
        "quantity_max": "total units sold",
        "invoices_max": "distinct invoices",
        "invoices_min": "distinct invoices",
        "sku_count_max": "distinct products",
        "top_product_share_min": "top-product revenue share (the largest single product revenue divided by total period sales)",
        "customers_max": "unique purchasing customers with known customer IDs",
        "identified_invoice_count_max": "invoices from customers with known customer IDs",
        "avg_invoice_value_max": "average invoice value",
        "avg_invoice_value_min": "average invoice value",
        "avg_units_per_invoice_max": "average units purchased per invoice",
        "avg_skus_per_invoice_max": "average distinct products per invoice",
        "revenue_increase_max": "increase in total sales relative to the previous observed period",
        "revenue_decrease_max": "decrease in total sales relative to the previous observed period",
    }
    metric = specs[code]
    if code in {"revenue_increase_max", "revenue_decrease_max"}:
        return [
            f"Which observed period had the largest {metric}{product_clause}{where}{scope}?",
            f"For the transactions shown, during which period was the {metric} greatest{product_clause}{where}?",
            f"Identify the period showing the greatest {metric}{product_clause}{where}, using this table.",
        ][style % 3]
    rank = "lowest" if code.endswith("_min") else "highest"
    if code == "invoices_min":
        rank = "fewest"
    if code == "invoices_max":
        rank = "most"
    if code in {"invoices_min", "invoices_max"}:
        target = f"the {rank} {metric}"
    else:
        target = f"the {rank} {metric}"
    return [
        f"Which observed period had {target}{product_clause}{where}{scope}?",
        f"Across the transactions shown{where}, what period recorded {target}{product_clause}?",
        f"For the provided transactions{where}, identify the period with {target}{product_clause}.",
    ][style % 3]


def make_clear_query(q, cond):
    # Explicit condition-given counterpart: this isn't delivered in standard model input.
    return f"{q} Group the transaction records {cond}."


def choose_countries(df, sheets):
    cnt = df.groupby(["Country", "source_sheet"]).size().unstack(fill_value=0)
    ranked = df.groupby("Country")["Revenue"].sum().sort_values(ascending=False)
    return [c for c in ranked.index if c in cnt.index and all(cnt.loc[c, s] >= 150 for s in sheets)][:16]


def choose_products(df, sheets):
    # Allow products from multiple countries; a single country is selected per record below.
    pairs = df.groupby(["Country", "StockCode", "source_sheet"], observed=True).size().unstack(fill_value=0)
    if not all(s in pairs.columns for s in sheets):
        return []
    eligible = pairs.loc[(pairs[sheets[0]] >= 55) & (pairs[sheets[1]] >= 55)].copy()
    eligible["total"] = eligible[sheets[0]] + eligible[sheets[1]]
    return [(str(country), str(sku)) for country, sku in eligible.sort_values("total", ascending=False).head(120).index]


def write_jsonl(path, rows):
    with Path(path).open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, allow_nan=False) + "\n")


def build(df, sheets, out, seed=20261011):
    rng = np.random.default_rng(seed)
    countries = choose_countries(df, sheets)
    products = choose_products(df, sheets)
    if len(countries) < 3:
        raise RuntimeError("Insufficient multi-year countries; cannot build genuine 200 questions.")
    if len(products) < 25:
        raise RuntimeError(f"Only {len(products)} multi-year product-country pairs have >=55 rows per sheet. "
                           "Cannot construct 25 supported product-specific examples without forcing data.")
    print("    Eligible countries:", len(countries), "| eligible product-country pairs:", len(products))
    # Build reusable slices once; don't scan the million-row dataframe on each retry.
    country_pools = {c: df.loc[df["Country"] == c] for c in countries}
    customer_pools = {c: p.loc[p["CustomerID"].notna()] for c, p in country_pools.items()}
    product_pools = {(c, sku): country_pools[c].loc[country_pools[c]["StockCode"] == sku]
                     for c, sku in products if c in country_pools}
    standard, model_inputs, condition_inputs = [], [], []
    audit, seen_q, seen_context = [], set(), set()
    total_attempts = Counter()
    for fam_idx, (family, codes) in enumerate(FAMILY_CONFIG):
        built = 0
        retries = 0
        while built < N_PER_FAMILY and retries < 1600:
            retries += 1
            total_attempts[family] += 1
            code = codes[(built + retries // 13) % len(codes)]
            if family == "single_product_performance":
                country, sku = products[(built + (retries - 1) * 19) % len(products)]
                pool = product_pools[(country, sku)]
                title = f"Sample of observed Online Retail II transactions for StockCode {sku} in {country}"
            else:
                country = countries[(built + (retries - 1) * 7 + fam_idx) % len(countries)]
                sku = None
                pool = country_pools[country]
                title = f"Sample of observed Online Retail II transactions in {country}"
            # Restrict to nonmissing CustomerID for customer analyses, document it.
            if family == "customer_reach":
                pool = customer_pools[country]
                title += " (nonmissing CustomerID only)"
            table_df = select_context(pool, sheets, rng)
            if table_df is None or len(table_df) < MIN_ROWS or len(table_df) > 100:
                continue
            answer_rows = calculate_answers(table_df, code)
            if answer_rows is None:
                continue
            question = make_question(code, country, sku, (built + retries // 11) % 3)
            if question in seen_q:
                continue
            table = encode_table(table_df, title)
            # An explicit verification independent of how the source was sampled.
            recomputed = calculate_answers(decode_table(table), code)
            if recomputed is None or len(recomputed) != len(answer_rows):
                raise AssertionError("Failed to recompute gold from model input table")
            for a, b in zip(recomputed, answer_rows):
                if a["condition"] != b["condition"] or a["answer"] != b["answer"] or not math.isclose(
                    a["answer_value"], b["answer_value"], abs_tol=1e-5, rel_tol=1e-9
                ):
                    raise AssertionError("Gold period OR metric value differs from model input table")
            fingerprint = (family, country, sku, tuple((r["Invoice"], r["InvoiceDate"], r["StockCode"]) for r in table["rows"]))
            if fingerprint in seen_context:
                continue
            seen_context.add(fingerprint)
            seen_q.add(question)
            qid = f"online_retail_unit_{len(standard)+1:04d}"
            gold_answers = [{**a, "clear_query": make_clear_query(question, a["condition"]),
                             "answer_value_name": METRIC_META[code][3]} for a in answer_rows]
            answer_by_condition = {a["condition"]: a["answer"] for a in gold_answers}
            gold = {
                "ambiguous_conditions": [{"term": "period", "dimension": "Unit", "conditions": CONDITIONS}],
                "condition_answer_pairs": [{"conditions": {"Unit": a["condition"]}, "answer": a["answer"],
                                            "condition": a["condition"], "answer_value": a["answer_value"]}
                                           for a in gold_answers],
                "dimension": "Unit", "gold_conditions": CONDITIONS,
                "gold_answers": gold_answers, "answer_by_condition": answer_by_condition,
                "acceptable_answers": list(answer_by_condition.values()),
            }
            meta = {
                "dataset": "online_retail_ii", "dimension": "Unit", "family": family,
                "metric_code": code, "metric_definition": METRIC_META[code][2],
                "country": country, "stock_code": sku, "source_sheets": sheets,
                "data_scope": "provided table ONLY, not the full workbook",
                "min_observed_rows": MIN_ROWS,
                "aggregation_unit_explanation": "year-sheet is the source workbook sheet period, not a calendar year",
                "status": "automated_checks_passed_human_review_pending",
            }
            rec = {
                "id": qid, "query": question, "table": table, "gold": gold, "metadata": meta,
                # Compatibility with earlier Online Retail eval standard/evaluator:
                "dataset": "online_retail_ii", "dimension": "Unit", "question": question,
                "ambiguous_query": question, "query_type": code, "ambiguity_family": family,
                "gold_conditions": list(CONDITIONS), "gold_answers": gold_answers,
                "answer_by_condition": answer_by_condition,
                "answer_type": "time_period", "gold_condition_count": 5,
            }
            standard.append(rec)
            # MODEL INPUT: no gold, dimension, family, metadata or answer.
            model_inputs.append({"id": qid, "query": question, "table": table})
            # CONDITION INPUT: only ONE explicitly supplied grouping unit, no gold answer.
            for a in gold_answers:
                condition_inputs.append({"id": f"{qid}__{a['condition'].replace(' ', '_')}",
                    "parent_id": qid, "query": question, "table": table,
                    "condition": a["condition"], "condition_query": a["clear_query"]})
            audit.append({"id": qid, "family": family, "metric_code": code, "country": country,
                          "stock_code": sku or "", "table_rows": len(table["rows"]),
                          "observed_dates": table_df["InvoiceDate"].dt.date.nunique(),
                          "unique_answers": len(set(answer_by_condition.values())),
                          "query": question, "sampled_sheets": ";".join(sheets)})
            built += 1
        if built != N_PER_FAMILY:
            raise RuntimeError(f"Family {family}: only {built}/{N_PER_FAMILY} valid, non-tied examples "
                               f"after {retries} attempts. Do not pad with fabricated examples. "
                               "Try relaxing source restrictions only after manual review.")
        print(f"[2/5] {family:27s} {built:3d} queries (attempts {retries})")

    assert len(standard) == 200 and len(model_inputs) == 200 and len(condition_inputs) == 1000
    assert all(r["dimension"] == "Unit" for r in standard)
    assert max(len(r["table"]["rows"]) for r in model_inputs) <= 100
    assert all(set(m) == {"id", "query", "table"} for m in model_inputs)
    assert all("gold" not in c and "answer" not in c and "gold_answers" not in str(c) for c in condition_inputs)
    assert len(set(x["id"] for x in standard)) == 200
    assert len(set(x["query"] for x in standard)) == 200
    assert Counter(x["ambiguity_family"] for x in standard) == {k: 25 for k, _ in FAMILY_CONFIG}
    # Defenses against accidentally writing gold into model input fields.
    for m in model_inputs:
        assert not (set(m.keys()) & {"gold", "gold_conditions", "answer_by_condition", "dimension", "query_type"})

    out.mkdir(parents=True, exist_ok=True)
    names = {
        "standard": out / "online_retail_unit_200_standard.jsonl",
        "model_inputs": out / "online_retail_unit_200_model_inputs.jsonl",
        "condition_inputs": out / "online_retail_unit_200_condition_inputs.jsonl",
    }
    write_jsonl(names["standard"], standard)
    write_jsonl(names["model_inputs"], model_inputs)
    write_jsonl(names["condition_inputs"], condition_inputs)
    pd.DataFrame(audit).to_csv(out / "online_retail_unit_200_audit.csv", index=False)
    summary = {
        "dataset": "Online Retail II", "dimension": "Unit", "n_queries": len(standard),
        "n_condition_answer_pairs": len(condition_inputs), "n_families": len(FAMILY_CONFIG),
        "family_counts": dict(Counter(x["ambiguity_family"] for x in standard)),
        "metric_code_counts": dict(Counter(x["query_type"] for x in standard)),
        "conditions": CONDITIONS, "min_table_rows": min(x["table_rows"] for x in audit),
        "max_table_rows": max(x["table_rows"] for x in audit),
        "construction": "Gold answers recomputed from the exact per-query sample table, not full workbook",
        "caveats": ["Automated validity checks do not replace human review of naturalness and ambiguity.",
                    "The source year-sheet is not a standard calendar-year unit.",
                    "Eight analytic task families share the same underlying temporal unit ambiguity; family diversity must be reviewed substantively.",
                    "Model must be given the table in model_inputs; the standard file is not a model prompt."],
        "human_review_status": "pending",
        "random_seed": seed,
    }
    (out / "online_retail_unit_200_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = ["# Online Retail II — Unit Ambiguity: 200-candidate human review",
             "", "All rows pass deterministic consistency checks, but **require human review before evaluation**.",
             "", "Definition: Unit means the **time aggregation unit** (day/week/month/quarter/original year-sheet), not currency or measurement unit.",
             "", "The table is an 84-row (typically) stratified **subset of actual positive transactions**. Gold is computed only on this table.",
             "", "The phrase 'previous observed period' refers to the prior period represented in the table, not necessarily the immediately preceding calendar period.", ""]
    for family, codes in FAMILY_CONFIG:
        rows = [r for r in standard if r["ambiguity_family"] == family]
        lines.append(f"\n## Family: {family} ({len(rows)} queries)\n")
        lines.append("Metric variations: " + ", ".join(codes) + "\n")
        for r in rows[:5]:
            lines.append(f"### {r['id']} — {r['query_type']}")
            lines.append("Query: " + r["query"])
            lines.append(f"Evidence: {len(r['table']['rows'])} rows, country={r['metadata']['country']}, SKU={r['metadata']['stock_code']}")
            for g in r["gold_answers"]:
                lines.append(f"- {g['condition']}: **{g['answer']}** (metric={g['answer_value']})")
            lines.append("")
    (out / "online_retail_unit_200_review.md").write_text("\n".join(lines), encoding="utf-8")
    readme = """# Online Retail II / Unit / 200 candidates

Dimension: `Unit` = **temporal aggregation unit** (day, ISO week, calendar month,
calendar quarter, original workbook year-sheet), NOT physical measurement/currency.

- `online_retail_unit_200_standard.jsonl`: 200 records, each `id/query/table/gold`.
  Use **only for scoring/QA**, never include `gold` or top-level `gold_*` fields in model prompts.
- `online_retail_unit_200_model_inputs.jsonl`: 200 records, strictly `id/query/table`.
  Use for Detection and End-to-End. The underlying data is included in `table.rows`.
- `online_retail_unit_200_condition_inputs.jsonl`: 1,000 records with an explicit
  `condition` and `condition_query`, without any answer, for Condition-Given.
  Use `parent_id` to join to standard.
- `online_retail_unit_200_review.md`: 5 illustrated examples per family (40 total).
- `online_retail_unit_200_audit.csv`: all 200 candidate questions and provenance stats.
- `online_retail_unit_200_summary.json`: family sizes and automatic consistency checks.

All gold answers are recomputed on each record's 84-row observed table. The previous
50 full-workbook queries/answers are kept separately and NOT mixed with this rebuilt set.
The tiny table is a stratified real-data sample, not a complete country revenue history.
By year-sheet refers to Year 2009-2010 / Year 2010-2011 workbook tabs.

This builder does NOT call a model. Automated checks are NOT a human validity study.
The eight categories are analytics/question families within Unit; they are not eight
independent types of missing-unit ambiguity. Validate diversity manually.

If reusing the old evaluator, update any hard-coded `Granularity` label and do NOT use
its schema-guided prompt generator as the formal zero-shot prompt. Reuse the unified
prompts v2 taxonomy with the `Unit` definition across ALL evaluated datasets.
"""
    (out / "README_for_Ruyu.md").write_text(readme, encoding="utf-8")
    import zipfile
    with zipfile.ZipFile(out / "online_retail_unit_200_for_ruyu.zip", "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in [*names.values(), out / "online_retail_unit_200_audit.csv",
                  out / "online_retail_unit_200_summary.json", out / "online_retail_unit_200_review.md",
                  out / "README_for_Ruyu.md"]:
            z.write(p, arcname=p.name)
    print("[3/5] Verified no gold in model or condition inputs")
    print("[4/5] Saved standard + model + condition inputs + QA")
    print("[5/5] ZIP:", out / "online_retail_unit_200_for_ruyu.zip")
    print(json.dumps({"queries": 200, "families": 8, "condition_answer_pairs": 1000, "dimension": "Unit",
                      "table_rows_range": [summary["min_table_rows"], summary["max_table_rows"]]}, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True, help="Cleaned CSV/parquet or raw two-sheet xlsx")
    parser.add_argument("--output", type=Path, default=Path("online_retail_unit_200_output"))
    parser.add_argument("--seed", type=int, default=20261011)
    args = parser.parse_args()
    df, sheets = load_source(args.source)
    build(df, sheets, args.output, args.seed)


if __name__ == "__main__":
    main()

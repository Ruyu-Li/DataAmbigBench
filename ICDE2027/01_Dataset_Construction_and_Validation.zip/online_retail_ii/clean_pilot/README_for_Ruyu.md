# Online Retail II — Unit Ambiguity v2

The dimension is Unit: temporal aggregation unit.

Conditions:
by day, by week, by month, by quarter, by year.

Files:
- standard.jsonl: full records with gold; scoring only.
- model_inputs.jsonl: id, query, table only.
- condition_inputs.jsonl: condition-given inputs without answers.

Each table contains complete selected invoices.
Gold is calculated from the exact provided table.

Calendar year replaces the old year-sheet condition.
Evaluation condition normalization must be updated.

The eight families are analytical task families rather
than eight independent ambiguity mechanisms.

Human validation is required before publication.

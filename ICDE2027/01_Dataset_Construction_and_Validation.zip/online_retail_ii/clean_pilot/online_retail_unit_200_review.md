# Online Retail II Unit — 200 candidate review

Automated validation passed. Human review pending.


## revenue_extremes

### online_retail_unit_0001
Query: Considering only the supplied transactions in Germany, which time period recorded the highest total revenue?
- by day: 2011-07-14 (value=1563.28)
- by week: 2011-W38 (value=2308.87)
- by month: 2011-09 (value=3080.52)
- by quarter: 2011Q3 (value=5840.62)
- by year: 2011 (value=8017.73)

### online_retail_unit_0002
Query: For the transactions displayed in Germany, find the time window with the lowest total revenue.
- by day: 2010-10-18 (value=244.4)
- by week: 2010-W26 (value=736.38)
- by month: 2010-02 (value=2082.86)
- by quarter: 2010Q1 (value=2082.86)
- by year: 2010 (value=6290.32)

### online_retail_unit_0003
Query: In the displayed transaction records in United Kingdom, which time bucket shows the lowest total revenue?
- by day: 2010-07-02 (value=8.0)
- by week: 2010-W18 (value=81.73)
- by month: 2010-05 (value=205.73)
- by quarter: 2010Q2 (value=205.73)
- by year: 2010 (value=3077.55)

### online_retail_unit_0004
Query: Among the observed transactions in Germany, what time bucket had the highest total revenue?
- by day: 2010-12-09 (value=1373.57)
- by week: 2010-W49 (value=2567.17)
- by month: 2010-12 (value=3129.9)
- by quarter: 2010Q4 (value=5083.65)
- by year: 2010 (value=7287.2)

### online_retail_unit_0005
Query: In the displayed transaction records in Germany, which time bucket shows the highest total revenue?
- by day: 2011-07-14 (value=1563.28)
- by week: 2011-W41 (value=2001.35)
- by month: 2011-10 (value=3794.87)
- by quarter: 2011Q4 (value=3794.87)
- by year: 2011 (value=8731.76)


## transaction_activity

### online_retail_unit_0026
Query: Considering only the supplied transactions in Germany, which time period recorded the most distinct invoices?
- by day: 2010-12-09 (value=5.0)
- by week: 2010-W49 (value=7.0)
- by month: 2010-12 (value=11.0)
- by quarter: 2010Q4 (value=19.0)
- by year: 2010 (value=27.0)

### online_retail_unit_0027
Query: What time span had the most transaction line items in United Kingdom, based on the transactions shown?
- by day: 2011-03-13 (value=35.0)
- by week: 2011-W10 (value=41.0)
- by month: 2011-03 (value=48.0)
- by quarter: 2011Q1 (value=95.0)
- by year: 2011 (value=103.0)

### online_retail_unit_0028
Query: For the transactions displayed in Germany, find the time window with the most distinct invoices.
- by day: 2011-10-06 (value=5.0)
- by week: 2011-W40 (value=7.0)
- by month: 2011-10 (value=11.0)
- by quarter: 2011Q4 (value=19.0)
- by year: 2011 (value=27.0)

### online_retail_unit_0029
Query: Within the supplied data for United Kingdom, select the time span with the most transaction line items.
- by day: 2011-07-03 (value=20.0)
- by week: 2011-W26 (value=24.0)
- by month: 2011-07 (value=39.0)
- by quarter: 2011Q2 (value=43.0)
- by year: 2011 (value=82.0)

### online_retail_unit_0030
Query: Among the observed transactions in United Kingdom, what time bucket had the most transaction line items?
- by day: 2010-12-12 (value=16.0)
- by week: 2010-W01 (value=21.0)
- by month: 2010-01 (value=29.0)
- by quarter: 2011Q3 (value=51.0)
- by year: 2011 (value=67.0)


## product_assortment

### online_retail_unit_0051
Query: Considering only the supplied transactions in Germany, which time period recorded the greatest number of distinct products?
- by day: 2011-11-24 (value=50.0)
- by week: 2011-W47 (value=67.0)
- by month: 2011-11 (value=88.0)
- by quarter: 2011Q3 (value=123.0)
- by year: 2011 (value=180.0)

### online_retail_unit_0052
Query: Using the provided table in Germany, which reporting period had the lowest top-product revenue share (highest single-product revenue divided by total revenue)?
- by day: 2011-03-07 (value=0.038361)
- by week: 2011-W10 (value=0.076175)
- by month: 2011-03 (value=0.063471)
- by quarter: 2011Q1 (value=0.063471)
- by year: 2011 (value=0.086692)

### online_retail_unit_0053
Query: Based solely on this transaction sample in Germany, name the time period with the greatest number of distinct products.
- by day: 2011-07-12 (value=29.0)
- by week: 2011-W28 (value=51.0)
- by month: 2010-06 (value=74.0)
- by quarter: 2010Q4 (value=111.0)
- by year: 2011 (value=168.0)

### online_retail_unit_0054
Query: What is the reporting period corresponding to the greatest number of distinct products in Germany in the supplied data?
- by day: 2011-03-08 (value=31.0)
- by week: 2011-W10 (value=59.0)
- by month: 2011-03 (value=84.0)
- by quarter: 2011Q1 (value=151.0)
- by year: 2011 (value=188.0)

### online_retail_unit_0055
Query: Considering only the supplied transactions in Germany, which time period recorded the lowest top-product revenue share (highest single-product revenue divided by total revenue)?
- by day: 2011-07-07 (value=0.07172)
- by week: 2010-W26 (value=0.08148)
- by month: 2011-01 (value=0.117886)
- by quarter: 2011Q1 (value=0.117886)
- by year: 2011 (value=0.096393)


## customer_reach

### online_retail_unit_0076
Query: For United Kingdom, identify the time window with the most distinct customers with known customer IDs among the observed transactions.
- by day: 2011-12-07 (value=5.0)
- by week: 2011-W49 (value=7.0)
- by month: 2011-12 (value=11.0)
- by quarter: 2011Q1 (value=15.0)
- by year: 2011 (value=26.0)

### online_retail_unit_0077
Query: Which reporting interval had the most distinct customers with known customer IDs in Germany in the provided transaction table?
- by day: 2011-11-16 (value=4.0)
- by week: 2011-W46 (value=6.0)
- by month: 2011-11 (value=10.0)
- by quarter: 2011Q4 (value=10.0)
- by year: 2011 (value=21.0)

### online_retail_unit_0078
Query: Which reporting interval had the most invoices from customers with known IDs in United Kingdom in the provided transaction table?
- by day: 2010-01-21 (value=5.0)
- by week: 2010-W03 (value=7.0)
- by month: 2010-01 (value=10.0)
- by quarter: 2010Q1 (value=10.0)
- by year: 2010 (value=22.0)

### online_retail_unit_0079
Query: What is the reporting period corresponding to the most invoices from customers with known IDs in United Kingdom in the supplied data?
- by day: 2011-02-17 (value=4.0)
- by week: 2011-W07 (value=6.0)
- by month: 2011-02 (value=10.0)
- by quarter: 2011Q1 (value=18.0)
- by year: 2011 (value=25.0)

### online_retail_unit_0080
Query: Using the provided table in United Kingdom, which reporting period had the most invoices from customers with known IDs?
- by day: 2011-04-01 (value=5.0)
- by week: 2011-W13 (value=7.0)
- by month: 2011-04 (value=11.0)
- by quarter: 2011Q2 (value=11.0)
- by year: 2011 (value=27.0)


## invoice_economics

### online_retail_unit_0101
Query: Considering only the supplied transactions in Germany, which time period recorded the highest average invoice value (total revenue divided by distinct invoices)?
- by day: 2011-07-14 (value=781.64)
- by week: 2011-W28 (value=505.48)
- by month: 2011-07 (value=365.8525)
- by quarter: 2011Q3 (value=365.8525)
- by year: 2011 (value=297.91)

### online_retail_unit_0102
Query: Using the provided table in United Kingdom, which reporting period had the lowest average invoice value (total revenue divided by distinct invoices)?
- by day: 2010-12-02 (value=13.8)
- by week: 2010-W48 (value=58.7375)
- by month: 2010-12 (value=99.56)
- by quarter: 2010Q4 (value=99.56)
- by year: 2010 (value=117.053704)

### online_retail_unit_0103
Query: Based solely on this transaction sample in Germany, name the time period with the highest average invoice value (total revenue divided by distinct invoices).
- by day: 2011-10-21 (value=673.525)
- by week: 2011-W42 (value=431.1725)
- by month: 2011-11 (value=358.076364)
- by quarter: 2011Q4 (value=344.854211)
- by year: 2011 (value=332.598148)

### online_retail_unit_0104
Query: For Germany, identify the time window with the highest average invoice value (total revenue divided by distinct invoices) among the observed transactions.
- by day: 2010-12-07 (value=596.8)
- by week: 2010-W49 (value=559.75)
- by month: 2010-12 (value=365.2125)
- by quarter: 2010Q4 (value=365.2125)
- by year: 2010 (value=289.41125)

### online_retail_unit_0105
Query: What is the reporting period corresponding to the highest average invoice value (total revenue divided by distinct invoices) in Germany in the supplied data?
- by day: 2011-10-21 (value=673.525)
- by week: 2011-W42 (value=431.1725)
- by month: 2011-10 (value=412.0525)
- by quarter: 2011Q4 (value=376.045789)
- by year: 2011 (value=359.629259)


## basket_composition

### online_retail_unit_0126
Query: For United Kingdom, identify the time window with the highest average quantity per invoice among the observed transactions.
- by day: 2011-08-31 (value=501.0)
- by week: 2011-W35 (value=294.75)
- by month: 2011-08 (value=180.0)
- by quarter: 2011Q3 (value=180.0)
- by year: 2011 (value=135.875)

### online_retail_unit_0127
Query: Using the provided table in Germany, which reporting period had the highest average distinct products per invoice?
- by day: 2010-12-07 (value=17.0)
- by week: 2011-W02 (value=12.75)
- by month: 2011-01 (value=12.25)
- by quarter: 2011Q1 (value=12.25)
- by year: 2010 (value=8.888889)

### online_retail_unit_0128
Query: What is the reporting period corresponding to the highest average distinct products per invoice in Germany in the supplied data?
- by day: 2010-12-07 (value=17.0)
- by week: 2011-W28 (value=14.75)
- by month: 2010-12 (value=11.454545)
- by quarter: 2010Q4 (value=10.473684)
- by year: 2010 (value=10.296296)

### online_retail_unit_0129
Query: Using the provided table in Germany, which reporting period had the highest average quantity per invoice?
- by day: 2011-09-19 (value=624.5)
- by week: 2011-W38 (value=363.0)
- by month: 2011-09 (value=202.125)
- by quarter: 2011Q3 (value=202.125)
- by year: 2011 (value=164.037037)

### online_retail_unit_0130
Query: Looking at the supplied transactions in Germany, which reporting interval corresponds to the highest average quantity per invoice?
- by day: 2010-06-28 (value=208.5)
- by week: 2010-W48 (value=152.5)
- by month: 2010-12 (value=145.090909)
- by quarter: 2010Q4 (value=145.090909)
- by year: 2010 (value=129.962963)


## unit_price_dynamics

### online_retail_unit_0151
Query: Among the observed transactions in United Kingdom, what time bucket had the highest average selling price per unit (total sales divided by total units sold)?
- by day: 2010-08-11 (value=402.125)
- by week: 2010-W31 (value=4.600427)
- by month: 2010-08 (value=3.539761)
- by quarter: 2010Q2 (value=2.794528)
- by year: 2010 (value=2.572098)

### online_retail_unit_0152
Query: For the transactions displayed in Germany, find the time window with the lowest average selling price per unit (total sales divided by total units sold).
- by day: 2010-10-18 (value=0.814667)
- by week: 2011-W42 (value=1.256176)
- by month: 2011-10 (value=2.12711)
- by quarter: 2011Q4 (value=2.12711)
- by year: 2010 (value=2.420667)

### online_retail_unit_0153
Query: In the displayed transaction records in United Kingdom, which time bucket shows the lowest average selling price per unit (total sales divided by total units sold)?
- by day: 2011-11-20 (value=0.2676)
- by week: 2010-W47 (value=0.982247)
- by month: 2010-11 (value=1.086882)
- by quarter: 2010Q4 (value=1.086882)
- by year: 2010 (value=2.54609)

### online_retail_unit_0154
Query: Looking at the supplied transactions in United Kingdom, which reporting interval corresponds to the lowest average selling price per unit (total sales divided by total units sold)?
- by day: 2010-08-19 (value=0.359403)
- by week: 2010-W33 (value=0.712826)
- by month: 2010-08 (value=1.014614)
- by quarter: 2010Q3 (value=1.014614)
- by year: 2011 (value=2.051713)

### online_retail_unit_0155
Query: Which reporting interval had the highest average selling price per unit (total sales divided by total units sold) in Germany in the provided transaction table?
- by day: 2010-10-19 (value=17.785714)
- by week: 2011-W18 (value=3.146984)
- by month: 2011-05 (value=2.265556)
- by quarter: 2011Q2 (value=2.265556)
- by year: 2010 (value=2.161035)


## revenue_change

### online_retail_unit_0176
Query: For Germany, identify the time window with the largest increase in total revenue compared with the previous observed interval among the observed transactions.
- by day: 2011-11-24 (value=1189.3)
- by week: 2011-W47 (value=1591.64)
- by month: 2011-11 (value=1596.43)
- by quarter: 2011Q1 (value=1760.01)
- by year: 2011 (value=652.75)

### online_retail_unit_0177
Query: Among the observed transactions in United Kingdom, what time bucket had the largest decrease in total revenue compared with the previous observed interval?
- by day: 2010-01-25 (value=2569.24)
- by week: 2010-W04 (value=2543.17)
- by month: 2010-11 (value=2337.2)
- by quarter: 2011Q1 (value=1604.45)
- by year: 2011 (value=2661.44)

### online_retail_unit_0178
Query: What time span had the largest increase in total revenue compared with the previous observed interval in Germany, based on the transactions shown?
- by day: 2011-07-14 (value=1271.36)
- by week: 2011-W04 (value=980.27)
- by month: 2010-12 (value=852.64)
- by quarter: 2010Q4 (value=3144.29)
- by year: 2011 (value=976.43)

### online_retail_unit_0179
Query: Considering only the supplied transactions in United Kingdom, which time period recorded the largest increase in total revenue compared with the previous observed interval?
- by day: 2011-12-07 (value=5520.36)
- by week: 2011-W49 (value=5358.07)
- by month: 2011-12 (value=5464.13)
- by quarter: 2011Q4 (value=5464.13)
- by year: 2011 (value=7491.8)

### online_retail_unit_0180
Query: Which reporting interval had the largest increase in total revenue compared with the previous observed interval in Germany in the provided transaction table?
- by day: 2010-10-04 (value=654.18)
- by week: 2011-W38 (value=811.21)
- by month: 2011-03 (value=493.26)
- by quarter: 2011Q1 (value=493.26)
- by year: 2011 (value=1398.72)

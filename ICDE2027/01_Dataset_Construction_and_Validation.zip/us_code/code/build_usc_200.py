#!/usr/bin/env python3
"""Build reproducible, evidence-grounded legal-scope ambiguity CANDIDATES.

Python 3.9+, pyarrow. No API calls. Uses the supplied standardizer unchanged.
Example:
  python build_usc_200.py --input train-00000-of-00003.parquet --n 200

200 means 200 ambiguous candidate queries, not controls or condition rows.
Textually different definitions are not necessarily semantically different.
All newly generated items require human review; evaluation_ready only means
that independent source context is present under the standardizer's convention.
"""
import argparse
import difflib
import hashlib
import importlib.util
import itertools
import json
import random
import re
from collections import Counter, defaultdict
from pathlib import Path


PATTERN = re.compile(r'^(?:The|the) (?:term|word) “([^”]+)” means (.+)\.$')
PRIORITY = ['commission', 'board', 'state', 'secretary', 'child']


def normalize(text):
    return re.sub(r'\W+', ' ', text.casefold()).strip()


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load_standardizer(path):
    spec = importlib.util.spec_from_file_location('usc_standardizer', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def extract(paths, exclude_reference_dependent=False):
    import pyarrow.parquet as pq
    groups = defaultdict(list)
    source_rows = {}
    stats = Counter()
    for path in paths:
        parquet = pq.ParquetFile(path)
        for batch in parquet.iter_batches(batch_size=512):
            for row in batch.to_pylist():
                stats['input_rows'] += 1
                ident = row.get('identifier')
                if not ident or not row.get('citation') or not isinstance(row.get('text'), str):
                    stats['missing_required_source_fields'] += 1
                    continue
                fingerprint = (row['text'], row.get('release_label'))
                if ident in source_rows:
                    if source_rows[ident] != fingerprint:
                        raise ValueError(f'{ident}: conflicting versions; this script handles legal scope, not version ambiguity.')
                    stats['duplicate_source_rows_skipped'] += 1
                    continue
                source_rows[ident] = fingerprint
                if row.get('status') is not None:
                    stats['explicit_status_rows_skipped'] += 1
                    continue
                # Fail closed on multiple matching definitions of one term in
                # a section; a section number would not resolve that sub-scope.
                found = defaultdict(list)
                offset = 0
                for raw_line in row['text'].splitlines(keepends=True):
                    line = raw_line.strip()
                    match = PATTERN.fullmatch(line)
                    if match and 1 <= len(match[1]) <= 100 and len(match[2]) <= 400:
                        term, answer = match.groups()
                        depends_on_reference = bool(re.search(r'\b(?:paragraph|subparagraph|clause|subsection)\b', answer, re.I))
                        if exclude_reference_dependent and depends_on_reference:
                            stats['reference_dependent_definitions_skipped'] += 1
                            continue
                        start = offset + raw_line.index(line)
                        found[term.casefold()].append({
                            'term': term, 'answer': answer, 'evidence_quote': line,
                            'span_start': start, 'span_end': start + len(line),
                            'source_id': ident, 'row': row,
                            'reference_dependent': depends_on_reference,
                        })
                    offset += len(raw_line)
                for term, entries in found.items():
                    if len(entries) != 1:
                        stats['multiple_definitions_in_section_skipped'] += 1
                        continue
                    groups[term].append(entries[0])
                    stats['definition_candidates'] += 1
    stats['unique_source_identifiers'] = len(source_rows)
    return groups, stats


def choose_pairs(groups, seed):
    candidates = []
    for term in sorted(groups):
        best = None
        entries = sorted(groups[term], key=lambda d: d['source_id'])
        for a, b in itertools.combinations(entries, 2):
            if a['source_id'] == b['source_id']:
                continue
            na, nb = normalize(a['answer']), normalize(b['answer'])
            if na == nb:
                continue
            similarity = difflib.SequenceMatcher(None, na, nb).ratio()
            if similarity >= 0.95:
                continue
            rank = (int(a['reference_dependent']) + int(b['reference_dependent']), similarity,
                    len(a['answer']) + len(b['answer']), a['source_id'], b['source_id'])
            if best is None or rank < best[0]:
                best = (rank, a, b)
        if best:
            candidates.append((term, best[1], best[2], best[0][1]))
    rng = random.Random(seed)
    rng.shuffle(candidates)
    candidates.sort(key=lambda c: PRIORITY.index(c[0]) if c[0] in PRIORITY else len(PRIORITY))
    return candidates


def source_context(entries):
    # Built ONLY from original Parquet rows, not from condition-answer gold.
    chunks = []
    for entry in entries:
        row = entry['row']
        chunks.append('\n'.join([
            f'### Source: {row["citation"]}',
            f'Identifier: {row["identifier"]}',
            f'Title: {row.get("title_name", "")}',
            f'Release: {row.get("release_label", "")}',
            f'Currency date (dataset field): {row.get("currency_date", "")}',
            'Original section text:', row['text'],
        ]))
    return '\n\n'.join(chunks)


def build(candidates, dimension):
    raw = []
    for index, (key, a, b, similarity) in enumerate(candidates, 1):
        term = a['term']
        entries = [a, b]
        conditions = [f'Apply the definition in {e["row"]["citation"]} in the supplied source text' for e in entries]
        evidence = []
        for entry in entries:
            row = entry['row']
            assert row['text'][entry['span_start']:entry['span_end']] == entry['evidence_quote']
            evidence.append({k: entry[k] for k in ('source_id', 'evidence_quote', 'span_start', 'span_end')})
            evidence[-1].update({k: str(row.get(k, '')) for k in ('citation', 'release_label', 'currency_date')})
        raw.append({
            'id': f'USC_SCOPE_{index:04d}', 'dataset': 'USC_LegalScope',
            'query': f'What does “{term}” mean?',
            'table': source_context(entries),
            'gold': {
                'ambiguous_conditions': [{'term': term, 'dimension': dimension, 'conditions': conditions}],
                'condition_answer_pairs': [
                    {'conditions': {dimension: cond}, 'answer': entry['answer']}
                    for cond, entry in zip(conditions, entries)
                ],
            },
            'evidence': evidence,
            'review_status': {
                'naturalness': 'pending', 'ambiguity': 'pending',
                'condition_sufficiency': 'pending', 'answer_correctness': 'pending',
            },
            'dimension_status': 'provisional_cross_domain_label',
            'normalized_definition_similarity': similarity,
            'construction': 'Controlled omission of legal scope; two source sections; one query per distinct term',
            'reference_warning': bool(any(re.search(r'\b(?:section|chapter|title|Act|established)\b', e['answer']) for e in entries)),
            'reference_dependent': any(e['reference_dependent'] for e in entries),
        })
    return raw


def write_review(path, raw):
    lines = ['# USC：200 条法律范围歧义候选题审阅', '',
             f'实际生成：{len(raw)} 条；每题有两个条件与两份原始来源。', '',
             '你之前的自然性结论只适用于原来的 10 题。本文件是新增候选题，全部待审。', '',
             '每题只需检查：问题自然吗？两种解释合理吗？指定条文足够吗？答案和证据对应吗？', '',
             'Dimension 默认是临时标签 Legal-Scope（法律范围），不是版本变化。英文条件与答案用于评测。', '']
    for i, row in enumerate(raw, 1):
        term = row['gold']['ambiguous_conditions'][0]['term']
        lines += [f'## {i}. {row["id"]}', '', f'**英文问题：** {row["query"]}', '',
                  f'**中文理解：** “{term}”是什么意思？', '',
                  '**歧义点：** 未说明使用哪条法律范围下的定义。', '']
        for j, (pair, ev) in enumerate(zip(row['gold']['condition_answer_pairs'], row['evidence']), 1):
            lines += [f'**Condition {j}：** 使用 {ev["citation"]} 中的定义。', '',
                      f'**英文条件：** {next(iter(pair["conditions"].values()))}', '',
                      f'**参考答案 {j}：** {pair["answer"]}', '',
                      '**原文证据：**', '', f'> {ev["evidence_quote"]}', '']
        if row['reference_warning']:
            lines += ['**复核提示：** 定义含引用／设立依据，需核对其法律范围和是否需要额外条文。', '']
        if row['reference_dependent']:
            lines += ['**重点复核：** 定义引用 paragraph/subsection 等段落。参考答案保留原始措辞，尚未展开引用；必须核对全文是否足够。', '']
        lines += ['- [ ] 问题自然', '- [ ] 两个条件对应两种合理且不同的定义',
                  '- [ ] 条件足以消歧', '- [ ] 答案与证据一致', '', '修改意见：________', '']
    path.write_text('\n'.join(lines), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', nargs='+', required=True, help='One or more local Parquet files')
    parser.add_argument('--n', type=int, default=200)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--dimension', default='Legal-Scope', help='Provisional label; use an agreed label only after review')
    parser.add_argument('--outdir', default='usc_200_output')
    parser.add_argument('--standardizer', default=str(Path(__file__).with_name('standardize_benchmark.py')))
    parser.add_argument('--exclude-reference-dependent', action='store_true', help='Stricter screening; may yield fewer than 200 terms')
    args = parser.parse_args()
    try:
        if args.n < 1 or not args.dimension.strip():
            raise ValueError('--n must be positive and --dimension must not be empty')
        paths = [Path(p).resolve() for p in args.input]
        out = Path(args.outdir).resolve()
        stdpath = Path(args.standardizer).resolve()
        if out.exists() and any(out.iterdir()):
            raise ValueError('Output directory is not empty; choose another --outdir to preserve previous results.')
        if len(set(paths)) != len(paths):
            raise ValueError('Repeated input paths')
        groups, extraction = extract(paths, args.exclude_reference_dependent)
        candidates = choose_pairs(groups, args.seed)
        if len(candidates) < args.n:
            raise ValueError(f'Only {len(candidates)} distinct-term candidates survived filtering; requested {args.n}. Add source shards or lower --n; no duplication to fill the count.')
        raw = build(candidates[:args.n], args.dimension)
        standardizer = load_standardizer(stdpath)
        standard = standardizer.convert(raw, require_table=True)
        assert len(standard) == args.n
        assert len({r['query'].casefold() for r in standard}) == args.n
        assert all(len(r['gold']['condition_answer_pairs']) == 2 for r in standard)
        assert all(r['evaluation_ready'] for r in standard)
        inputs = [{k: r[k] for k in ('id', 'query', 'table')} for r in standard]
        assert all(set(r) == {'id', 'query', 'table'} for r in inputs)
        manifest = {
            'queries': len(standard), 'unique_terms': len(standard),
            'condition_answer_pairs': 2 * len(standard), 'unambiguous_controls': 0,
            'available_distinct_term_candidates': len(candidates),
            'selected_reference_dependent_items': sum(r['reference_dependent'] for r in raw),
            'exclude_reference_dependent': args.exclude_reference_dependent,
            'extraction': dict(extraction), 'seed': args.seed,
            'dimension': args.dimension, 'dimension_status': 'provisional_cross_domain_label',
            'model_run': False, 'new_item_human_review': 'pending',
            'previous_pilot_naturalness': 'User accepted the original 10 pilot questions; not transferred to these newly templated questions.',
            'inputs': [{'name': p.name, 'sha256': sha256(p)} for p in paths],
            'standardizer_sha256': sha256(stdpath),
            'checks': ['unique ids and queries', 'two distinct normalized definitions', 'exact original evidence spans', 'standardizer gold/table validation', 'separate model inputs without gold'],
            'limits': ['Lexical difference does not establish semantic difference.',
                       'Purposive controlled construction, not naturally collected user queries.',
                       'Candidate set is closed to the two provided source sections.',
                       'This is text QA, not original table analytics or policy-version comparison.',
                       'Full section text can contain multiple sub-scopes; review condition sufficiency.',
                       'evaluation_ready indicates context presence only; it is not human quality approval.',
                       'Custom dimension label may require alignment with downstream prompts.'],
        }
        out.mkdir(parents=True, exist_ok=True)
        standardizer.write_jsonl(out / 'usc_standard.jsonl', standard)
        standardizer.write_jsonl(out / 'usc_model_inputs.jsonl', inputs)
        write_review(out / 'USC_review_200.md', raw)
        (out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
        print(f'完成：{len(standard)}条歧义候选题、{2 * len(standard)}组条件答案、{len(standard)}个不同术语。')
        print(f'审阅只看：{out / "USC_review_200.md"}')
        print('评分数据：usc_standard.jsonl；模型只读：usc_model_inputs.jsonl。')
        print('新增题全部待审；未调用模型；Legal-Scope不是版本变化。')
    except (ValueError, OSError, ImportError, KeyError, AssertionError) as exc:
        parser.exit(1, f'错误：{exc}\n')


if __name__ == '__main__':
    main()

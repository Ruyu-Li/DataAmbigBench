#!/usr/bin/env python3
"""Build 200 USC legal-scope short-answer examples from original source rows.

Retain the 38 explicit v2 rewrites and add distinct term/answer pairs from a
curated registry of entity names. No API calls, no duplicated answer-pair
padding. Repeated terms occur in different statutory contexts.
Python 3.10+, pyarrow. All source references describe the supplied snapshot,
not independently verified current law. Semantic review remains separate.
"""
import argparse
import copy
import hashlib
import itertools
import json
import random
import re
from collections import Counter, defaultdict
from pathlib import Path
import importlib.util

from revise_usc_short import ALIASES, DIMENSION_TEXT, build as revise

# Exact contiguous proper names, inspected in the supplied Parquet.
# Do not include underspecified titles such as 'Director of the Office'.
NAMES = {
 'administration': ['National Oceanic and Atmospheric Administration','Small Business Administration','Transportation Security Administration'],
 'administrator': ['Administrator of General Services','Administrator of the Agency for International Development','Administrator of the Bonneville Power Administration','Administrator of the Environmental Protection Agency','Administrator of the Federal Emergency Management Agency','Administrator of the National Oceanic and Atmospheric Administration','Administrator of the Small Business Administration','Administrator of the Transportation Security Administration','Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration'],
 'advisory board': ['Land Between the Lakes Advisory Board','National Agricultural Research, Extension, Education, and Economics Advisory Board'],
 'advisory committee': ['Biomass Research and Development Technical Advisory Committee','National Artificial Intelligence Advisory Committee','National Quantum Initiative Advisory Committee'],
 'advisory council': ['Great Sand Dunes National Park Advisory Council','Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program Advisory Council'],
 'advisory panel': ['Advisory Panel on Pacific Hake/Whiting','President’s National Nanotechnology Advisory Panel'],
 'agency': ['Cybersecurity and Infrastructure Security Agency','Federal Housing Finance Agency','Forest Service','Minority Business Development Agency of the Department of Commerce'],
 'authority': ['Delta Regional Authority','Horseracing Integrity and Safety Authority','Northern Great Plains Regional Authority'],
 'board': ['Biomass Research and Development Board','Board of Directors of the Office of Congressional Workplace Rights','Board of Governors of the Federal Reserve System','Community Development Advisory Board','Community Enterprise Assessment Credit Board','Concrete Masonry Products Board','Federal Housing Finance Oversight Board','General Administration Board of the Graduate School','Lime Board','Merit Systems Protection Board','National Canola and Rapeseed Board','National Fish Habitat Board','National Kiwifruit Board','National Processor Advertising and Promotion Board','National Sheep Promotion, Research, and Information Board','Pecan Marketing Board','Popcorn Board','Public Company Accounting Oversight Board','Resource Conservation and Development Policy Advisory Board','United Soybean Board','Advisory Board for the HOPE for Homeowners Program'],
 'commission': ['Cedar Creek and Belle Grove National Historical Park Advisory Commission','Coltsville National Historical Park Advisory Commission','Commission for the Conservation and Management of Highly Migratory Fish Stocks in the Western and Central Pacific Ocean','Commission for the Conservation of Antarctic Marine Living Resources','Commission of the South Pacific Regional Fisheries Management Organization','Commodity Futures Trading Commission','Consumer Product Safety Commission','Federal Communications Commission','Federal Energy Regulatory Commission','Federal Trade Commission','Inter-American Tropical Tuna Commission','North Pacific Fisheries Commission','Paterson Great Falls National Historical Park Advisory Commission','Rio Grande Natural Area Commission','Securities and Exchange Commission'],
 'committee': ['American Fisheries Advisory Committee','Soybean Program Coordinating Committee'],
 'conservation area': ['California Desert Conservation Area','Dominguez-Escalante National Conservation Area','Fort Stanton-Snowy River Cave National Conservation Area','Las Cienegas National Conservation Area','McInnis Canyons National Conservation Area','Numunaa Nobe National Conservation Area','Pistone-Black Mountain National Conservation Area','Sloan Canyon National Conservation Area','Gunnison Gorge National Conservation Area'],
 'corporation': ['Federal Deposit Insurance Corporation','Commodity Credit Corporation','Federal Home Loan Mortgage Corporation','Federal Agricultural Mortgage Corporation','Federal Crop Insurance Corporation'],
 'council': ['Dominguez-Escalante National Conservation Area Advisory Council','Federal Financial Institutions Examinations Council','Financial Stability Oversight Council','McInnis Canyons National Conservation Area Advisory Council','Mushroom Council','Northwest Power and Conservation Planning Council','Western Pacific Regional Fishery Management Council'],
 'county': ['Clark County, Nevada','La Plata County, Colorado','Miami-Dade County, Florida'],
 'department': ['Department of Agriculture','Department of Homeland Security','Department of Energy','Department of Defense','Department of Commerce','Department of the Interior','Department of Transportation','Department of Health and Human Services'],
 'director': ['Director of the Agriculture Advanced Research and Development Authority','Director of the Bureau of Consumer Financial Protection','Director of the Bureau of Land Management','Director of the Cybersecurity and Infrastructure Security Agency','Director of the Federal Housing Finance Agency','Director of the Federal Law Enforcement Training Centers','Director of the Graduate School','Director of the National Institute of Standards and Technology','Director of the National Science Foundation','Director of the United States Fish and Wildlife Service','Director of the United States Geological Survey','Director of the Office of Management and Budget','Director of the Office of Personnel Management'],
 'district': ['Rocky Mountain Ranger District of the Lewis and Clark National Forest','South Florida Water Management District'],
 'foundation': ['Foundation for Food and Agriculture Research','National Fish and Wildlife Foundation','National Natural Resources Conservation Foundation'],
 'fund': ['Acceleration Fund for Research and Development of Homeland Security Technologies','Coastal Aquatic Invasive Species Mitigation Fund','Collaborative Forest Landscape Restoration Fund','Commodity Futures Trading Commission Customer Protection Fund','Community Development Financial Institutions Fund','Cyber Response and Recovery Fund','Great Ape Conservation Fund','Homeowner Assistance Fund','Marine Turtle Conservation Fund','National Oceans and Coastal Security Fund','National Sheep Industry Improvement Center Revolving Fund','Neotropical Migratory Bird Conservation Fund','Orderly Liquidation Fund','Pest and Disease Revolving Loan Fund','Restaurant Revitalization Fund','Securities and Exchange Commission Investor Protection Fund','Troubled Assets Insurance Financing Fund','Valles Caldera Fund'],
 'historical park': ['Adams National Historical Park','First State National Historical Park','Harriet Tubman National Historical Park','Harriet Tubman Underground Railroad National Historical Park','Manhattan Project National Historical Park','Ocmulgee Mounds National Historical Park','Pullman National Historical Park','Reconstruction Era National Historical Park','Brown v. Board of Education National Historical Park'],
 'initiative': ['Biomass Research and Development Initiative','Healthy Food Financing Initiative','National Artificial Intelligence Initiative','pulse crop health initiative'],
 'institute': ['National Institute of Food and Agriculture','National Institute of Standards and Technology'],
 'monument': ['Oregon Caves National Monument','White Sands National Monument'],
 'national park': ['Everglades National Park','Great Sand Dunes National Park'],
 'office': ['Office of Congressional Workplace Rights','Countering Weapons of Mass Destruction Office'],
 'park': ['Black Canyon of the Gunnison National Park','Blackstone River Valley National Historical Park','Cedar Creek and Belle Grove National Historical Park','Coltsville National Historical Park','Cumberland Gap National Historical Park','Fort Sumter and Fort Moultrie National Historical Park','Golden Spike National Historical Park','Kennesaw Mountain National Battlefield Park','Lewis and Clark National Historical Park','Paterson Great Falls National Historical Park','Shiloh National Military Park','White Sands National Park','Women’s Rights National Historical Park'],
 'preserve': ['Great Sand Dunes National Preserve','Tallgrass Prairie National Preserve','Valles Caldera National Preserve'],
 'program': ['Agriculture Innovation Center Demonstration Program','Coastal Aquatic Invasive Species Mitigation Grant Program','Collaborative Forest Landscape Restoration Program','Community Wood Energy and Wood Innovation Program','Cooperative Watershed Management Program','Great Lakes and Lake Champlain Invasive Species Program','Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program','Joint Chiefs Landscape Restoration Partnership program','Local Agriculture Market Program','National Nanotechnology Program','National Quantum Initiative Program','State Small Business Credit Initiative','Vector Expedited Review Voucher program','Water Source Protection Program'],
 'recreation area': ['Ashley Karst National Recreation and Geologic Area','Land Between the Lakes National Recreation Area','Spring Mountains National Recreation Area'],
 'secretary': ['Secretary of Agriculture','Secretary of Commerce','Secretary of Defense','Secretary of Energy','Secretary of Health and Human Services','Secretary of Homeland Security','Secretary of Housing and Urban Development','Secretary of Labor','Secretary of State','Secretary of Transportation','Secretary of the Interior','Secretary of the Senate','Secretary of the Treasury'],
 'service': ['United States Fish and Wildlife Service','Foreign Agricultural Service of the Department of Agriculture'],
 'special management area': ['Frank and Jeanne Moore Wild Steelhead Special Management Area','Hermosa Creek Special Management Area','Numu Newe Special Management Area'],
 'state': ['State of Alaska','State of Arizona','State of California','State of Colorado','State of Connecticut','State of Hawaii','State of Maryland','State of Missouri','State of Montana','State of Nevada','State of New Jersey','State of New Mexico','State of New York','State of Oregon','State of South Carolina','State of Tennessee','State of Utah'],
 'system': ['John H. Chafee Coastal Barrier Resources System','National Landscape Conservation System'],
 'task force': ['Presidential Task Force on Wildlife Trafficking','United States Coral Reef Task Force'],
 'tribe': ['Lone Pine Paiute-Shoshone Tribe','Walker River Paiute Tribe'],
 'trust': ['Oklahoma City National Memorial Trust','Valles Caldera Trust'],
 'under secretary': ['Under Secretary for Science and Technology','Under Secretary of Commerce for Minority Business Development','Under Secretary of Commerce for Oceans and Atmosphere'],
 'wilderness': ['Black Ridge Canyons Wilderness','Dominguez Canyon Wilderness Area'],
}


def norm(s):
    return re.sub(r'\W+', ' ', s.casefold()).strip()


def identity_key(term, answers):
    return norm(term), tuple(sorted(norm(a) for a in answers))


def name_entry(e, names):
    answer = e['answer']
    # Scope exceptions or alternative entities may remain unresolved by citation.
    if re.search(r'\b(?:or|except|unless|with respect to)\b', answer, re.I):
        return None
    text = re.sub(r'^(?:the|The) ', '', answer)
    possible = [n for n in names if text == n or text.startswith(n + ' ') or text.startswith(n + ',') or text.startswith(n + '.')]
    if not possible:
        return None
    name = max(possible, key=len)
    suffix = text[len(name):]
    # Only remove provenance, location, creation references or acting capacities.
    # The question asks the name, rather than the complete statutory definition.
    if suffix and not re.match(r'^(?:,? (?:established|designated|appointed|selected|provided for|under |as |acting |who |in the State of|in accordance with|consisting of|so designated|implemented|located|a unit of|with jurisdiction)|, (?:New Mexico|New Jersey))', suffix):
        return None
    d = dict(e)
    d['short_answer'] = name
    return d


def question(term, i):
    t = term
    # Query wording contains no citation, source answer, or dimension label.
    patterns = [
      'What is the full name designated by “{t}”?',
      'Which entity does the defined term “{t}” identify?',
      'What is the name of the entity called “{t}”?',
      'Which entity is designated as “{t}”?',
      'What entity is named in the definition of “{t}”?',
    ]
    return patterns[i % len(patterns)].format(t=t)


def context(entries):
    chunks = []
    for e in entries:
        row = e['row']
        # Relevant definition paragraph copied in full. A prefix preserves the
        # chapter heading/scope where available. This is source text, not gold.
        text = row['text']
        line = e['evidence_quote']
        prefix = text[:min(1600, e['span_start'])].rstrip()
        body = prefix + '\n\n[Relevant definition paragraph from the same section]\n' + line if e['span_start'] >= 1600 else text[:e['span_end']]
        chunks.append(f'### Source: {row["citation"]}\nIdentifier: {row["identifier"]}\nTitle: {row.get("title_name", "")}\nRelease: {row.get("release_label", "")}\nSource excerpt:\n{body}')
    return '\n\n'.join(chunks)


def evidence(e, answer):
    offset = e['evidence_quote'].index(answer)
    start = e['span_start'] + offset
    assert e['row']['text'][start:start+len(answer)] == answer
    return {'citation':e['row']['citation'], 'source_id':e['source_id'],
            'evidence_quote':e['evidence_quote'], 'answer':answer,
            'section_start':start, 'section_end':start+len(answer),
            'release_label':e['row'].get('release_label')}


def write_jsonl(path, rows):
    path.write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in rows), encoding='utf-8')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input-parquet', required=True)
    ap.add_argument('--original-200', required=True)
    ap.add_argument('--extractor', default='build_usc_200.py')
    ap.add_argument('--outdir', default='usc_200_short_v3')
    ap.add_argument('--n', type=int, default=200)
    args = ap.parse_args()
    out = Path(args.outdir)
    if out.exists() and any(out.iterdir()):
        ap.error('Choose an empty output directory.')
    spec = importlib.util.spec_from_file_location('source_extractor', args.extractor)
    module = importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    groups, stats = module.extract([Path(args.input_parquet)])
    originals = [json.loads(l) for l in Path(args.original_200).read_text().splitlines() if l.strip()]
    _, seeds, _ = revise(originals)
    sources = {e['source_id']:e['row'] for es in groups.values() for e in es}
    used = set();rows = []
    for seed in seeds:
        rec = seed['metadata']['original_record']
        pairs = seed['gold']['condition_answer_pairs']
        evs = rec['short_answer_evidence']
        for ev in evs:
            text = sources[ev['source_id']]['text']
            assert text[ev['section_start']:ev['section_end']] == ev['answer']
        term = seed['gold']['ambiguous_conditions'][0]['term']
        used.add(identity_key(term,[p['answer'] for p in pairs]))
        source_entries = []
        for ev in evs:
            source_entries.append({'row':sources[ev['source_id']], 'evidence_quote':ev['evidence_quote'],
                                   'span_start':sources[ev['source_id']]['text'].index(ev['evidence_quote'])})
            source_entries[-1]['span_end'] = source_entries[-1]['span_start']+len(ev['evidence_quote'])
        rows.append({'id':seed['id'], 'query':seed['query'], 'table':context(source_entries),
                     'gold':copy.deepcopy(seed['gold']), 'evaluation_ready':True,
                     'metadata':{'dataset':'USC_LegalScope', 'evidence':evs, 'origin':'retained_v2_rewrite',
                                 'human_review':'pending', 'dimension_status':'proposed_primary_label_with_entity_overlap'}})
    pools = {}
    eligible_counts = {}
    for term, names in NAMES.items():
        distinct = {}
        for e in groups.get(term,[]):
            d = name_entry(e, names)
            if not d:continue
            # Canonically identical entity names are not different answers.
            k=norm(d['short_answer'])
            rank=(len(d['row']['text']),d['source_id'])
            if k not in distinct or rank < (len(distinct[k]['row']['text']),distinct[k]['source_id']):distinct[k]=d
        eligible_counts[term]=len(distinct)
        combinations=[]
        for a,b in itertools.combinations(sorted(distinct.values(),key=lambda d:d['source_id']),2):
            if a['source_id']==b['source_id']:continue
            key=identity_key(term,[a['short_answer'],b['short_answer']])
            if key in used:continue
            combinations.append((a,b))
        random.Random('USC-v3-'+term).shuffle(combinations)
        pools[term]=combinations
    # Balanced rounds: term/answer pairs are unique; at most 12 examples/term.
    counts=Counter(norm(r['gold']['ambiguous_conditions'][0]['term']) for r in rows)
    indices=Counter();total_candidates=sum(len(p) for p in pools.values())
    while len(rows)<args.n:
        progressed=False
        for term in sorted(pools):
            if len(rows)>=args.n:break
            if counts[term]>=12 or indices[term]>=len(pools[term]):continue
            a,b=pools[term][indices[term]];indices[term]+=1
            answers=[a['short_answer'],b['short_answer']]
            key=identity_key(term,answers)
            if key in used:continue
            used.add(key)
            conds=[a['row']['citation'],b['row']['citation']]
            gold={'ambiguous_conditions':[{'term':a['term'],'dimension':'Legal-Scope','conditions':conds}],
                  'condition_answer_pairs':[{'conditions':{'Legal-Scope':c},'answer':ans,'acceptable_answers':[ans]+ALIASES.get(ans,[])} for c,ans in zip(conds,answers)]}
            rows.append({'id':f'USC_V3_{len(rows)+1:04d}', 'query':question(a['term'],counts[term]),
                'table':context([a,b]), 'gold':gold, 'evaluation_ready':True,
                'metadata':{'dataset':'USC_LegalScope','evidence':[evidence(e,ans) for e,ans in zip([a,b],answers)],
                            'origin':'new_distinct_scope_answer_pair','human_review':'pending',
                            'dimension_status':'proposed_primary_label_with_entity_overlap'}})
            counts[term]+=1;progressed=True
        if not progressed:
            raise ValueError(f'Only {len(rows)} examples satisfy registry and cap; cannot pad to {args.n}.')
    assert len(rows)==args.n and len({r['id'] for r in rows})==args.n
    assert len({identity_key(r['gold']['ambiguous_conditions'][0]['term'],[p['answer'] for p in r['gold']['condition_answer_pairs']]) for r in rows})==args.n
    standardizer = module.load_standardizer(str(Path(args.extractor).with_name('standardize_benchmark.py')))
    for r in rows:
        standardizer.validate_gold(r['gold'])
        for p,ev in zip(r['gold']['condition_answer_pairs'],r['metadata']['evidence']):
            assert p['answer']==ev['answer'] and ev['evidence_quote'] in r['table']
            assert p['answer'] in ev['evidence_quote'] and len(p['answer'].split())<=25
            assert sources[ev['source_id']]['text'][ev['section_start']:ev['section_end']]==p['answer']
            assert p['answer'] in p['acceptable_answers']
    out.mkdir(parents=True,exist_ok=True)
    write_jsonl(out/'usc_eval_standard.jsonl',rows)
    write_jsonl(out/'usc_model_inputs.jsonl',[{k:r[k] for k in ('id','query','table')} for r in rows])
    lines=['# USC 200题：短答案修订版','', '共200题、400组条件答案。全部答案已核对原始法条中的连续片段。',
           '技术可运行不代表独立人工验证已完成；human_review仍为pending。Legal-Scope主标签采用“适用法条优先”的约定，机构名称题有实体消歧重叠。','']
    for i,r in enumerate(rows,1):
        lines += [f'## {i}. {r["id"]}', '', '**问题：** '+r['query'], '', '**维度：** Legal-Scope','']
        for p,ev in zip(r['gold']['condition_answer_pairs'],r['metadata']['evidence']):
            lines += ['**Condition：** '+ev['citation'],'','**Answer：** '+p['answer'],'',
                      '**Acceptable answers：** '+' / '.join(p['acceptable_answers']),'','> '+ev['evidence_quote'],'']
    (out/'USC_review_200.md').write_text('\n'.join(lines),encoding='utf-8')
    report={'queries':len(rows),'condition_answer_pairs':2*len(rows),'unique_terms':len(counts),
        'term_counts':dict(sorted(counts.items())),'unique_term_answer_pairs':len(used),
        'unique_query_wordings':len({r['query'] for r in rows}),
        'max_answer_words':max(len(p['answer'].split()) for r in rows for p in r['gold']['condition_answer_pairs']),
        'max_context_characters':max(len(r['table']) for r in rows),'source_rows':dict(stats),
        'available_entity_pairs_before_sampling':total_candidates,
        'verified_source_spans':2*len(rows), 'retained_v2_examples':len(seeds),
        'input_sha256':hashlib.sha256(Path(args.input_parquet).read_bytes()).hexdigest(),
        'checks':['200 unique IDs','400 source-verified contiguous answer spans','two distinct conditions and normalized answers per example',
                  'no duplicate term/answer pairs','gold schema validation','citation-only conditions','model inputs contain only id/query/table'],
        'evaluation_ready_meaning':'independent source context and valid schema; does not mean human-reviewed',
        'human_review':'pending','model_run':False,'limits':['Legal-Scope/Entity overlap requires an agreed primary-label convention.',
           'Repeated terms occur across distinct scope/answer pairs; this is not 200 unique terms.',
           'Controlled questions constructed from provided legal snapshots; not naturally collected queries.',
           'Aliases require evaluator support and independent review.','Predominantly entity-name questions; template diversity is limited.',
           'Different release labels can occur; no legal-version ambiguity is claimed.']}
    (out/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'dimension_prompt_proposal.txt').write_text(DIMENSION_TEXT,encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['queries','condition_answer_pairs','unique_terms','max_answer_words','max_context_characters','verified_source_spans','available_entity_pairs_before_sampling']},ensure_ascii=False,indent=2))


if __name__=='__main__':main()

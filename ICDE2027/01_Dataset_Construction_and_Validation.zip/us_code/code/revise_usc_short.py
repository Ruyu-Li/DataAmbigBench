#!/usr/bin/env python3
"""Revise the original USC 200 candidate JSONL; no API calls or new legal facts.

Only explicitly reviewed rewrite specifications enter the short-answer subset.
All 200 receive citation-only condition labels. IDs and source contexts persist.
The short-answer subset remains pending independent human semantic review.
"""
import argparse
import copy
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

# ID -> (query, two contiguous original-text answer spans).
# These specifications apply to the supplied original USC_SCOPE dataset only.
SPECS = {
    1: ('Which commission is designated by the term “Commission”?', ['Federal Energy Regulatory Commission', 'Commission for the Conservation and Management of Highly Migratory Fish Stocks in the Western and Central Pacific Ocean']),
    2: ('Which board is designated by the term “Board”?', ['Advisory Board for the HOPE for Homeowners Program', 'Merit Systems Protection Board']),
    5: ('Below what age does a person qualify as a “child”?', ['16', '13']),
    7: ('Which official is designated as “Under Secretary”?', ['Under Secretary of Commerce for Minority Business Development', 'Under Secretary for Science and Technology']),
    8: ('What is the name of the “Fund”?', ['Orderly Liquidation Fund', 'Securities and Exchange Commission Investor Protection Fund']),
    13: ('Which agency is designated as “Administration”?', ['Small Business Administration', 'National Oceanic and Atmospheric Administration']),
    16: ('What is the name of the “Monument”?', ['White Sands National Monument', 'Oregon Caves National Monument']),
    19: ('What donated product does an “eligible distributor” distribute?', ['eligible milk', 'eligible dairy products']),
    22: ('Which fruit is the subject of “consumer information”?', ['kiwifruit', 'Hass avocados']),
    24: ('Which official is designated as “Administrator”?', ['Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration', 'Administrator of General Services']),
    27: ('What is the name of the “Conservation Area”?', ['California Desert Conservation Area', 'Gunnison Gorge National Conservation Area']),
    33: ('Which advisory committee is designated as “Advisory Committee”?', ['National Artificial Intelligence Advisory Committee', 'Biomass Research and Development Technical Advisory Committee']),
    38: ('Which committee is designated as “Committee”?', ['American Fisheries Advisory Committee', 'Soybean Program Coordinating Committee']),
    43: ('Which city is designated as “City”?', ['City of Paterson, New Jersey', 'city of Durango, Colorado']),
    44: ('Which tribe is designated as “Tribe”?', ['Lone Pine Paiute-Shoshone Tribe', 'Walker River Paiute Tribe']),
    50: ('Which corporation is designated as “Corporation”?', ['Federal Deposit Insurance Corporation', 'Commodity Credit Corporation']),
    70: ('Which commodity is the focus of “industry information”?', ['honey', 'Hass avocados']),
    71: ('Which official is designated as “Assistant Secretary”?', ['Assistant Secretary for the Countering Weapons of Mass Destruction Office', 'Assistant Secretary of Commerce for Communications and Information']),
    78: ('Which service is designated as “Service”?', ['United States Fish and Wildlife Service', 'Foreign Agricultural Service of the Department of Agriculture']),
    92: ('What is the name of the “Special Management Area”?', ['Numu Newe Special Management Area', 'Frank and Jeanne Moore Wild Steelhead Special Management Area']),
    97: ('What is the name of the “preserve”?', ['Great Sand Dunes National Preserve', 'Valles Caldera National Preserve']),
    100: ('Which task force is designated as “Task Force”?', ['United States Coral Reef Task Force', 'Presidential Task Force on Wildlife Trafficking']),
    104: ('Which board is designated as “Advisory Board”?', ['Land Between the Lakes Advisory Board', 'National Agricultural Research, Extension, Education, and Economics Advisory Board']),
    105: ('Which chairperson is designated as “Chairperson”?', ['Chairperson of the Appraisal Subcommittee', 'Chairperson of the Council']),
    107: ('Which foundation is designated as “Foundation”?', ['National Fish and Wildlife Foundation', 'National Natural Resources Conservation Foundation']),
    109: ('Which crop or crops are the subject of “marketing”?', ['canola, rapeseed', 'kiwifruit']),
    111: ('What is the name of the “Wilderness”?', ['Black Ridge Canyons Wilderness', 'Dominguez Canyon Wilderness Area']),
    121: ('Which authority is designated as “Authority”?', ['Horseracing Integrity and Safety Authority', 'Delta Regional Authority']),
    135: ('What is the name of the “Initiative”?', ['National Artificial Intelligence Initiative', 'pulse crop health initiative']),
    140: ('What is the name of the “park”?', ['Cumberland Gap National Historical Park', 'Kennesaw Mountain National Battlefield Park']),
    148: ('Which office is designated as “Office”?', ['Office of Congressional Workplace Rights', 'Countering Weapons of Mass Destruction Office']),
    160: ('What is the name of the “System”?', ['John H. Chafee Coastal Barrier Resources System', 'National Landscape Conservation System']),
    161: ('Which trust is designated as “Trust”?', ['Oklahoma City National Memorial Trust', 'Valles Caldera Trust']),
    174: ('What is the name of the “Historic District”?', ['Coltsville Historic District', 'Ste. Genevieve Historic District National Historic Landmark']),
    183: ('Which county is designated as “County”?', ['Miami-Dade County, Florida', 'Clark County, Nevada']),
    185: ('Which panel is designated as “Advisory Panel”?', ['President’s National Nanotechnology Advisory Panel', 'Advisory Panel on Pacific Hake/Whiting']),
    187: ('What is the name of the “historical park”?', ['Brown v. Board of Education National Historical Park', 'Pullman National Historical Park']),
    200: ('Which council is designated as “Advisory Council”?', ['Great Sand Dunes National Park Advisory Council', 'Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program Advisory Council']),
}

# Explicit aliases only. Never invent an acronym by taking initial letters.
ALIASES = {
    'Federal Energy Regulatory Commission': ['FERC'],
    'Federal Deposit Insurance Corporation': ['FDIC'],
    'Small Business Administration': ['SBA'],
    'National Oceanic and Atmospheric Administration': ['NOAA'],
    'United States Fish and Wildlife Service': ['U.S. Fish and Wildlife Service', 'US Fish and Wildlife Service', 'USFWS'],
    'City of Paterson, New Jersey': ['Paterson, New Jersey', 'Paterson'],
    'city of Durango, Colorado': ['Durango, Colorado', 'Durango'],
    'Miami-Dade County, Florida': ['Miami-Dade County'],
    'Clark County, Nevada': ['Clark County'],
    '16': ['16 years', '16 years old'],
    '13': ['13 years', '13 years old'],
    'canola, rapeseed': ['canola and rapeseed', 'rapeseed and canola', 'rapeseed, canola'],
}

DIMENSION_TEXT = '''Legal-Scope: The missing condition is the applicable legal provision or legal scope. The meaning of a term, or a fact derived from its definition, changes across the supplied provisions. Supply the provision citation to resolve it.
Entity Disambiguation: The missing condition is the identity of a same-named person, place, organization, or work; resolving the identity does not depend on choosing an applicable statutory definition.
For cases where statutory definitions name different entities, use Legal-Scope as the primary label when selecting the governing provision resolves the question. This is a proposed annotation convention; agree on it in both the paper and the evaluation prompt before scoring. Acknowledge entity overlap rather than claiming the categories are inherently disjoint.
'''


def normalized(s):
    return re.sub(r'\W+', ' ', s.casefold()).strip()


def write_jsonl(path, rows):
    path.write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in rows), encoding='utf-8')


def read_records(path):
    return [json.loads(l) for l in path.read_text(encoding='utf-8-sig').splitlines() if l.strip()]


def build(rows):
    annotated, short, audit = [], [], []
    seen = set()
    for original in rows:
        r = copy.deepcopy(original)
        qid = r['id']
        if qid in seen:
            raise ValueError('Duplicate ID: ' + qid)
        seen.add(qid)
        record = r['metadata']['original_record']
        evidence = record['evidence']
        gold = r['gold']
        annotation = gold['ambiguous_conditions'][0]
        dim = annotation['dimension']
        pairs = gold['condition_answer_pairs']
        if dim != 'Legal-Scope' or len(evidence) != 2 or len(pairs) != 2:
            raise ValueError(qid + ': unexpected original schema')
        conditions = [e['citation'] for e in evidence]
        if len(set(conditions)) != 2:
            raise ValueError(qid + ': section citation cannot distinguish the conditions')
        for p, e, citation in zip(pairs, evidence, conditions):
            if e['evidence_quote'] not in r['table']:
                raise ValueError(qid + ': original evidence absent from model context')
            if p['answer'] not in e['evidence_quote']:
                raise ValueError(qid + ': original answer is not in its evidence')
            p['conditions'] = {dim: citation}
        annotation['conditions'] = conditions
        record['gold'] = copy.deepcopy(gold)
        r['evaluation_ready'] = False
        number = int(qid.removeprefix('USC_SCOPE_'))
        spec = SPECS.get(number)
        if spec is not None:
            query, answers = spec
            term = annotation['term']
            if '“' + term + '”' not in query:
                raise ValueError(qid + ': rewrite specification does not match original term')
            if normalized(answers[0]) == normalized(answers[1]):
                raise ValueError(qid + ': rewritten answers collapse')
            r['query'] = query
            spans = []
            for p, e, answer in zip(pairs, evidence, answers):
                if answer not in p['answer'] or answer not in e['evidence_quote']:
                    raise ValueError(qid + ': rewritten answer is not a contiguous source span: ' + answer)
                if len(answer.split()) > 25:
                    raise ValueError(qid + ': answer exceeds 25-word screening limit')
                accepted = [answer] + ALIASES.get(answer, [])
                p['answer'] = answer
                p['acceptable_answers'] = accepted
                offset = e['evidence_quote'].index(answer)
                spans.append({'citation': e['citation'], 'source_id': e['source_id'],
                              'answer': answer, 'section_start': e['span_start'] + offset,
                              'section_end': e['span_start'] + offset + len(answer),
                              'evidence_quote': e['evidence_quote'],
                              'aliases_status': 'proposed_for_human_review'})
            record['query'] = query
            record['gold'] = copy.deepcopy(gold)
            record['short_answer_evidence'] = spans
            status = 'short_answer_candidate_pending_review'
            reason = 'Two distinct contiguous answer spans; rewritten to ask the named entity or explicit attribute.'
            short.append(r)
        else:
            status = 'excluded_from_short_subset'
            reason = 'No approved short-span rewrite in this pass. Needs a complete attribute question, replacement, or semantic-equivalence review; not automatically declared invalid.'
        record['review_status'] = {k: 'pending' for k in ('naturalness', 'ambiguity', 'condition_sufficiency', 'answer_correctness', 'aliases', 'dimension')}
        record['revision_status'] = status
        # Preserve original source-reference warnings even when asking only a name.
        r['metadata']['revision'] = {'status': status, 'reason': reason, 'old_query': original['query'],
            'old_answers': [p['answer'] for p in original['gold']['condition_answer_pairs']],
            'dimension_convention': 'proposed; governing statutory scope is primary, entity overlap acknowledged',
            'evaluation_ready_note': 'false until independent human review; context is present'}
        annotated.append(r)
        audit.append({'id': qid, 'term': annotation['term'], 'status': status, 'reason': reason,
                      'old_query': original['query'], 'new_query': r['query'],
                      'old_answers': [p['answer'] for p in original['gold']['condition_answer_pairs']],
                      'new_answers': [p['answer'] for p in pairs]})
    if len({r['query'] for r in short}) != len(short):
        raise ValueError('Duplicate rewritten questions')
    return annotated, short, audit


def review(rows):
    lines = ['# USC 短答案修订候选题', '', f'共 {len(rows)} 题。保留原编号；全部需独立人工复核。', '',
             '请逐题核对：新问题自然且完整；两条法律范围都适用；两个答案语义不同；短片段完整回答新问题；别名等价；Legal-Scope 主标签合理。', '',
             '较长的机构正式名称保留全名，不机械截断。完整法条仍在模型 context 中。', '']
    for r in rows:
        old = r['metadata']['revision']
        lines += [f'## {r["id"]}', '', '**新问题：** ' + r['query'], '', '**原问题：** ' + old['old_query'], '']
        for j, (p, e) in enumerate(zip(r['gold']['condition_answer_pairs'], r['metadata']['original_record']['evidence']), 1):
            lines += [f'**Condition {j}：** {e["citation"]}', '', '**新答案：** ' + p['answer'], '',
                      '**允许答案（待核对）：** ' + ' / '.join(p['acceptable_answers']), '',
                      '**原答案：** ' + old['old_answers'][j-1], '', '**原文证据：**', '', '> ' + e['evidence_quote'], '']
        lines += ['审阅：□自然 □歧义成立 □条件足够 □答案完整正确 □别名等价 □维度合理', '', '意见：________', '']
    return '\n'.join(lines)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input', required=True)
    ap.add_argument('--outdir', default='usc_short_output')
    ap.add_argument('--source-parquet', help='Optional original Parquet for byte-exact section-offset verification; requires pyarrow')
    args = ap.parse_args()
    inp, out = Path(args.input), Path(args.outdir)
    if out.exists() and any(out.iterdir()):
        ap.error('Output directory must be empty; use a new --outdir.')
    rows = read_records(inp)
    annotated, short, audit = build(rows)
    if not short:
        ap.error('No rewrite specifications matched; use the original USC 200 file.')
    verified = 0
    if args.source_parquet:
        import pyarrow.parquet as pq
        wanted = {e['source_id'] for r in short for e in r['metadata']['original_record']['short_answer_evidence']}
        sources = {}
        for batch in pq.ParquetFile(args.source_parquet).iter_batches(batch_size=512, columns=['identifier','text']):
            for source in batch.to_pylist():
                if source['identifier'] in wanted:
                    sources[source['identifier']] = source['text']
        for r in short:
            for e in r['metadata']['original_record']['short_answer_evidence']:
                if sources.get(e['source_id'], '')[e['section_start']:e['section_end']] != e['answer']:
                    raise ValueError(r['id'] + ': answer offsets do not match original Parquet')
                verified += 1
    out.mkdir(parents=True, exist_ok=True)
    write_jsonl(out / 'usc_all_conditions_shortened.jsonl', annotated)
    write_jsonl(out / 'usc_short_candidates.jsonl', short)
    write_jsonl(out / 'usc_short_model_inputs.jsonl', [{k:r[k] for k in ('id','query','table')} for r in short])
    write_jsonl(out / 'usc_revision_audit.jsonl', audit)
    (out / 'USC_review_short.md').write_text(review(short), encoding='utf-8')
    (out / 'dimension_prompt_proposal.txt').write_text(DIMENSION_TEXT, encoding='utf-8')
    report = {'input_queries':len(rows), 'conditions_shortened':sum(len(r['gold']['condition_answer_pairs']) for r in annotated),
        'short_answer_candidates':len(short), 'short_answer_pairs':2*len(short), 'remaining_for_rewrite_or_replacement':len(rows)-len(short),
        'max_answer_words':max(len(p['answer'].split()) for r in short for p in r['gold']['condition_answer_pairs']),
        'answer_type_counts':dict(Counter('age' if r['id'].endswith('0005') else 'commodity' if int(r['id'][-4:]) in [19,22,70,109] else 'entity_name' for r in short)),
        'checks': ['unique IDs and queries', 'citation-only conditions synchronized in gold and metadata', 'answers are contiguous spans of their own source evidence and model context', 'source contexts unchanged', 'two distinct normalized answers per question', 'model inputs contain only id/query/table'],
        'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(), 'human_review':'pending', 'model_run':False,
        'verified_answer_spans_in_parquet':verified,
        'scoring_note':'No scoring code changed. Verify the downstream evaluator actually reads acceptable_answers. Revisions require rerunning affected experiments; historical scores are not guaranteed unchanged.'}
    (out / 'revision_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()

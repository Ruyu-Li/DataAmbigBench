USC 200 short-answer revision v3 — handoff to Ruyu

Files to use:
  usc_eval_standard.jsonl : all 200 examples with gold, scoring input
  usc_model_inputs.jsonl  : the same 200 examples, only id/query/table
  USC_review_200.md       : readable questions, conditions, answers, evidence
  validation_report.json : provenance, counts, technical checks, limitations
  dimension_prompt_proposal.txt : proposed dimension definitions for paper/prompt

200 queries, 400 condition-answer pairs, 49 distinct terms.
38 explicit rewrites from v2 are retained. The 162 additions use different
statutory definitions and distinct term/answer pairs. Some query wordings and
terms repeat across different contexts. This is NOT 200 unique terms.
Each term occurs at most 11 times in this released set (generation cap: 12).
Split related term/source clusters together if introducing train/test splits;
random example splits could leak shared definitions across partitions.

Format:
  id / query / table / gold / evaluation_ready / metadata
  gold.ambiguous_conditions: term, dimension, conditions
  gold.condition_answer_pairs: conditions, answer, acceptable_answers
Compatible with the previous core data schema. The alias field must actually
be read by the evaluator; the field alone cannot enable alias scoring.
Only query/table should reach the model. Never send gold or metadata.

Changes:
  Conditions contain citation only (e.g. 15 U.S.C. § 3301).
  Queries ask names or explicit attributes rather than full legal definitions.
  Canonical answers are contiguous original-source spans, maximum 18 words.
  Longer official names remain intact; never arbitrarily truncate a name.
  Relevant full definition paragraphs are copied into context. Section prefixes
  retain available headings/scope; irrelevant long section bodies are omitted.
  Maximum context length: 4,117 characters (not a measured model token count).
  All 400 answer character offsets were verified against the original Parquet.
  No model calls were made and no scoring functions were changed.

evaluation_ready=true means that source context and valid gold are available
for a technical pilot. Independent human review is still pending in metadata;
this flag does not assert human approval. Source extraction and annotation
checks are not independent naturalness validation.

Dimension:
  Legal-Scope is the proposed primary label where selecting the governing
  statutory provision resolves the definition. Many name questions overlap
  with Entity Disambiguation. Align this convention in the paper and prompt
  before interpreting Dimension F1; see dimension_prompt_proposal.txt.
  Examples are controlled scope omissions from supplied legal snapshots.
  Different release labels can occur; this set does not test legal revisions.

Running:
The generated JSONL files are included. No regeneration is needed to inspect
or pilot the 200 examples. Use the existing evaluator on usc_eval_standard.jsonl,
after checking alias handling and the proposed dimension convention.
For answer scoring, keep the existing normalization/numeric-equivalence rules
and compare against answer plus acceptable_answers. Re-run changed experiments;
this release does not imply historical scores remain unchanged.

Reproduce in Colab:
1. Upload this ZIP and train-00000-of-00003.parquet.
2. Run:
   import zipfile
   with zipfile.ZipFile('/content/USC_200_short_answer_v3.zip') as z:
       z.extractall('/content/usc_v3')
3. Run:
   !pip -q install pyarrow
   !python /content/usc_v3/code/build_usc_200_short_v3.py --input-parquet /content/train-00000-of-00003.parquet --original-200 /content/usc_v3/code/input/usc_standard_original.jsonl --extractor /content/usc_v3/code/build_usc_200.py --outdir /content/usc_v3_reproduced
Choose a new empty output directory if repeating the command.
The original Parquet is intentionally not duplicated in the package.

中文：直接给 Ruyu 整个 ZIP。评分文件是 usc_eval_standard.jsonl，
模型输入是 usc_model_inputs.jsonl。两者为同一批200题。
原38题版不再作为这次交付的独立评测输入；不需要你反复解压或重跑。

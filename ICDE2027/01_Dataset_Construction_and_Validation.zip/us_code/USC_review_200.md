# USC 200题：短答案修订版

共200题、400组条件答案。全部答案已核对原始法条中的连续片段。
技术可运行不代表独立人工验证已完成；human_review仍为pending。Legal-Scope主标签采用“适用法条优先”的约定，机构名称题有实体消歧重叠。

## 1. USC_SCOPE_0001

**问题：** Which commission is designated by the term “Commission”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 3301

**Answer：** Federal Energy Regulatory Commission

**Acceptable answers：** Federal Energy Regulatory Commission / FERC

> The term “Commission” means the Federal Energy Regulatory Commission.

**Condition：** 16 U.S.C. § 6901

**Answer：** Commission for the Conservation and Management of Highly Migratory Fish Stocks in the Western and Central Pacific Ocean

**Acceptable answers：** Commission for the Conservation and Management of Highly Migratory Fish Stocks in the Western and Central Pacific Ocean

> The term “Commission” means the Commission for the Conservation and Management of Highly Migratory Fish Stocks in the Western and Central Pacific Ocean established in accordance with this Convention.

## 2. USC_SCOPE_0002

**问题：** Which board is designated by the term “Board”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1715z–23

**Answer：** Advisory Board for the HOPE for Homeowners Program

**Acceptable answers：** Advisory Board for the HOPE for Homeowners Program

> The term “Board” means the Advisory Board for the HOPE for Homeowners Program. The Board shall be composed of the Secretary, the Secretary of the Treasury, the Chairperson of the Board of Governors of the Federal Reserve System, and the Chairperson of the Board of Directors of the Federal Deposit Insurance Corporation, or their designees.

**Condition：** 3 U.S.C. § 401

**Answer：** Merit Systems Protection Board

**Acceptable answers：** Merit Systems Protection Board

> The term “Board” means the Merit Systems Protection Board under chapter 12 of title 5.

## 3. USC_SCOPE_0005

**问题：** Below what age does a person qualify as a “child”?

**维度：** Legal-Scope

**Condition：** 10 U.S.C. § 920b

**Answer：** 16

**Acceptable answers：** 16 / 16 years / 16 years old

> The term “child” means any person who has not attained the age of 16 years.

**Condition：** 15 U.S.C. § 6501

**Answer：** 13

**Acceptable answers：** 13 / 13 years / 13 years old

> The term “child” means an individual under the age of 13.

## 4. USC_SCOPE_0007

**问题：** Which official is designated as “Under Secretary”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9501

**Answer：** Under Secretary of Commerce for Minority Business Development

**Acceptable answers：** Under Secretary of Commerce for Minority Business Development

> The term “Under Secretary” means the Under Secretary of Commerce for Minority Business Development, who is appointed as described in section ___3(b) 1 to administer this chapter.

**Condition：** 6 U.S.C. § 187

**Answer：** Under Secretary for Science and Technology

**Acceptable answers：** Under Secretary for Science and Technology

> The term “Under Secretary” means the Under Secretary for Science and Technology.

## 5. USC_SCOPE_0008

**问题：** What is the name of the “Fund”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5381

**Answer：** Orderly Liquidation Fund

**Acceptable answers：** Orderly Liquidation Fund

> The term “Fund” means the Orderly Liquidation Fund established under section 5390(n) of this title.

**Condition：** 15 U.S.C. § 78u–6

**Answer：** Securities and Exchange Commission Investor Protection Fund

**Acceptable answers：** Securities and Exchange Commission Investor Protection Fund

> The term “Fund” means the Securities and Exchange Commission Investor Protection Fund.

## 6. USC_SCOPE_0013

**问题：** Which agency is designated as “Administration”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 6901

**Answer：** Small Business Administration

**Acceptable answers：** Small Business Administration / SBA

> The term “Administration” means the Small Business Administration.

**Condition：** 15 U.S.C. § 8512a

**Answer：** National Oceanic and Atmospheric Administration

**Acceptable answers：** National Oceanic and Atmospheric Administration / NOAA

> The term “Administration” means the National Oceanic and Atmospheric Administration.

## 7. USC_SCOPE_0016

**问题：** What is the name of the “Monument”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410dddd

**Answer：** White Sands National Monument

**Acceptable answers：** White Sands National Monument

> The term “Monument” means the White Sands National Monument, New Mexico, established by Presidential Proclamation No. 2025 (54 U.S.C. 320301 note), dated January 18, 1933, and administered by the Secretary of the Interior.

**Condition：** 16 U.S.C. § 410vvv

**Answer：** Oregon Caves National Monument

**Acceptable answers：** Oregon Caves National Monument

> The term “Monument” means the Oregon Caves National Monument established by Presidential Proclamation Number 876 (36 Stat. 2497), dated July 12, 1909.

## 8. USC_SCOPE_0019

**问题：** What donated product does an “eligible distributor” distribute?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 9071

**Answer：** eligible milk

**Acceptable answers：** eligible milk

> The term “eligible distributor” means a public or private nonprofit organization that distributes donated eligible milk.

**Condition：** 7 U.S.C. § 9071a

**Answer：** eligible dairy products

**Acceptable answers：** eligible dairy products

> The term “eligible distributor” means a public or private nonprofit organization that distributes donated eligible dairy products to recipient individuals and families.

## 9. USC_SCOPE_0022

**问题：** Which fruit is the subject of “consumer information”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 7462

**Answer：** kiwifruit

**Acceptable answers：** kiwifruit

> The term “consumer information” means any action taken to provide information to, and broaden the understanding of, the general public regarding the consumption, use, nutritional attributes, and care of kiwifruit.

**Condition：** 7 U.S.C. § 7802

**Answer：** Hass avocados

**Acceptable answers：** Hass avocados

> The term “consumer information” means any action or program that provides information to consumers and other persons on the use, nutritional attributes, and other information that will assist consumers and other persons in making evaluations and decisions regarding the purchase, preparation, and use of Hass avocados.

## 10. USC_SCOPE_0024

**问题：** Which official is designated as “Administrator”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8512a

**Answer：** Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration

**Acceptable answers：** Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration

> The term “Administrator” means the Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration.

**Condition：** 16 U.S.C. § 410r–6

**Answer：** Administrator of General Services

**Acceptable answers：** Administrator of General Services

> The term “Administrator” means the Administrator of General Services.

## 11. USC_SCOPE_0027

**问题：** What is the name of the “Conservation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410aaa–81c

**Answer：** California Desert Conservation Area

**Acceptable answers：** California Desert Conservation Area

> The term “Conservation Area” means the California Desert Conservation Area.

**Condition：** 16 U.S.C. § 410fff–1

**Answer：** Gunnison Gorge National Conservation Area

**Acceptable answers：** Gunnison Gorge National Conservation Area

> The term “Conservation Area” means the Gunnison Gorge National Conservation Area, consisting of approximately 57,725 acres surrounding the Gunnison Gorge as depicted on the Map.

## 12. USC_SCOPE_0033

**问题：** Which advisory committee is designated as “Advisory Committee”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9401

**Answer：** National Artificial Intelligence Advisory Committee

**Acceptable answers：** National Artificial Intelligence Advisory Committee

> The term “Advisory Committee” means the National Artificial Intelligence Advisory Committee established under section 9414(a) of this title.

**Condition：** 7 U.S.C. § 8101

**Answer：** Biomass Research and Development Technical Advisory Committee

**Acceptable answers：** Biomass Research and Development Technical Advisory Committee

> The term “Advisory Committee” means the Biomass Research and Development Technical Advisory Committee established by section 8108(d)(1) of this title.

## 13. USC_SCOPE_0038

**问题：** Which committee is designated as “Committee”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 713c–3

**Answer：** American Fisheries Advisory Committee

**Acceptable answers：** American Fisheries Advisory Committee

> The term “Committee” means the American Fisheries Advisory Committee established under paragraph (2).

**Condition：** 7 U.S.C. § 6302

**Answer：** Soybean Program Coordinating Committee

**Acceptable answers：** Soybean Program Coordinating Committee

> The term “Committee” means the Soybean Program Coordinating Committee established under section 6304(g) of this title.

## 14. USC_SCOPE_0043

**问题：** Which city is designated as “City”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410lll

**Answer：** City of Paterson, New Jersey

**Acceptable answers：** City of Paterson, New Jersey / Paterson, New Jersey / Paterson

> The term “City” means the City of Paterson, New Jersey.

**Condition：** 16 U.S.C. § 539q

**Answer：** city of Durango, Colorado

**Acceptable answers：** city of Durango, Colorado / Durango, Colorado / Durango

> The term “City” means the city of Durango, Colorado.

## 15. USC_SCOPE_0044

**问题：** Which tribe is designated as “Tribe”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460ffff

**Answer：** Lone Pine Paiute-Shoshone Tribe

**Acceptable answers：** Lone Pine Paiute-Shoshone Tribe

> The term “Tribe” means the Lone Pine Paiute-Shoshone Tribe.

**Condition：** 16 U.S.C. § 460iiii

**Answer：** Walker River Paiute Tribe

**Acceptable answers：** Walker River Paiute Tribe

> The term “Tribe” means the Walker River Paiute Tribe.

## 16. USC_SCOPE_0050

**问题：** Which corporation is designated as “Corporation”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1831q

**Answer：** Federal Deposit Insurance Corporation

**Acceptable answers：** Federal Deposit Insurance Corporation / FDIC

> The term “Corporation” means the Federal Deposit Insurance Corporation acting in its corporate capacity or its capacity as receiver.

**Condition：** 7 U.S.C. § 1736o

**Answer：** Commodity Credit Corporation

**Acceptable answers：** Commodity Credit Corporation

> The term “Corporation” means the Commodity Credit Corporation.

## 17. USC_SCOPE_0070

**问题：** Which commodity is the focus of “industry information”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 4602

**Answer：** honey

**Acceptable answers：** honey

> The term “industry information” means information or a program that will lead to the development of new markets, new marketing strategies, or increased efficiency for the honey industry, or an activity to enhance the image of honey and honey products and of the honey industry.

**Condition：** 7 U.S.C. § 7802

**Answer：** Hass avocados

**Acceptable answers：** Hass avocados

> The term “industry information” means information and programs that are designed to increase efficiency in processing, enhance the development of new markets and marketing strategies, increase marketing efficiency, and activities to enhance the image of Hass avocados and the Hass avocado industry domestically.

## 18. USC_SCOPE_0071

**问题：** Which official is designated as “Assistant Secretary”?

**维度：** Legal-Scope

**Condition：** 6 U.S.C. § 590

**Answer：** Assistant Secretary for the Countering Weapons of Mass Destruction Office

**Acceptable answers：** Assistant Secretary for the Countering Weapons of Mass Destruction Office

> The term “Assistant Secretary” means the Assistant Secretary for the Countering Weapons of Mass Destruction Office.

**Condition：** 7 U.S.C. § 950bb–6

**Answer：** Assistant Secretary of Commerce for Communications and Information

**Acceptable answers：** Assistant Secretary of Commerce for Communications and Information

> The term “Assistant Secretary” means the Assistant Secretary of Commerce for Communications and Information.

## 19. USC_SCOPE_0078

**问题：** Which service is designated as “Service”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 8302

**Answer：** United States Fish and Wildlife Service

**Acceptable answers：** United States Fish and Wildlife Service / U.S. Fish and Wildlife Service / US Fish and Wildlife Service / USFWS

> The term “Service” means the United States Fish and Wildlife Service.

**Condition：** 7 U.S.C. § 5602

**Answer：** Foreign Agricultural Service of the Department of Agriculture

**Acceptable answers：** Foreign Agricultural Service of the Department of Agriculture

> The term “Service” means the Foreign Agricultural Service of the Department of Agriculture.

## 20. USC_SCOPE_0092

**问题：** What is the name of the “Special Management Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460gggg

**Answer：** Numu Newe Special Management Area

**Acceptable answers：** Numu Newe Special Management Area

> The term “Special Management Area” means the Numu Newe Special Management Area established by subsection (b).

**Condition：** 16 U.S.C. § 539s

**Answer：** Frank and Jeanne Moore Wild Steelhead Special Management Area

**Acceptable answers：** Frank and Jeanne Moore Wild Steelhead Special Management Area

> The term “Special Management Area” means the Frank and Jeanne Moore Wild Steelhead Special Management Area designated by subsection (c)(1).

## 21. USC_SCOPE_0097

**问题：** What is the name of the “preserve”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410hhh–1

**Answer：** Great Sand Dunes National Preserve

**Acceptable answers：** Great Sand Dunes National Preserve

> The term “preserve” means the Great Sand Dunes National Preserve established in section 410hhh–3 of this title.

**Condition：** 16 U.S.C. § 698v–11

**Answer：** Valles Caldera National Preserve

**Acceptable answers：** Valles Caldera National Preserve

> The term “Preserve” means the Valles Caldera National Preserve in the State.

## 22. USC_SCOPE_0100

**问题：** Which task force is designated as “Task Force”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 6415

**Answer：** United States Coral Reef Task Force

**Acceptable answers：** United States Coral Reef Task Force

> The term “Task Force” means the United States Coral Reef Task Force established under section 6451 of this title.

**Condition：** 16 U.S.C. § 7601

**Answer：** Presidential Task Force on Wildlife Trafficking

**Acceptable answers：** Presidential Task Force on Wildlife Trafficking

> The term “Task Force” means the Presidential Task Force on Wildlife Trafficking, as established by Executive Order 13648 (78 Fed. Reg. 40621) and modified by section 7631 of this title.

## 23. USC_SCOPE_0104

**问题：** Which board is designated as “Advisory Board”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460lll

**Answer：** Land Between the Lakes Advisory Board

**Acceptable answers：** Land Between the Lakes Advisory Board

> The term “Advisory Board” means the Land Between the Lakes Advisory Board established under section 460lll–22 of this title.

**Condition：** 7 U.S.C. § 6971

**Answer：** National Agricultural Research, Extension, Education, and Economics Advisory Board

**Acceptable answers：** National Agricultural Research, Extension, Education, and Economics Advisory Board

> The term “Advisory Board” means the National Agricultural Research, Extension, Education, and Economics Advisory Board established under section 1408 of the National Agricultural Research, Extension, and Teaching Policy Act of 1977 (7 U.S.C. 3123).

## 24. USC_SCOPE_0105

**问题：** Which chairperson is designated as “Chairperson”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 3350

**Answer：** Chairperson of the Appraisal Subcommittee

**Acceptable answers：** Chairperson of the Appraisal Subcommittee

> The term “Chairperson” means the Chairperson of the Appraisal Subcommittee selected by the Council.

**Condition：** 12 U.S.C. § 5311

**Answer：** Chairperson of the Council

**Acceptable answers：** Chairperson of the Council

> The term “Chairperson” means the Chairperson of the Council.

## 25. USC_SCOPE_0107

**问题：** Which foundation is designated as “Foundation”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 4729

**Answer：** National Fish and Wildlife Foundation

**Acceptable answers：** National Fish and Wildlife Foundation

> The term “Foundation” means the National Fish and Wildlife Foundation established by section 3701(a) of this title.

**Condition：** 16 U.S.C. § 5801

**Answer：** National Natural Resources Conservation Foundation

**Acceptable answers：** National Natural Resources Conservation Foundation

> The term “Foundation” means the National Natural Resources Conservation Foundation established by section 5802(a) of this title.

## 26. USC_SCOPE_0109

**问题：** Which crop or crops are the subject of “marketing”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 7442

**Answer：** canola, rapeseed

**Acceptable answers：** canola, rapeseed / canola and rapeseed / rapeseed and canola / rapeseed, canola

> The term “marketing” means the sale or other disposition of canola, rapeseed, or canola or rapeseed products in a channel of commerce.

**Condition：** 7 U.S.C. § 7462

**Answer：** kiwifruit

**Acceptable answers：** kiwifruit

> The term “marketing” means the sale or other disposition of kiwifruit into interstate, foreign, or intrastate commerce by buying, marketing, distribution, or otherwise placing kiwifruit into commerce.

## 27. USC_SCOPE_0111

**问题：** What is the name of the “Wilderness”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460mmm–1

**Answer：** Black Ridge Canyons Wilderness

**Acceptable answers：** Black Ridge Canyons Wilderness

> The term “Wilderness” means the Black Ridge Canyons Wilderness so designated in section 460mmm–3 of this title.

**Condition：** 16 U.S.C. § 460zzz

**Answer：** Dominguez Canyon Wilderness Area

**Acceptable answers：** Dominguez Canyon Wilderness Area

> The term “Wilderness” means the Dominguez Canyon Wilderness Area designated by section 460zzz–2(a) of this title.

## 28. USC_SCOPE_0121

**问题：** Which authority is designated as “Authority”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 3051

**Answer：** Horseracing Integrity and Safety Authority

**Acceptable answers：** Horseracing Integrity and Safety Authority

> The term “Authority” means the Horseracing Integrity and Safety Authority designated by section 3052(a) of this title.

**Condition：** 7 U.S.C. § 2009aa

**Answer：** Delta Regional Authority

**Acceptable answers：** Delta Regional Authority

> The term “Authority” means the Delta Regional Authority established by section 2009aa–1 of this title.

## 29. USC_SCOPE_0135

**问题：** What is the name of the “Initiative”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9401

**Answer：** National Artificial Intelligence Initiative

**Acceptable answers：** National Artificial Intelligence Initiative

> The term “Initiative” means the National Artificial Intelligence Initiative established under section 9411(a) of this title.

**Condition：** 7 U.S.C. § 5925

**Answer：** pulse crop health initiative

**Acceptable answers：** pulse crop health initiative

> The term “Initiative” means the pulse crop health initiative established by paragraph (2).

## 30. USC_SCOPE_0140

**问题：** What is the name of the “park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 268a

**Answer：** Cumberland Gap National Historical Park

**Acceptable answers：** Cumberland Gap National Historical Park

> The term “park” means Cumberland Gap National Historical Park, as authorized and established by the Act of June 11, 1940 (54 Stat. 262; 16 U.S.C. 261 et seq.).

**Condition：** 16 U.S.C. § 430t–1

**Answer：** Kennesaw Mountain National Battlefield Park

**Acceptable answers：** Kennesaw Mountain National Battlefield Park

> The term “Park” means the Kennesaw Mountain National Battlefield Park.

## 31. USC_SCOPE_0148

**问题：** Which office is designated as “Office”?

**维度：** Legal-Scope

**Condition：** 2 U.S.C. § 1301

**Answer：** Office of Congressional Workplace Rights

**Acceptable answers：** Office of Congressional Workplace Rights

> The term “Office” means the Office of Congressional Workplace Rights.

**Condition：** 6 U.S.C. § 590

**Answer：** Countering Weapons of Mass Destruction Office

**Acceptable answers：** Countering Weapons of Mass Destruction Office

> The term “Office” means the Countering Weapons of Mass Destruction Office established under section 591(a) of this title.

## 32. USC_SCOPE_0160

**问题：** What is the name of the “System”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 3502

**Answer：** John H. Chafee Coastal Barrier Resources System

**Acceptable answers：** John H. Chafee Coastal Barrier Resources System

> The term “System” means the John H. Chafee Coastal Barrier Resources System established under section 3503(a) of this title.

**Condition：** 16 U.S.C. § 7201

**Answer：** National Landscape Conservation System

**Acceptable answers：** National Landscape Conservation System

> The term “system” means the National Landscape Conservation System established by section 7202(a) of this title.

## 33. USC_SCOPE_0161

**问题：** Which trust is designated as “Trust”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 450ss–1

**Answer：** Oklahoma City National Memorial Trust

**Acceptable answers：** Oklahoma City National Memorial Trust

> The term “Trust” means the Oklahoma City National Memorial Trust.

**Condition：** 16 U.S.C. § 698v–11

**Answer：** Valles Caldera Trust

**Acceptable answers：** Valles Caldera Trust

> The term “Trust” means the Valles Caldera Trust established by section 106(a) of the Valles Caldera Preservation Act.

## 34. USC_SCOPE_0174

**问题：** What is the name of the “Historic District”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410qqq

**Answer：** Coltsville Historic District

**Acceptable answers：** Coltsville Historic District

> The term “Historic District” means the Coltsville Historic District.

**Condition：** 16 U.S.C. § 410xxx

**Answer：** Ste. Genevieve Historic District National Historic Landmark

**Acceptable answers：** Ste. Genevieve Historic District National Historic Landmark

> The term “Historic District” means the Ste. Genevieve Historic District National Historic Landmark, as generally depicted on the Map.

## 35. USC_SCOPE_0183

**问题：** Which county is designated as “County”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410r–6

**Answer：** Miami-Dade County, Florida

**Acceptable answers：** Miami-Dade County, Florida / Miami-Dade County

> The term “County” means Miami-Dade County, Florida.

**Condition：** 16 U.S.C. § 460aaaa

**Answer：** Clark County, Nevada

**Acceptable answers：** Clark County, Nevada / Clark County

> The term “County” means Clark County, Nevada.

## 36. USC_SCOPE_0185

**问题：** Which panel is designated as “Advisory Panel”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 7509

**Answer：** President’s National Nanotechnology Advisory Panel

**Acceptable answers：** President’s National Nanotechnology Advisory Panel

> The term “Advisory Panel” means the President’s National Nanotechnology Advisory Panel established or designated under section 7503 of this title.

**Condition：** 16 U.S.C. § 7001

**Answer：** Advisory Panel on Pacific Hake/Whiting

**Acceptable answers：** Advisory Panel on Pacific Hake/Whiting

> The term “advisory panel” means the Advisory Panel on Pacific Hake/Whiting established by the Agreement.

## 37. USC_SCOPE_0187

**问题：** What is the name of the “historical park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410iiii

**Answer：** Brown v. Board of Education National Historical Park

**Acceptable answers：** Brown v. Board of Education National Historical Park

> The term “historical park” means the Brown v. Board of Education National Historical Park as established in section 410iiii–2 of this title.

**Condition：** 16 U.S.C. § 410jjjj

**Answer：** Pullman National Historical Park

**Acceptable answers：** Pullman National Historical Park

> The term “historical park” means the Pullman National Historical Park.

## 38. USC_SCOPE_0200

**问题：** Which council is designated as “Advisory Council”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410hhh–1

**Answer：** Great Sand Dunes National Park Advisory Council

**Acceptable answers：** Great Sand Dunes National Park Advisory Council

> The term “Advisory Council” means the Great Sand Dunes National Park Advisory Council established under section 410hhh–6(a) 1 of this title.

**Condition：** 7 U.S.C. § 6712

**Answer：** Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program Advisory Council

**Acceptable answers：** Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program Advisory Council

> The term “Advisory Council” means the Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program Advisory Council established under subsection (f)(1).

## 39. USC_V3_0039

**问题：** Which entity does the defined term “Administration” identify?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8512a

**Answer：** National Oceanic and Atmospheric Administration

**Acceptable answers：** National Oceanic and Atmospheric Administration / NOAA

> The term “Administration” means the National Oceanic and Atmospheric Administration.

**Condition：** 6 U.S.C. § 561

**Answer：** Transportation Security Administration

**Acceptable answers：** Transportation Security Administration

> The term “Administration” means the Transportation Security Administration.

## 40. USC_V3_0040

**问题：** Which entity does the defined term “Administrator” identify?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 6901

**Answer：** Administrator of the Small Business Administration

**Acceptable answers：** Administrator of the Small Business Administration

> The term “Administrator” means the Administrator of the Small Business Administration.

**Condition：** 16 U.S.C. § 838n

**Answer：** Administrator of the Bonneville Power Administration

**Acceptable answers：** Administrator of the Bonneville Power Administration

> The term “Administrator” means the Administrator of the Bonneville Power Administration.

## 41. USC_V3_0041

**问题：** Which entity does the defined term “Advisory Committee” identify?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8801

**Answer：** National Quantum Initiative Advisory Committee

**Acceptable answers：** National Quantum Initiative Advisory Committee

> The term “Advisory Committee” means the National Quantum Initiative Advisory Committee established under section 8814(a) of this title.

**Condition：** 7 U.S.C. § 8101

**Answer：** Biomass Research and Development Technical Advisory Committee

**Acceptable answers：** Biomass Research and Development Technical Advisory Committee

> The term “Advisory Committee” means the Biomass Research and Development Technical Advisory Committee established by section 8108(d)(1) of this title.

## 42. USC_V3_0042

**问题：** What is the full name designated by “Agency”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1422

**Answer：** Federal Housing Finance Agency

**Acceptable answers：** Federal Housing Finance Agency

> The term “Agency” means the Federal Housing Finance Agency, established under section 4511 of this title.

**Condition：** 15 U.S.C. § 9501

**Answer：** Minority Business Development Agency of the Department of Commerce

**Acceptable answers：** Minority Business Development Agency of the Department of Commerce

> The term “Agency” means the Minority Business Development Agency of the Department of Commerce.

## 43. USC_V3_0043

**问题：** Which entity does the defined term “Authority” identify?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 3051

**Answer：** Horseracing Integrity and Safety Authority

**Acceptable answers：** Horseracing Integrity and Safety Authority

> The term “Authority” means the Horseracing Integrity and Safety Authority designated by section 3052(a) of this title.

**Condition：** 7 U.S.C. § 2009bb

**Answer：** Northern Great Plains Regional Authority

**Acceptable answers：** Northern Great Plains Regional Authority

> The term “Authority” means the Northern Great Plains Regional Authority established by section 2009bb–1 of this title.

## 44. USC_V3_0044

**问题：** Which entity does the defined term “Board” identify?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 4502

**Answer：** Federal Housing Finance Oversight Board

**Acceptable answers：** Federal Housing Finance Oversight Board

> The term “Board” means the Federal Housing Finance Oversight Board established under section 4513a of this title.

**Condition：** 3 U.S.C. § 401

**Answer：** Merit Systems Protection Board

**Acceptable answers：** Merit Systems Protection Board

> The term “Board” means the Merit Systems Protection Board under chapter 12 of title 5.

## 45. USC_V3_0045

**问题：** Which entity does the defined term “Commission” identify?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 720

**Answer：** Federal Energy Regulatory Commission

**Acceptable answers：** Federal Energy Regulatory Commission / FERC

> The term “Commission” means the Federal Energy Regulatory Commission.

**Condition：** 16 U.S.C. § 7701

**Answer：** North Pacific Fisheries Commission

**Acceptable answers：** North Pacific Fisheries Commission

> The term “Commission” means the North Pacific Fisheries Commission established in accordance with the North Pacific Fisheries Convention.

## 46. USC_V3_0046

**问题：** Which entity does the defined term “Conservation Area” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460hhhh

**Answer：** Numunaa Nobe National Conservation Area

**Acceptable answers：** Numunaa Nobe National Conservation Area

> The term “Conservation Area” means the Numunaa Nobe National Conservation Area established by paragraph (2).

**Condition：** 16 U.S.C. § 460mmm–1

**Answer：** McInnis Canyons National Conservation Area

**Acceptable answers：** McInnis Canyons National Conservation Area

> The term “Conservation Area” means the McInnis Canyons National Conservation Area established by section 460mmm–2(a) of this title.

## 47. USC_V3_0047

**问题：** Which entity does the defined term “Corporation” identify?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1462

**Answer：** Federal Deposit Insurance Corporation

**Acceptable answers：** Federal Deposit Insurance Corporation / FDIC

> The term “Corporation” means the Federal Deposit Insurance Corporation.

**Condition：** 7 U.S.C. § 1502

**Answer：** Federal Crop Insurance Corporation

**Acceptable answers：** Federal Crop Insurance Corporation

> The term “Corporation” means the Federal Crop Insurance Corporation established under section 1503 of this title.

## 48. USC_V3_0048

**问题：** What is the full name designated by “Council”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 7801

**Answer：** Western Pacific Regional Fishery Management Council

**Acceptable answers：** Western Pacific Regional Fishery Management Council

> The term “Council” means the Western Pacific Regional Fishery Management Council.

**Condition：** 7 U.S.C. § 6102

**Answer：** Mushroom Council

**Acceptable answers：** Mushroom Council

> The term “Council” means the Mushroom Council established under section 6104(b) of this title.

## 49. USC_V3_0049

**问题：** Which entity does the defined term “County” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410r–6

**Answer：** Miami-Dade County, Florida

**Acceptable answers：** Miami-Dade County, Florida / Miami-Dade County

> The term “County” means Miami-Dade County, Florida.

**Condition：** 16 U.S.C. § 539q

**Answer：** La Plata County, Colorado

**Acceptable answers：** La Plata County, Colorado

> The term “County” means La Plata County, Colorado.

## 50. USC_V3_0050

**问题：** What is the full name designated by “Department”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8702

**Answer：** Department of Commerce

**Acceptable answers：** Department of Commerce

> The term “Department” means the Department of Commerce.

**Condition：** 6 U.S.C. § 1101

**Answer：** Department of Homeland Security

**Acceptable answers：** Department of Homeland Security

> The term “Department” means the Department of Homeland Security.

## 51. USC_V3_0051

**问题：** What is the full name designated by “Director”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5102

**Answer：** Director of the Bureau of Consumer Financial Protection

**Acceptable answers：** Director of the Bureau of Consumer Financial Protection

> The term “Director” means the Director of the Bureau of Consumer Financial Protection.

**Condition：** 7 U.S.C. § 3319k

**Answer：** Director of the Agriculture Advanced Research and Development Authority

**Acceptable answers：** Director of the Agriculture Advanced Research and Development Authority

> The term “Director” means the Director of the Agriculture Advanced Research and Development Authority established under subsection (b)(1).

## 52. USC_V3_0052

**问题：** What is the full name designated by “District”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410r–6

**Answer：** South Florida Water Management District

**Acceptable answers：** South Florida Water Management District

> The term “District” means the South Florida Water Management District.

**Condition：** 16 U.S.C. § 539r

**Answer：** Rocky Mountain Ranger District of the Lewis and Clark National Forest

**Acceptable answers：** Rocky Mountain Ranger District of the Lewis and Clark National Forest

> The term “district” means the Rocky Mountain Ranger District of the Lewis and Clark National Forest.

## 53. USC_V3_0053

**问题：** Which entity does the defined term “Foundation” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 7501

**Answer：** National Fish and Wildlife Foundation

**Acceptable answers：** National Fish and Wildlife Foundation

> The term “Foundation” means the National Fish and Wildlife Foundation established by section 3701(a) of this title.

**Condition：** 7 U.S.C. § 5939

**Answer：** Foundation for Food and Agriculture Research

**Acceptable answers：** Foundation for Food and Agriculture Research

> The term “Foundation” means the Foundation for Food and Agriculture Research established under subsection (b).

## 54. USC_V3_0054

**问题：** Which entity does the defined term “Fund” identify?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 4702

**Answer：** Community Development Financial Institutions Fund

**Acceptable answers：** Community Development Financial Institutions Fund

> The term “Fund” means the Community Development Financial Institutions Fund established under section 4703(a) of this title.

**Condition：** 15 U.S.C. § 9009c

**Answer：** Restaurant Revitalization Fund

**Acceptable answers：** Restaurant Revitalization Fund

> The term “Fund” means the Restaurant Revitalization Fund established under subsection (b).

## 55. USC_V3_0055

**问题：** Which entity does the defined term “historical park” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410bbbb

**Answer：** Reconstruction Era National Historical Park

**Acceptable answers：** Reconstruction Era National Historical Park

> The term “historical park” means the Reconstruction Era National Historical Park.

**Condition：** 16 U.S.C. § 410eee–1

**Answer：** Adams National Historical Park

**Acceptable answers：** Adams National Historical Park

> The term “historical park” means the Adams National Historical Park established in section 410eee–2 of this title.

## 56. USC_V3_0056

**问题：** Which entity does the defined term “Initiative” identify?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 6953

**Answer：** Healthy Food Financing Initiative

**Acceptable answers：** Healthy Food Financing Initiative

> The term “Initiative” means the Healthy Food Financing Initiative established under subsection (c)(1).

**Condition：** 7 U.S.C. § 8108

**Answer：** Biomass Research and Development Initiative

**Acceptable answers：** Biomass Research and Development Initiative

> The term “Initiative” means the Biomass Research and Development Initiative established under subsection (e).

## 57. USC_V3_0057

**问题：** What is the full name designated by “Institute”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 7461

**Answer：** National Institute of Standards and Technology

**Acceptable answers：** National Institute of Standards and Technology

> The term “Institute” means the National Institute of Standards and Technology.

**Condition：** 7 U.S.C. § 6971

**Answer：** National Institute of Food and Agriculture

**Acceptable answers：** National Institute of Food and Agriculture

> The term “Institute” means the National Institute of Food and Agriculture established by paragraph (2)(A).

## 58. USC_V3_0058

**问题：** What is the full name designated by “national park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410hhh–1

**Answer：** Great Sand Dunes National Park

**Acceptable answers：** Great Sand Dunes National Park

> The term “national park” means the Great Sand Dunes National Park established in section 410hhh–2 of this title.

**Condition：** 16 U.S.C. § 410r–9

**Answer：** Everglades National Park

**Acceptable answers：** Everglades National Park

> The term “National Park” means the Everglades National Park located in the State.

## 59. USC_V3_0059

**问题：** Which entity does the defined term “Park” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410dddd

**Answer：** White Sands National Park

**Acceptable answers：** White Sands National Park

> The term “Park” means the White Sands National Park established by subsection (b)(1).

**Condition：** 16 U.S.C. § 410kkk

**Answer：** Lewis and Clark National Historical Park

**Acceptable answers：** Lewis and Clark National Historical Park

> The term “park” means the Lewis and Clark National Historical Park designated in section 410kkk–1 of this title.

## 60. USC_V3_0060

**问题：** Which entity does the defined term “preserve” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410hhh–1

**Answer：** Great Sand Dunes National Preserve

**Acceptable answers：** Great Sand Dunes National Preserve

> The term “preserve” means the Great Sand Dunes National Preserve established in section 410hhh–3 of this title.

**Condition：** 16 U.S.C. § 698u–1

**Answer：** Tallgrass Prairie National Preserve

**Acceptable answers：** Tallgrass Prairie National Preserve

> The term “Preserve” means the Tallgrass Prairie National Preserve established by section 698u–2 of this title.

## 61. USC_V3_0061

**问题：** What is the full name designated by “Program”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 4729

**Answer：** Coastal Aquatic Invasive Species Mitigation Grant Program

**Acceptable answers：** Coastal Aquatic Invasive Species Mitigation Grant Program

> The term “Program” means the Coastal Aquatic Invasive Species Mitigation Grant Program established under paragraph (2)(A).

**Condition：** 16 U.S.C. § 6592d

**Answer：** Joint Chiefs Landscape Restoration Partnership program

**Acceptable answers：** Joint Chiefs Landscape Restoration Partnership program

> The term “Program” means the Joint Chiefs Landscape Restoration Partnership program established under subsection (b)(1).

## 62. USC_V3_0062

**问题：** What is the full name designated by “Recreation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460bbbb

**Answer：** Ashley Karst National Recreation and Geologic Area

**Acceptable answers：** Ashley Karst National Recreation and Geologic Area

> The term “Recreation Area” means the Ashley Karst National Recreation and Geologic Area established by subsection (b)(1).

**Condition：** 16 U.S.C. § 460lll

**Answer：** Land Between the Lakes National Recreation Area

**Acceptable answers：** Land Between the Lakes National Recreation Area

> The term “Recreation Area” means the Land Between the Lakes National Recreation Area.

## 63. USC_V3_0063

**问题：** What is the full name designated by “Secretary”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1715z–11a

**Answer：** Secretary of Housing and Urban Development

**Acceptable answers：** Secretary of Housing and Urban Development

> The term “Secretary” means the Secretary of Housing and Urban Development.

**Condition：** 15 U.S.C. § 290a

**Answer：** Secretary of Commerce

**Acceptable answers：** Secretary of Commerce

> The term “Secretary” means the Secretary of Commerce.

## 64. USC_V3_0064

**问题：** Which entity does the defined term “Special Management Area” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 539q

**Answer：** Hermosa Creek Special Management Area

**Acceptable answers：** Hermosa Creek Special Management Area

> The term “Special Management Area” means the Hermosa Creek Special Management Area designated by subsection (b)(1).

**Condition：** 16 U.S.C. § 539s

**Answer：** Frank and Jeanne Moore Wild Steelhead Special Management Area

**Acceptable answers：** Frank and Jeanne Moore Wild Steelhead Special Management Area

> The term “Special Management Area” means the Frank and Jeanne Moore Wild Steelhead Special Management Area designated by subsection (c)(1).

## 65. USC_V3_0065

**问题：** What is the full name designated by “State”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410xxx

**Answer：** State of Missouri

**Acceptable answers：** State of Missouri

> The term “State” means the State of Missouri.

**Condition：** 16 U.S.C. § 460aaaa

**Answer：** State of Nevada

**Acceptable answers：** State of Nevada

> The term “State” means the State of Nevada.

## 66. USC_V3_0066

**问题：** Which entity does the defined term “Under Secretary” identify?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8501

**Answer：** Under Secretary of Commerce for Oceans and Atmosphere

**Acceptable answers：** Under Secretary of Commerce for Oceans and Atmosphere

> The term “Under Secretary” means the Under Secretary of Commerce for Oceans and Atmosphere.

**Condition：** 6 U.S.C. § 187

**Answer：** Under Secretary for Science and Technology

**Acceptable answers：** Under Secretary for Science and Technology

> The term “Under Secretary” means the Under Secretary for Science and Technology.

## 67. USC_V3_0067

**问题：** What is the name of the entity called “Administration”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 6901

**Answer：** Small Business Administration

**Acceptable answers：** Small Business Administration / SBA

> The term “Administration” means the Small Business Administration.

**Condition：** 6 U.S.C. § 561

**Answer：** Transportation Security Administration

**Acceptable answers：** Transportation Security Administration

> The term “Administration” means the Transportation Security Administration.

## 68. USC_V3_0068

**问题：** What is the name of the entity called “Administrator”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9701

**Answer：** Administrator of the National Oceanic and Atmospheric Administration

**Acceptable answers：** Administrator of the National Oceanic and Atmospheric Administration

> The term “Administrator” means the Administrator of the National Oceanic and Atmospheric Administration.

**Condition：** 16 U.S.C. § 460lll

**Answer：** Administrator of the Environmental Protection Agency

**Acceptable answers：** Administrator of the Environmental Protection Agency

> The term “Administrator” means the Administrator of the Environmental Protection Agency.

## 69. USC_V3_0069

**问题：** What is the name of the entity called “Advisory Committee”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8801

**Answer：** National Quantum Initiative Advisory Committee

**Acceptable answers：** National Quantum Initiative Advisory Committee

> The term “Advisory Committee” means the National Quantum Initiative Advisory Committee established under section 8814(a) of this title.

**Condition：** 15 U.S.C. § 9401

**Answer：** National Artificial Intelligence Advisory Committee

**Acceptable answers：** National Artificial Intelligence Advisory Committee

> The term “Advisory Committee” means the National Artificial Intelligence Advisory Committee established under section 9414(a) of this title.

## 70. USC_V3_0070

**问题：** Which entity does the defined term “Agency” identify?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9501

**Answer：** Minority Business Development Agency of the Department of Commerce

**Acceptable answers：** Minority Business Development Agency of the Department of Commerce

> The term “Agency” means the Minority Business Development Agency of the Department of Commerce.

**Condition：** 6 U.S.C. § 650

**Answer：** Cybersecurity and Infrastructure Security Agency

**Acceptable answers：** Cybersecurity and Infrastructure Security Agency

> The term “Agency” means the Cybersecurity and Infrastructure Security Agency.

## 71. USC_V3_0071

**问题：** What is the name of the entity called “Authority”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 2009aa

**Answer：** Delta Regional Authority

**Acceptable answers：** Delta Regional Authority

> The term “Authority” means the Delta Regional Authority established by section 2009aa–1 of this title.

**Condition：** 7 U.S.C. § 2009bb

**Answer：** Northern Great Plains Regional Authority

**Acceptable answers：** Northern Great Plains Regional Authority

> The term “Authority” means the Northern Great Plains Regional Authority established by section 2009bb–1 of this title.

## 72. USC_V3_0072

**问题：** What is the name of the entity called “Board”?

**维度：** Legal-Scope

**Condition：** 2 U.S.C. § 1301

**Answer：** Board of Directors of the Office of Congressional Workplace Rights

**Acceptable answers：** Board of Directors of the Office of Congressional Workplace Rights

> The term “Board” means the Board of Directors of the Office of Congressional Workplace Rights.

**Condition：** 7 U.S.C. § 6402

**Answer：** National Processor Advertising and Promotion Board

**Acceptable answers：** National Processor Advertising and Promotion Board

> The term “Board” means the National Processor Advertising and Promotion Board established under section 6407(b) of this title.

## 73. USC_V3_0073

**问题：** What is the name of the entity called “Commission”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410iii–2

**Answer：** Cedar Creek and Belle Grove National Historical Park Advisory Commission

**Acceptable answers：** Cedar Creek and Belle Grove National Historical Park Advisory Commission

> The term “Commission” means the Cedar Creek and Belle Grove National Historical Park Advisory Commission established by section 410iii–7 of this title.

**Condition：** 16 U.S.C. § 7701

**Answer：** North Pacific Fisheries Commission

**Acceptable answers：** North Pacific Fisheries Commission

> The term “Commission” means the North Pacific Fisheries Commission established in accordance with the North Pacific Fisheries Convention.

## 74. USC_V3_0074

**问题：** What is the name of the entity called “Conservation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460hhhh

**Answer：** Numunaa Nobe National Conservation Area

**Acceptable answers：** Numunaa Nobe National Conservation Area

> The term “Conservation Area” means the Numunaa Nobe National Conservation Area established by paragraph (2).

**Condition：** 16 U.S.C. § 460qqq–1

**Answer：** Sloan Canyon National Conservation Area

**Acceptable answers：** Sloan Canyon National Conservation Area

> The term “Conservation Area” means the Sloan Canyon National Conservation Area established by section 460qqq–2(a) of this title.

## 75. USC_V3_0075

**问题：** What is the name of the entity called “Corporation”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1462

**Answer：** Federal Deposit Insurance Corporation

**Acceptable answers：** Federal Deposit Insurance Corporation / FDIC

> The term “Corporation” means the Federal Deposit Insurance Corporation.

**Condition：** 12 U.S.C. § 2279aa

**Answer：** Federal Agricultural Mortgage Corporation

**Acceptable answers：** Federal Agricultural Mortgage Corporation

> The term “Corporation” means the Federal Agricultural Mortgage Corporation established in section 2279aa–1 of this title.

## 76. USC_V3_0076

**问题：** Which entity does the defined term “Council” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460mmm–1

**Answer：** McInnis Canyons National Conservation Area Advisory Council

**Acceptable answers：** McInnis Canyons National Conservation Area Advisory Council

> The term “Council” means the McInnis Canyons National Conservation Area Advisory Council established under section 460mmm–6 of this title.

**Condition：** 16 U.S.C. § 7801

**Answer：** Western Pacific Regional Fishery Management Council

**Acceptable answers：** Western Pacific Regional Fishery Management Council

> The term “Council” means the Western Pacific Regional Fishery Management Council.

## 77. USC_V3_0077

**问题：** What is the name of the entity called “County”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460aaaa

**Answer：** Clark County, Nevada

**Acceptable answers：** Clark County, Nevada / Clark County

> The term “County” means Clark County, Nevada.

**Condition：** 16 U.S.C. § 539q

**Answer：** La Plata County, Colorado

**Acceptable answers：** La Plata County, Colorado

> The term “County” means La Plata County, Colorado.

## 78. USC_V3_0078

**问题：** Which entity does the defined term “Department” identify?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 5541

**Answer：** Department of Energy

**Acceptable answers：** Department of Energy

> The term “Department” means the Department of Energy.

**Condition：** 6 U.S.C. § 1101

**Answer：** Department of Homeland Security

**Acceptable answers：** Department of Homeland Security

> The term “Department” means the Department of Homeland Security.

## 79. USC_V3_0079

**问题：** Which entity does the defined term “Director” identify?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 7461

**Answer：** Director of the National Institute of Standards and Technology

**Acceptable answers：** Director of the National Institute of Standards and Technology

> The term “Director” means the Director of the National Institute of Standards and Technology.

**Condition：** 6 U.S.C. § 1521

**Answer：** Director of the Office of Management and Budget

**Acceptable answers：** Director of the Office of Management and Budget

> The term “Director” means the Director of the Office of Management and Budget.

## 80. USC_V3_0080

**问题：** What is the name of the entity called “Foundation”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 5801

**Answer：** National Natural Resources Conservation Foundation

**Acceptable answers：** National Natural Resources Conservation Foundation

> The term “Foundation” means the National Natural Resources Conservation Foundation established by section 5802(a) of this title.

**Condition：** 7 U.S.C. § 5939

**Answer：** Foundation for Food and Agriculture Research

**Acceptable answers：** Foundation for Food and Agriculture Research

> The term “Foundation” means the Foundation for Food and Agriculture Research established under subsection (b).

## 81. USC_V3_0081

**问题：** What is the name of the entity called “Fund”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5202

**Answer：** Troubled Assets Insurance Financing Fund

**Acceptable answers：** Troubled Assets Insurance Financing Fund

> The term “Fund” means the Troubled Assets Insurance Financing Fund established under section 5212 of this title.

**Condition：** 6 U.S.C. § 677a

**Answer：** Cyber Response and Recovery Fund

**Acceptable answers：** Cyber Response and Recovery Fund

> The term “Fund” means the Cyber Response and Recovery Fund established under section 677c(a) of this title.

## 82. USC_V3_0082

**问题：** What is the name of the entity called “historical park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410bbbb

**Answer：** Reconstruction Era National Historical Park

**Acceptable answers：** Reconstruction Era National Historical Park

> The term “historical park” means the Reconstruction Era National Historical Park.

**Condition：** 16 U.S.C. § 410iiii

**Answer：** Brown v. Board of Education National Historical Park

**Acceptable answers：** Brown v. Board of Education National Historical Park

> The term “historical park” means the Brown v. Board of Education National Historical Park as established in section 410iiii–2 of this title.

## 83. USC_V3_0083

**问题：** What is the name of the entity called “Initiative”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 5925

**Answer：** pulse crop health initiative

**Acceptable answers：** pulse crop health initiative

> The term “Initiative” means the pulse crop health initiative established by paragraph (2).

**Condition：** 7 U.S.C. § 6953

**Answer：** Healthy Food Financing Initiative

**Acceptable answers：** Healthy Food Financing Initiative

> The term “Initiative” means the Healthy Food Financing Initiative established under subsection (c)(1).

## 84. USC_V3_0084

**问题：** What is the name of the entity called “Park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410aaaa

**Answer：** Fort Sumter and Fort Moultrie National Historical Park

**Acceptable answers：** Fort Sumter and Fort Moultrie National Historical Park

> The term “Park” means the Fort Sumter and Fort Moultrie National Historical Park established by subsection (b).

**Condition：** 16 U.S.C. § 410fff–1

**Answer：** Black Canyon of the Gunnison National Park

**Acceptable answers：** Black Canyon of the Gunnison National Park

> The term “Park” means the Black Canyon of the Gunnison National Park established under section 410fff–2 of this title and depicted on the Map.

## 85. USC_V3_0085

**问题：** What is the name of the entity called “Preserve”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 698u–1

**Answer：** Tallgrass Prairie National Preserve

**Acceptable answers：** Tallgrass Prairie National Preserve

> The term “Preserve” means the Tallgrass Prairie National Preserve established by section 698u–2 of this title.

**Condition：** 16 U.S.C. § 698v–1

**Answer：** Valles Caldera National Preserve

**Acceptable answers：** Valles Caldera National Preserve

> The term “Preserve” means the Valles Caldera National Preserve established under section 698v–3 of this title.

## 86. USC_V3_0086

**问题：** Which entity does the defined term “Program” identify?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5701

**Answer：** State Small Business Credit Initiative

**Acceptable answers：** State Small Business Credit Initiative

> The term “Program” means the State Small Business Credit Initiative established under this chapter.

**Condition：** 16 U.S.C. § 1015

**Answer：** Cooperative Watershed Management Program

**Acceptable answers：** Cooperative Watershed Management Program

> The term “program” means the Cooperative Watershed Management Program established by the Secretary under section 1015a(a) of this title.

## 87. USC_V3_0087

**问题：** Which entity does the defined term “Recreation Area” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460hhh

**Answer：** Spring Mountains National Recreation Area

**Acceptable answers：** Spring Mountains National Recreation Area

> The term “Recreation Area” means the Spring Mountains National Recreation Area established by this subchapter.

**Condition：** 16 U.S.C. § 460lll

**Answer：** Land Between the Lakes National Recreation Area

**Acceptable answers：** Land Between the Lakes National Recreation Area

> The term “Recreation Area” means the Land Between the Lakes National Recreation Area.

## 88. USC_V3_0088

**问题：** Which entity does the defined term “Secretary” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 7201

**Answer：** Secretary of the Interior

**Acceptable answers：** Secretary of the Interior

> The term “Secretary” means the Secretary of the Interior.

**Condition：** 2 U.S.C. § 4579

**Answer：** Secretary of the Senate

**Acceptable answers：** Secretary of the Senate

> The term “Secretary” means the Secretary of the Senate.

## 89. USC_V3_0089

**问题：** What is the name of the entity called “Special Management Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460gggg

**Answer：** Numu Newe Special Management Area

**Acceptable answers：** Numu Newe Special Management Area

> The term “Special Management Area” means the Numu Newe Special Management Area established by subsection (b).

**Condition：** 16 U.S.C. § 539q

**Answer：** Hermosa Creek Special Management Area

**Acceptable answers：** Hermosa Creek Special Management Area

> The term “Special Management Area” means the Hermosa Creek Special Management Area designated by subsection (b)(1).

## 90. USC_V3_0090

**问题：** Which entity does the defined term “State” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410dddd

**Answer：** State of New Mexico

**Acceptable answers：** State of New Mexico

> The term “State” means the State of New Mexico.

**Condition：** 16 U.S.C. § 410qqq

**Answer：** State of Connecticut

**Acceptable answers：** State of Connecticut

> The term “State” means the State of Connecticut.

## 91. USC_V3_0091

**问题：** What is the name of the entity called “Under Secretary”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8501

**Answer：** Under Secretary of Commerce for Oceans and Atmosphere

**Acceptable answers：** Under Secretary of Commerce for Oceans and Atmosphere

> The term “Under Secretary” means the Under Secretary of Commerce for Oceans and Atmosphere.

**Condition：** 15 U.S.C. § 9501

**Answer：** Under Secretary of Commerce for Minority Business Development

**Acceptable answers：** Under Secretary of Commerce for Minority Business Development

> The term “Under Secretary” means the Under Secretary of Commerce for Minority Business Development, who is appointed as described in section ___3(b) 1 to administer this chapter.

## 92. USC_V3_0092

**问题：** Which entity is designated as “Administrator”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 6901

**Answer：** Administrator of the Small Business Administration

**Acceptable answers：** Administrator of the Small Business Administration

> The term “Administrator” means the Administrator of the Small Business Administration.

**Condition：** 16 U.S.C. § 460lll

**Answer：** Administrator of the Environmental Protection Agency

**Acceptable answers：** Administrator of the Environmental Protection Agency

> The term “Administrator” means the Administrator of the Environmental Protection Agency.

## 93. USC_V3_0093

**问题：** What is the name of the entity called “Agency”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1422

**Answer：** Federal Housing Finance Agency

**Acceptable answers：** Federal Housing Finance Agency

> The term “Agency” means the Federal Housing Finance Agency, established under section 4511 of this title.

**Condition：** 16 U.S.C. § 6203

**Answer：** Forest Service

**Acceptable answers：** Forest Service

> The term “agency” means the Forest Service.

## 94. USC_V3_0094

**问题：** Which entity is designated as “Board”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 4502

**Answer：** Federal Housing Finance Oversight Board

**Acceptable answers：** Federal Housing Finance Oversight Board

> The term “Board” means the Federal Housing Finance Oversight Board established under section 4513a of this title.

**Condition：** 16 U.S.C. § 3451

**Answer：** Resource Conservation and Development Policy Advisory Board

**Acceptable answers：** Resource Conservation and Development Policy Advisory Board

> The term “Board” means the Resource Conservation and Development Policy Advisory Board established under section 3456(a) of this title.

## 95. USC_V3_0095

**问题：** Which entity is designated as “Commission”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410iii–2

**Answer：** Cedar Creek and Belle Grove National Historical Park Advisory Commission

**Acceptable answers：** Cedar Creek and Belle Grove National Historical Park Advisory Commission

> The term “Commission” means the Cedar Creek and Belle Grove National Historical Park Advisory Commission established by section 410iii–7 of this title.

**Condition：** 16 U.S.C. § 951

**Answer：** Inter-American Tropical Tuna Commission

**Acceptable answers：** Inter-American Tropical Tuna Commission

> The term “Commission” means the Inter-American Tropical Tuna Commission provided for by the Convention.

## 96. USC_V3_0096

**问题：** Which entity is designated as “Conservation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460iiii

**Answer：** Pistone-Black Mountain National Conservation Area

**Acceptable answers：** Pistone-Black Mountain National Conservation Area

> The term “Conservation Area” means the Pistone-Black Mountain National Conservation Area established by paragraph (2)(A).

**Condition：** 16 U.S.C. § 460ooo

**Answer：** Las Cienegas National Conservation Area

**Acceptable answers：** Las Cienegas National Conservation Area

> The term “Conservation Area” means the Las Cienegas National Conservation Area established by section 460ooo–3(a) of this title.

## 97. USC_V3_0097

**问题：** Which entity is designated as “Corporation”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 1502

**Answer：** Federal Crop Insurance Corporation

**Acceptable answers：** Federal Crop Insurance Corporation

> The term “Corporation” means the Federal Crop Insurance Corporation established under section 1503 of this title.

**Condition：** 7 U.S.C. § 1736o

**Answer：** Commodity Credit Corporation

**Acceptable answers：** Commodity Credit Corporation

> The term “Corporation” means the Commodity Credit Corporation.

## 98. USC_V3_0098

**问题：** What is the name of the entity called “Council”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5301

**Answer：** Financial Stability Oversight Council

**Acceptable answers：** Financial Stability Oversight Council

> The term “Council” means the Financial Stability Oversight Council established under subchapter I.

**Condition：** 16 U.S.C. § 832m

**Answer：** Northwest Power and Conservation Planning Council

**Acceptable answers：** Northwest Power and Conservation Planning Council

> The term “Council” means the Northwest Power and Conservation Planning Council.

## 99. USC_V3_0099

**问题：** What is the name of the entity called “Department”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8702

**Answer：** Department of Commerce

**Acceptable answers：** Department of Commerce

> The term “Department” means the Department of Commerce.

**Condition：** 16 U.S.C. § 5801

**Answer：** Department of Agriculture

**Acceptable answers：** Department of Agriculture

> The term “Department” means the Department of Agriculture.

## 100. USC_V3_0100

**问题：** What is the name of the entity called “Director”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5102

**Answer：** Director of the Bureau of Consumer Financial Protection

**Acceptable answers：** Director of the Bureau of Consumer Financial Protection

> The term “Director” means the Director of the Bureau of Consumer Financial Protection.

**Condition：** 6 U.S.C. § 1521

**Answer：** Director of the Office of Management and Budget

**Acceptable answers：** Director of the Office of Management and Budget

> The term “Director” means the Director of the Office of Management and Budget.

## 101. USC_V3_0101

**问题：** Which entity is designated as “Fund”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5202

**Answer：** Troubled Assets Insurance Financing Fund

**Acceptable answers：** Troubled Assets Insurance Financing Fund

> The term “Fund” means the Troubled Assets Insurance Financing Fund established under section 5212 of this title.

**Condition：** 16 U.S.C. § 7302

**Answer：** Collaborative Forest Landscape Restoration Fund

**Acceptable answers：** Collaborative Forest Landscape Restoration Fund

> The term “Fund” means the Collaborative Forest Landscape Restoration Fund established by section 7303(f) of this title.

## 102. USC_V3_0102

**问题：** Which entity is designated as “historical park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410iiii

**Answer：** Brown v. Board of Education National Historical Park

**Acceptable answers：** Brown v. Board of Education National Historical Park

> The term “historical park” means the Brown v. Board of Education National Historical Park as established in section 410iiii–2 of this title.

**Condition：** 16 U.S.C. § 410uuu

**Answer：** Manhattan Project National Historical Park

**Acceptable answers：** Manhattan Project National Historical Park

> The term “Historical Park” means the Manhattan Project National Historical Park established under subsection (c).

## 103. USC_V3_0103

**问题：** Which entity is designated as “Initiative”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9401

**Answer：** National Artificial Intelligence Initiative

**Acceptable answers：** National Artificial Intelligence Initiative

> The term “Initiative” means the National Artificial Intelligence Initiative established under section 9411(a) of this title.

**Condition：** 7 U.S.C. § 6953

**Answer：** Healthy Food Financing Initiative

**Acceptable answers：** Healthy Food Financing Initiative

> The term “Initiative” means the Healthy Food Financing Initiative established under subsection (c)(1).

## 104. USC_V3_0104

**问题：** Which entity is designated as “park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 268a

**Answer：** Cumberland Gap National Historical Park

**Acceptable answers：** Cumberland Gap National Historical Park

> The term “park” means Cumberland Gap National Historical Park, as authorized and established by the Act of June 11, 1940 (54 Stat. 262; 16 U.S.C. 261 et seq.).

**Condition：** 16 U.S.C. § 410fff–1

**Answer：** Black Canyon of the Gunnison National Park

**Acceptable answers：** Black Canyon of the Gunnison National Park

> The term “Park” means the Black Canyon of the Gunnison National Park established under section 410fff–2 of this title and depicted on the Map.

## 105. USC_V3_0105

**问题：** What is the name of the entity called “Program”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8801

**Answer：** National Quantum Initiative Program

**Acceptable answers：** National Quantum Initiative Program

> The term “Program” means the National Quantum Initiative Program implemented under section 8811(a) of this title.

**Condition：** 7 U.S.C. § 8113

**Answer：** Community Wood Energy and Wood Innovation Program

**Acceptable answers：** Community Wood Energy and Wood Innovation Program

> The term “Program” means the Community Wood Energy and Wood Innovation Program established under subsection (b).

## 106. USC_V3_0106

**问题：** What is the name of the entity called “Recreation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460bbbb

**Answer：** Ashley Karst National Recreation and Geologic Area

**Acceptable answers：** Ashley Karst National Recreation and Geologic Area

> The term “Recreation Area” means the Ashley Karst National Recreation and Geologic Area established by subsection (b)(1).

**Condition：** 16 U.S.C. § 460hhh

**Answer：** Spring Mountains National Recreation Area

**Acceptable answers：** Spring Mountains National Recreation Area

> The term “Recreation Area” means the Spring Mountains National Recreation Area established by this subchapter.

## 107. USC_V3_0107

**问题：** What is the name of the entity called “Secretary”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 290a

**Answer：** Secretary of Commerce

**Acceptable answers：** Secretary of Commerce

> The term “Secretary” means the Secretary of Commerce.

**Condition：** 6 U.S.C. § 1533

**Answer：** Secretary of Health and Human Services

**Acceptable answers：** Secretary of Health and Human Services

> The term “Secretary” means the Secretary of Health and Human Services.

## 108. USC_V3_0108

**问题：** What is the name of the entity called “State”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410aaaa

**Answer：** State of South Carolina

**Acceptable answers：** State of South Carolina

> The term “State” means the State of South Carolina.

**Condition：** 16 U.S.C. § 539s

**Answer：** State of Oregon

**Acceptable answers：** State of Oregon

> The term “State” means the State of Oregon.

## 109. USC_V3_0109

**问题：** What entity is named in the definition of “Administrator”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8563

**Answer：** Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration

**Acceptable answers：** Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration

> The term “Administrator” means the Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration.

**Condition：** 6 U.S.C. § 821

**Answer：** Administrator of the Federal Emergency Management Agency

**Acceptable answers：** Administrator of the Federal Emergency Management Agency

> The term “Administrator” means the Administrator of the Federal Emergency Management Agency.

## 110. USC_V3_0110

**问题：** Which entity is designated as “Agency”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1422

**Answer：** Federal Housing Finance Agency

**Acceptable answers：** Federal Housing Finance Agency

> The term “Agency” means the Federal Housing Finance Agency, established under section 4511 of this title.

**Condition：** 6 U.S.C. § 650

**Answer：** Cybersecurity and Infrastructure Security Agency

**Acceptable answers：** Cybersecurity and Infrastructure Security Agency

> The term “Agency” means the Cybersecurity and Infrastructure Security Agency.

## 111. USC_V3_0111

**问题：** What entity is named in the definition of “Board”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 6002

**Answer：** Pecan Marketing Board

**Acceptable answers：** Pecan Marketing Board

> The term “Board” means the Pecan Marketing Board established in section 6005(b) of this title.

**Condition：** 7 U.S.C. § 6402

**Answer：** National Processor Advertising and Promotion Board

**Acceptable answers：** National Processor Advertising and Promotion Board

> The term “Board” means the National Processor Advertising and Promotion Board established under section 6407(b) of this title.

## 112. USC_V3_0112

**问题：** What entity is named in the definition of “Commission”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 1a

**Answer：** Commodity Futures Trading Commission

**Acceptable answers：** Commodity Futures Trading Commission

> The term “Commission” means the Commodity Futures Trading Commission established under section 2(a)(2) of this title.

**Condition：** 7 U.S.C. § 950bb–6

**Answer：** Federal Communications Commission

**Acceptable answers：** Federal Communications Commission

> The term “Commission” means the Federal Communications Commission.

## 113. USC_V3_0113

**问题：** What entity is named in the definition of “Conservation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410aaa–81c

**Answer：** California Desert Conservation Area

**Acceptable answers：** California Desert Conservation Area

> The term “Conservation Area” means the California Desert Conservation Area.

**Condition：** 16 U.S.C. § 460qqq–1

**Answer：** Sloan Canyon National Conservation Area

**Acceptable answers：** Sloan Canyon National Conservation Area

> The term “Conservation Area” means the Sloan Canyon National Conservation Area established by section 460qqq–2(a) of this title.

## 114. USC_V3_0114

**问题：** What entity is named in the definition of “Corporation”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 2279aa

**Answer：** Federal Agricultural Mortgage Corporation

**Acceptable answers：** Federal Agricultural Mortgage Corporation

> The term “Corporation” means the Federal Agricultural Mortgage Corporation established in section 2279aa–1 of this title.

**Condition：** 7 U.S.C. § 1502

**Answer：** Federal Crop Insurance Corporation

**Acceptable answers：** Federal Crop Insurance Corporation

> The term “Corporation” means the Federal Crop Insurance Corporation established under section 1503 of this title.

## 115. USC_V3_0115

**问题：** Which entity is designated as “Council”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 3350

**Answer：** Federal Financial Institutions Examinations Council

**Acceptable answers：** Federal Financial Institutions Examinations Council

> The term “Council” means the Federal Financial Institutions Examinations Council.

**Condition：** 16 U.S.C. § 460mmm–1

**Answer：** McInnis Canyons National Conservation Area Advisory Council

**Acceptable answers：** McInnis Canyons National Conservation Area Advisory Council

> The term “Council” means the McInnis Canyons National Conservation Area Advisory Council established under section 460mmm–6 of this title.

## 116. USC_V3_0116

**问题：** Which entity is designated as “Department”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 5541

**Answer：** Department of Energy

**Acceptable answers：** Department of Energy

> The term “Department” means the Department of Energy.

**Condition：** 16 U.S.C. § 5801

**Answer：** Department of Agriculture

**Acceptable answers：** Department of Agriculture

> The term “Department” means the Department of Agriculture.

## 117. USC_V3_0117

**问题：** Which entity is designated as “Director”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 8202

**Answer：** Director of the United States Fish and Wildlife Service

**Acceptable answers：** Director of the United States Fish and Wildlife Service

> The term “Director” means the Director of the United States Fish and Wildlife Service.

**Condition：** 6 U.S.C. § 464

**Answer：** Director of the Federal Law Enforcement Training Centers

**Acceptable answers：** Director of the Federal Law Enforcement Training Centers

> The term “Director” means the Director of the Federal Law Enforcement Training Centers.

## 118. USC_V3_0118

**问题：** What entity is named in the definition of “Fund”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5381

**Answer：** Orderly Liquidation Fund

**Acceptable answers：** Orderly Liquidation Fund

> The term “Fund” means the Orderly Liquidation Fund established under section 5390(n) of this title.

**Condition：** 16 U.S.C. § 7302

**Answer：** Collaborative Forest Landscape Restoration Fund

**Acceptable answers：** Collaborative Forest Landscape Restoration Fund

> The term “Fund” means the Collaborative Forest Landscape Restoration Fund established by section 7303(f) of this title.

## 119. USC_V3_0119

**问题：** What entity is named in the definition of “historical park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410rrr

**Answer：** First State National Historical Park

**Acceptable answers：** First State National Historical Park

> The term “historical park” means the First State National Historical Park.

**Condition：** 16 U.S.C. § 410yyy–3

**Answer：** Ocmulgee Mounds National Historical Park

**Acceptable answers：** Ocmulgee Mounds National Historical Park

> The term “Historical Park” means the Ocmulgee Mounds National Historical Park in the State of Georgia, as redesignated by subsection (b)(1)(A).

## 120. USC_V3_0120

**问题：** What entity is named in the definition of “Initiative”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 5925

**Answer：** pulse crop health initiative

**Acceptable answers：** pulse crop health initiative

> The term “Initiative” means the pulse crop health initiative established by paragraph (2).

**Condition：** 7 U.S.C. § 8108

**Answer：** Biomass Research and Development Initiative

**Acceptable answers：** Biomass Research and Development Initiative

> The term “Initiative” means the Biomass Research and Development Initiative established under subsection (e).

## 121. USC_V3_0121

**问题：** What entity is named in the definition of “Park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410aaaa

**Answer：** Fort Sumter and Fort Moultrie National Historical Park

**Acceptable answers：** Fort Sumter and Fort Moultrie National Historical Park

> The term “Park” means the Fort Sumter and Fort Moultrie National Historical Park established by subsection (b).

**Condition：** 16 U.S.C. § 410dddd

**Answer：** White Sands National Park

**Acceptable answers：** White Sands National Park

> The term “Park” means the White Sands National Park established by subsection (b)(1).

## 122. USC_V3_0122

**问题：** Which entity is designated as “Program”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 4729

**Answer：** Coastal Aquatic Invasive Species Mitigation Grant Program

**Acceptable answers：** Coastal Aquatic Invasive Species Mitigation Grant Program

> The term “Program” means the Coastal Aquatic Invasive Species Mitigation Grant Program established under paragraph (2)(A).

**Condition：** 7 U.S.C. § 6712

**Answer：** Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program

**Acceptable answers：** Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program

> The term “Program” means the Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program established under subsection (b).

## 123. USC_V3_0123

**问题：** Which entity is designated as “Secretary”?

**维度：** Legal-Scope

**Condition：** 10 U.S.C. § 4873

**Answer：** Secretary of Defense

**Acceptable answers：** Secretary of Defense

> The term “Secretary” means the Secretary of Defense.

**Condition：** 8 U.S.C. § 1375b

**Answer：** Secretary of State

**Acceptable answers：** Secretary of State

> The term “Secretary” means the Secretary of State.

## 124. USC_V3_0124

**问题：** Which entity is designated as “State”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410dddd

**Answer：** State of New Mexico

**Acceptable answers：** State of New Mexico

> The term “State” means the State of New Mexico.

**Condition：** 16 U.S.C. § 539s

**Answer：** State of Oregon

**Acceptable answers：** State of Oregon

> The term “State” means the State of Oregon.

## 125. USC_V3_0125

**问题：** What is the full name designated by “Administrator”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9701

**Answer：** Administrator of the National Oceanic and Atmospheric Administration

**Acceptable answers：** Administrator of the National Oceanic and Atmospheric Administration

> The term “Administrator” means the Administrator of the National Oceanic and Atmospheric Administration.

**Condition：** 7 U.S.C. § 1726c

**Answer：** Administrator of the Agency for International Development

**Acceptable answers：** Administrator of the Agency for International Development

> The term “Administrator” means the Administrator of the Agency for International Development.

## 126. USC_V3_0126

**问题：** What entity is named in the definition of “agency”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 6203

**Answer：** Forest Service

**Acceptable answers：** Forest Service

> The term “agency” means the Forest Service.

**Condition：** 6 U.S.C. § 650

**Answer：** Cybersecurity and Infrastructure Security Agency

**Acceptable answers：** Cybersecurity and Infrastructure Security Agency

> The term “Agency” means the Cybersecurity and Infrastructure Security Agency.

## 127. USC_V3_0127

**问题：** What is the full name designated by “Board”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8702

**Answer：** Concrete Masonry Products Board

**Acceptable answers：** Concrete Masonry Products Board

> The term “Board” means the Concrete Masonry Products Board established under section 8704 of this title.

**Condition：** 7 U.S.C. § 6202

**Answer：** Lime Board

**Acceptable answers：** Lime Board

> The term “Board” means the Lime Board provided for under section 6204(b) of this title.

## 128. USC_V3_0128

**问题：** What is the full name designated by “Commission”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410qqq

**Answer：** Coltsville National Historical Park Advisory Commission

**Acceptable answers：** Coltsville National Historical Park Advisory Commission

> The term “Commission” means the Coltsville National Historical Park Advisory Commission established by subsection (k)(1).

**Condition：** 16 U.S.C. § 7801

**Answer：** Commission of the South Pacific Regional Fisheries Management Organization

**Acceptable answers：** Commission of the South Pacific Regional Fisheries Management Organization

> The term “Commission” means the Commission of the South Pacific Regional Fisheries Management Organization established in accordance with the South Pacific Fishery Resources Convention.

## 129. USC_V3_0129

**问题：** What is the full name designated by “Conservation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460ooo

**Answer：** Las Cienegas National Conservation Area

**Acceptable answers：** Las Cienegas National Conservation Area

> The term “Conservation Area” means the Las Cienegas National Conservation Area established by section 460ooo–3(a) of this title.

**Condition：** 16 U.S.C. § 460zzz

**Answer：** Dominguez-Escalante National Conservation Area

**Acceptable answers：** Dominguez-Escalante National Conservation Area

> The term “Conservation Area” means the Dominguez-Escalante National Conservation Area established by section 460zzz–1(a)(1) of this title.

## 130. USC_V3_0130

**问题：** What is the full name designated by “Corporation”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 2279aa

**Answer：** Federal Agricultural Mortgage Corporation

**Acceptable answers：** Federal Agricultural Mortgage Corporation

> The term “Corporation” means the Federal Agricultural Mortgage Corporation established in section 2279aa–1 of this title.

**Condition：** 7 U.S.C. § 1736o

**Answer：** Commodity Credit Corporation

**Acceptable answers：** Commodity Credit Corporation

> The term “Corporation” means the Commodity Credit Corporation.

## 131. USC_V3_0131

**问题：** What entity is named in the definition of “Council”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 3350

**Answer：** Federal Financial Institutions Examinations Council

**Acceptable answers：** Federal Financial Institutions Examinations Council

> The term “Council” means the Federal Financial Institutions Examinations Council.

**Condition：** 12 U.S.C. § 5301

**Answer：** Financial Stability Oversight Council

**Acceptable answers：** Financial Stability Oversight Council

> The term “Council” means the Financial Stability Oversight Council established under subchapter I.

## 132. USC_V3_0132

**问题：** What entity is named in the definition of “Department”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 5541

**Answer：** Department of Energy

**Acceptable answers：** Department of Energy

> The term “Department” means the Department of Energy.

**Condition：** 15 U.S.C. § 8702

**Answer：** Department of Commerce

**Acceptable answers：** Department of Commerce

> The term “Department” means the Department of Commerce.

## 133. USC_V3_0133

**问题：** What entity is named in the definition of “Director”?

**维度：** Legal-Scope

**Condition：** 5 U.S.C. § 3115

**Answer：** Director of the Office of Personnel Management

**Acceptable answers：** Director of the Office of Personnel Management

> The term “Director” means the Director of the Office of Personnel Management.

**Condition：** 6 U.S.C. § 1521

**Answer：** Director of the Office of Management and Budget

**Acceptable answers：** Director of the Office of Management and Budget

> The term “Director” means the Director of the Office of Management and Budget.

## 134. USC_V3_0134

**问题：** What is the full name designated by “Fund”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5381

**Answer：** Orderly Liquidation Fund

**Acceptable answers：** Orderly Liquidation Fund

> The term “Fund” means the Orderly Liquidation Fund established under section 5390(n) of this title.

**Condition：** 16 U.S.C. § 2104a

**Answer：** Pest and Disease Revolving Loan Fund

**Acceptable answers：** Pest and Disease Revolving Loan Fund

> The term “Fund” means the Pest and Disease Revolving Loan Fund established by subsection (b).

## 135. USC_V3_0135

**问题：** What is the full name designated by “historical park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410iiii

**Answer：** Brown v. Board of Education National Historical Park

**Acceptable answers：** Brown v. Board of Education National Historical Park

> The term “historical park” means the Brown v. Board of Education National Historical Park as established in section 410iiii–2 of this title.

**Condition：** 16 U.S.C. § 410rrr

**Answer：** First State National Historical Park

**Acceptable answers：** First State National Historical Park

> The term “historical park” means the First State National Historical Park.

## 136. USC_V3_0136

**问题：** What is the full name designated by “Initiative”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9401

**Answer：** National Artificial Intelligence Initiative

**Acceptable answers：** National Artificial Intelligence Initiative

> The term “Initiative” means the National Artificial Intelligence Initiative established under section 9411(a) of this title.

**Condition：** 7 U.S.C. § 8108

**Answer：** Biomass Research and Development Initiative

**Acceptable answers：** Biomass Research and Development Initiative

> The term “Initiative” means the Biomass Research and Development Initiative established under subsection (e).

## 137. USC_V3_0137

**问题：** What is the full name designated by “Park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410aaaa

**Answer：** Fort Sumter and Fort Moultrie National Historical Park

**Acceptable answers：** Fort Sumter and Fort Moultrie National Historical Park

> The term “Park” means the Fort Sumter and Fort Moultrie National Historical Park established by subsection (b).

**Condition：** 16 U.S.C. § 410iii–2

**Answer：** Cedar Creek and Belle Grove National Historical Park

**Acceptable answers：** Cedar Creek and Belle Grove National Historical Park

> The term “Park” means the Cedar Creek and Belle Grove National Historical Park established under section 410iii–3 of this title and depicted on the Map.

## 138. USC_V3_0138

**问题：** What entity is named in the definition of “Program”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8801

**Answer：** National Quantum Initiative Program

**Acceptable answers：** National Quantum Initiative Program

> The term “Program” means the National Quantum Initiative Program implemented under section 8811(a) of this title.

**Condition：** 16 U.S.C. § 1015

**Answer：** Cooperative Watershed Management Program

**Acceptable answers：** Cooperative Watershed Management Program

> The term “program” means the Cooperative Watershed Management Program established by the Secretary under section 1015a(a) of this title.

## 139. USC_V3_0139

**问题：** What entity is named in the definition of “Secretary”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460hhh

**Answer：** Secretary of Agriculture

**Acceptable answers：** Secretary of Agriculture

> The term “Secretary” means the Secretary of Agriculture.

**Condition：** 16 U.S.C. § 7201

**Answer：** Secretary of the Interior

**Acceptable answers：** Secretary of the Interior

> The term “Secretary” means the Secretary of the Interior.

## 140. USC_V3_0140

**问题：** What entity is named in the definition of “State”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 424c

**Answer：** State of Tennessee

**Acceptable answers：** State of Tennessee

> The term “State” means the State of Tennessee.

**Condition：** 16 U.S.C. § 4503b

**Answer：** State of Hawaii

**Acceptable answers：** State of Hawaii

> The term “State” means the State of Hawaii.

## 141. USC_V3_0141

**问题：** Which entity does the defined term “Administrator” identify?

**维度：** Legal-Scope

**Condition：** 5 U.S.C. § 1001

**Answer：** Administrator of General Services

**Acceptable answers：** Administrator of General Services

> The term “Administrator” means the Administrator of General Services.

**Condition：** 7 U.S.C. § 1726c

**Answer：** Administrator of the Agency for International Development

**Acceptable answers：** Administrator of the Agency for International Development

> The term “Administrator” means the Administrator of the Agency for International Development.

## 142. USC_V3_0142

**问题：** What is the full name designated by “Agency”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9501

**Answer：** Minority Business Development Agency of the Department of Commerce

**Acceptable answers：** Minority Business Development Agency of the Department of Commerce

> The term “Agency” means the Minority Business Development Agency of the Department of Commerce.

**Condition：** 16 U.S.C. § 6203

**Answer：** Forest Service

**Acceptable answers：** Forest Service

> The term “agency” means the Forest Service.

## 143. USC_V3_0143

**问题：** Which entity does the defined term “Board” identify?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 7102

**Answer：** National Sheep Promotion, Research, and Information Board

**Acceptable answers：** National Sheep Promotion, Research, and Information Board

> The term “Board” means the National Sheep Promotion, Research, and Information Board established under section 7104(b) of this title.

**Condition：** 7 U.S.C. § 7462

**Answer：** National Kiwifruit Board

**Acceptable answers：** National Kiwifruit Board

> The term “Board” means the National Kiwifruit Board established under section 7464 of this title.

## 144. USC_V3_0144

**问题：** Which entity does the defined term “Commission” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410qqq

**Answer：** Coltsville National Historical Park Advisory Commission

**Acceptable answers：** Coltsville National Historical Park Advisory Commission

> The term “Commission” means the Coltsville National Historical Park Advisory Commission established by subsection (k)(1).

**Condition：** 7 U.S.C. § 1a

**Answer：** Commodity Futures Trading Commission

**Acceptable answers：** Commodity Futures Trading Commission

> The term “Commission” means the Commodity Futures Trading Commission established under section 2(a)(2) of this title.

## 145. USC_V3_0145

**问题：** Which entity does the defined term “Conservation Area” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460hhhh

**Answer：** Numunaa Nobe National Conservation Area

**Acceptable answers：** Numunaa Nobe National Conservation Area

> The term “Conservation Area” means the Numunaa Nobe National Conservation Area established by paragraph (2).

**Condition：** 16 U.S.C. § 460yyy

**Answer：** Fort Stanton-Snowy River Cave National Conservation Area

**Acceptable answers：** Fort Stanton-Snowy River Cave National Conservation Area

> The term “Conservation Area” means the Fort Stanton-Snowy River Cave National Conservation Area established by section 460yyy–1(a) of this title.

## 146. USC_V3_0146

**问题：** What is the full name designated by “Council”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5301

**Answer：** Financial Stability Oversight Council

**Acceptable answers：** Financial Stability Oversight Council

> The term “Council” means the Financial Stability Oversight Council established under subchapter I.

**Condition：** 16 U.S.C. § 460zzz

**Answer：** Dominguez-Escalante National Conservation Area Advisory Council

**Acceptable answers：** Dominguez-Escalante National Conservation Area Advisory Council

> The term “Council” means the Dominguez-Escalante National Conservation Area Advisory Council established under section 460zzz–6 of this title.

## 147. USC_V3_0147

**问题：** What is the full name designated by “Department”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 5801

**Answer：** Department of Agriculture

**Acceptable answers：** Department of Agriculture

> The term “Department” means the Department of Agriculture.

**Condition：** 6 U.S.C. § 1101

**Answer：** Department of Homeland Security

**Acceptable answers：** Department of Homeland Security

> The term “Department” means the Department of Homeland Security.

## 148. USC_V3_0148

**问题：** What is the full name designated by “Director”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 6591c

**Answer：** Director of the Bureau of Land Management

**Acceptable answers：** Director of the Bureau of Land Management

> The term “Director” means the Director of the Bureau of Land Management.

**Condition：** 5 U.S.C. § 3115

**Answer：** Director of the Office of Personnel Management

**Acceptable answers：** Director of the Office of Personnel Management

> The term “Director” means the Director of the Office of Personnel Management.

## 149. USC_V3_0149

**问题：** Which entity does the defined term “Fund” identify?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 78u–6

**Answer：** Securities and Exchange Commission Investor Protection Fund

**Acceptable answers：** Securities and Exchange Commission Investor Protection Fund

> The term “Fund” means the Securities and Exchange Commission Investor Protection Fund.

**Condition：** 16 U.S.C. § 6602

**Answer：** Marine Turtle Conservation Fund

**Acceptable answers：** Marine Turtle Conservation Fund

> The term “Fund” means the Marine Turtle Conservation Fund established by section 6604 of this title.

## 150. USC_V3_0150

**问题：** Which entity does the defined term “historical park” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410iiii

**Answer：** Brown v. Board of Education National Historical Park

**Acceptable answers：** Brown v. Board of Education National Historical Park

> The term “historical park” means the Brown v. Board of Education National Historical Park as established in section 410iiii–2 of this title.

**Condition：** 16 U.S.C. § 410sss

**Answer：** Harriet Tubman Underground Railroad National Historical Park

**Acceptable answers：** Harriet Tubman Underground Railroad National Historical Park

> The term “historical park” means the Harriet Tubman Underground Railroad National Historical Park established by subsection (b)(1)(A).

## 151. USC_V3_0151

**问题：** Which entity does the defined term “Park” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410aaaa

**Answer：** Fort Sumter and Fort Moultrie National Historical Park

**Acceptable answers：** Fort Sumter and Fort Moultrie National Historical Park

> The term “Park” means the Fort Sumter and Fort Moultrie National Historical Park established by subsection (b).

**Condition：** 16 U.S.C. § 410qqq

**Answer：** Coltsville National Historical Park

**Acceptable answers：** Coltsville National Historical Park

> The term “park” means the Coltsville National Historical Park in the State of Connecticut.

## 152. USC_V3_0152

**问题：** What is the full name designated by “Program”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 7509

**Answer：** National Nanotechnology Program

**Acceptable answers：** National Nanotechnology Program

> The term “Program” means the National Nanotechnology Program established under section 7501 of this title.

**Condition：** 16 U.S.C. § 6592d

**Answer：** Joint Chiefs Landscape Restoration Partnership program

**Acceptable answers：** Joint Chiefs Landscape Restoration Partnership program

> The term “Program” means the Joint Chiefs Landscape Restoration Partnership program established under subsection (b)(1).

## 153. USC_V3_0153

**问题：** What is the full name designated by “Secretary”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9026

**Answer：** Secretary of Labor

**Acceptable answers：** Secretary of Labor

> The term “Secretary” means the Secretary of Labor.

**Condition：** 6 U.S.C. § 1101

**Answer：** Secretary of Homeland Security

**Acceptable answers：** Secretary of Homeland Security

> The term “Secretary” means the Secretary of Homeland Security.

## 154. USC_V3_0154

**问题：** What is the full name designated by “State”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410aaaa

**Answer：** State of South Carolina

**Acceptable answers：** State of South Carolina

> The term “State” means the State of South Carolina.

**Condition：** 16 U.S.C. § 410sss

**Answer：** State of Maryland

**Acceptable answers：** State of Maryland

> The term “State” means the State of Maryland.

## 155. USC_V3_0155

**问题：** What is the name of the entity called “Administrator”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9701

**Answer：** Administrator of the National Oceanic and Atmospheric Administration

**Acceptable answers：** Administrator of the National Oceanic and Atmospheric Administration

> The term “Administrator” means the Administrator of the National Oceanic and Atmospheric Administration.

**Condition：** 5 U.S.C. § 1001

**Answer：** Administrator of General Services

**Acceptable answers：** Administrator of General Services

> The term “Administrator” means the Administrator of General Services.

## 156. USC_V3_0156

**问题：** What is the name of the entity called “Board”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 6302

**Answer：** United Soybean Board

**Acceptable answers：** United Soybean Board

> The term “Board” means the United Soybean Board established under section 6304(b) of this title.

**Condition：** 7 U.S.C. § 6402

**Answer：** National Processor Advertising and Promotion Board

**Acceptable answers：** National Processor Advertising and Promotion Board

> The term “Board” means the National Processor Advertising and Promotion Board established under section 6407(b) of this title.

## 157. USC_V3_0157

**问题：** What is the name of the entity called “Commission”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1820a

**Answer：** Securities and Exchange Commission

**Acceptable answers：** Securities and Exchange Commission

> The term “Commission” means the Securities and Exchange Commission.

**Condition：** 15 U.S.C. § 6555

**Answer：** Federal Trade Commission

**Acceptable answers：** Federal Trade Commission

> The term “Commission” means the Federal Trade Commission.

## 158. USC_V3_0158

**问题：** What is the name of the entity called “Conservation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460iiii

**Answer：** Pistone-Black Mountain National Conservation Area

**Acceptable answers：** Pistone-Black Mountain National Conservation Area

> The term “Conservation Area” means the Pistone-Black Mountain National Conservation Area established by paragraph (2)(A).

**Condition：** 16 U.S.C. § 460zzz

**Answer：** Dominguez-Escalante National Conservation Area

**Acceptable answers：** Dominguez-Escalante National Conservation Area

> The term “Conservation Area” means the Dominguez-Escalante National Conservation Area established by section 460zzz–1(a)(1) of this title.

## 159. USC_V3_0159

**问题：** Which entity does the defined term “Council” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460mmm–1

**Answer：** McInnis Canyons National Conservation Area Advisory Council

**Acceptable answers：** McInnis Canyons National Conservation Area Advisory Council

> The term “Council” means the McInnis Canyons National Conservation Area Advisory Council established under section 460mmm–6 of this title.

**Condition：** 16 U.S.C. § 460zzz

**Answer：** Dominguez-Escalante National Conservation Area Advisory Council

**Acceptable answers：** Dominguez-Escalante National Conservation Area Advisory Council

> The term “Council” means the Dominguez-Escalante National Conservation Area Advisory Council established under section 460zzz–6 of this title.

## 160. USC_V3_0160

**问题：** Which entity does the defined term “Director” identify?

**维度：** Legal-Scope

**Condition：** 6 U.S.C. § 677a

**Answer：** Director of the Cybersecurity and Infrastructure Security Agency

**Acceptable answers：** Director of the Cybersecurity and Infrastructure Security Agency

> The term “Director” means the Director of the Cybersecurity and Infrastructure Security Agency.

**Condition：** 7 U.S.C. § 2279b

**Answer：** Director of the Graduate School

**Acceptable answers：** Director of the Graduate School

> The term “Director” means the Director of the Graduate School.

## 161. USC_V3_0161

**问题：** What is the name of the entity called “Fund”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5381

**Answer：** Orderly Liquidation Fund

**Acceptable answers：** Orderly Liquidation Fund

> The term “Fund” means the Orderly Liquidation Fund established under section 5390(n) of this title.

**Condition：** 16 U.S.C. § 6602

**Answer：** Marine Turtle Conservation Fund

**Acceptable answers：** Marine Turtle Conservation Fund

> The term “Fund” means the Marine Turtle Conservation Fund established by section 6604 of this title.

## 162. USC_V3_0162

**问题：** What is the name of the entity called “historical park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410sss

**Answer：** Harriet Tubman Underground Railroad National Historical Park

**Acceptable answers：** Harriet Tubman Underground Railroad National Historical Park

> The term “historical park” means the Harriet Tubman Underground Railroad National Historical Park established by subsection (b)(1)(A).

**Condition：** 16 U.S.C. § 410uuu

**Answer：** Manhattan Project National Historical Park

**Acceptable answers：** Manhattan Project National Historical Park

> The term “Historical Park” means the Manhattan Project National Historical Park established under subsection (c).

## 163. USC_V3_0163

**问题：** What is the name of the entity called “park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410kkk

**Answer：** Lewis and Clark National Historical Park

**Acceptable answers：** Lewis and Clark National Historical Park

> The term “park” means the Lewis and Clark National Historical Park designated in section 410kkk–1 of this title.

**Condition：** 16 U.S.C. § 410ll–1

**Answer：** Women’s Rights National Historical Park

**Acceptable answers：** Women’s Rights National Historical Park

> The term “Park” means the Women’s Rights National Historical Park established by section 410ll of this title.

## 164. USC_V3_0164

**问题：** Which entity does the defined term “Program” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 6542

**Answer：** Water Source Protection Program

**Acceptable answers：** Water Source Protection Program

> The term “Program” means the Water Source Protection Program established under subsection (b).

**Condition：** 7 U.S.C. § 6712

**Answer：** Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program

**Acceptable answers：** Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program

> The term “Program” means the Greenhouse Gas Technical Assistance Provider and Third-Party Verifier Program established under subsection (b).

## 165. USC_V3_0165

**问题：** Which entity does the defined term “Secretary” identify?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1715z–11a

**Answer：** Secretary of Housing and Urban Development

**Acceptable answers：** Secretary of Housing and Urban Development

> The term “Secretary” means the Secretary of Housing and Urban Development.

**Condition：** 15 U.S.C. § 9131

**Answer：** Secretary of Transportation

**Acceptable answers：** Secretary of Transportation

> The term “Secretary” means the Secretary of Transportation.

## 166. USC_V3_0166

**问题：** Which entity does the defined term “State” identify?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410xxx

**Answer：** State of Missouri

**Acceptable answers：** State of Missouri

> The term “State” means the State of Missouri.

**Condition：** 16 U.S.C. § 460zzz

**Answer：** State of Colorado

**Acceptable answers：** State of Colorado

> The term “State” means the State of Colorado.

## 167. USC_V3_0167

**问题：** Which entity is designated as “Administrator”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8563

**Answer：** Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration

**Acceptable answers：** Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration

> The term “Administrator” means the Under Secretary of Commerce for Oceans and Atmosphere and Administrator of the National Oceanic and Atmospheric Administration.

**Condition：** 6 U.S.C. § 561

**Answer：** Administrator of the Transportation Security Administration

**Acceptable answers：** Administrator of the Transportation Security Administration

> The term “Administrator” means the Administrator of the Transportation Security Administration.

## 168. USC_V3_0168

**问题：** Which entity is designated as “Board”?

**维度：** Legal-Scope

**Condition：** 7 U.S.C. § 2279b

**Answer：** General Administration Board of the Graduate School

**Acceptable answers：** General Administration Board of the Graduate School

> The term “Board” means the General Administration Board of the Graduate School.

**Condition：** 7 U.S.C. § 7102

**Answer：** National Sheep Promotion, Research, and Information Board

**Acceptable answers：** National Sheep Promotion, Research, and Information Board

> The term “Board” means the National Sheep Promotion, Research, and Information Board established under section 7104(b) of this title.

## 169. USC_V3_0169

**问题：** Which entity is designated as “Commission”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1820a

**Answer：** Securities and Exchange Commission

**Acceptable answers：** Securities and Exchange Commission

> The term “Commission” means the Securities and Exchange Commission.

**Condition：** 15 U.S.C. § 720

**Answer：** Federal Energy Regulatory Commission

**Acceptable answers：** Federal Energy Regulatory Commission / FERC

> The term “Commission” means the Federal Energy Regulatory Commission.

## 170. USC_V3_0170

**问题：** Which entity is designated as “Conservation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460iiii

**Answer：** Pistone-Black Mountain National Conservation Area

**Acceptable answers：** Pistone-Black Mountain National Conservation Area

> The term “Conservation Area” means the Pistone-Black Mountain National Conservation Area established by paragraph (2)(A).

**Condition：** 16 U.S.C. § 460mmm–1

**Answer：** McInnis Canyons National Conservation Area

**Acceptable answers：** McInnis Canyons National Conservation Area

> The term “Conservation Area” means the McInnis Canyons National Conservation Area established by section 460mmm–2(a) of this title.

## 171. USC_V3_0171

**问题：** What is the name of the entity called “Council”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 460zzz

**Answer：** Dominguez-Escalante National Conservation Area Advisory Council

**Acceptable answers：** Dominguez-Escalante National Conservation Area Advisory Council

> The term “Council” means the Dominguez-Escalante National Conservation Area Advisory Council established under section 460zzz–6 of this title.

**Condition：** 7 U.S.C. § 6102

**Answer：** Mushroom Council

**Acceptable answers：** Mushroom Council

> The term “Council” means the Mushroom Council established under section 6104(b) of this title.

## 172. USC_V3_0172

**问题：** What is the name of the entity called “Director”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 1422

**Answer：** Director of the Federal Housing Finance Agency

**Acceptable answers：** Director of the Federal Housing Finance Agency

> The term “Director” means the Director of the Federal Housing Finance Agency.

**Condition：** 5 U.S.C. § 3115

**Answer：** Director of the Office of Personnel Management

**Acceptable answers：** Director of the Office of Personnel Management

> The term “Director” means the Director of the Office of Personnel Management.

## 173. USC_V3_0173

**问题：** Which entity is designated as “Fund”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 9009c

**Answer：** Restaurant Revitalization Fund

**Acceptable answers：** Restaurant Revitalization Fund

> The term “Fund” means the Restaurant Revitalization Fund established under subsection (b).

**Condition：** 16 U.S.C. § 2104a

**Answer：** Pest and Disease Revolving Loan Fund

**Acceptable answers：** Pest and Disease Revolving Loan Fund

> The term “Fund” means the Pest and Disease Revolving Loan Fund established by subsection (b).

## 174. USC_V3_0174

**问题：** Which entity is designated as “historical park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410rrr

**Answer：** First State National Historical Park

**Acceptable answers：** First State National Historical Park

> The term “historical park” means the First State National Historical Park.

**Condition：** 16 U.S.C. § 410uuu

**Answer：** Manhattan Project National Historical Park

**Acceptable answers：** Manhattan Project National Historical Park

> The term “Historical Park” means the Manhattan Project National Historical Park established under subsection (c).

## 175. USC_V3_0175

**问题：** Which entity is designated as “Park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410lll

**Answer：** Paterson Great Falls National Historical Park

**Acceptable answers：** Paterson Great Falls National Historical Park

> The term “Park” means the Paterson Great Falls National Historical Park established by subsection (b)(1)(A).

**Condition：** 16 U.S.C. § 430t–1

**Answer：** Kennesaw Mountain National Battlefield Park

**Acceptable answers：** Kennesaw Mountain National Battlefield Park

> The term “Park” means the Kennesaw Mountain National Battlefield Park.

## 176. USC_V3_0176

**问题：** What is the name of the entity called “Program”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 4730

**Answer：** Great Lakes and Lake Champlain Invasive Species Program

**Acceptable answers：** Great Lakes and Lake Champlain Invasive Species Program

> The term “Program” means the Great Lakes and Lake Champlain Invasive Species Program established under paragraph (2)(A).

**Condition：** 7 U.S.C. § 8113

**Answer：** Community Wood Energy and Wood Innovation Program

**Acceptable answers：** Community Wood Energy and Wood Innovation Program

> The term “Program” means the Community Wood Energy and Wood Innovation Program established under subsection (b).

## 177. USC_V3_0177

**问题：** What is the name of the entity called “Secretary”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 5541

**Answer：** Secretary of Energy

**Acceptable answers：** Secretary of Energy

> The term “Secretary” means the Secretary of Energy.

**Condition：** 15 U.S.C. § 9026

**Answer：** Secretary of Labor

**Acceptable answers：** Secretary of Labor

> The term “Secretary” means the Secretary of Labor.

## 178. USC_V3_0178

**问题：** What is the name of the entity called “State”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 539p

**Answer：** State of Arizona

**Acceptable answers：** State of Arizona

> The term “State” means the State of Arizona.

**Condition：** 16 U.S.C. § 539r

**Answer：** State of Montana

**Acceptable answers：** State of Montana

> The term “State” means the State of Montana.

## 179. USC_V3_0179

**问题：** What entity is named in the definition of “Administrator”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 6901

**Answer：** Administrator of the Small Business Administration

**Acceptable answers：** Administrator of the Small Business Administration

> The term “Administrator” means the Administrator of the Small Business Administration.

**Condition：** 5 U.S.C. § 1001

**Answer：** Administrator of General Services

**Acceptable answers：** Administrator of General Services

> The term “Administrator” means the Administrator of General Services.

## 180. USC_V3_0180

**问题：** What entity is named in the definition of “Board”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8702

**Answer：** Concrete Masonry Products Board

**Acceptable answers：** Concrete Masonry Products Board

> The term “Board” means the Concrete Masonry Products Board established under section 8704 of this title.

**Condition：** 7 U.S.C. § 7482

**Answer：** Popcorn Board

**Acceptable answers：** Popcorn Board

> The term “Board” means the Popcorn Board established under section 7484(b) of this title.

## 181. USC_V3_0181

**问题：** What entity is named in the definition of “Commission”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410iii–2

**Answer：** Cedar Creek and Belle Grove National Historical Park Advisory Commission

**Acceptable answers：** Cedar Creek and Belle Grove National Historical Park Advisory Commission

> The term “Commission” means the Cedar Creek and Belle Grove National Historical Park Advisory Commission established by section 410iii–7 of this title.

**Condition：** 16 U.S.C. § 410qqq

**Answer：** Coltsville National Historical Park Advisory Commission

**Acceptable answers：** Coltsville National Historical Park Advisory Commission

> The term “Commission” means the Coltsville National Historical Park Advisory Commission established by subsection (k)(1).

## 182. USC_V3_0182

**问题：** What entity is named in the definition of “Conservation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410fff–1

**Answer：** Gunnison Gorge National Conservation Area

**Acceptable answers：** Gunnison Gorge National Conservation Area

> The term “Conservation Area” means the Gunnison Gorge National Conservation Area, consisting of approximately 57,725 acres surrounding the Gunnison Gorge as depicted on the Map.

**Condition：** 16 U.S.C. § 460qqq–1

**Answer：** Sloan Canyon National Conservation Area

**Acceptable answers：** Sloan Canyon National Conservation Area

> The term “Conservation Area” means the Sloan Canyon National Conservation Area established by section 460qqq–2(a) of this title.

## 183. USC_V3_0183

**问题：** Which entity is designated as “Council”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 7801

**Answer：** Western Pacific Regional Fishery Management Council

**Acceptable answers：** Western Pacific Regional Fishery Management Council

> The term “Council” means the Western Pacific Regional Fishery Management Council.

**Condition：** 16 U.S.C. § 832m

**Answer：** Northwest Power and Conservation Planning Council

**Acceptable answers：** Northwest Power and Conservation Planning Council

> The term “Council” means the Northwest Power and Conservation Planning Council.

## 184. USC_V3_0184

**问题：** Which entity is designated as “Director”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 7402

**Answer：** Director of the National Science Foundation

**Acceptable answers：** Director of the National Science Foundation

> The term “Director” means the Director of the National Science Foundation.

**Condition：** 15 U.S.C. § 7461

**Answer：** Director of the National Institute of Standards and Technology

**Acceptable answers：** Director of the National Institute of Standards and Technology

> The term “Director” means the Director of the National Institute of Standards and Technology.

## 185. USC_V3_0185

**问题：** What entity is named in the definition of “Fund”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 6302

**Answer：** Great Ape Conservation Fund

**Acceptable answers：** Great Ape Conservation Fund

> The term “Fund” means the Great Ape Conservation Fund established by section 6304 of this title.

**Condition：** 16 U.S.C. § 698v–11

**Answer：** Valles Caldera Fund

**Acceptable answers：** Valles Caldera Fund

> The term “Fund” means the Valles Caldera Fund established by section 106(h)(2) of the Valles Caldera Preservation Act.

## 186. USC_V3_0186

**问题：** What entity is named in the definition of “historical park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410eee–1

**Answer：** Adams National Historical Park

**Acceptable answers：** Adams National Historical Park

> The term “historical park” means the Adams National Historical Park established in section 410eee–2 of this title.

**Condition：** 16 U.S.C. § 410jjjj

**Answer：** Pullman National Historical Park

**Acceptable answers：** Pullman National Historical Park

> The term “historical park” means the Pullman National Historical Park.

## 187. USC_V3_0187

**问题：** What entity is named in the definition of “Park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410dddd

**Answer：** White Sands National Park

**Acceptable answers：** White Sands National Park

> The term “Park” means the White Sands National Park established by subsection (b)(1).

**Condition：** 16 U.S.C. § 410iii–2

**Answer：** Cedar Creek and Belle Grove National Historical Park

**Acceptable answers：** Cedar Creek and Belle Grove National Historical Park

> The term “Park” means the Cedar Creek and Belle Grove National Historical Park established under section 410iii–3 of this title and depicted on the Map.

## 188. USC_V3_0188

**问题：** Which entity is designated as “Program”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 8801

**Answer：** National Quantum Initiative Program

**Acceptable answers：** National Quantum Initiative Program

> The term “Program” means the National Quantum Initiative Program implemented under section 8811(a) of this title.

**Condition：** 16 U.S.C. § 6542

**Answer：** Water Source Protection Program

**Acceptable answers：** Water Source Protection Program

> The term “Program” means the Water Source Protection Program established under subsection (b).

## 189. USC_V3_0189

**问题：** Which entity is designated as “Secretary”?

**维度：** Legal-Scope

**Condition：** 6 U.S.C. § 1101

**Answer：** Secretary of Homeland Security

**Acceptable answers：** Secretary of Homeland Security

> The term “Secretary” means the Secretary of Homeland Security.

**Condition：** 6 U.S.C. § 1533

**Answer：** Secretary of Health and Human Services

**Acceptable answers：** Secretary of Health and Human Services

> The term “Secretary” means the Secretary of Health and Human Services.

## 190. USC_V3_0190

**问题：** Which entity is designated as “State”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 720

**Answer：** State of Alaska

**Acceptable answers：** State of Alaska

> The term “State” means the State of Alaska.

**Condition：** 16 U.S.C. § 410dddd

**Answer：** State of New Mexico

**Acceptable answers：** State of New Mexico

> The term “State” means the State of New Mexico.

## 191. USC_V3_0191

**问题：** What is the full name designated by “Administrator”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 838n

**Answer：** Administrator of the Bonneville Power Administration

**Acceptable answers：** Administrator of the Bonneville Power Administration

> The term “Administrator” means the Administrator of the Bonneville Power Administration.

**Condition：** 7 U.S.C. § 1726c

**Answer：** Administrator of the Agency for International Development

**Acceptable answers：** Administrator of the Agency for International Development

> The term “Administrator” means the Administrator of the Agency for International Development.

## 192. USC_V3_0192

**问题：** What is the full name designated by “Board”?

**维度：** Legal-Scope

**Condition：** 2 U.S.C. § 1301

**Answer：** Board of Directors of the Office of Congressional Workplace Rights

**Acceptable answers：** Board of Directors of the Office of Congressional Workplace Rights

> The term “Board” means the Board of Directors of the Office of Congressional Workplace Rights.

**Condition：** 7 U.S.C. § 7462

**Answer：** National Kiwifruit Board

**Acceptable answers：** National Kiwifruit Board

> The term “Board” means the National Kiwifruit Board established under section 7464 of this title.

## 193. USC_V3_0193

**问题：** What is the full name designated by “Commission”?

**维度：** Legal-Scope

**Condition：** 15 U.S.C. § 6555

**Answer：** Federal Trade Commission

**Acceptable answers：** Federal Trade Commission

> The term “Commission” means the Federal Trade Commission.

**Condition：** 16 U.S.C. § 410iii–2

**Answer：** Cedar Creek and Belle Grove National Historical Park Advisory Commission

**Acceptable answers：** Cedar Creek and Belle Grove National Historical Park Advisory Commission

> The term “Commission” means the Cedar Creek and Belle Grove National Historical Park Advisory Commission established by section 410iii–7 of this title.

## 194. USC_V3_0194

**问题：** What is the full name designated by “Conservation Area”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410fff–1

**Answer：** Gunnison Gorge National Conservation Area

**Acceptable answers：** Gunnison Gorge National Conservation Area

> The term “Conservation Area” means the Gunnison Gorge National Conservation Area, consisting of approximately 57,725 acres surrounding the Gunnison Gorge as depicted on the Map.

**Condition：** 16 U.S.C. § 460ooo

**Answer：** Las Cienegas National Conservation Area

**Acceptable answers：** Las Cienegas National Conservation Area

> The term “Conservation Area” means the Las Cienegas National Conservation Area established by section 460ooo–3(a) of this title.

## 195. USC_V3_0195

**问题：** What entity is named in the definition of “Council”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 3350

**Answer：** Federal Financial Institutions Examinations Council

**Acceptable answers：** Federal Financial Institutions Examinations Council

> The term “Council” means the Federal Financial Institutions Examinations Council.

**Condition：** 16 U.S.C. § 832m

**Answer：** Northwest Power and Conservation Planning Council

**Acceptable answers：** Northwest Power and Conservation Planning Council

> The term “Council” means the Northwest Power and Conservation Planning Council.

## 196. USC_V3_0196

**问题：** What entity is named in the definition of “Director”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5102

**Answer：** Director of the Bureau of Consumer Financial Protection

**Acceptable answers：** Director of the Bureau of Consumer Financial Protection

> The term “Director” means the Director of the Bureau of Consumer Financial Protection.

**Condition：** 15 U.S.C. § 7461

**Answer：** Director of the National Institute of Standards and Technology

**Acceptable answers：** Director of the National Institute of Standards and Technology

> The term “Director” means the Director of the National Institute of Standards and Technology.

## 197. USC_V3_0197

**问题：** What is the full name designated by “Fund”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 4702

**Answer：** Community Development Financial Institutions Fund

**Acceptable answers：** Community Development Financial Institutions Fund

> The term “Fund” means the Community Development Financial Institutions Fund established under section 4703(a) of this title.

**Condition：** 16 U.S.C. § 698v–11

**Answer：** Valles Caldera Fund

**Acceptable answers：** Valles Caldera Fund

> The term “Fund” means the Valles Caldera Fund established by section 106(h)(2) of the Valles Caldera Preservation Act.

## 198. USC_V3_0198

**问题：** What is the full name designated by “historical park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410sss

**Answer：** Harriet Tubman Underground Railroad National Historical Park

**Acceptable answers：** Harriet Tubman Underground Railroad National Historical Park

> The term “historical park” means the Harriet Tubman Underground Railroad National Historical Park established by subsection (b)(1)(A).

**Condition：** 16 U.S.C. § 410ttt

**Answer：** Harriet Tubman National Historical Park

**Acceptable answers：** Harriet Tubman National Historical Park

> The term “historical park” means the Harriet Tubman National Historical Park established by subsection (b)(1)(A).

## 199. USC_V3_0199

**问题：** What is the full name designated by “Park”?

**维度：** Legal-Scope

**Condition：** 16 U.S.C. § 410lll

**Answer：** Paterson Great Falls National Historical Park

**Acceptable answers：** Paterson Great Falls National Historical Park

> The term “Park” means the Paterson Great Falls National Historical Park established by subsection (b)(1)(A).

**Condition：** 16 U.S.C. § 430f–7

**Answer：** Shiloh National Military Park

**Acceptable answers：** Shiloh National Military Park

> The term “Park” means the Shiloh National Military Park.

## 200. USC_V3_0200

**问题：** What entity is named in the definition of “Program”?

**维度：** Legal-Scope

**Condition：** 12 U.S.C. § 5701

**Answer：** State Small Business Credit Initiative

**Acceptable answers：** State Small Business Credit Initiative

> The term “Program” means the State Small Business Credit Initiative established under this chapter.

**Condition：** 15 U.S.C. § 7509

**Answer：** National Nanotechnology Program

**Acceptable answers：** National Nanotechnology Program

> The term “Program” means the National Nanotechnology Program established under section 7501 of this title.

from google.colab import drive
from pathlib import Path
from datetime import datetime
from collections import defaultdict
import json
import shutil

import pandas as pd


drive.mount("/content/drive")

ROOT = Path("/content/drive/MyDrive")
matches = list(ROOT.rglob("311_Service_Requests_from_2020_to_Present_20261008.csv"))
assert matches, "找不到原始 NYC311 CSV"
source = max(matches, key=lambda p: p.stat().st_mtime)

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
out_dir = ROOT / "NYC311_2024" / f"Geography_Family_Profile_{stamp}"
out_dir.mkdir(parents=True, exist_ok=False)

header = pd.read_csv(source, nrows=0).columns.tolist()
complaint_col = (
    "Problem (formerly Complaint Type)"
    if "Problem (formerly Complaint Type)" in header
    else "Complaint Type"
)

requested = [
    "Created Date", complaint_col, "Borough", "City", "Street Name",
    "Park Facility Name", "Park Borough",
]
missing = [c for c in requested if c not in header]
assert not missing, f"CSV缺少字段：{missing}"

VALID_BOROUGHS = ["BRONX", "BROOKLYN", "MANHATTAN", "QUEENS", "STATEN ISLAND"]
BAD_PLACE_VALUES = {
    "", "NAN", "NONE", "NULL", "UNKNOWN", "UNSPECIFIED", "N/A",
    "NA", "NO NAME", "UNNAMED", "UNNAMED STREET",
}


def clean_text(series):
    return series.fillna("").astype(str).str.strip().str.upper().str.replace(r"\s+", " ", regex=True)


street_parts = []
park_parts = []
incident_parts = []
park_borough_parts = []
city_parts = []
locality_parts = []

source_rows = 0
retained_rows = 0

print("正在扫描：", source)
for chunk_no, chunk in enumerate(
    pd.read_csv(source, usecols=requested, chunksize=200_000, low_memory=False), 1
):
    source_rows += len(chunk)
    dt = pd.to_datetime(chunk["Created Date"], errors="coerce")
    mask = (dt >= "2024-02-01") & (dt < "2024-12-01")
    chunk = chunk.loc[mask].copy()
    dt = dt.loc[mask]

    chunk["Borough"] = clean_text(chunk["Borough"])
    chunk = chunk[chunk["Borough"].isin(VALID_BOROUGHS)].copy()
    dt = dt.loc[chunk.index]
    retained_rows += len(chunk)

    chunk["month"] = dt.dt.to_period("M").astype(str)
    chunk["complaint"] = clean_text(chunk[complaint_col])
    chunk["city"] = clean_text(chunk["City"])
    chunk["street"] = clean_text(chunk["Street Name"])
    chunk["park_name"] = clean_text(chunk["Park Facility Name"])
    chunk["park_borough"] = clean_text(chunk["Park Borough"])

    base_keys = ["month", "complaint"]

    # Family candidate 1: the same street name occurs in multiple boroughs.
    s = chunk[
        (~chunk["street"].isin(BAD_PLACE_VALUES))
        & (chunk["street"].str.len() >= 4)
    ]
    if len(s):
        street_parts.append(
            s.groupby(base_keys + ["street", "Borough"]).size().rename("count").reset_index()
        )

    # Family candidate 2: the same park/facility name occurs in multiple park boroughs.
    p = chunk[
        (~chunk["park_name"].isin(BAD_PLACE_VALUES))
        & (chunk["park_name"].str.len() >= 4)
        & (chunk["park_borough"].isin(VALID_BOROUGHS))
    ]
    if len(p):
        park_parts.append(
            p.groupby(base_keys + ["park_name", "park_borough"]).size().rename("count").reset_index()
        )

    # Family candidate 3: "in Brooklyn" could use incident Borough or Park Borough.
    incident_parts.append(
        chunk.groupby(base_keys + ["Borough"]).size().rename("incident_borough_count").reset_index()
    )
    pb = chunk[chunk["park_borough"].isin(VALID_BOROUGHS)]
    if len(pb):
        park_borough_parts.append(
            pb.groupby(base_keys + ["park_borough"]).size().rename("park_borough_count").reset_index()
        )

    # Family candidate 4: "New York" could mean all NYC or rows whose City field is NEW YORK.
    citywide = chunk.groupby(base_keys).size().rename("nyc_total").reset_index()
    city_new_york = (
        chunk[chunk["city"] == "NEW YORK"]
        .groupby(base_keys).size().rename("city_field_new_york_count").reset_index()
    )
    city_parts.append(citywide.merge(city_new_york, on=base_keys, how="left").fillna(0))

    # Diagnostic: whether an identical City/locality value spans boroughs.
    loc = chunk[~chunk["city"].isin(BAD_PLACE_VALUES)]
    if len(loc):
        locality_parts.append(
            loc.groupby(base_keys + ["city", "Borough"]).size().rename("count").reset_index()
        )

    print(f"已扫描 {source_rows:,} 行")


def collapse(parts, keys, value_col="count"):
    if not parts:
        return pd.DataFrame(columns=keys + [value_col])
    x = pd.concat(parts, ignore_index=True)
    return x.groupby(keys, as_index=False)[value_col].sum()


# Same-street candidates: at least two boroughs with >=10 requests each.
street = collapse(street_parts, ["month", "complaint", "street", "Borough"])
street_ok = street[street["count"] >= 10].copy()
street_stats = (
    street_ok.groupby(["month", "complaint", "street"])
    .agg(borough_count=("Borough", "nunique"), total_count=("count", "sum"))
    .reset_index()
)
street_stats = street_stats[street_stats["borough_count"] >= 2]
street_candidates = street_ok.merge(street_stats, on=["month", "complaint", "street"])
street_candidates = street_candidates.sort_values(
    ["borough_count", "total_count", "month", "complaint", "street", "count"],
    ascending=[False, False, True, True, True, False],
)

# Same-park candidates: at least two park boroughs with >=5 requests each.
park = collapse(park_parts, ["month", "complaint", "park_name", "park_borough"])
park_ok = park[park["count"] >= 5].copy()
park_stats = (
    park_ok.groupby(["month", "complaint", "park_name"])
    .agg(borough_count=("park_borough", "nunique"), total_count=("count", "sum"))
    .reset_index()
)
park_stats = park_stats[park_stats["borough_count"] >= 2]
park_candidates = park_ok.merge(park_stats, on=["month", "complaint", "park_name"])
park_candidates = park_candidates.sort_values(
    ["borough_count", "total_count", "month", "complaint", "park_name", "count"],
    ascending=[False, False, True, True, True, False],
)

# Incident Borough versus Park Borough candidates.
incident = collapse(
    incident_parts, ["month", "complaint", "Borough"], "incident_borough_count"
).rename(columns={"Borough": "target_borough"})
park_borough = collapse(
    park_borough_parts, ["month", "complaint", "park_borough"], "park_borough_count"
).rename(columns={"park_borough": "target_borough"})
borough_vs_park = incident.merge(
    park_borough, on=["month", "complaint", "target_borough"], how="inner"
)
borough_vs_park["absolute_difference"] = (
    borough_vs_park["incident_borough_count"] - borough_vs_park["park_borough_count"]
).abs()
borough_vs_park = borough_vs_park[
    (borough_vs_park["incident_borough_count"] >= 20)
    & (borough_vs_park["park_borough_count"] >= 20)
    & (borough_vs_park["absolute_difference"] >= 10)
].sort_values("absolute_difference", ascending=False)

# All NYC versus City field == NEW YORK.
city_scope = collapse(city_parts, ["month", "complaint"], "nyc_total")
city_new_york = collapse(city_parts, ["month", "complaint"], "city_field_new_york_count")
city_scope = city_scope.merge(city_new_york, on=["month", "complaint"])
city_scope["absolute_difference"] = (
    city_scope["nyc_total"] - city_scope["city_field_new_york_count"]
).abs()
city_scope = city_scope[
    (city_scope["nyc_total"] >= 100)
    & (city_scope["city_field_new_york_count"] >= 20)
].sort_values("absolute_difference", ascending=False)

# Repeated locality diagnostics.
locality = collapse(locality_parts, ["month", "complaint", "city", "Borough"])
locality_ok = locality[locality["count"] >= 5].copy()
locality_stats = (
    locality_ok.groupby(["month", "complaint", "city"])
    .agg(borough_count=("Borough", "nunique"), total_count=("count", "sum"))
    .reset_index()
)
locality_stats = locality_stats[locality_stats["borough_count"] >= 2]
locality_candidates = locality_ok.merge(locality_stats, on=["month", "complaint", "city"])
locality_candidates = locality_candidates.sort_values(
    ["borough_count", "total_count", "count"], ascending=False
)

outputs = {
    "street_name_across_borough_candidates.csv": street_candidates,
    "park_name_across_borough_candidates.csv": park_candidates,
    "incident_borough_vs_park_borough_candidates.csv": borough_vs_park,
    "new_york_scope_candidates.csv": city_scope,
    "city_locality_across_borough_diagnostics.csv": locality_candidates,
}
for name, frame in outputs.items():
    frame.head(5000).to_csv(out_dir / name, index=False)

summary = {
    "source": str(source),
    "period": "2024-02-01 inclusive to 2024-12-01 exclusive",
    "source_rows_scanned": int(source_rows),
    "valid_period_and_borough_rows": int(retained_rows),
    "candidate_row_counts_before_top5000_cap": {
        "street_name_across_borough": int(len(street_candidates)),
        "park_name_across_borough": int(len(park_candidates)),
        "incident_borough_vs_park_borough": int(len(borough_vs_park)),
        "new_york_scope": int(len(city_scope)),
        "city_locality_across_borough": int(len(locality_candidates)),
    },
    "interpretation_warning": (
        "These are candidate mechanisms, not automatically accepted benchmark families. "
        "Each candidate still requires naturalness and dimension review."
    ),
}
with open(out_dir / "profile_summary.json", "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)

zip_path = shutil.make_archive(str(out_dir), "zip", root_dir=out_dir)

print("\n========== 完成 ==========")
print(json.dumps(summary, ensure_ascii=False, indent=2))
print("输出文件夹：", out_dir)
print("ZIP：", zip_path)

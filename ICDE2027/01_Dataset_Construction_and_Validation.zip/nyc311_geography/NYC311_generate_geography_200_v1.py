from google.colab import drive
from pathlib import Path
from datetime import datetime
from collections import Counter
import hashlib
import json
import math
import re
import shutil

import pandas as pd


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------
drive.mount("/content/drive")

ROOT = Path("/content/drive/MyDrive")
SOURCE_NAME = "311_Service_Requests_from_2020_to_Present_20261008.csv"
PERIOD_START = "2024-02-01"
PERIOD_END = "2024-12-01"
N_COMMUNITY_BOARD = 100
N_STREET = 100
CHUNK_SIZE = 200_000

BOROUGHS = ["BRONX", "BROOKLYN", "MANHATTAN", "QUEENS", "STATEN ISLAND"]
BOROUGH_DISPLAY = {
    "BRONX": "Bronx",
    "BROOKLYN": "Brooklyn",
    "MANHATTAN": "Manhattan",
    "QUEENS": "Queens",
    "STATEN ISLAND": "Staten Island",
}
BOROUGH_IN_PHRASE = {
    "BRONX": "the Bronx",
    "BROOKLYN": "Brooklyn",
    "MANHATTAN": "Manhattan",
    "QUEENS": "Queens",
    "STATEN ISLAND": "Staten Island",
}
MONTH_NAMES = {
    "01": "January", "02": "February", "03": "March", "04": "April",
    "05": "May", "06": "June", "07": "July", "08": "August",
    "09": "September", "10": "October", "11": "November", "12": "December",
}
BAD_STREET_VALUES = {
    "", "NAN", "NONE", "NULL", "UNKNOWN", "UNSPECIFIED", "N/A", "NA",
    "NO NAME", "UNNAMED", "UNNAMED STREET",
}


def clean_text(series):
    return (
        series.fillna("").astype(str).str.strip().str.upper()
        .str.replace(r"\s+", " ", regex=True)
    )


def pretty_label(value):
    """Readable display form while preserving a few common NYC acronyms."""
    text = value.title()
    replacements = {
        "Nyc": "NYC", "Nypd": "NYPD", "Fdot": "FDOT", "Dot": "DOT",
        "Dep": "DEP", "Dof": "DOF", "Dsny": "DSNY", "Hpd": "HPD",
        "Heat/Hot Water": "HEAT/HOT WATER",
    }
    for old, new in replacements.items():
        text = re.sub(rf"\b{re.escape(old)}\b", new, text)
    return text


def month_display(period):
    year, month = period.split("-")
    return f"{MONTH_NAMES[month]} {year}"


def markdown_table(rows):
    return pd.DataFrame(rows).to_markdown(index=False)


def balanced_select(frame, n, unique_field=None, extra_balance_field=None):
    """
    Greedy selection that favors underused months, complaints, and entity values,
    while preferring candidates with more boroughs and stronger cell counts.
    """
    records = frame.to_dict("records")
    chosen = []
    used_unique = set()
    month_use = Counter()
    complaint_use = Counter()
    extra_use = Counter()

    while len(chosen) < n:
        available = [
            row for row in records
            if unique_field is None or row[unique_field] not in used_unique
        ]
        if not available:
            break

        def rank(row):
            balance_cost = (
                3 * month_use[row["month"]]
                + 2 * complaint_use[row["complaint"]]
            )
            if extra_balance_field is not None:
                balance_cost += extra_use[row[extra_balance_field]]
            return (
                balance_cost,
                month_use[row["month"]],
                complaint_use[row["complaint"]],
                -int(row["borough_count"]),
                -int(row["min_count"]),
                -int(row["total_count"]),
                str(row.get(unique_field, "")),
                str(row["month"]),
                str(row["complaint"]),
            )

        selected = min(available, key=rank)
        chosen.append(selected)
        if unique_field is not None:
            used_unique.add(selected[unique_field])
        month_use[selected["month"]] += 1
        complaint_use[selected["complaint"]] += 1
        if extra_balance_field is not None:
            extra_use[selected[extra_balance_field]] += 1

        # A community-board candidate is a unique month/complaint/board tuple.
        # Remove the exact selected row so it cannot be selected twice.
        records.remove(selected)

    assert len(chosen) == n, (
        f"候选不足：需要 {n} 条，只选出 {len(chosen)} 条。"
        "请检查筛选阈值或原始数据。"
    )
    return pd.DataFrame(chosen)


# -----------------------------------------------------------------------------
# Find source and scan it once
# -----------------------------------------------------------------------------
matches = list(ROOT.rglob(SOURCE_NAME))
assert matches, f"找不到原始文件：{SOURCE_NAME}"
source = max(matches, key=lambda p: p.stat().st_mtime)

header = pd.read_csv(source, nrows=0).columns.tolist()
complaint_col = (
    "Problem (formerly Complaint Type)"
    if "Problem (formerly Complaint Type)" in header
    else "Complaint Type"
)
usecols = [
    "Created Date", complaint_col, "Borough", "Community Board", "Street Name"
]
missing = [c for c in usecols if c not in header]
assert not missing, f"原始CSV缺少字段：{missing}"

cb_parts = []
street_parts = []
source_rows = 0
valid_period_borough_rows = 0

print("正在扫描：", source)
for chunk in pd.read_csv(
    source, usecols=usecols, chunksize=CHUNK_SIZE, low_memory=False
):
    source_rows += len(chunk)
    dt = pd.to_datetime(
        chunk["Created Date"], format="%m/%d/%Y %I:%M:%S %p", errors="coerce"
    )
    mask = (dt >= PERIOD_START) & (dt < PERIOD_END)
    chunk = chunk.loc[mask].copy()
    dt = dt.loc[mask]

    chunk["borough"] = clean_text(chunk["Borough"])
    chunk = chunk[chunk["borough"].isin(BOROUGHS)].copy()
    dt = dt.loc[chunk.index]
    valid_period_borough_rows += len(chunk)

    chunk["month"] = dt.dt.to_period("M").astype(str)
    chunk["complaint"] = clean_text(chunk[complaint_col])
    chunk["community_board"] = clean_text(chunk["Community Board"])
    chunk["street"] = clean_text(chunk["Street Name"])
    chunk = chunk[chunk["complaint"] != ""].copy()

    # Parse values such as "01 BRONX" and ensure the suffix agrees with Borough.
    parsed = chunk["community_board"].str.extract(
        r"^(\d{2}) (BRONX|BROOKLYN|MANHATTAN|QUEENS|STATEN ISLAND)$"
    )
    parsed.columns = ["board_number", "board_borough"]
    cb = chunk.join(parsed)
    cb = cb[
        cb["board_number"].notna()
        & (cb["board_borough"] == cb["borough"])
    ].copy()
    if len(cb):
        cb["board_number"] = cb["board_number"].astype(int)
        cb_parts.append(
            cb.groupby(
                ["month", "complaint", "board_number", "borough"]
            ).size().rename("count").reset_index()
        )

    st = chunk[
        (~chunk["street"].isin(BAD_STREET_VALUES))
        & (chunk["street"].str.len() >= 4)
    ]
    if len(st):
        street_parts.append(
            st.groupby(
                ["month", "complaint", "street", "borough"]
            ).size().rename("count").reset_index()
        )

    print(f"已扫描 {source_rows:,} 行")

assert source_rows == 3_449_471, f"原始总行数异常：{source_rows:,}"
assert valid_period_borough_rows == 2_853_404, (
    f"有效期间与Borough行数异常：{valid_period_borough_rows:,}"
)


def collapse(parts, keys):
    assert parts, f"没有生成聚合结果：{keys}"
    return (
        pd.concat(parts, ignore_index=True)
        .groupby(keys, as_index=False)["count"].sum()
    )


cb_counts = collapse(
    cb_parts, ["month", "complaint", "board_number", "borough"]
)
street_counts = collapse(
    street_parts, ["month", "complaint", "street", "borough"]
)


# -----------------------------------------------------------------------------
# Build and select 100 Community Board candidates
# -----------------------------------------------------------------------------
# Each selected board number must yield a positive answer in all five boroughs.
cb_min_answer = 5
cb_positive = cb_counts[cb_counts["count"] >= cb_min_answer].copy()


def make_cb_candidates(frame):
    stats = (
        frame.groupby(["month", "complaint", "board_number"])
        .agg(
            borough_count=("borough", "nunique"),
            min_count=("count", "min"),
            total_count=("count", "sum"),
        )
        .reset_index()
    )
    return stats[stats["borough_count"] == 5].copy()


cb_candidates_all = make_cb_candidates(cb_positive)

# Avoid letting obscure, extremely rare complaint labels dominate the sample.
complaint_totals = (
    cb_counts.groupby("complaint")["count"].sum().sort_values(ascending=False)
)
top_cb_complaints = set(complaint_totals.head(30).index)
cb_candidates = cb_candidates_all[
    cb_candidates_all["complaint"].isin(top_cb_complaints)
].copy()
if len(cb_candidates) < N_COMMUNITY_BOARD:
    cb_candidates = cb_candidates_all.copy()
if len(cb_candidates) < N_COMMUNITY_BOARD:
    cb_min_answer = 1
    cb_positive = cb_counts[cb_counts["count"] >= cb_min_answer].copy()
    cb_candidates = make_cb_candidates(cb_positive)

selected_cb = balanced_select(
    cb_candidates,
    N_COMMUNITY_BOARD,
    unique_field=None,
    extra_balance_field="board_number",
)


# -----------------------------------------------------------------------------
# Build and select 100 Street Name candidates
# -----------------------------------------------------------------------------
# Keep borough interpretations with at least 10 matching requests. Two or more
# boroughs are sufficient for genuine ambiguity; one street is used only once.
def make_street_candidates(min_answer):
    positive = street_counts[street_counts["count"] >= min_answer].copy()
    stats = (
        positive.groupby(["month", "complaint", "street"])
        .agg(
            borough_count=("borough", "nunique"),
            min_count=("count", "min"),
            total_count=("count", "sum"),
        )
        .reset_index()
    )
    natural = (
        stats["street"].str.match(r"^[A-Z][A-Z .&'\-]+$", na=False)
        & ~stats["street"].str.contains(
            r"UNKNOWN|UNNAMED|NO NAME|SERVICE ROAD|ENTRANCE|EXIT RAMP",
            regex=True,
            na=False,
        )
    )
    candidates = stats[(stats["borough_count"] >= 2) & natural].copy()
    # This catches near-duplicate raw spellings such as DEKALB vs. DE KALB.
    candidates["street_key"] = candidates["street"].str.replace(
        r"[^A-Z]", "", regex=True
    )
    return positive, candidates


street_min_answer = 10
street_positive, street_candidates = make_street_candidates(street_min_answer)
if street_candidates["street_key"].nunique() < N_STREET:
    street_min_answer = 5
    street_positive, street_candidates = make_street_candidates(street_min_answer)

selected_street = balanced_select(
    street_candidates,
    N_STREET,
    unique_field="street_key",
)

assert selected_street["street"].nunique() == N_STREET
assert selected_street["street_key"].nunique() == N_STREET


# -----------------------------------------------------------------------------
# Construct benchmark files in the existing SF311-compatible schema
# -----------------------------------------------------------------------------
stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
out_dir = ROOT / "NYC311_2024" / f"Geography_200_V1_{stamp}"
out_dir.mkdir(parents=True, exist_ok=False)

standard = []
model_inputs = []
condition_inputs = []
review_rows = []
selection_rows = []


def add_record(qid, family, month, complaint, entity_value, rows):
    complaint_display = pretty_label(complaint)
    period_display = month_display(month)

    if family == "community_board_borough_omission":
        board = int(entity_value)
        term = f"Community Board {board}"
        query = (
            f"How many {complaint_display} service requests were recorded for "
            f"Community Board {board} in {period_display}?"
        )
        table_label = "Community Board Location"
    else:
        street_display = pretty_label(entity_value)
        term = street_display
        query = (
            f"How many {complaint_display} service requests were recorded on "
            f"{street_display} in {period_display}?"
        )
        table_label = "Street Location"

    table_rows = [
        {table_label: BOROUGH_DISPLAY[b], "Request Count": int(value)}
        for b, value in rows
    ]
    table = markdown_table(table_rows)
    conditions = []
    pairs = []

    for condition_index, (borough, value) in enumerate(rows, 1):
        if family == "community_board_borough_omission":
            condition = (
                f"Interpret '{term}' as {BOROUGH_DISPLAY[borough]} "
                f"Community Board {int(entity_value)}."
            )
        else:
            condition = (
                f"Interpret '{term}' as the street located in "
                f"{BOROUGH_IN_PHRASE[borough]}."
            )
        conditions.append(condition)
        pairs.append({"conditions": {"Geography": condition}, "answer": int(value)})
        condition_inputs.append({
            "id": qid,
            "condition_index": condition_index,
            "query": query,
            "table": table,
            "condition": condition,
        })
        review_rows.append({
            "query_id": qid,
            "family": family,
            "query": query,
            "condition": condition,
            "answer": int(value),
            "query_natural": "",
            "genuine_geography_ambiguity": "",
            "dimension_correct": "",
            "condition_valid": "",
            "answer_correct": "",
            "notes": "",
        })

    record = {
        "id": qid,
        "query": query,
        "table": table,
        "gold": {
            "ambiguous_conditions": [{
                "term": term,
                "dimension": "Geography",
                "conditions": conditions,
            }],
            "condition_answer_pairs": pairs,
        },
        "evaluation_ready": False,
        "metadata": {
            "dataset": "NYC311",
            "dimension": "Geography",
            "family": family,
            "source_period": f"{PERIOD_START} inclusive to {PERIOD_END} exclusive",
            "source_month": month,
            "source_complaint": complaint,
            "source_entity": str(entity_value),
            "constructed_query": True,
            "manual_review_status": "pending",
            "condition_set_exhaustive_within_supplied_table": True,
            "official_geographic_exhaustiveness_verified": False,
        },
    }
    standard.append(record)
    model_inputs.append({"id": qid, "query": query, "table": table})
    selection_rows.append({
        "id": qid,
        "family": family,
        "month": month,
        "complaint": complaint,
        "entity": str(entity_value),
        "condition_count": len(rows),
        "minimum_answer": min(v for _, v in rows),
        "total_answer": sum(v for _, v in rows),
    })


next_id = 1
for row in selected_cb.sort_values(
    ["month", "complaint", "board_number"]
).to_dict("records"):
    key_mask = (
        (cb_positive["month"] == row["month"])
        & (cb_positive["complaint"] == row["complaint"])
        & (cb_positive["board_number"] == row["board_number"])
    )
    values = dict(
        zip(
            cb_positive.loc[key_mask, "borough"],
            cb_positive.loc[key_mask, "count"].astype(int),
        )
    )
    ordered = [(b, values[b]) for b in BOROUGHS]
    add_record(
        f"G{next_id:03d}", "community_board_borough_omission",
        row["month"], row["complaint"], int(row["board_number"]), ordered,
    )
    next_id += 1

for row in selected_street.sort_values(
    ["street", "month", "complaint"]
).to_dict("records"):
    key_mask = (
        (street_positive["month"] == row["month"])
        & (street_positive["complaint"] == row["complaint"])
        & (street_positive["street"] == row["street"])
    )
    values = dict(
        zip(
            street_positive.loc[key_mask, "borough"],
            street_positive.loc[key_mask, "count"].astype(int),
        )
    )
    ordered = [(b, values[b]) for b in BOROUGHS if b in values]
    add_record(
        f"G{next_id:03d}", "street_name_borough_omission",
        row["month"], row["complaint"], row["street"], ordered,
    )
    next_id += 1


# -----------------------------------------------------------------------------
# Strong validation before writing
# -----------------------------------------------------------------------------
assert len(standard) == 200
assert len(model_inputs) == 200
assert len({x["id"] for x in standard}) == 200
assert len({x["query"].strip().lower() for x in standard}) == 200
assert Counter(x["metadata"]["family"] for x in standard) == {
    "community_board_borough_omission": 100,
    "street_name_borough_omission": 100,
}

flat_pairs = []
for record in standard:
    declared = record["gold"]["ambiguous_conditions"][0]["conditions"]
    pairs = record["gold"]["condition_answer_pairs"]
    assert declared == [p["conditions"]["Geography"] for p in pairs]
    assert len(pairs) >= 2
    assert all(isinstance(p["answer"], int) and p["answer"] > 0 for p in pairs)
    if record["metadata"]["family"] == "community_board_borough_omission":
        assert len(pairs) == 5
    flat_pairs.extend(pairs)

assert len(condition_inputs) == len(review_rows) == len(flat_pairs)
for standard_record, model_record in zip(standard, model_inputs):
    assert model_record == {
        "id": standard_record["id"],
        "query": standard_record["query"],
        "table": standard_record["table"],
    }

street_entities = [
    x["metadata"]["source_entity"] for x in standard
    if x["metadata"]["family"] == "street_name_borough_omission"
]
assert len(street_entities) == len(set(street_entities)) == 100


def write_jsonl(path, records):
    with path.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


standard_path = out_dir / "nyc311_geography_200_standard.jsonl"
model_path = out_dir / "nyc311_geography_200_model_inputs.jsonl"
condition_path = out_dir / "nyc311_geography_200_condition_inputs.jsonl"
review_path = out_dir / "nyc311_geography_200_manual_review.csv"
audit_path = out_dir / "nyc311_geography_200_selection_audit.csv"

write_jsonl(standard_path, standard)
write_jsonl(model_path, model_inputs)
write_jsonl(condition_path, condition_inputs)
pd.DataFrame(review_rows).to_csv(review_path, index=False)
pd.DataFrame(selection_rows).to_csv(audit_path, index=False)

summary = {
    "version": "nyc311-geography-200-v1",
    "source": str(source),
    "period": f"{PERIOD_START} inclusive to {PERIOD_END} exclusive",
    "source_rows_scanned": source_rows,
    "valid_period_and_borough_rows": valid_period_borough_rows,
    "query_count": len(standard),
    "condition_answer_pair_count": len(flat_pairs),
    "families": dict(Counter(x["metadata"]["family"] for x in standard)),
    "unique_street_names": len(set(street_entities)),
    "community_board_minimum_answer_threshold": cb_min_answer,
    "street_minimum_answer_threshold": street_min_answer,
    "unique_queries": len({x["query"].lower() for x in standard}),
    "months_covered": sorted({x["metadata"]["source_month"] for x in standard}),
    "complaint_types_covered": len({x["metadata"]["source_complaint"] for x in standard}),
    "validation": {
        "jsonl_schema_consistent": True,
        "standard_model_projection_exact": True,
        "all_answers_positive": True,
        "all_queries_unique": True,
        "all_street_names_unique_within_street_family": True,
        "manual_review_status": "pending",
    },
}
(out_dir / "summary.json").write_text(
    json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
)

readme = """# NYC311 Geography 200 V1

This package contains 200 Geography-ambiguity queries generated from the
validated 2024 NYC311 snapshot.

- 100 Community Board number / borough-omission queries
- 100 street-name / borough-omission queries
- every street-name query uses a different street name
- all answers are positive integers computed from the source CSV
- all records remain `evaluation_ready=false` until human review is completed

Files:

- `nyc311_geography_200_standard.jsonl`: full benchmark records and gold data
- `nyc311_geography_200_model_inputs.jsonl`: ambiguous query + table inputs
- `nyc311_geography_200_condition_inputs.jsonl`: oracle-condition inputs
- `nyc311_geography_200_manual_review.csv`: review worksheet
- `nyc311_geography_200_selection_audit.csv`: selection/diversity audit
- `summary.json`: counts and validation summary
"""
(out_dir / "README.md").write_text(readme, encoding="utf-8")

# Checksums make later handoff verification straightforward.
checksum_lines = []
for path in sorted(out_dir.iterdir()):
    if path.is_file() and path.name != "SHA256SUMS.txt":
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        checksum_lines.append(f"{digest}  {path.name}")
(out_dir / "SHA256SUMS.txt").write_text(
    "\n".join(checksum_lines) + "\n", encoding="utf-8"
)

zip_path = shutil.make_archive(str(out_dir), "zip", root_dir=out_dir)

print("\n========== Geography 200 完成 ==========")
print(json.dumps(summary, indent=2, ensure_ascii=False))
print("输出文件夹：", out_dir)
print("ZIP：", zip_path)

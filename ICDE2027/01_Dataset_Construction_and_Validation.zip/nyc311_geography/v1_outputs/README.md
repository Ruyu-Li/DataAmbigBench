# NYC311 Geography 200 V1

This package contains 200 Geography-ambiguity queries generated from the
validated 2024 NYC311 snapshot.

- 100 Community Board number / borough-omission queries
- 100 street-name / borough-omission queries
- every street-name query uses a different street name
- all answers are positive integers computed from the source CSV
- all records remain `evaluation_ready=false` until human review is completed

Files:

- `nyc311_geography_200_standard.jsonl`: full benchmark records and gold data
- `nyc311_geography_200_model_inputs.jsonl`: ambiguous query + table inputs
- `nyc311_geography_200_condition_inputs.jsonl`: oracle-condition inputs
- `nyc311_geography_200_manual_review.csv`: review worksheet
- `nyc311_geography_200_selection_audit.csv`: selection/diversity audit
- `summary.json`: counts and validation summary

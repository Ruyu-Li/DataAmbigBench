"""Synthetic checks only. Not a replacement for validation on the user's snapshot."""
import json
import tempfile
import unittest
from pathlib import Path
import pyarrow as pa
import pyarrow.parquet as pq
from build_nyc311_geography import build, load_daily, BOROUGHS

class BuildTests(unittest.TestCase):
    def test_pipeline_and_input_isolation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); raw=[]
            for c in range(5):
                for month in range(1,13):
                    for bi,b in enumerate(BOROUGHS):
                        for day in range(1,bi+2):
                            for repeat in range(bi+1):
                                raw.append({'Unique Key':str(len(raw)), 'Created Date':f'{month:02d}/{day:02d}/2024 01:00:00 PM','Borough':b,'Complaint Type':f'TEST TYPE {c}'})
            source=root/'fixture.parquet'
            pq.write_table(pa.Table.from_pylist(raw),source)
            samples=build(source,root/'out',min_total=1)
            self.assertEqual(len(samples),200)
            first=samples[0]
            self.assertEqual([p['answer'] for p in first['gold']['condition_answer_pairs']],[1,4,9,16,25])
            peak=next(s for s in samples if s['metadata']['query_family']=='peak_daily')
            self.assertEqual([p['answer'] for p in peak['gold']['condition_answer_pairs']],[1,2,3,4,5])
            active=next(s for s in samples if s['metadata']['query_family']=='active_days')
            self.assertEqual([p['answer'] for p in active['gold']['condition_answer_pairs']],[1,2,3,4,5])
            weekday=next(s for s in samples if s['metadata']['query_family']=='weekday_total')
            from datetime import date
            month=weekday['metadata']['month']
            expected=[(bi+1)*sum(date(2024,month,d).weekday()<5 for d in range(1,bi+2)) for bi in range(5)]
            self.assertEqual([p['answer'] for p in weekday['gold']['condition_answer_pairs']],expected)
            inputs=[json.loads(s) for s in (root/'out/NYC311_Geography_200_model_inputs.jsonl').read_text().splitlines()]
            self.assertTrue(all(set(s)=={'id','query','table'} for s in inputs))
            import calendar
            self.assertEqual(len(first['table'].splitlines()),4+5*calendar.monthrange(2024,first['metadata']['month'])[1]) # 3 description/header lines + divider + 155 daily rows
            pq.write_table(pa.Table.from_pylist(raw+[raw[0]]),source)
            with self.assertRaisesRegex(ValueError,'Unique Key'): load_daily(source,2024)
    def test_invalid_date_and_zero_padding(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'bad.parquet'
            pq.write_table(pa.Table.from_pylist([{'unique_key':1,'created_date':'invalid','borough':'BRONX','complaint_type':'TEST'}]),p)
            with self.assertRaisesRegex(ValueError,'Created Date'): load_daily(p,2024)

if __name__=='__main__': unittest.main()

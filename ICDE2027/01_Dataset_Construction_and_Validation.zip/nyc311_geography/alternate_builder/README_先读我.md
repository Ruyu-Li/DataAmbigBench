# NYC311 Geography 200：Colab 操作

原始数据预期位置：`/content/drive/MyDrive/NYC311_2024/NYC311_2024_complete.parquet`。
这个代码包不包含原始数据，也没有预先生成真实的200条结果。
现有 Temporal/Granularity 文件无需修改。本程序另建输出文件夹。

## 1. 挂载 Drive，安装依赖
```python
from google.colab import drive
from pathlib import Path

drive.mount('/content/drive')
%pip -q install duckdb pyarrow
source = Path('/content/drive/MyDrive/NYC311_2024/NYC311_2024_complete.parquet')
assert source.is_file(), f'找不到原始文件：{source}。请把这里改成你的实际路径。'
```

## 2. 上传本代码包并解压
```python
from google.colab import files
import zipfile
uploaded = files.upload()  # 选择 NYC311_Geography_200_Code.zip
assert 'NYC311_Geography_200_Code.zip' in uploaded
with zipfile.ZipFile('NYC311_Geography_200_Code.zip') as z:
    z.extractall('/content/nyc311_geography_code')
```

## 3. 生成200条
```python
import subprocess
out = Path('/content/drive/MyDrive/NYC311_2024/Geography_200')
subprocess.run([
    'python', '/content/nyc311_geography_code/build_nyc311_geography.py',
    '--input', str(source), '--output', str(out), '--year', '2024', '--n', '200'
], check=True)
```
遇到字段不匹配、重复 Unique Key、无法解析的日期或样本不足会停止，不会静默凑数。输出目录属于本程序；重跑会覆盖其中同名文件。

## 4. 先看问题、条件、答案，再下载全部结果
```python
from IPython.display import display, Markdown
review = out / '先看这个_问题条件答案.md'
# 首次只显示前10题，避免一次输出200题太长；下载文件包含全部200题。
text = review.read_text(encoding='utf-8')
head, *questions = text.split('\n## NYC311_GEO_')
display(Markdown(head + ''.join('\n## NYC311_GEO_' + q for q in questions[:10])))

import shutil
zip_path = shutil.make_archive('/content/NYC311_Geography_200_Output', 'zip', out)
files.download(zip_path)
```

## 输出文件该看哪一个

- **先看这个_问题条件答案.md**：全部200题，每题直接显示问题、5个borough条件、5个答案；展开可看数据上下文。
- `NYC311_Geography_200_standard.jsonl`：含标准 `query/table/gold/evaluation_ready`，用于评估程序。
- `NYC311_Geography_200_model_inputs.jsonl`：仅 `id/query/table`，用于歧义识别和端到端模型输入。不要把standard整条交给模型；给定条件回答时，由评估器另加当前待测condition。
- `quality_report.json`：数据清洗统计、200条完整性与答案计算检查。

## 设计和边界

全部问题固定 borough 层级、省略地理范围；按来源记录的 Created Date（月内纽约本地日期）统计，五个候选条件为 Bronx、Brooklyn、Manhattan、Queens、Staten Island。

四种问题各50条：整月总数、单日最大请求数、有请求的天数、工作日（明确周一至周五）总数。日期和类别都明确，不改变时间定义。每题上下文独立从源数据聚合整月的每日请求数，覆盖五个borough和全部日期，缺少组合填0；不直接把月度gold答案复制成上下文。

Unique Key 必须非空且唯一；未知borough、缺少类别、2024年外记录按规则排除并报告。默认类别月份五个borough合计至少100条，且每题至少两个条件的答案不同。此筛选是有目的采样，不能称为随机代表性样本。类别转大写并去首尾空格。候选来源为单个parquet快照；文件是否完整、日期截取和数据质量仍由原始来源决定。

这仍然是受控构造的隐含地理范围歧义；普通读者也可能默认理解为全纽约市范围。人工验证必须判断它是否符合你的歧义定义，并可拒绝或改写。自然度没有自动通过；原先10条的自然度判断不能套用到新200条。

`evaluation_ready=true`只表示本程序确认上下文齐全且能计算gold，不代表已跑过模型或现有评估器。`ambiguous_conditions.term`暂用整句占位，因为地理项是隐含省略；如果任务要求词级歧义标注，需要另行标注。

代码已用合成数据检查计数、四种聚合、模型输入隔离以及坏日期/重复键阻断；未在你的真实parquet上执行。需要在Colab跑完，检查quality_report，再做人工小样本验证。

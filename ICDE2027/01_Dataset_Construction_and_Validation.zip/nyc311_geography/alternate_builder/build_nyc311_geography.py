#!/usr/bin/env python3
"""Build controlled, implicit borough-scope ambiguity from NYC311 raw data."""
import argparse
import calendar
import hashlib
import json
import random
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path
import duckdb

BOROUGHS = ['BRONX', 'BROOKLYN', 'MANHATTAN', 'QUEENS', 'STATEN ISLAND']
DISPLAY = {'BRONX': 'the Bronx', 'BROOKLYN': 'Brooklyn', 'MANHATTAN': 'Manhattan', 'QUEENS': 'Queens', 'STATEN ISLAND': 'Staten Island'}
FAMILIES = ['total', 'peak_daily', 'active_days', 'weekday_total']

def qi(s):
    return '"' + s.replace('"', '""') + '"'

def normalize(s):
    return ''.join(c for c in s.lower() if c.isalnum())

def pick(columns, aliases):
    matches = [c for c in columns if normalize(c) in aliases]
    if len(matches) != 1:
        raise ValueError(f'需要唯一字段 {aliases}; 找到 {matches}; 全部字段: {columns}')
    return qi(matches[0])

def load_daily(source, year):
    con = duckdb.connect()
    con.execute("SET TimeZone='America/New_York'")
    con.read_parquet(str(source)).create_view('raw')
    columns = [r[0] for r in con.execute('DESCRIBE raw').fetchall()]
    created = pick(columns, ['createddate'])
    borough = pick(columns, ['borough'])
    complaint = pick(columns, ['complainttype', 'problem'])
    key = pick(columns, ['uniquekey'])
    n, nonnull, distinct = con.execute(f'SELECT count(*),count({key}),count(DISTINCT {key}) FROM raw').fetchone()
    if n != nonnull or n != distinct:
        raise ValueError(f'Unique Key 必须非空且唯一：rows={n}, nonnull={nonnull}, distinct={distinct}。先核查源文件，脚本不会静默去重。')
    # Naive NYC311 dates are interpreted as NYC local calendar dates.
    parsed = f"coalesce(try_cast({created} AS TIMESTAMP), try_strptime(cast({created} AS VARCHAR), ['%m/%d/%Y %I:%M:%S %p','%m/%d/%Y %H:%M:%S','%m/%d/%Y']))"
    con.execute(f'''CREATE TEMP TABLE cleaned AS SELECT cast({parsed} AS DATE) AS day,
        upper(trim(cast({borough} AS VARCHAR))) AS borough,
        upper(trim(cast({complaint} AS VARCHAR))) AS complaint FROM raw''')
    invalid = con.execute('SELECT count(*) FROM cleaned WHERE day IS NULL').fetchone()[0]
    if invalid:
        raise ValueError(f'{invalid} 条 Created Date 无法解析，停止生成以免漏计。')
    start, end = date(year, 1, 1), date(year + 1, 1, 1)
    stats = {'source_rows': n, 'invalid_dates': invalid,
        'outside_year_rows': con.execute('SELECT count(*) FROM cleaned WHERE day < ? OR day >= ?', [start,end]).fetchone()[0],
        'excluded_borough_rows': con.execute('SELECT count(*) FROM cleaned WHERE day >= ? AND day < ? AND (borough IS NULL OR borough NOT IN (?,?,?,?,?))', [start,end,*BOROUGHS]).fetchone()[0],
        'missing_complaint_rows': con.execute("SELECT count(*) FROM cleaned WHERE day >= ? AND day < ? AND borough IN (?,?,?,?,?) AND (complaint IS NULL OR complaint = '')", [start,end,*BOROUGHS]).fetchone()[0]}
    records = con.execute("SELECT day,borough,complaint,count(*) FROM cleaned WHERE day >= ? AND day < ? AND borough IN (?,?,?,?,?) AND complaint IS NOT NULL AND complaint <> '' GROUP BY 1,2,3 ORDER BY 3,1,2", [start,end,*BOROUGHS]).fetchall()
    con.close()
    groups = defaultdict(dict)
    for day, b, c, count in records:
        groups[(c,day.month)][(day.day,b)] = int(count)
    return groups, stats

def answer(family, values, year, month):
    if family == 'total': return sum(values)
    if family == 'peak_daily': return max(values)
    if family == 'active_days': return sum(v > 0 for v in values)
    return sum(v for d,v in enumerate(values,1) if date(year,month,d).weekday() < 5)

def question(family, complaint, year, month):
    when = f'{calendar.month_name[month]} {year}'
    if family == 'total': return f'How many {complaint} service requests were created in {when}?'
    if family == 'peak_daily': return f'What was the highest daily number of {complaint} service requests created in {when}?'
    if family == 'active_days': return f'On how many days in {when} was at least one {complaint} service request created?'
    return f'How many {complaint} service requests were created on weekdays (Monday through Friday) in {when}?'

def build(source, out, year=2024, target=200, min_total=100):
    if target <= 0 or target % 4:
        raise ValueError('--n 必须是正数且可被4整除。')
    groups, stats = load_daily(source, year)
    quota = target // 4
    counts = Counter()
    samples = []
    # Spread selected samples across complaint types, rather than exhausting one type first.
    candidate_order = sorted(groups)
    random.Random(42).shuffle(candidate_order)
    for family in FAMILIES:
        for complaint, month in candidate_order:
            daily = groups.get((complaint,month), {})
            days = calendar.monthrange(year,month)[1]
            values = {b:[daily.get((d,b),0) for d in range(1,days+1)] for b in BOROUGHS}
            if sum(map(sum,values.values())) < min_total: continue
            answers = {b:answer(family,v,year,month) for b,v in values.items()}
            if len(set(answers.values())) < 2: continue
            rows = [(date(year,month,d).isoformat(), b, values[b][d-1]) for d in range(1,days+1) for b in BOROUGHS]
            table = f'NYC311 snapshot: {source.name}. Category: {complaint}. Month: {year}-{month:02d}.\n' + \
                'Counts are service requests by Created Date (New York local date) and borough. Every calendar day and all five boroughs are included; zero means no matching requests.\n' + \
                '| created_date | borough | request_count |\n|---|---|---:|\n' + '\n'.join(f'| {d} | {b} | {v} |' for d,b,v in rows)
            query = question(family,complaint,year,month)
            pairs = [{'conditions':{'Geography':DISPLAY[b]},'answer':answers[b]} for b in BOROUGHS]
            # Independently re-evaluate each answer from the serialized table rows.
            for b in BOROUGHS:
                series = [v for d,bb,v in rows if bb == b]
                assert answers[b] == answer(family,series,year,month)
            samples.append({'id':f'NYC311_GEO_{len(samples)+1:03d}', 'query':query, 'table':table,
                'gold':{'ambiguous_conditions':[{'term':query,'dimension':'Geography','conditions':[DISPLAY[b] for b in BOROUGHS]}], 'condition_answer_pairs':pairs},
                'evaluation_ready':True,
                'metadata':{'dataset':'NYC311', 'year':year,'month':month,'complaint_type':complaint,
                    'query_family':family,'ambiguity_design':'controlled omission of borough scope; human naturalness review pending',
                    'term_annotation':'whole-query placeholder for implicit geographic scope',
                    'conditioned_queries':{DISPLAY[b]:f'In {DISPLAY[b]}, {query[0].lower() + query[1:]}' for b in BOROUGHS},
                    'geographic_level':'borough','context_kind':'daily counts aggregated from raw requests',
                    'context_sha256':hashlib.sha256(table.encode()).hexdigest(),
                    'readiness_scope':'context completeness and answer recomputation only; model/evaluator integration not tested'}})
            counts[family] += 1
            if counts[family] == quota: break
        if counts[family] != quota:
            raise ValueError(f'{family} 只有 {counts[family]} 条符合条件，需要 {quota} 条。可降低 --min-total 或 --n；不会用重复问题凑数。')
    assert len(samples) == target and len({s['query'] for s in samples}) == target
    out = Path(out)
    out.mkdir(parents=True,exist_ok=True)
    for name, records in [('NYC311_Geography_200_standard.jsonl', samples),
                          ('NYC311_Geography_200_model_inputs.jsonl',[{k:s[k] for k in ('id','query','table')} for s in samples])]:
        (out/name).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records),encoding='utf-8')
    review = ['# NYC311 Geography 人工检查\n',
        '这是固定 borough 层级、省略 borough 范围的受控样本。请检查问题自然度、补入 borough 后的自然度及条件是否合理。下面中文为阅读提示，英文是实验输入。\n',
        '答案按当前 parquet 快照计算，不代表纽约市实时统计。每条的上下文都包含整月每日、五个 borough 的请求数。\n']
    for s in samples:
        m=s['metadata']; family=m['query_family']
        hint={'total':'整月请求总数','peak_daily':'单日请求数的最大值','active_days':'至少有一条请求的日期数量','weekday_total':'周一到周五的请求总数'}[family]
        review += [f"## {s['id']}\n",f"**问题：** {s['query']}\n",f"**计算内容：** {m['year']}年{m['month']}月，{m['complaint_type']}，{hint}。省略项：borough。\n", '| Geography 条件 | 补齐条件的问题 | 答案 |\n|---|---|---:|']
        review += [f"| {p['conditions']['Geography']} | {m['conditioned_queries'][p['conditions']['Geography']]} | {p['answer']} |" for p in s['gold']['condition_answer_pairs']]
        review += ['\n<details><summary>展开本题的数据上下文</summary>\n',s['table'],'\n</details>\n']
    (out/'先看这个_问题条件答案.md').write_text('\n'.join(review),encoding='utf-8')
    report={'sample_count':len(samples),'condition_answer_count':len(samples)*5,'family_counts':dict(counts),
        'duplicate_questions':0,'empty_tables':0,'context_answer_checks':'passed','naturalness_review':'pending',
        'actual_model_experiment':'not_run','selection':'min month total plus at least two distinct borough answers; purposive, not random',
        'source_file':str(source),'source_size_bytes':Path(source).stat().st_size,'year':year,'min_total':min_total,**stats}
    (out/'quality_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return samples

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--year',type=int,default=2024)
    p.add_argument('--n',type=int,default=200)
    p.add_argument('--min-total',type=int,default=100)
    a=p.parse_args()
    build(a.input,a.output,a.year,a.n,a.min_total)

#!/usr/bin/env python3
"""Review TAT-QA gold against saved predictions without overwriting original runs.

audit: make a pair-level decision sheet from the existing 496-row audit.
build: apply reviewed answer corrections; reject unresolved or invalid conditions.
rescore: use the existing lab.py scorers and cached outputs (no API calls).
"""
import argparse
import copy
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def jsonl(path):
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_jsonl(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for item in data:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")


def write_csv(path, data, columns):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        w.writeheader()
        w.writerows(data)


def audit(args):
    data = jsonl(args.data)
    assert len(data) == 200 and len({x["id"] for x in data}) == 200
    by_id = {x["id"]: x for x in data}
    cg = rows(args.cg)
    det = rows(args.detection)
    assert len(cg) == 496 and len(det) == 200
    assert all(x["id"] in by_id for x in cg + det)
    seen = set()
    decisions = []
    suggestions = {
        ("tatqa_000188", 1): ("28,754 thousand", "Total row, not Other row"),
        ("tatqa_000163", 0): ("Products", "Query asks for main source, not amount"),
        ("tatqa_000163", 1): ("Products", "Query asks for main source, not amount"),
        ("tatqa_000128", 0): ("62 million", "2017 Total consideration row"),
        ("tatqa_000128", 2): ("1,957 million", "2019 Total consideration row"),
        ("tatqa_000200", 0): ("660,460", "2018 Number column, not euro amount"),
        ("tatqa_000200", 1): ("454,870", "2019 Number column, not euro amount"),
        ("tatqa_000330", 0): ("0.92", "2 Jul 2013 grant, Exercise Price column"),
        ("tatqa_000330", 1): ("1.30", "2 Jul 2014 grant, Exercise Price column"),
        ("tatqa_000330", 2): ("2.67", "2 Jul 2015 grant, Exercise Price column"),
        ("tatqa_000353", 0): ("28,814,803,308", "31 March 2018 closing number of allotted shares"),
        ("tatqa_000353", 1): ("28,815,258,178", "31 March 2019 closing number of allotted shares"),
        ("tatqa_000494", 0): ("0 percent", "2018 SEC/DOJ settlement cost is a dash; 2019 has -10.7"),
        ("tatqa_000367", 0): ("$558.3 million", "2018 Fair Value column; old answer is Carrying Value"),
        ("tatqa_000367", 1): ("$560.6 million", "2019 Fair Value column; old answer is Carrying Value"),
        ("tatqa_000467", 1): ("0.62", "2019 (186+448)/1030 ~ 0.6155; verify rounding policy"),
    }
    invalid = {("tatqa_000330", i) for i in range(3, 9)} | {
        ("tatqa_000217", 0), ("tatqa_000217", 1),
        ("tatqa_000353", 2), ("tatqa_000200", 2),
        ("tatqa_000169", 0), ("tatqa_000169", 1),
        ("tatqa_000594", 2), ("tatqa_000594", 3), ("tatqa_000594", 4)
    }
    for x in cg:
        key = (x["id"], int(x["pair_index"]))
        assert key not in seen, f"duplicate audit row: {key}"
        seen.add(key)
        pair = by_id[key[0]]["gold"]["condition_answer_pairs"][key[1]]
        assert x["gold_answer"] == str(pair["answer"]), key
        assert json.loads(x["condition"]) == pair["conditions"], key
        if x["paper_score"] not in ("0", "0.0", "1", "1.0"):
            raise ValueError(f"Unknown paper_score at {key}")
        if float(x["paper_score"]) == 1 and key not in invalid:
            continue
        suggestion, reason = suggestions.get(key, ("", ""))
        if key in invalid:
            reason = "condition/year may not support this query; replace the entire sample if confirmed"
        decisions.append({
            "id": key[0], "pair_index": key[1], "condition": x["condition"],
            "query": x["query"], "old_answer": x["gold_answer"],
            "predicted_answer": x["predicted_answer"], "paper_score": x["paper_score"],
            "decision": "", "new_answer": "", "suggested_answer": suggestion,
            "reason_to_check": reason or x["flags"], "review_note": "",
        })
    assert len(seen) == 496, len(seen)
    write_csv(args.out / "gold_pair_decisions.csv", decisions, list(decisions[0]))
    detection = []
    for x in det:
        if "years_mentioned_but_temporal_label_missing" in x["flags"]:
            detection.append({k: x[k] for k in ("id", "query", "gold_years", "predicted_years", "predicted_dimensions", "dimension_f1")})
    if detection:
        write_csv(args.out / "temporal_label_review.csv", detection, list(detection[0]))
    print("Gold pairs to decide:", len(decisions))
    print("Temporal label candidates:", len(detection))
    print("Decision sheet:", args.out / "gold_pair_decisions.csv")
    print("Use keep / change / equivalent / invalid_condition in the decision column.")
    print("Suggested answers are hypotheses; verify table and paragraphs before approving.")


def build(args):
    original = jsonl(args.data)
    assert len(original) == 200 and len({r["id"] for r in original}) == 200
    data = copy.deepcopy(original)
    lookup = {r["id"]: r for r in data}
    changes = []
    unresolved = []
    known_invalid = {("tatqa_000330", i) for i in range(3, 9)} | {
        ("tatqa_000217", 0), ("tatqa_000217", 1),
        ("tatqa_000353", 2), ("tatqa_000200", 2),
        ("tatqa_000169", 0), ("tatqa_000169", 1),
        ("tatqa_000594", 2), ("tatqa_000594", 3), ("tatqa_000594", 4)
    }
    for d in rows(args.decisions):
        key = (d["id"], int(d["pair_index"]))
        if key[0] not in lookup:
            raise ValueError(f"Unknown ID: {key}")
        pair = lookup[key[0]]["gold"]["condition_answer_pairs"][key[1]]
        assert str(pair["answer"]) == d["old_answer"], f"Answer changed since audit: {key}"
        assert pair["conditions"] == json.loads(d["condition"]), f"Conditions changed since audit: {key}"
        decision = d["decision"].strip().lower()
        if key in known_invalid:
            unresolved.append((key, "unsupported condition; rebuild sample"))
            continue
        if decision == "change":
            answer = d["new_answer"].strip()
            if not answer or answer == d["old_answer"]:
                raise ValueError(f"Change needs a different new_answer: {key}")
            pair["answer"] = answer
            # Old aliases cannot silently contradict the corrected answer.
            pair.pop("acceptable_answers", None)
            changes.append({"id": key[0], "pair_index": key[1], "old": d["old_answer"], "new": answer,
                            "review_note": d["review_note"]})
        elif decision == "equivalent":
            answer = d["new_answer"].strip()
            if not answer:
                raise ValueError(f"Equivalent needs a verified alias: {key}")
            aliases = pair.setdefault("acceptable_answers", [])
            if answer not in aliases and answer != pair["answer"]:
                aliases.append(answer)
            changes.append({"id": key[0], "pair_index": key[1], "alias": answer,
                            "review_note": d["review_note"]})
        elif decision == "keep":
            if not d["review_note"].strip():
                raise ValueError(f"Keep needs a reason in review_note: {key}")
        elif decision in ("", "invalid_condition"):
            unresolved.append((key, decision or "undecided"))
        else:
            raise ValueError(f"Unknown decision: {key} {decision}")
    if unresolved:
        print("UNRESOLVED", len(unresolved), "first 15:", unresolved[:15])
        raise SystemExit("No final data written. Repair/replace invalid query-level samples, then rerun the audit.")
    assert len(data) == len(original) == 200
    assert all(a["id"] == b["id"] and a["query"] == b["query"] and
               a["table"] == b["table"] and
               [p["conditions"] for p in a["gold"]["condition_answer_pairs"]] ==
               [p["conditions"] for p in b["gold"]["condition_answer_pairs"]]
               for a, b in zip(original, data)), "Input/query/condition changed; cannot reuse cached predictions"
    write_jsonl(args.out / "tatqa.jsonl", data)
    (args.out / "changes.json").write_text(json.dumps(changes, indent=2, ensure_ascii=False), encoding="utf-8")
    print("Saved reviewed 200-query data:", args.out / "tatqa.jsonl")


def rescore(args):
    sys.path.insert(0, str(args.project))
    import lab  # noqa: E402
    original = jsonl(args.original_data)
    corrected = jsonl(args.data)
    old = {x["id"]: x for x in original}
    new = {x["id"]: x for x in corrected}
    assert set(old) == set(new) and len(new) == 200
    for sid in old:
        a, b = old[sid], new[sid]
        assert a["query"] == b["query"] and a["table"] == b["table"]
        assert [p["conditions"] for p in a["gold"]["condition_answer_pairs"]] == [
            p["conditions"] for p in b["gold"]["condition_answer_pairs"]]
        assert a["gold"]["ambiguous_conditions"] == b["gold"]["ambiguous_conditions"]
    predictions = jsonl(args.predictions)
    assert len(predictions) == 1096, f"Expected 1096, found {len(predictions)}"
    scored = []
    groups = defaultdict(list)
    for rec in predictions:
        assert rec["dataset"] == "tatqa" and rec["id"] in new
        pair_index, task = rec.get("pair_index"), rec["task"]
        gold = new[rec["id"]]["gold"]
        if task == "detection":
            gold = gold["ambiguous_conditions"]
        elif task == "condition_given":
            gold = gold["condition_answer_pairs"][int(pair_index)]
        assert rec["query"] == new[rec["id"]]["query"]
        output = {**rec, "gold": gold}
        output["scores"] = lab.score_record(output)
        scored.append(output)
        groups[task].append(output)
    out = args.out
    write_jsonl(out / "rescored_predictions.jsonl", scored)
    summary = {}
    for task, rr in sorted(groups.items()):
        metric = {"detection": "dimension_f1", "condition_given": "answer_relaxed",
                  "e2e": "answer_relaxed_norm", "e2e_open": "gold_answer_recall"}[task]
        vals = [float(x["scores"][metric]) for x in rr]
        summary[task] = {"n": len(rr), metric + "_pct": round(100 * sum(vals) / len(vals), 4)}
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("No model calls. Rescored", len(scored), "saved predictions:", summary)
    print("Output:", out)


def finalize_v3(args):
    """Curated repair: remove unsupported pairs, clarify two queries, preserve raw outputs."""
    data = copy.deepcopy(jsonl(args.data))
    assert len(data) == 200 and len({r["id"] for r in data}) == 200
    by_id = {r["id"]: r for r in data}
    decisions = rows(args.decisions)
    assert len(decisions) == 64, f"Expected reviewed v2 with 64 rows, got {len(decisions)}"
    seen, changes, removed = set(), [], defaultdict(list)
    rewrite_ids = {"tatqa_000169", "tatqa_000524"}
    drop_ids = {
        ("tatqa_000330", i) for i in range(3, 9)
    } | {("tatqa_000353", 2), ("tatqa_000217", 0),
         ("tatqa_000217", 1), ("tatqa_000200", 2),
         ("tatqa_000594", 2), ("tatqa_000594", 3), ("tatqa_000594", 4)}
    assert len(drop_ids) == 13
    for d in decisions:
        sid, i = d["id"], int(d["pair_index"])
        assert sid in by_id and (sid, i) not in seen, (sid, i)
        seen.add((sid, i))
        pairs = by_id[sid]["gold"]["condition_answer_pairs"]
        pair = pairs[i]
        assert str(pair["answer"]) == d["old_answer"] and pair["conditions"] == json.loads(d["condition"]), (sid, i)
        decision = d["decision"].strip().lower()
        if (sid, i) in drop_ids:
            assert decision == "invalid_condition", (sid, i, decision)
            removed[sid].append(i)
        elif sid == "tatqa_000169":
            assert decision == "invalid_condition", (sid, i, decision)
        elif sid == "tatqa_000524":
            assert decision == "", (sid, i, decision)
        elif decision == "change":
            new_answer = d["new_answer"].strip()
            assert new_answer and new_answer != str(pair["answer"]), (sid, i)
            changes.append({"id": sid, "pair_index": i, "old": pair["answer"], "new": new_answer,
                            "reason": d["review_note"]})
            pair["answer"] = new_answer
            pair.pop("acceptable_answers", None)
        elif decision == "equivalent":
            # Do not add model-specific observed predictions to the gold aliases.
            changes.append({"id": sid, "pair_index": i, "equivalence_to_verify": d["new_answer"],
                            "reason": d["review_note"]})
        elif decision == "keep":
            assert d["review_note"].strip(), (sid, i)
        else:
            raise ValueError(f"Unresolved row: {(sid, i, decision)}")
    for sid, indexes in removed.items():
        gold = by_id[sid]["gold"]
        gold["condition_answer_pairs"] = [p for i, p in enumerate(gold["condition_answer_pairs"])
                                          if i not in set(indexes)]
        assert len(gold["condition_answer_pairs"]) >= 2, sid
        remaining = [p["conditions"]["Temporal"] for p in gold["condition_answer_pairs"]]
        assert len(gold["ambiguous_conditions"]) == 1
        gold["ambiguous_conditions"][0]["conditions"] = remaining
    r = by_id["tatqa_000169"]
    r["query"] = "What was Gavin Darby's basic annual salary?"
    g = r["gold"]
    assert [p["conditions"]["Temporal"] for p in g["condition_answer_pairs"]] == ["2017", "2018"]
    for p, cond in zip(g["condition_answer_pairs"], ["2017/18", "2018/19"]):
        p["conditions"]["Temporal"] = cond
    g["ambiguous_conditions"][0]["conditions"] = ["2017/18", "2018/19"]
    g["ambiguous_conditions"][0]["term"] = "Gavin Darby's basic annual salary"
    r.setdefault("metadata", {})["repair_note"] = "Clarified fiscal-year interpretation; rerun all tasks"
    r = by_id["tatqa_000524"]
    r["query"] = "What was revenue divided by year-end total assets?"
    r["gold"]["ambiguous_conditions"][0]["term"] = "revenue divided by year-end total assets"
    r.setdefault("metadata", {})["repair_note"] = "Clarified original TAT-QA derivation; rerun all tasks"
    assert all(len(x["gold"]["condition_answer_pairs"]) >= 2 for x in data)
    assert all(len(x["gold"]["ambiguous_conditions"][0]["conditions"]) ==
               len(x["gold"]["condition_answer_pairs"]) for x in data)
    assert sum(len(x["gold"]["condition_answer_pairs"]) for x in data) == 483
    args.out.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.out / "data" / "tatqa.jsonl", data)
    write_jsonl(args.out / "rerun_only" / "tatqa.jsonl", [x for x in data if x["id"] in rewrite_ids])
    manifest = {"queries": len(data), "pairs": 483, "total_task_requests": 1083,
                "rerun_all_tasks_for_ids": sorted(rewrite_ids),
                "rerun_request_count": 10, "removed_pairs": {k: sorted(v) for k, v in removed.items()},
                "gold_changes": changes, "caution": "Equivalent decisions require a general scoring rule; aliases not copied"}
    (args.out / "repair_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Candidate:", args.out / "data" / "tatqa.jsonl")
    print("New model calls only for:", sorted(rewrite_ids), "(10 requests, one model)")
    print("200 queries, 483 pairs, 1083 total task requests per model")


def rescore_compatible(args):
    """Reuse saved responses only where the exact model prompt is unchanged."""
    sys.path.insert(0, str(args.project))
    import lab  # noqa: E402
    original = {r["id"]: r for r in jsonl(args.original_data)}
    new = {r["id"]: r for r in jsonl(args.data)}
    assert len(original) == len(new) == 200 and set(original) == set(new)
    rerun = {sid for sid in original if original[sid]["query"] != new[sid]["query"]}
    assert rerun == {"tatqa_000169", "tatqa_000524"}, rerun
    saved = jsonl(args.predictions)
    assert len(saved) == 1096
    reused = []
    for row in saved:
        sid, task = row["id"], row["task"]
        assert row["dataset"] == "tatqa" and sid in new
        assert row["query"] == original[sid]["query"]
        assert original[sid]["table"] == new[sid]["table"]
        if sid in rerun:
            continue
        updated = dict(row)
        ngold = new[sid]["gold"]
        if task == "condition_given":
            old_pair = original[sid]["gold"]["condition_answer_pairs"][int(row["pair_index"])]
            matches = [(i, p) for i, p in enumerate(ngold["condition_answer_pairs"])
                       if p["conditions"] == old_pair["conditions"]]
            if not matches:
                continue
            assert len(matches) == 1, (sid, row["pair_index"])
            updated["original_pair_index"] = row["pair_index"]
            updated["pair_index"], updated["gold"] = matches[0]
        elif task == "detection":
            updated["gold"] = ngold["ambiguous_conditions"]
        else:
            updated["gold"] = ngold
        updated["scores"] = lab.score_record(updated)
        updated["response_source"] = "cached_original_prompt"
        reused.append(updated)
    assert len(reused) == 1073, len(reused)
    write_jsonl(args.out / "reused_rescored.jsonl", reused)
    print("Reused and rescored 1073 requests without model calls")
    print("Run 10 requests for IDs 000169 and 000524 using rerun_only/tatqa.jsonl")


def merge_v3(args):
    """Combine compatible cached responses and the 10 newly run requests."""
    sys.path.insert(0, str(args.project))
    import lab  # noqa: E402
    data = {r["id"]: r for r in jsonl(args.data)}
    old = jsonl(args.reused)
    new = jsonl(args.rerun_predictions)
    rerun = {"tatqa_000169", "tatqa_000524"}
    assert len(data) == 200 and len(old) == 1073 and len(new) == 10
    assert {r["id"] for r in new} == rerun
    assert all(r["id"] not in rerun for r in old)
    combined = old + new
    keys = set()
    for r in combined:
        sid, task = r["id"], r["task"]
        assert r["dataset"] == "tatqa" and r["query"] == data[sid]["query"]
        key = (sid, task, r.get("pair_index"), r["model"])
        assert key not in keys, f"Duplicate result: {key}"
        keys.add(key)
        gold = data[sid]["gold"]
        if task == "detection": gold = gold["ambiguous_conditions"]
        elif task == "condition_given": gold = gold["condition_answer_pairs"][int(r["pair_index"])]
        r["gold"] = gold
        r["scores"] = lab.score_record(r)
    assert len(combined) == 1083 and len({r["model"] for r in combined}) == 1
    assert {task: sum(r["task"] == task for r in combined) for task in
            ("detection", "condition_given", "e2e", "e2e_open")} == {
                "detection": 200, "condition_given": 483, "e2e": 200, "e2e_open": 200}
    write_jsonl(args.out / "predictions_merged_v3.jsonl", combined)
    print("Merged 1083 requests: 1073 cached + 10 new")
    print("New failed:", sum(r.get("status") != "ok" for r in new))
    print("Merged results:", args.out / "predictions_merged_v3.jsonl")


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("audit")
    for flag in ("data", "cg", "detection", "out"):
        a.add_argument("--" + flag, required=True, type=Path)
    a.set_defaults(func=audit)
    b = sub.add_parser("build")
    for flag in ("data", "decisions", "out"):
        b.add_argument("--" + flag, required=True, type=Path)
    b.set_defaults(func=build)
    c = sub.add_parser("rescore")
    for flag in ("project", "original-data", "data", "predictions", "out"):
        c.add_argument("--" + flag, required=True, type=Path)
    c.set_defaults(func=rescore)
    v3 = sub.add_parser("finalize-v3")
    for flag in ("data", "decisions", "out"):
        v3.add_argument("--" + flag, required=True, type=Path)
    v3.set_defaults(func=finalize_v3)
    reuse = sub.add_parser("rescore-compatible")
    for flag in ("project", "original-data", "data", "predictions", "out"):
        reuse.add_argument("--" + flag, required=True, type=Path)
    reuse.set_defaults(func=rescore_compatible)
    merge = sub.add_parser("merge-v3")
    for flag in ("project", "data", "reused", "rerun-predictions", "out"):
        merge.add_argument("--" + flag, required=True, type=Path)
    merge.set_defaults(func=merge_v3)
    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

# OpinionQA 维度边界提案（待与论文现有分类核对）

## 论文与 prompt 共用的英文定义

Perspective: A question about opinions, preferences, or judgments leaves the
respondent group unspecified. Different displayed respondent groups yield
different leading answers to the same survey item. The response options,
historical survey wave, and survey-weighted within-group aggregation rule are
held fixed. This benchmark uses Perspective specifically for the source of
survey opinions, not for the identity of the entity discussed in the question.

Granularity: The question leaves the level or unit of aggregation unspecified,
such as item versus order or city versus state. Under this proposed taxonomy,
the source group of survey opinions is assigned to Perspective. If the paper's
existing Granularity definition already includes these population scopes, the
taxonomy and affected annotations must be reconciled before evaluation.

Definition–Metric: The question leaves the definition or calculation of the
requested measure unspecified, such as strongly favor alone versus strongly
favor plus somewhat favor. Fixed survey weighting does not itself create a
Definition–Metric ambiguity.

## 对照例子

| 例子 | 维度提案 | 改变的内容 |
|---|---|---|
| 同一政策调查，不同年龄群体的最高占比选项不同 | Perspective | 意见来源群体 |
| 按订单还是按商品统计平均金额 | Granularity | 汇总单位/层级 |
| 支持率包含 strongly favor 还是也包含 somewhat favor | Definition–Metric | 选项合并与指标定义 |

## 限制与人工判定

这是一套建议的操作性分类，不是意见调查天然具有的唯一分类。
这些 query 是围绕真实调查构造的聚合问题，不是原始自然歧义问题。
即使是态度题，读者也可能默认 respondents 指总体受访者。当前表格只
给出候选子群体，缺少总体分布；仍需人工判断这是合理的群体歧义，还是
仅仅缺少回答总体问题所需的数据。总体不能通过对子群体比例简单平均补出。

人工审核时分别记录：自然性、群体歧义是否成立、condition 是否合理、
问卷路由/片段是否完整、维度是否接受。不要用模型分类准确率决定 gold。
修改定义或模板后的实验要单独报告，不能把旧预测当作新版本结果。

## 模板变体的意义

本版四个模板保持同一任务：选择加权占比最高的原始选项。
它们只增加措辞变化，不增加任务或推理多样性；不能声称已彻底解决
模板多样性问题。未改成“多数支持”，也未合并回答选项。

#!/usr/bin/env python3
"""Build OpinionQA candidates in the supplied standardize_benchmark schema.

Python 3.9+, pandas, numpy. Offline: no API calls, no invented survey answers.
Run: python build_opinionqa_200_v3.py --model-input model_input.tar.gz \
     --human-resp human_resp.tar.gz --outdir opinionqa_200 --n 200
This creates candidates, not 200 human-validated ambiguity examples.
"""
import argparse
import ast
import collections
import hashlib
import io
import itertools
import json
import random
import re
import sys
import tarfile
from pathlib import Path

import numpy as np
import pandas as pd

AXES = ['AGE', 'EDUCATION', 'INCOME', 'SEX', 'POLPARTY']
PILOT_KEYS = [('INCFUTURE_W32','AGE'), ('GOVRESP_b_W54','AGE'),
              ('TRAITSA_W29','EDUCATION'), ('IMMIMPACT_W32','EDUCATION'),
              ('FIN_SIT_W54','INCOME'), ('ROBJOB7_W27','INCOME'),
              ('SCI5_W34','SEX'), ('TRAITSC_W29','SEX'),
              ('POL1JB_W92','POLPARTY'), ('GOVSIZE1_W92','POLPARTY')]
OPINION_PATTERN = re.compile(
    r'think|should|prefer|favor|oppose|approve|agree|important|effect|better|worse|'
    r'satisfied|confiden|feel|concern|trust|would you rather|describe you', re.I)


def archive_csvs(path):
    # Read CSV members only; never extract archive paths or unpickle .npy files.
    with tarfile.open(path, 'r:*') as tar:
        return {m.name.lstrip('./'): tar.extractfile(m).read()
                for m in tar if m.isfile() and m.name.endswith('.csv')}


def csv(data, path, **kwargs):
    return pd.read_csv(io.BytesIO(data[path]), **kwargs)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def cell(value):
    return str(value).replace('|', '\\|').replace('\n', ' ').replace('\r', ' ')


def collect(args):
    models, humans = archive_csvs(args.model_input), archive_csvs(args.human_resp)
    waves = sorted(int(re.fullmatch(r'model_input/Pew_American_Trends_Panel_W(\d+)\.csv', p).group(1))
                   for p in models if re.fullmatch(r'model_input/Pew_American_Trends_Panel_W(\d+)\.csv', p))
    if not waves:
        raise ValueError('model_input archive has no expected wave CSVs.')
    candidates, audit = [], []
    for wave in waves:
        prefix = f'human_resp/American_Trends_Panel_W{wave}/'
        for name in ['responses.csv', 'info.csv', 'metadata.csv']:
            if prefix + name not in humans:
                raise ValueError(f'Missing archive member: {prefix + name}')
        qs = csv(models, f'model_input/Pew_American_Trends_Panel_W{wave}.csv', sep='\t')
        info = csv(humans, prefix+'info.csv').set_index('key')
        meta = csv(humans, prefix+'metadata.csv').set_index('key')
        data = csv(humans, prefix+'responses.csv', low_memory=False)
        weight_key = f'WEIGHT_W{wave}'
        weights = pd.to_numeric(data[weight_key], errors='coerce')
        valid_weights = weights.notna() & np.isfinite(weights) & weights.gt(0)
        counts = collections.Counter(questions=len(qs), respondents=len(data))
        for _, q in qs.iterrows():
            key = q['key']
            if key not in info.index or key not in data.columns:
                counts['missing_key'] += 1
                continue
            details = info.loc[key]
            if not isinstance(details, pd.Series):
                counts['shared_key_excluded'] += 1
                continue
            if q['question'] != details['question']:
                raise ValueError(f'Question text mismatch: {key}')
            references = ast.literal_eval(details['references'])
            ordinal = ast.literal_eval(details['option_ordinal'])
            options = references[:len(ordinal)]
            if len(options) < 2 or len(set(options)) != len(options):
                counts['invalid_options'] += 1
                continue
            if not set(options).issubset(ast.literal_eval(q['options'])):
                raise ValueError(f'Option mismatch: {key}')
            counts['matched'] += 1
            question = q['question'].strip()
            opinion_like = bool(OPINION_PATTERN.search(question)) and 'have you ever' not in question.lower()
            if args.opinion_only and not opinion_like:
                continue
            valid = valid_weights & data[key].isin(options)
            for axis in AXES:
                if axis not in meta.index or axis not in data:
                    continue
                groups = []
                for group in ast.literal_eval(meta.loc[axis, 'options']):
                    mask = valid & data[axis].eq(group)
                    n = int(mask.sum())
                    if n < args.min_n:
                        continue
                    w = weights[mask]
                    effective_n = float(w.sum()**2 / (w**2).sum())
                    if effective_n < args.min_ess:
                        continue
                    sums = pd.DataFrame({'response': data.loc[mask, key], 'weight': w}).groupby('response')['weight'].sum()
                    shares = (sums.reindex(options, fill_value=0) / w.sum()).to_numpy()
                    order = np.argsort(-shares)
                    margin = float(shares[order[0]] - shares[order[1]])
                    if margin < args.min_margin:
                        continue
                    groups.append({'group': group, 'n_valid': n, 'effective_n': effective_n,
                                   'weight_sum': float(w.sum()), 'shares': list(map(float, shares)),
                                   'answer': options[int(order[0])], 'winner_margin': margin})
                if len({g['answer'] for g in groups}) < 2:
                    continue
                # Keep ALL qualifying groups, including those with the same winner.
                scores = [min(a['winner_margin'], b['winner_margin'])
                          for a,b in itertools.combinations(groups, 2) if a['answer'] != b['answer']]
                candidates.append({'source_key': key, 'wave': wave, 'question': question, 'axis': axis,
                                   'options': options, 'groups': groups, 'score': max(scores),
                                   'opinion_keyword_match': opinion_like})
        audit.append(dict(wave=wave, **counts))
        print(f'W{wave}: matched {counts["matched"]}/{len(qs)}; candidates so far {len(candidates)}', flush=True)
    return candidates, audit


def choose(candidates, n, seed):
    rng = random.Random(seed)
    pools = {a: [c for c in candidates if c['axis'] == a] for a in AXES}
    for pool in pools.values():
        rng.shuffle(pool)
        # Prefer attitude-like questions; regex is only screening, not semantic validation.
        pool.sort(key=lambda c: not c['opinion_keyword_match'])
    selected, seen_keys, seen_texts = [], set(), set()
    # Keep the ten original source items first when they remain eligible.
    for key,axis in PILOT_KEYS:
        match = next((c for c in candidates if c['source_key']==key and c['axis']==axis),None)
        if match is None:
            continue
        text_key = re.sub(r'\s+', ' ', match['question']).casefold()
        if key in seen_keys or text_key in seen_texts:
            continue
        selected.append(match);seen_keys.add(key);seen_texts.add(text_key)
        if len(selected)==n:
            return selected
    while len(selected) < n:
        progress = False
        for axis in AXES:
            while pools[axis]:
                c = pools[axis].pop(0)
                text_key = re.sub(r'\s+', ' ', c['question']).casefold()
                if c['source_key'] in seen_keys or text_key in seen_texts:
                    continue
                seen_keys.add(c['source_key']); seen_texts.add(text_key)
                selected.append(c); progress = True
                break
            if len(selected) == n:
                break
        if not progress:
            raise ValueError(f'Only {len(selected)} distinct question texts available; requested {n}. '
                             'No duplicate/paraphrased questions were added. Change thresholds explicitly or use more data.')
    return selected


def build_record(c, index, dimension):
    qid = f'opinionqa_perspective_{index:03d}'
    query = ('Among respondents, which response to the following survey item has the highest weighted share: '
             + json.dumps(c['question'], ensure_ascii=False) + '?')
    # Context comes ONLY from original survey question/options and group distributions.
    # It contains no gold annotation, answer key, or maximum/winner marker.
    table_lines = [f'Pew American Trends Panel, historical wave W{c["wave"]}; item {c["source_key"]}.',
                   'Survey item: '+c['question'],
                   'Shares are survey-weighted, normalized separately within each displayed group.',
                   'Refusal/missing responses are excluded. No overall distribution is supplied.',
                   'All response options and all groups qualifying for this candidate are displayed.', '',
                   '| Respondent group | Response option | Weighted share (%) |', '|---|---|---:|']
    for g in c['groups']:
        for option, share in zip(c['options'], g['shares']):
            table_lines.append(f'| {cell(g["group"])} | {cell(option)} | {100*share:.8f} |')
    conditions = [f'{c["axis"]} = {g["group"]}' for g in c['groups']]
    pairs = [{'conditions': {dimension: cond}, 'answer': g['answer']}
             for cond,g in zip(conditions, c['groups'])]
    gold = {'ambiguous_conditions': [{'term': 'respondents', 'dimension': dimension, 'conditions': conditions}],
            'condition_answer_pairs': pairs}
    table = '\n'.join(table_lines)
    source = {'dataset': 'OpinionQA', 'source_key': c['source_key'], 'wave': c['wave'], 'axis': c['axis'],
              'options': c['options'], 'group_evidence': c['groups'],
              'opinion_keyword_match': c['opinion_keyword_match'],
              'human_naturalness_review': 'pending_for_this_generated_wording',
              'human_ambiguity_review': 'pending', 'questionnaire_routing_review': 'pending',
              'dimension_taxonomy_review': 'Perspective/population scope may overlap Granularity',
              'evaluation_ready_meaning': 'Nonempty evidence table; NOT scientific ambiguity approval.',
              'scope_note': 'Gold covers displayed groups only. Overall/other-group interpretations need separate adjudication.',
              'construction': 'Controlled survey aggregation query; not a native ambiguous survey question.'}
    original_record = {'id': qid, 'query': query, 'table': table, 'gold': gold, 'dataset': 'OpinionQA'}
    record = {'id': qid, 'query': query, 'table': table, 'gold': gold, 'evaluation_ready': True,
              'metadata': {'dataset': 'OpinionQA', 'original_record': original_record, 'provenance': source}}
    # Meanings of options come from the table even when original survey stems are fragments.
    return record


def verify(records):
    if len({r['id'] for r in records}) != len(records):
        raise ValueError('Duplicate IDs.')
    for r in records:
        gold = r['gold']; annotations = gold['ambiguous_conditions']; pairs = gold['condition_answer_pairs']
        a = annotations[0]; dim = a['dimension']; conds = a['conditions']
        assert len(conds) >= 2 and len(set(conds)) == len(conds)
        assert [p['conditions'][dim] for p in pairs] == conds
        assert len({p['answer'] for p in pairs}) >= 2
        evidence = r['metadata']['provenance']
        for group, pair in zip(evidence['group_evidence'], pairs):
            assert abs(sum(group['shares']) - 1) < 1e-8
            answer_index = int(np.argmax(group['shares']))
            assert pair['answer'] == evidence['options'][answer_index]
            # Precision of visible table must preserve the same unique winner.
            visible = [round(p*100, 8) for p in group['shares']]
            assert int(np.argmax(visible)) == answer_index


def write_jsonl(path, rows):
    Path(path).write_text(''.join(json.dumps(r, ensure_ascii=False, allow_nan=False)+'\n' for r in rows), encoding='utf-8')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--model-input', required=True, type=Path)
    ap.add_argument('--human-resp', required=True, type=Path)
    ap.add_argument('--outdir', type=Path, default=Path('opinionqa_200_v3'))
    ap.add_argument('--n', type=int, default=200)
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--dimension', default='Perspective')
    ap.add_argument('--min-n', type=int, default=200)
    ap.add_argument('--min-ess', type=float, default=100)
    ap.add_argument('--min-margin', type=float, default=0.10)
    ap.add_argument('--opinion-only', action='store_true', help='Do not use for v3: the explicit content inventory replaces the keyword screen.')
    args = ap.parse_args()
    if args.opinion_only:
        ap.error('v3 uses a reviewed source inventory; omit --opinion-only.')
    if args.n <= 0 or args.min_n < 1 or args.min_ess <= 0 or not 0 < args.min_margin < 1 or not args.dimension.strip():
        ap.error('Invalid count, thresholds or dimension.')
    names = ['opinionqa_eval_standard.jsonl', 'opinionqa_model_inputs.jsonl', 'review_200.md', 'validation_summary.json', 'dimension_definition.md']
    if any((args.outdir / name).exists() for name in names):
        ap.error('Output files already exist. Choose a new --outdir to preserve previous review work.')
    try:
        candidates, audit = collect(args)
        selected = choose(candidates, args.n, args.seed)
        records = [build_record(c, i, args.dimension) for i,c in enumerate(selected)]
        verify(records)
        assert len({re.sub(r'\s+', ' ', c['question']).casefold() for c in selected}) == len(records)
        assert all(len(c['groups'])*len(c['options']) <= 100 for c in selected)
        args.outdir.mkdir(parents=True, exist_ok=True)
        write_jsonl(args.outdir/names[0], records)
        inputs = [{k:r[k] for k in ['id', 'query', 'table']} for r in records]
        assert all(set(r) == {'id','query','table'} for r in inputs)
        write_jsonl(args.outdir/names[1], inputs)
        review = ['# OpinionQA：200题人工审核', '',
                  '本文件一次列全：问题、数据表、dimension、conditions 和每个条件的答案。只用于人工审核。',
                  '只把 opinionqa_model_inputs.jsonl 的 query/table 发给模型；不要发送本审核文件或 gold。',
                  '旧10题的自然性确认不会自动转移到新增题或改写后的题干。',
                  '重点判断：问句自然吗？群体解释合理吗？能否默认理解为总体？是否只是缺少总体数据？',
                  '数值核验通过不代表歧义审核通过；本版维度暂用 Perspective。', '']
        for r in records:
            dim = r['gold']['ambiguous_conditions'][0]['dimension']
            review += [f'## {r["id"]}', '', '**问题：** '+r['query'], '', r['table'], '',
                       '**Dimension：** '+dim, '', '| Condition | Answer |','|---|---|']
            for p in r['gold']['condition_answer_pairs']:
                review.append(f'| {cell(p["conditions"][dim])} | {cell(p["answer"])} |')
            review += ['', '**人工结论：** 自然性 待审；歧义性 待审；原问卷路由 待审。', '', '---','']
        (args.outdir/names[2]).write_text('\n'.join(review), encoding='utf-8')
        summary = {'selected_queries':len(records), 'condition_answer_pairs':sum(len(r['gold']['condition_answer_pairs']) for r in records),
                   'unique_question_texts':len({c['question'] for c in selected}), 'selected_by_axis':dict(collections.Counter(c['axis'] for c in selected)),
                   'keyword_attitude_like_selected':sum(c['opinion_keyword_match'] for c in selected),
                   'eligible_question_axis_pairs':len(candidates), 'eligible_unique_source_keys':len({c['source_key'] for c in candidates}),
                   'wave_audit':audit, 'seed':args.seed, 'dimension':args.dimension,
                   'thresholds':{'n_valid':args.min_n,'effective_n':args.min_ess,'winner_margin':args.min_margin},
                   'raw_archive_sha256':{'model_input':sha256(args.model_input), 'human_resp':sha256(args.human_resp)},
                   'checks':{'unique_ids':True,'unique_question_texts':True,'shares_sum_to_one':True,
                             'gold_matches_weighted_argmax':True,'table_rounding_preserves_winner':True,'model_inputs_exclude_gold':True},
                   'human_review':'pending', 'model_evaluation':'not_run',
                   'retained_v2_source_items':160, 'additional_source_items':len(records)-160,
                   'max_answer_words':max(len(p['answer'].split()) for r in records for p in r['gold']['condition_answer_pairs']),
                   'wording_templates':4,
                   'max_table_data_rows':max(len(c['groups'])*len(c['options']) for c in selected),
                   'caveats':['Selection favors distinct and stable group winners; not representative sampling.',
                              'Explicit content-screened inventory; human ambiguity and taxonomy review remain pending.',
                              'Group scope / native ambiguity / questionnaire eligibility need review.',
                              'No API called; no generated human responses; no statistical significance claim.']}
        (args.outdir/names[3]).write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
        (args.outdir/names[4]).write_text(DIMENSION_DEFINITION,encoding='utf-8')
        print(f'COMPLETE: {len(records)} distinct queries; {summary["condition_answer_pairs"]} condition-answer pairs.')
        print('Selected axes:',summary['selected_by_axis'])
        print('Attitude-keyword matches:',summary['keyword_attitude_like_selected'])
        print('Human-readable review:',args.outdir/names[2])
        print('Gold file:',args.outdir/names[0]); print('Model input file:',args.outdir/names[1])
    except (OSError, ValueError, KeyError, TypeError, tarfile.TarError) as exc:
        ap.exit(1,f'ERROR: {exc}\n')



DIMENSION_DEFINITION = "# OpinionQA 维度边界提案（待与论文现有分类核对）\n\n## 论文与 prompt 共用的英文定义\n\nPerspective: A question about opinions, preferences, or judgments leaves the\nrespondent group unspecified. Different displayed respondent groups yield\ndifferent leading answers to the same survey item. The response options,\nhistorical survey wave, and survey-weighted within-group aggregation rule are\nheld fixed. This benchmark uses Perspective specifically for the source of\nsurvey opinions, not for the identity of the entity discussed in the question.\n\nGranularity: The question leaves the level or unit of aggregation unspecified,\nsuch as item versus order or city versus state. Under this proposed taxonomy,\nthe source group of survey opinions is assigned to Perspective. If the paper's\nexisting Granularity definition already includes these population scopes, the\ntaxonomy and affected annotations must be reconciled before evaluation.\n\nDefinition–Metric: The question leaves the definition or calculation of the\nrequested measure unspecified, such as strongly favor alone versus strongly\nfavor plus somewhat favor. Fixed survey weighting does not itself create a\nDefinition–Metric ambiguity.\n\n## 对照例子\n\n| 例子 | 维度提案 | 改变的内容 |\n|---|---|---|\n| 同一政策调查，不同年龄群体的最高占比选项不同 | Perspective | 意见来源群体 |\n| 按订单还是按商品统计平均金额 | Granularity | 汇总单位/层级 |\n| 支持率包含 strongly favor 还是也包含 somewhat favor | Definition–Metric | 选项合并与指标定义 |\n\n## 限制与人工判定\n\n这是一套建议的操作性分类，不是意见调查天然具有的唯一分类。\n这些 query 是围绕真实调查构造的聚合问题，不是原始自然歧义问题。\n即使是态度题，读者也可能默认 respondents 指总体受访者。当前表格只\n给出候选子群体，缺少总体分布；仍需人工判断这是合理的群体歧义，还是\n仅仅缺少回答总体问题所需的数据。总体不能通过对子群体比例简单平均补出。\n\n人工审核时分别记录：自然性、群体歧义是否成立、condition 是否合理、\n问卷路由/片段是否完整、维度是否接受。不要用模型分类准确率决定 gold。\n修改定义或模板后的实验要单独报告，不能把旧预测当作新版本结果。\n\n## 模板变体的意义\n\n本版四个模板保持同一任务：选择加权占比最高的原始选项。\n它们只增加措辞变化，不增加任务或推理多样性；不能声称已彻底解决\n模板多样性问题。未改成“多数支持”，也未合并回答选项。\n"

# Content-screened source inventory. Preserve the160 retained source/axis pairs;
# select40 additional survey items from the explicit reviewed attitude inventory.
RETAINED_SOURCE_AXES = [('GOVRESP_b_W54', 'AGE'), ('IMMIMPACT_W32', 'EDUCATION'), ('SCI5_W34', 'SEX'), ('POL1JB_W92', 'POLPARTY'), ('GOVSIZE1_W92', 'POLPARTY'), ('VALUEURBAN_W32', 'EDUCATION'), ('PROG_RRETRO_W92', 'INCOME'), ('WMNPRZ1_W36', 'SEX'), ('GOVRESP_f_W54', 'POLPARTY'), ('GAYMARR2_W32', 'AGE'), ('GOVRESP_e_W54', 'INCOME'), ('RACESURV19e_W43', 'POLPARTY'), ('TRAITBIZWF2B_W36', 'AGE'), ('IMPROVE1_W36', 'POLPARTY'), ('LIFEFIFTY_W92', 'EDUCATION'), ('GOVRESP_a_W54', 'INCOME'), ('GOVPRIOe_W41', 'POLPARTY'), ('MAN1B_W29', 'AGE'), ('GAP21Q33_j_W82', 'EDUCATION'), ('MAN1E_W29', 'INCOME'), ('GAP21Q34_c_W82', 'POLPARTY'), ('FUD24_W34', 'AGE'), ('FAMSURV2Wd_W50', 'EDUCATION'), ('TRAITPOLMF1G_W36', 'INCOME'), ('WRKTRN1F1_W41', 'POLPARTY'), ('COMMIMPF_W32', 'AGE'), ('MOREWMN2F2_W36', 'EDUCATION'), ('SOLVPROBa_W41', 'INCOME'), ('PQ4_F2Ab_W42', 'POLPARTY'), ('RQ8_F1B_W42', 'AGE'), ('INFOWHYc_W45', 'EDUCATION'), ('GAP21Q13_c_W82', 'INCOME'), ('SOCIETY_TRANS_W92', 'POLPARTY'), ('DRONE4C_W27', 'AGE'), ('SNGLPYER_W92', 'EDUCATION'), ('INEQ5_j_W54', 'INCOME'), ('RQ4_F1Ba_W42', 'POLPARTY'), ('PQ8_F2C_W42', 'AGE'), ('EXECCHF2_W36', 'EDUCATION'), ('ROBJOB5D_W27', 'INCOME'), ('RACESURV12_W43', 'POLPARTY'), ('INFOKNOWc_W45', 'EDUCATION'), ('RACESURV3_W43', 'INCOME'), ('AMNTWMNBF1_W36', 'POLPARTY'), ('RQ4_F1Be_W42', 'EDUCATION'), ('FUD33A_W34', 'INCOME'), ('CONFg_W42', 'POLPARTY'), ('GAP21Q33_e_W82', 'EDUCATION'), ('BIOTECHA_W34', 'INCOME'), ('WHYNOTPOLF1L_W36', 'POLPARTY'), ('NEWSPREFV2_W45', 'EDUCATION'), ('PQ5_F2A_W42', 'INCOME'), ('GAP21Q42_W82', 'POLPARTY'), ('INEQ5_l_W54', 'AGE'), ('RACATTN_W43', 'EDUCATION'), ('MED2C_W34', 'INCOME'), ('BETTERBIZ2F2F_W36', 'AGE'), ('GAP21Q33_i_W82', 'EDUCATION'), ('MAN1C_W29', 'INCOME'), ('INEQ5_g_W54', 'POLPARTY'), ('INEQ5_i_W54', 'AGE'), ('POLINTOL2_b_W92', 'EDUCATION'), ('GOVTHC_W92', 'POLPARTY'), ('BILLION_W92', 'AGE'), ('RQ4_F1Bb_W42', 'EDUCATION'), ('POORASSIST_W92', 'INCOME'), ('GAP21Q23_W82', 'POLPARTY'), ('GAP21Q33_q_W82', 'AGE'), ('BETTERBIZ1F2K_W36', 'EDUCATION'), ('SOCIETY_SSM_W92', 'AGE'), ('RQ8_F1C_W42', 'POLPARTY'), ('INFOWHYd_W45', 'AGE'), ('WHYNOTBIZF2O_W36', 'INCOME'), ('MED2G_W34', 'AGE'), ('GOVRESP_d_W54', 'EDUCATION'), ('GOVPRIOfF1_W41', 'POLPARTY'), ('INEQ5_a_W54', 'AGE'), ('INTRMAR_W41', 'EDUCATION'), ('RQ8_F1A_W42', 'INCOME'), ('GAP21Q33_h_W82', 'POLPARTY'), ('WHYNOTBIZF2C_W36', 'AGE'), ('ECON3_h_W54', 'POLPARTY'), ('RACESURV47a_W43', 'POLPARTY'), ('MISINFT_W32', 'AGE'), ('RTBFc_W49', 'EDUCATION'), ('ROBJOB8E_W27', 'INCOME'), ('FEDSHAREA_W32', 'POLPARTY'), ('GAP21Q33_s_W82', 'EDUCATION'), ('ECON5_j_W54', 'INCOME'), ('GAP21Q19_b_W82', 'POLPARTY'), ('MED2A_W34', 'AGE'), ('GAP21Q38_c_W82', 'EDUCATION'), ('GAP21Q38_b_W82', 'POLPARTY'), ('GAP21Q33_t_W82', 'AGE'), ('INSTN_TECHCMP_W92', 'POLPARTY'), ('WHYNOTPOLF1J_W36', 'AGE'), ('GAP21Q34_b_W82', 'POLPARTY'), ('DRONE4E_W27', 'AGE'), ('GAP21Q3_W82', 'EDUCATION'), ('PQ4_F2Aa_W42', 'POLPARTY'), ('INFOCREATEa_W45', 'AGE'), ('BETTERPOL1F1C_W36', 'EDUCATION'), ('GAP21Q34_f_W82', 'POLPARTY'), ('GAP21Q31_W82', 'AGE'), ('POPPROB_W41', 'EDUCATION'), ('PQ4_F2Cb_W42', 'POLPARTY'), ('ELDFINANCEF1_W41', 'EDUCATION'), ('GAP21Q33_g_W82', 'POLPARTY'), ('WHYNOTBIZF2J_W36', 'AGE'), ('ECIMPc_W54', 'POLPARTY'), ('IL_IMM_PRI_W92', 'AGE'), ('GODMORALIMP_W92', 'POLPARTY'), ('INEQ8_h_W54', 'AGE'), ('WHYNOTBIZF2I_W36', 'POLPARTY'), ('WHYNOTBIZF2G_W36', 'AGE'), ('GAP21Q34_d_W82', 'POLPARTY'), ('DATAUSEd_W49', 'AGE'), ('INSTN_LBRUN_W92', 'POLPARTY'), ('INEQ7_W54', 'POLPARTY'), ('DATAUSEe_W49', 'AGE'), ('WHYNOTBIZF2B_W36', 'POLPARTY'), ('GAP21Q33_n_W82', 'AGE'), ('PQ4_F2Be_W42', 'POLPARTY'), ('GAP21Q40_W82', 'POLPARTY'), ('INSTN_BNKS_W92', 'AGE'), ('INSTN_CLGS_W92', 'POLPARTY'), ('DRONE4D_W27', 'AGE'), ('INSTN_K12_W92', 'POLPARTY'), ('GAP21Q34_e_W82', 'POLPARTY'), ('DRONE4A_W27', 'AGE'), ('MOREWMN4F2_W36', 'POLPARTY'), ('COMMIMPE_W32', 'AGE'), ('BETTERBIZ1F2E_W36', 'POLPARTY'), ('RACESURV47e_W43', 'POLPARTY'), ('SOLVPROBf_W41', 'POLPARTY'), ('GAP21Q4_b_W82', 'POLPARTY'), ('INEQ5_h_W54', 'POLPARTY'), ('GUNCONTRIBA_W26', 'POLPARTY'), ('BETTERBIZ1F2C_W36', 'POLPARTY'), ('GOVRESP_g_W54', 'POLPARTY'), ('CONFc_W42', 'POLPARTY'), ('BETTERPOL2F1D_W36', 'POLPARTY'), ('ABORTION_W32', 'POLPARTY'), ('RACESURV10_W43', 'POLPARTY'), ('RACESURV6_W43', 'POLPARTY'), ('INEQ5_k_W54', 'POLPARTY'), ('INEQ6_W54', 'POLPARTY'), ('PQ6_F2A_W42', 'POLPARTY'), ('GAP21Q10_W82', 'POLPARTY'), ('INEQ10_W54', 'POLPARTY'), ('FREECOLL_W92', 'POLPARTY'), ('GAP21Q27_W82', 'POLPARTY'), ('INFOCREATEe_W45', 'POLPARTY'), ('BETTERPOL2F1B_W36', 'POLPARTY'), ('SCM5j_W42', 'POLPARTY'), ('INEQ1_W54', 'POLPARTY'), ('SOURCESKEPa_W45', 'POLPARTY'), ('MOREWMN1F2_W36', 'POLPARTY'), ('WHYNOTPOLF1G_W36', 'POLPARTY'), ('FCFAIR_W45', 'POLPARTY')]
ADDITIONAL_SOURCES = set('TRANSGEND3_W29 AMNTWMNPF1_W36 IMPROVE2_W36 RACESURV15b_W43 RACESURV18c_W43 RACESURV19b_W43 INEQ4_e_W54 GAP21Q19_a_W82 GAP21Q28_W82 GAP21Q34_a_W82 SOCIETY_GUNS_W92 CARS5_W27 BOYSF1A_W29 GIRLSF2A_W29 GIRLSF2C_W29 SOCTRUST_W32 SOCTRUST5_W32 HARASS1C_W32 HARASS1D_W32 IMMCULT2_W32 MARRFAM2_W32 GOVT_ROLE_W32 SCI4_W34 FUD37B_W34 HARASS1F1a_W41 HARASS1NOWRKF2a_W41 POLICY1_W42 Q6F2_W42 POP1_W42 RACESURV5a_W43 RACESURV5c_W43 RACESURV5g_W43 RACESURV14_W43 RACESURV28a_W43 RACESURV28b_W43 RACESURV28c_W43 RACESURV28d_W43 RACESURV28e_W43 RACESURV28f_W43 RACESURV28g_W43 INFORESTRICTc_W45 FAMSURV4_W50 FIN_SITMOST_W54 ECONFAIR_W53 GAP21Q7_b_W82 GAP21Q15_b_W82 GAP21Q26_a_W82 GAP21Q35_W82 GAP21Q37_W82 GAP21Q43_b_W82 PEACESTR_W92 GOVWASTE_W92 GLBLZE_W92 PROG_RNEED_W92 CANQUALPOL_W92 CNTRYFAIR_W92 GOVPROTCT_W92 GOODEVIL_W92'.split())
QUERY_TEMPLATES = [
    'Which response had the highest survey-weighted percentage when respondents answered this item: {item}',
    'Based on the survey-weighted percentages, what was respondents’ most common answer to this item: {item}',
    'For this survey item, which answer was most frequent among respondents after applying the survey weights: {item}',
    'What was the leading response among respondents to this item, using survey-weighted percentages: {item}',
]
_base_collect = collect
_base_choose = choose
_base_build_record = build_record

def collect(args):
    candidates, audit = _base_collect(args)
    allowed = {k for k,a in RETAINED_SOURCE_AXES} | ADDITIONAL_SOURCES
    return [c for c in candidates if c['source_key'] in allowed and
            max(len(o.split()) for o in c['options']) <= 18], audit

def choose(candidates, n, seed):
    lookup = {(c['source_key'],c['axis']):c for c in candidates}
    retained = []
    for key, axis in RETAINED_SOURCE_AXES:
        if (key,axis) not in lookup:
            raise ValueError(f'Retained source no longer meets thresholds: {key}/{axis}')
        retained.append(lookup[(key,axis)])
    if n < len(retained):
        raise ValueError('This expansion preserves160 items; --n must be at least160.')
    seen_keys = {c['source_key'] for c in retained}
    seen_text = {re.sub(r'\s+', ' ', c['question']).casefold() for c in retained}
    remaining = [c for c in candidates if c['source_key'] not in seen_keys and
                 re.sub(r'\s+', ' ', c['question']).casefold() not in seen_text]
    return retained + (_base_choose(remaining, n-len(retained),seed) if n>len(retained) else [])

def build_record(c,index,dimension):
    r = _base_build_record(c,index,dimension)
    r['id'] = f'opinionqa_perspective_v3_{index:03d}'
    r['query'] = QUERY_TEMPLATES[index%4].format(item=json.dumps(c['question'],ensure_ascii=False))
    r['metadata']['original_record']['id'] = r['id']
    r['metadata']['original_record']['query'] = r['query']
    r['metadata']['provenance']['content_screen'] = 'reviewed attitude/preference/judgment candidate'
    r['metadata']['provenance']['expansion_role'] = 'retained160' if index<160 else 'new40'
    r['metadata']['provenance']['query_template_id'] = index%4
    return r

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Reproducible editorial screening of the specific OpinionQA 200 archive.
Python standard library only. Does not call a model or assert human approval.
Run: python revise_opinionqa.py --input opinionqa_200.zip --outdir revised_output
"""
import argparse
import collections
import copy
import json
import re
import zipfile
from pathlib import Path

# Explicit decisions for the source items in this archive, not a general classifier.
EXCLUDE = {
    4: '家庭财务状况自报，不是对公共议题的意见。',
    10: '婚龄是事实性经历；年龄分组差异不是意见视角差异。',
    55: '阅读隐私政策的频率是行为自报。',
    63: '是否住在成长社区附近是事实性经历。',
    85: '邻里互相帮忙的频率是行为自报。',
    86: '成长时期家中是否有枪是事实性经历。',
    97: '工作与育儿冲突的个人经历；不是公共议题态度。',
    104: 'Blue collar 是身份自报。',
    105: '科技如何改变自己的工作强度是个人经历自报。',
    166: '能否请邻居照看孩子主要反映个人处境。',
}
HOLD = {
    0: '对自身未来收入的预期，暂不用于最清晰的意见视角子集。',
    2: 'Intelligent 是自我评价；与公共议题意见不同。',
    7: 'Nurturing 是自我评价；与公共议题意见不同。',
    16: '生活乐观情绪频率，可能混合心理状态与态度。',
    20: '个人职业机会变化，可能混合经历与主观判断。',
    21: 'other major reasons 依赖前文与问卷路由；不能只凭当前片段补写。',
    23: '自身工作满意度，先暂缓以收紧视角边界。',
    51: '自身数据控制感；且选项包含 Offline，混合意见与资格。',
    59: '题干仅为 Thinking about parents…，缺少完整提问，需核对问卷。',
    70: 'NRA 支持者身份自报，暂缓。',
    88: '政党未来相关情绪，题干残缺；核对完整问卷后再决定。',
    89: '食品价格对家庭财务的影响，个人处境与判断混合。',
    92: 'such as these 依赖缺失的机器人介绍；需补齐原问卷语境。',
    94: '关于本人退休时间的预期；年龄可能改变预测时点，混入 Temporal。',
    107: '职业投入是自我评价，暂缓。',
    109: '汽油价格对家庭财务的影响，个人处境与判断混合。',
    115: '自身职业培训需要，年龄/就业资格可能改变问题适用性。',
    123: 'LGBT 权利支持者身份自报，暂缓。',
    126: '税制对家庭财务的影响，个人处境与判断混合。',
    137: '邻里支持感可能主要体现生活处境。',
    139: '候选人是否代表自己，身份/经历与意见混合，暂缓。',
    140: '结婚意愿需核对婚姻资格与路由，暂不纳入试跑。',
    152: '自身数据控制感，先暂缓以收紧视角边界。',
    155: 'BLM 支持者身份自报，暂缓。',
    156: '忙碌情绪频率，主要体现生活状态。',
    174: 'Environmentalist 是身份自报，暂缓。',
}
TEMPLATES = [
    'Which response had the highest survey-weighted percentage when respondents answered this item: {item}',
    'Based on the survey-weighted percentages, what was respondents’ most common answer to this item: {item}',
    'For this survey item, which answer was most frequent among respondents after applying the survey weights: {item}',
    'What was the leading response among respondents to this item, using survey-weighted percentages: {item}',
]
PREFERRED = [6, 8, 12, 13, 15, 22, 24, 26, 28, 34, 37, 41, 42, 43,
             49, 50, 53, 58, 60, 64, 68, 72, 78, 82, 87, 98, 100, 110, 112, 124]

DEFINITIONS = '''# OpinionQA 维度边界提案（待与论文现有分类核对）

## 论文与 prompt 共用的英文定义

Perspective: A question about opinions, preferences, or judgments leaves the
respondent group unspecified. Different displayed respondent groups yield
different leading answers to the same survey item. The response options,
historical survey wave, and survey-weighted within-group aggregation rule are
held fixed. This benchmark uses Perspective specifically for the source of
survey opinions, not for the identity of the entity discussed in the question.

Granularity: The question leaves the level or unit of aggregation unspecified,
such as item versus order or city versus state. Under this proposed taxonomy,
the source group of survey opinions is assigned to Perspective. If the paper's
existing Granularity definition already includes these population scopes, the
taxonomy and affected annotations must be reconciled before evaluation.

Definition–Metric: The question leaves the definition or calculation of the
requested measure unspecified, such as strongly favor alone versus strongly
favor plus somewhat favor. Fixed survey weighting does not itself create a
Definition–Metric ambiguity.

## 对照例子

| 例子 | 维度提案 | 改变的内容 |
|---|---|---|
| 同一政策调查，不同年龄群体的最高占比选项不同 | Perspective | 意见来源群体 |
| 按订单还是按商品统计平均金额 | Granularity | 汇总单位/层级 |
| 支持率包含 strongly favor 还是也包含 somewhat favor | Definition–Metric | 选项合并与指标定义 |

## 限制与人工判定

这是一套建议的操作性分类，不是意见调查天然具有的唯一分类。
这些 query 是围绕真实调查构造的聚合问题，不是原始自然歧义问题。
即使是态度题，读者也可能默认 respondents 指总体受访者。当前表格只
给出候选子群体，缺少总体分布；仍需人工判断这是合理的群体歧义，还是
仅仅缺少回答总体问题所需的数据。总体不能通过对子群体比例简单平均补出。

人工审核时分别记录：自然性、群体歧义是否成立、condition 是否合理、
问卷路由/片段是否完整、维度是否接受。不要用模型分类准确率决定 gold。
修改定义或模板后的实验要单独报告，不能把旧预测当作新版本结果。

## 模板变体的意义

本版四个模板保持同一任务：选择加权占比最高的原始选项。
它们只增加措辞变化，不增加任务或推理多样性；不能声称已彻底解决
模板多样性问题。未改成“多数支持”，也未合并回答选项。
'''

def write_jsonl(path, rows):
    path.write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in rows), encoding='utf-8')

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input', required=True)
    ap.add_argument('--outdir', required=True)
    args = ap.parse_args()
    out = Path(args.outdir)
    if out.exists() and any(out.iterdir()):
        raise SystemExit('输出目录非空；请指定新目录。')
    with zipfile.ZipFile(args.input) as z:
        names = [n for n in z.namelist() if n.endswith('opinionqa_eval_standard.jsonl')]
        if len(names) != 1:
            raise ValueError('应有且只有一个 opinionqa_eval_standard.jsonl')
        rows = [json.loads(line) for line in z.read(names[0]).decode().splitlines() if line.strip()]
    if len(rows) != 200 or len({r['id'] for r in rows}) != 200:
        raise ValueError('此脚本仅适用于已审核编号的原始200题包。')
    # Match the complete source-key order to prevent applying editorial labels
    # to a different generated archive by accident.
    expected_keys = SOURCE_KEYS.split()
    if [r['metadata']['provenance']['source_key'] for r in rows] != expected_keys:
        raise ValueError('来源题目顺序与审核版本不同，请勿套用这些人工分类。')
    out.mkdir(parents=True, exist_ok=True)
    audit, retained = [], []
    for i, r in enumerate(rows):
        p = r['metadata']['provenance']
        options = p['options']
        max_words = max(len(x.split()) for x in options)
        status = 'exclude' if i in EXCLUDE else ('hold' if i in HOLD else 'retain_candidate')
        reason = EXCLUDE.get(i) or HOLD.get(i) or '调查内容属于对议题的意见、判断或偏好；歧义性仍待人工确认。'
        if status == 'retain_candidate' and max_words > 18:
            status = 'hold'
            reason = '回答选项超过18个英文词；需人工确认可否提供短且唯一的等价标签。'
        entry = dict(id=r['id'], source_key=p['source_key'], axis=p['axis'],
                     status=status, reason=reason, max_option_words=max_words,
                     original_query=r['query'])
        audit.append(entry)
        if status != 'retain_candidate':
            continue
        item = re.search(r'^Survey item: (.*)$', r['table'], re.M)
        if not item:
            raise ValueError('缺少原始调查题干')
        v = copy.deepcopy(r)
        v['query'] = TEMPLATES[len(retained) % len(TEMPLATES)].format(item=json.dumps(item.group(1), ensure_ascii=False))
        v['metadata']['revision_v2'] = dict(original_query=r['query'],
            template_id=len(retained) % 4, content_screen='retain_candidate',
            dimension_proposal='Perspective: survey opinion source group',
            human_review='pending', taxonomy_approval='pending')
        # Preserve all evidence, original options, gold labels and answers.
        assert v['table'] == r['table'] and v['gold'] == r['gold']
        retained.append(v)
    preferred_ids = {f'opinionqa_perspective_{i:03d}' for i in PREFERRED}
    short = [r for r in retained if max(len(p['answer'].split()) for p in r['gold']['condition_answer_pairs']) <= 12]
    ranked = sorted(short, key=lambda r: (r['id'] not in preferred_ids, r['id']))
    buckets = {axis: [r for r in ranked if r['metadata']['provenance']['axis'] == axis]
               for axis in ['AGE', 'EDUCATION', 'INCOME', 'SEX', 'POLPARTY']}
    pilot = []
    while len(pilot) < 30 and any(buckets.values()):
        for bucket in buckets.values():
            if bucket and len(pilot) < 30:
                pilot.append(bucket.pop(0))
    if len(pilot) != 30:
        raise ValueError('不足30个短答案候选，未自动放宽筛选。')
    for prefix, selected in [('retained_candidates', retained), ('pilot30', pilot)]:
        write_jsonl(out / (prefix + '_standard.jsonl'), selected)
        write_jsonl(out / (prefix + '_model_inputs.jsonl'), [{k:r[k] for k in ['id','query','table']} for r in selected])
    write_jsonl(out / 'screening_200.jsonl', audit)
    md = ['# 原200题逐题筛查', '', 'retain_candidate = 内容适合意见题候选；不代表自然性、歧义性或维度已获人工批准。', '', '| ID | 来源 | 处理 | 原因 |', '|---|---|---|---|']
    md += [f"| {v['id']} | {v['source_key']} | {v['status']} | {v['reason']} |" for v in audit]
    (out / 'screening_200.md').write_text('\n'.join(md) + '\n', encoding='utf-8')
    rev = ['# 30题试跑前人工审核', '', '每题一次列全问题、证据、dimension、conditions、answers。Perspective 暂用提案定义。', '检查：自然性；群体歧义是否合理；默认总体解释；原问卷资格；维度边界。', '不要把这个文件发给模型。', '']
    for r in pilot:
        rev += [f"## {r['id']}", '', '**Query：** ' + r['query'], '', r['table'], '', '**Dimension：** Perspective（待确认）', '', '| Condition | Answer |', '|---|---|']
        rev += [f"| {p['conditions']['Perspective']} | {p['answer']} |" for p in r['gold']['condition_answer_pairs']]
        rev += ['', '**人工结论：** 自然性 □通过 □修改；歧义性 □通过 □不成立；维度 □接受 □重分类；问卷语境 □完整 □补充', '', '---', '']
    (out / 'pilot30_review.md').write_text('\n'.join(rev), encoding='utf-8')
    (out / 'dimension_proposal.md').write_text(DEFINITIONS, encoding='utf-8')
    summary = dict(original_queries=200, decisions=dict(collections.Counter(v['status'] for v in audit)),
                   retained_queries=len(retained), retained_condition_answer_pairs=sum(len(r['gold']['condition_answer_pairs']) for r in retained),
                   pilot_queries=30, pilot_axes=dict(collections.Counter(r['metadata']['provenance']['axis'] for r in pilot)),
                   pilot_condition_answer_pairs=sum(len(r['gold']['condition_answer_pairs']) for r in pilot),
                   answer_aliases_added=0, original_tables_and_gold_unchanged=True,
                   human_ambiguity_review='pending', model_evaluation='not_run', dimension_taxonomy='proposal_not_approved')
    (out / 'revision_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    (out / 'README_zh.md').write_text('''# OpinionQA 修订候选包

先看 screening_200.md：原200题分别保留、暂缓或剔除及原因。
人工审核只看 pilot30_review.md：30题的query、table、condition、answer都在一起。
维度定义提案看 dimension_proposal.md；先与论文现有Granularity定义核对。
评测脚本读取 pilot30_standard.jsonl；发给模型的内容仅为query/table。
pilot30_model_inputs.jsonl 没有gold。不要把standard的metadata或gold发给模型。
其余筛查后候选在 retained_candidates_standard.jsonl，仍待歧义人工审核。

本版没有凑满200；暂缓题需要补原问卷或替换。事实性自报题建议从
Perspective子集移除。答案保留原始选项，未添加未经核对的答案别名。
四个模板只改变措辞，计算目标相同；不声称提升任务多样性。
evaluation_ready沿用旧结构字段，只表示非空证据，不表示人工审核通过。
统计是编辑筛查，不是模型测评结果，也不是独立人工验证结果。

复现（Python标准库，无额外依赖）：
python revise_opinionqa.py --input opinionqa_200.zip --outdir revised_output
脚本内按来源顺序校验本次200题，不能泛化到其他输入版本。
''', encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))

SOURCE_KEYS = '''INCFUTURE_W32 GOVRESP_b_W54 TRAITSA_W29 IMMIMPACT_W32 FIN_SIT_W54 ROBJOB7_W27 SCI5_W34 TRAITSC_W29 POL1JB_W92 GOVSIZE1_W92 MARRDUR_W50 VALUEURBAN_W32 PROG_RRETRO_W92 WMNPRZ1_W36 GOVRESP_f_W54 GAYMARR2_W32 FEELC_W32 GOVRESP_e_W54 RACESURV19e_W43 TRAITBIZWF2B_W36 WORK4C_W27 HIGHEDWRNGS_W36 IMPROVE1_W36 SATLIFEd_W50 LIFEFIFTY_W92 GOVRESP_a_W54 GOVPRIOe_W41 MAN1B_W29 GAP21Q33_j_W82 MAN1E_W29 GAP21Q34_c_W82 FUD24_W34 FAMSURV2Wd_W50 TRAITPOLMF1G_W36 WRKTRN1F1_W41 COMMIMPF_W32 MOREWMN2F2_W36 SOLVPROBa_W41 PQ4_F2Ab_W42 RQ8_F1B_W42 INFOWHYc_W45 GAP21Q13_c_W82 SOCIETY_TRANS_W92 DRONE4C_W27 SNGLPYER_W92 INEQ5_j_W54 RQ4_F1Ba_W42 PQ8_F2C_W42 EXECCHF2_W36 ROBJOB5D_W27 RACESURV12_W43 CONTROLGRPe_W49 INFOKNOWc_W45 RACESURV3_W43 AMNTWMNBF1_W36 PP2_W49 RQ4_F1Be_W42 FUD33A_W34 CONFg_W42 FAMSURV12_W50 GAP21Q33_e_W82 BIOTECHA_W34 WHYNOTPOLF1L_W36 GROWUPNEAR_W32 NEWSPREFV2_W45 PQ5_F2A_W42 GAP21Q42_W82 INEQ5_l_W54 RACATTN_W43 MED2C_W34 MESUM2_FC_W29 BETTERBIZ2F2F_W36 GAP21Q33_i_W82 MAN1C_W29 INEQ5_g_W54 INEQ5_i_W54 POLINTOL2_b_W92 MED1_W34 GOVTHC_W92 BILLION_W92 RQ4_F1Bb_W42 POORASSIST_W92 GAP21Q23_W82 GAP21Q33_q_W82 BETTERBIZ1F2K_W36 FAVORS_CPS_W29 GROWUPGUN1_W26 SOCIETY_SSM_W92 GOPDIRCT_W29 ECON4_c_W54 RQ8_F1C_W42 INFOWHYd_W45 CAREGIV6B_W27 WHYNOTBIZF2O_W36 SSMONEY_W41 MED2G_W34 GOVRESP_d_W54 FAMSURV35b_W50 GOVPRIOfF1_W41 INEQ5_a_W54 INTRMAR_W41 RQ8_F1A_W42 GAP21Q33_h_W82 WHYNOTBIZF2C_W36 MESUM1_FD_W29 WORK4A_W27 ECON3_h_W54 MESUM1_FE_W29 EVOPERS3_W34 ECON4_f_W54 RACESURV47a_W43 MISINFT_W32 RTBFc_W49 ROBJOB8E_W27 FEDSHAREA_W32 JOBTRAIN_W54 GAP21Q33_s_W82 ECON5_j_W54 GAP21Q19_b_W82 MED2A_W34 GAP21Q38_c_W82 GAP21Q38_b_W82 GAP21Q33_t_W82 MESUM2_FE_W29 INSTN_TECHCMP_W92 WHYNOTPOLF1J_W36 ECON4_i_W54 GAP21Q34_b_W82 DRONE4E_W27 GAP21Q3_W82 PQ4_F2Aa_W42 INFOCREATEa_W45 BETTERPOL1F1C_W36 GAP21Q34_f_W82 GAP21Q31_W82 POPPROB_W41 PQ4_F2Cb_W42 HOOD_NHISA_W29 ELDFINANCEF1_W41 CANMTCHPOL_W92 MARRYPREF1_W50 GAP21Q33_g_W82 WHYNOTBIZF2J_W36 ECIMPc_W54 IL_IMM_PRI_W92 GODMORALIMP_W92 INEQ8_h_W54 WHYNOTBIZF2I_W36 WHYNOTBIZF2G_W36 GAP21Q34_d_W82 DATAUSEd_W49 INSTN_LBRUN_W92 CONTROLGRPc_W49 INEQ7_W54 DATAUSEe_W49 MESUM2_FD_W29 FEELD_W32 WHYNOTBIZF2B_W36 GAP21Q33_n_W82 PQ4_F2Be_W42 RACESURV50_W43 GAP21Q40_W82 INSTN_BNKS_W92 INSTN_CLGS_W92 DRONE4D_W27 INSTN_K12_W92 NEIGHKIDS_W32 GAP21Q34_e_W82 DRONE4A_W27 MOREWMN4F2_W36 COMMIMPE_W32 BETTERBIZ1F2E_W36 RACESURV47e_W43 SOLVPROBf_W41 MESUM2_FA_W29 GAP21Q4_b_W82 INEQ5_h_W54 GUNCONTRIBA_W26 BETTERBIZ1F2C_W36 GOVRESP_g_W54 CONFc_W42 BETTERPOL2F1D_W36 ABORTION_W32 RACESURV10_W43 RACESURV6_W43 INEQ5_k_W54 INEQ6_W54 PQ6_F2A_W42 GAP21Q10_W82 INEQ10_W54 FREECOLL_W92 GAP21Q27_W82 INFOCREATEe_W45 BETTERPOL2F1B_W36 SCM5j_W42 INEQ1_W54 SOURCESKEPa_W45 MOREWMN1F2_W36 WHYNOTPOLF1G_W36 FCFAIR_W45'''

if __name__ == '__main__':
    main()

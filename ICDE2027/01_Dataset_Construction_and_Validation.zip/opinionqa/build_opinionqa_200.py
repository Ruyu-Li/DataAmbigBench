#!/usr/bin/env python3
"""Build OpinionQA candidates in the supplied standardize_benchmark schema.

Python 3.9+, pandas, numpy. Offline: no API calls, no invented survey answers.
Run: python build_opinionqa_200.py --model-input model_input.tar.gz \
     --human-resp human_resp.tar.gz --outdir opinionqa_200 --n 200
This creates candidates, not 200 human-validated ambiguity examples.
"""
import argparse
import ast
import collections
import hashlib
import io
import itertools
import json
import random
import re
import sys
import tarfile
from pathlib import Path

import numpy as np
import pandas as pd

AXES = ['AGE', 'EDUCATION', 'INCOME', 'SEX', 'POLPARTY']
PILOT_KEYS = [('INCFUTURE_W32','AGE'), ('GOVRESP_b_W54','AGE'),
              ('TRAITSA_W29','EDUCATION'), ('IMMIMPACT_W32','EDUCATION'),
              ('FIN_SIT_W54','INCOME'), ('ROBJOB7_W27','INCOME'),
              ('SCI5_W34','SEX'), ('TRAITSC_W29','SEX'),
              ('POL1JB_W92','POLPARTY'), ('GOVSIZE1_W92','POLPARTY')]
OPINION_PATTERN = re.compile(
    r'think|should|prefer|favor|oppose|approve|agree|important|effect|better|worse|'
    r'satisfied|confiden|feel|concern|trust|would you rather|describe you', re.I)


def archive_csvs(path):
    # Read CSV members only; never extract archive paths or unpickle .npy files.
    with tarfile.open(path, 'r:*') as tar:
        return {m.name.lstrip('./'): tar.extractfile(m).read()
                for m in tar if m.isfile() and m.name.endswith('.csv')}


def csv(data, path, **kwargs):
    return pd.read_csv(io.BytesIO(data[path]), **kwargs)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def cell(value):
    return str(value).replace('|', '\\|').replace('\n', ' ').replace('\r', ' ')


def collect(args):
    models, humans = archive_csvs(args.model_input), archive_csvs(args.human_resp)
    waves = sorted(int(re.fullmatch(r'model_input/Pew_American_Trends_Panel_W(\d+)\.csv', p).group(1))
                   for p in models if re.fullmatch(r'model_input/Pew_American_Trends_Panel_W(\d+)\.csv', p))
    if not waves:
        raise ValueError('model_input archive has no expected wave CSVs.')
    candidates, audit = [], []
    for wave in waves:
        prefix = f'human_resp/American_Trends_Panel_W{wave}/'
        for name in ['responses.csv', 'info.csv', 'metadata.csv']:
            if prefix + name not in humans:
                raise ValueError(f'Missing archive member: {prefix + name}')
        qs = csv(models, f'model_input/Pew_American_Trends_Panel_W{wave}.csv', sep='\t')
        info = csv(humans, prefix+'info.csv').set_index('key')
        meta = csv(humans, prefix+'metadata.csv').set_index('key')
        data = csv(humans, prefix+'responses.csv', low_memory=False)
        weight_key = f'WEIGHT_W{wave}'
        weights = pd.to_numeric(data[weight_key], errors='coerce')
        valid_weights = weights.notna() & np.isfinite(weights) & weights.gt(0)
        counts = collections.Counter(questions=len(qs), respondents=len(data))
        for _, q in qs.iterrows():
            key = q['key']
            if key not in info.index or key not in data.columns:
                counts['missing_key'] += 1
                continue
            details = info.loc[key]
            if not isinstance(details, pd.Series):
                counts['shared_key_excluded'] += 1
                continue
            if q['question'] != details['question']:
                raise ValueError(f'Question text mismatch: {key}')
            references = ast.literal_eval(details['references'])
            ordinal = ast.literal_eval(details['option_ordinal'])
            options = references[:len(ordinal)]
            if len(options) < 2 or len(set(options)) != len(options):
                counts['invalid_options'] += 1
                continue
            if not set(options).issubset(ast.literal_eval(q['options'])):
                raise ValueError(f'Option mismatch: {key}')
            counts['matched'] += 1
            question = q['question'].strip()
            opinion_like = bool(OPINION_PATTERN.search(question)) and 'have you ever' not in question.lower()
            if args.opinion_only and not opinion_like:
                continue
            valid = valid_weights & data[key].isin(options)
            for axis in AXES:
                if axis not in meta.index or axis not in data:
                    continue
                groups = []
                for group in ast.literal_eval(meta.loc[axis, 'options']):
                    mask = valid & data[axis].eq(group)
                    n = int(mask.sum())
                    if n < args.min_n:
                        continue
                    w = weights[mask]
                    effective_n = float(w.sum()**2 / (w**2).sum())
                    if effective_n < args.min_ess:
                        continue
                    sums = pd.DataFrame({'response': data.loc[mask, key], 'weight': w}).groupby('response')['weight'].sum()
                    shares = (sums.reindex(options, fill_value=0) / w.sum()).to_numpy()
                    order = np.argsort(-shares)
                    margin = float(shares[order[0]] - shares[order[1]])
                    if margin < args.min_margin:
                        continue
                    groups.append({'group': group, 'n_valid': n, 'effective_n': effective_n,
                                   'weight_sum': float(w.sum()), 'shares': list(map(float, shares)),
                                   'answer': options[int(order[0])], 'winner_margin': margin})
                if len({g['answer'] for g in groups}) < 2:
                    continue
                # Keep ALL qualifying groups, including those with the same winner.
                scores = [min(a['winner_margin'], b['winner_margin'])
                          for a,b in itertools.combinations(groups, 2) if a['answer'] != b['answer']]
                candidates.append({'source_key': key, 'wave': wave, 'question': question, 'axis': axis,
                                   'options': options, 'groups': groups, 'score': max(scores),
                                   'opinion_keyword_match': opinion_like})
        audit.append(dict(wave=wave, **counts))
        print(f'W{wave}: matched {counts["matched"]}/{len(qs)}; candidates so far {len(candidates)}', flush=True)
    return candidates, audit


def choose(candidates, n, seed):
    rng = random.Random(seed)
    pools = {a: [c for c in candidates if c['axis'] == a] for a in AXES}
    for pool in pools.values():
        rng.shuffle(pool)
        # Prefer attitude-like questions; regex is only screening, not semantic validation.
        pool.sort(key=lambda c: not c['opinion_keyword_match'])
    selected, seen_keys, seen_texts = [], set(), set()
    # Keep the ten original source items first when they remain eligible.
    for key,axis in PILOT_KEYS:
        match = next((c for c in candidates if c['source_key']==key and c['axis']==axis),None)
        if match is None:
            continue
        text_key = re.sub(r'\s+', ' ', match['question']).casefold()
        if key in seen_keys or text_key in seen_texts:
            continue
        selected.append(match);seen_keys.add(key);seen_texts.add(text_key)
        if len(selected)==n:
            return selected
    while len(selected) < n:
        progress = False
        for axis in AXES:
            while pools[axis]:
                c = pools[axis].pop(0)
                text_key = re.sub(r'\s+', ' ', c['question']).casefold()
                if c['source_key'] in seen_keys or text_key in seen_texts:
                    continue
                seen_keys.add(c['source_key']); seen_texts.add(text_key)
                selected.append(c); progress = True
                break
            if len(selected) == n:
                break
        if not progress:
            raise ValueError(f'Only {len(selected)} distinct question texts available; requested {n}. '
                             'No duplicate/paraphrased questions were added. Change thresholds explicitly or use more data.')
    return selected


def build_record(c, index, dimension):
    qid = f'opinionqa_perspective_{index:03d}'
    query = ('Among respondents, which response to the following survey item has the highest weighted share: '
             + json.dumps(c['question'], ensure_ascii=False) + '?')
    # Context comes ONLY from original survey question/options and group distributions.
    # It contains no gold annotation, answer key, or maximum/winner marker.
    table_lines = [f'Pew American Trends Panel, historical wave W{c["wave"]}; item {c["source_key"]}.',
                   'Survey item: '+c['question'],
                   'Shares are survey-weighted, normalized separately within each displayed group.',
                   'Refusal/missing responses are excluded. No overall distribution is supplied.',
                   'All response options and all groups qualifying for this candidate are displayed.', '',
                   '| Respondent group | Response option | Weighted share (%) |', '|---|---|---:|']
    for g in c['groups']:
        for option, share in zip(c['options'], g['shares']):
            table_lines.append(f'| {cell(g["group"])} | {cell(option)} | {100*share:.8f} |')
    conditions = [f'{c["axis"]} = {g["group"]}' for g in c['groups']]
    pairs = [{'conditions': {dimension: cond}, 'answer': g['answer']}
             for cond,g in zip(conditions, c['groups'])]
    gold = {'ambiguous_conditions': [{'term': 'respondents', 'dimension': dimension, 'conditions': conditions}],
            'condition_answer_pairs': pairs}
    table = '\n'.join(table_lines)
    source = {'dataset': 'OpinionQA', 'source_key': c['source_key'], 'wave': c['wave'], 'axis': c['axis'],
              'options': c['options'], 'group_evidence': c['groups'],
              'opinion_keyword_match': c['opinion_keyword_match'],
              'human_naturalness_review': 'pending_for_this_generated_wording',
              'human_ambiguity_review': 'pending', 'questionnaire_routing_review': 'pending',
              'dimension_taxonomy_review': 'Perspective/population scope may overlap Granularity',
              'evaluation_ready_meaning': 'Nonempty evidence table; NOT scientific ambiguity approval.',
              'scope_note': 'Gold covers displayed groups only. Overall/other-group interpretations need separate adjudication.',
              'construction': 'Controlled survey aggregation query; not a native ambiguous survey question.'}
    original_record = {'id': qid, 'query': query, 'table': table, 'gold': gold, 'dataset': 'OpinionQA'}
    record = {'id': qid, 'query': query, 'table': table, 'gold': gold, 'evaluation_ready': True,
              'metadata': {'dataset': 'OpinionQA', 'original_record': original_record, 'provenance': source}}
    # Meanings of options come from the table even when original survey stems are fragments.
    return record


def verify(records):
    if len({r['id'] for r in records}) != len(records):
        raise ValueError('Duplicate IDs.')
    for r in records:
        gold = r['gold']; annotations = gold['ambiguous_conditions']; pairs = gold['condition_answer_pairs']
        a = annotations[0]; dim = a['dimension']; conds = a['conditions']
        assert len(conds) >= 2 and len(set(conds)) == len(conds)
        assert [p['conditions'][dim] for p in pairs] == conds
        assert len({p['answer'] for p in pairs}) >= 2
        evidence = r['metadata']['provenance']
        for group, pair in zip(evidence['group_evidence'], pairs):
            assert abs(sum(group['shares']) - 1) < 1e-8
            answer_index = int(np.argmax(group['shares']))
            assert pair['answer'] == evidence['options'][answer_index]
            # Precision of visible table must preserve the same unique winner.
            visible = [round(p*100, 8) for p in group['shares']]
            assert int(np.argmax(visible)) == answer_index


def write_jsonl(path, rows):
    Path(path).write_text(''.join(json.dumps(r, ensure_ascii=False, allow_nan=False)+'\n' for r in rows), encoding='utf-8')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--model-input', required=True, type=Path)
    ap.add_argument('--human-resp', required=True, type=Path)
    ap.add_argument('--outdir', type=Path, default=Path('opinionqa_200'))
    ap.add_argument('--n', type=int, default=200)
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--dimension', default='Perspective')
    ap.add_argument('--min-n', type=int, default=200)
    ap.add_argument('--min-ess', type=float, default=100)
    ap.add_argument('--min-margin', type=float, default=0.10)
    ap.add_argument('--opinion-only', action='store_true', help='Keyword-screened attitude-like items only; may yield fewer than 200.')
    args = ap.parse_args()
    if args.n <= 0 or args.min_n < 1 or args.min_ess <= 0 or not 0 < args.min_margin < 1 or not args.dimension.strip():
        ap.error('Invalid count, thresholds or dimension.')
    names = ['opinionqa_eval_standard.jsonl', 'opinionqa_model_inputs.jsonl', 'review_200.md', 'validation_summary.json']
    if any((args.outdir / name).exists() for name in names):
        ap.error('Output files already exist. Choose a new --outdir to preserve previous review work.')
    try:
        candidates, audit = collect(args)
        selected = choose(candidates, args.n, args.seed)
        records = [build_record(c, i, args.dimension) for i,c in enumerate(selected)]
        verify(records)
        args.outdir.mkdir(parents=True, exist_ok=True)
        write_jsonl(args.outdir/names[0], records)
        inputs = [{k:r[k] for k in ['id', 'query', 'table']} for r in records]
        assert all(set(r) == {'id','query','table'} for r in inputs)
        write_jsonl(args.outdir/names[1], inputs)
        review = ['# OpinionQA：200题人工审核', '',
                  '本文件一次列全：问题、数据表、dimension、conditions 和每个条件的答案。只用于人工审核。',
                  '只把 opinionqa_model_inputs.jsonl 的 query/table 发给模型；不要发送本审核文件或 gold。',
                  '旧10题的自然性确认不会自动转移到新增题或改写后的题干。',
                  '重点判断：问句自然吗？群体解释合理吗？能否默认理解为总体？是否只是缺少总体数据？',
                  '数值核验通过不代表歧义审核通过；本版维度暂用 Perspective。', '']
        for r in records:
            dim = r['gold']['ambiguous_conditions'][0]['dimension']
            review += [f'## {r["id"]}', '', '**问题：** '+r['query'], '', r['table'], '',
                       '**Dimension：** '+dim, '', '| Condition | Answer |','|---|---|']
            for p in r['gold']['condition_answer_pairs']:
                review.append(f'| {cell(p["conditions"][dim])} | {cell(p["answer"])} |')
            review += ['', '**人工结论：** 自然性 待审；歧义性 待审；原问卷路由 待审。', '', '---','']
        (args.outdir/names[2]).write_text('\n'.join(review), encoding='utf-8')
        summary = {'selected_queries':len(records), 'condition_answer_pairs':sum(len(r['gold']['condition_answer_pairs']) for r in records),
                   'unique_question_texts':len({c['question'] for c in selected}), 'selected_by_axis':dict(collections.Counter(c['axis'] for c in selected)),
                   'keyword_attitude_like_selected':sum(c['opinion_keyword_match'] for c in selected),
                   'eligible_question_axis_pairs':len(candidates), 'eligible_unique_source_keys':len({c['source_key'] for c in candidates}),
                   'wave_audit':audit, 'seed':args.seed, 'dimension':args.dimension,
                   'thresholds':{'n_valid':args.min_n,'effective_n':args.min_ess,'winner_margin':args.min_margin},
                   'raw_archive_sha256':{'model_input':sha256(args.model_input), 'human_resp':sha256(args.human_resp)},
                   'checks':{'unique_ids':True,'unique_question_texts':True,'shares_sum_to_one':True,
                             'gold_matches_weighted_argmax':True,'table_rounding_preserves_winner':True,'model_inputs_exclude_gold':True},
                   'human_review':'pending', 'model_evaluation':'not_run',
                   'retained_pilot_source_items':sum((c['source_key'],c['axis']) in PILOT_KEYS for c in selected),
                   'caveats':['Selection favors distinct and stable group winners; not representative sampling.',
                              'Keyword attitude screen is heuristic; default permits other self-report items.',
                              'Group scope / native ambiguity / questionnaire eligibility need review.',
                              'No API called; no generated human responses; no statistical significance claim.']}
        (args.outdir/names[3]).write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
        print(f'COMPLETE: {len(records)} distinct queries; {summary["condition_answer_pairs"]} condition-answer pairs.')
        print('Selected axes:',summary['selected_by_axis'])
        print('Attitude-keyword matches:',summary['keyword_attitude_like_selected'])
        print('Human-readable review:',args.outdir/names[2])
        print('Gold file:',args.outdir/names[0]); print('Model input file:',args.outdir/names[1])
    except (OSError, ValueError, KeyError, TypeError, tarfile.TarError) as exc:
        ap.exit(1,f'ERROR: {exc}\n')


if __name__ == '__main__':
    main()

"""SF311 v2: short labels and <=100 source rows per question. Standard library only."""
import argparse
import hashlib
import json
import random
from pathlib import Path
import sf311_status_core as core
import standardize_benchmark as standard
from generate_sf311_event_status_200 import markdown_table

LABELS = {
    'pending': ['not closed', 'work status = open'],
    'underway': ['work status in {accepted, in progress}', 'work status = in progress'],
    'active': ['work status in {open, sent, accepted, in progress}', 'work status = in progress'],
}

def revise(source, candidates, output, cap=100, seed=20261009):
    if not 2 <= cap <= 100:
        raise ValueError('Table cap must be between 2 and 100.')
    raw, cases, _ = core.read_source(source)
    eligible, excluded = core.exclusions(cases)
    records = json.loads(candidates.read_text(encoding='utf-8'))
    cache = {}
    revised = []
    report = []
    review = ['# SF311 v2：200题人工审核', '',
              '每张表最多100行；短标签沿用原状态集合。答案只针对所给表格，不代表城市总体。',
              '抽样使用固定种子；若两种解释答案相同，则重新抽样。这是受控诊断构造。',
              '缺失、冲突状态仍排除；状态解释仍需人工确认，不声称为官方定义。', '']
    for old in records:
        family, scope, operation = old['family'], old['scope'], old['operation']
        pool = sorted(core.select_scope(eligible, scope), key=lambda r: r['CASE ID'])
        scope_key = json.dumps(scope, sort_keys=True)
        attempt = 0
        while True:
            cache_key = (scope_key, attempt)
            if cache_key not in cache:
                digest = hashlib.sha256(f'{seed}:{scope_key}:{attempt}'.encode()).hexdigest()
                cache[cache_key] = (random.Random(int(digest, 16)).sample(pool, cap)
                                    if len(pool) > cap else list(pool))
            rows = cache[cache_key]
            answers = [core.answer_python(rows, policy[3], operation)[0]
                       for policy in core.POLICIES[family]]
            # Ranking must differ in winning categories, not merely winning counts.
            comparable = ([a['categories'] for a in answers]
                          if operation == 'argmax_category' else answers)
            if comparable[0] != comparable[1]:
                break
            attempt += 1
            if len(pool) <= cap or attempt >= 100:
                raise ValueError(f"{old['id']}: no answer-sensitive capped table; replace this sample.")
        assert len(rows) <= cap and len({r['CASE ID'] for r in rows}) == len(rows)
        con = core.sql_connection(rows)
        for policy, answer in zip(core.POLICIES[family], answers):
            core.check_sql(con, scope, policy[3], operation, answer)
        con.close()
        row = dict(old)
        labels = LABELS[family]
        row['gold'] = {
            'ambiguous_conditions': [{'term': family, 'dimension': 'Event Status', 'conditions': labels}],
            'condition_answer_pairs': [
                {'conditions': {'Event Status': label}, 'answer': answer}
                for label, answer in zip(labels, answers)]}
        row['table'] = markdown_table(rows)
        row['scope_case_count'] = len(rows)
        row['evidence_group_id'] = hashlib.sha256('\n'.join(sorted(r['CASE ID'] for r in rows)).encode()).hexdigest()[:16]
        row['revision'] = {'version': 'v2', 'source_scope_cases': len(pool),
                           'table_row_cap': cap, 'seed': seed, 'sampling_attempt': attempt,
                           'sampled_case_ids': sorted(r['CASE ID'] for r in rows),
                           'old_gold': old['gold'],
                           'status_rules': {label: p[3] for label, p in zip(labels, core.POLICIES[family])}}
        row['semantic_validation_complete'] = False
        row['model_evaluated'] = False
        revised.append(row)
        report.append({'id': row['id'], 'old_rows': len(pool), 'new_rows': len(rows),
                       'answers_changed': [p['answer'] for p in old['gold']['condition_answer_pairs']] != answers,
                       'sampling_attempt': attempt})
        review.extend([f"## {row['id']} · Event Status", row['query'], row['query_zh'],
                       f'表格行数：{len(pool)} → {len(rows)}', ''])
        for label, policy, answer in zip(labels, core.POLICIES[family], answers):
            review.extend([f'**Condition：`{label}`**', policy[1],
                           '状态集合：'+', '.join(policy[3]), '**答案：'+core.answer_text(answer)+'**', ''])
        review.extend(['审核：问题自然 □是 □否；两个解释合理 □是 □否。', ''])
    output.mkdir(parents=True, exist_ok=True)
    converted = standard.convert(revised, require_table=True)
    standard.write_jsonl(output/'sf311_event_status_200_standard.jsonl', converted)
    standard.write_jsonl(output/'sf311_event_status_200_model_inputs.jsonl',
                         [{k:r[k] for k in ('id','query','table')} for r in converted])
    conditioned = []
    for r in converted:
        for index, pair in enumerate(r['gold']['condition_answer_pairs'], 1):
            conditioned.append({'id':r['id'], 'condition_index':index, 'query':r['query'],
                                'table':r['table'], 'condition':pair['conditions']['Event Status']})
    standard.write_jsonl(output/'sf311_event_status_200_condition_inputs.jsonl', conditioned)
    core.write_json(output/'sf311_event_status_200_candidates.json', revised)
    core.write_json(output/'revision_report.json', report)
    core.write_json(output/'validation_summary.json', {
        'version':'v2', 'queries':len(revised), 'condition_answer_pairs':len(conditioned),
        'max_table_rows':max(r['scope_case_count'] for r in revised),
        'tables_reduced':sum(r['old_rows']>r['new_rows'] for r in report),
        'questions_with_changed_answers':sum(r['answers_changed'] for r in report),
        'python_sqlite_checks_passed':len(conditioned), 'seed':seed,
        'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'human_semantic_review_complete':False, 'model_run':False,
        'sampling':'Seeded sampling by scope, with rejection if interpretations yield the same answer; controlled diagnostic construction.',
        'dimension_definition':'Event Status: alternative interpretations of a lifecycle/status term include different recorded processing stages while scope and counting unit remain fixed.',
        'scoring_note':'Scoring algorithm was not modified. Changed tables/answers require fresh model evaluation; condition labels must also match evaluator mappings.'})
    (output/'人工审核_200题.md').write_text('\n'.join(review), encoding='utf-8')
    print(json.dumps(json.loads((output/'validation_summary.json').read_text()), ensure_ascii=False, indent=2))

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--candidates', type=Path, required=True)
    p.add_argument('--output', type=Path, default=Path('results_v2'))
    p.add_argument('--cap', type=int, default=100)
    p.add_argument('--seed', type=int, default=20261009)
    args = p.parse_args()
    revise(args.source, args.candidates, args.output, args.cap, args.seed)

#!/usr/bin/env python3
"""Generate SF311 Event Status candidates in the supplied standardizer's schema.

Python 3.9+, standard library only. Place this script, sf311_status_core.py,
and standardize_benchmark.py in the same directory. No API or network calls.
"""
import argparse
import collections
import hashlib
import itertools
import json
import random
from pathlib import Path
import sf311_status_core as core
import standardize_benchmark as standard

def key(scope):
    return tuple(sorted(scope.items()))

def markdown_table(rows):
    fields=['CASE ID','STATUS','WORK STATUS','CATEGORY','NEIGHBORHOOD','SUPERVISOR DISTRICT']
    def cell(x): return str(x).replace('|','\\|').replace('\n',' ').replace('\r',' ')
    lines=['Scope: only the supplied rows, one per distinct CASE ID. These are recorded statuses in the export, not current citywide totals.',
           'Rows with missing or conflicting status fields were excluded before this table was built. Do not infer what happened to excluded cases.',
           'Count each CASE ID once. Blank area labels mean unknown, not another named area.', '',
           '| '+' | '.join(fields)+' |','| '+' | '.join(['---']*len(fields))+' |']
    lines += ['| '+' | '.join(cell(r[f]) for f in fields)+' |' for r in sorted(rows,key=lambda r:r['CASE ID'])]
    return '\n'.join(lines)

def query_for(family,scope):
    qualifier=[]
    if 'CATEGORY' in scope: qualifier.append('in the "'+scope['CATEGORY']+'" category')
    if 'NEIGHBORHOOD' in scope: qualifier.append('in the '+scope['NEIGHBORHOOD'].title()+' neighborhood')
    if 'SUPERVISOR DISTRICT' in scope: qualifier.append('in Supervisor District '+scope['SUPERVISOR DISTRICT'])
    where=' '.join(qualifier)
    query=f'In the supplied table, how many cases {where} are {family}?'
    word={'pending':'待处理','underway':'已进入处理阶段','active':'活跃'}[family]
    zh='在所给表格中，'
    if 'CATEGORY' in scope: zh+=scope['CATEGORY']+'类别、'
    if 'NEIGHBORHOOD' in scope: zh+=scope['NEIGHBORHOOD'].title()+'社区、'
    if 'SUPERVISOR DISTRICT' in scope: zh+='第'+scope['SUPERVISOR DISTRICT']+'行政区、'
    return query,zh.rstrip('、')+f'有多少{word}案件？'

def generate(source,out,n,seed,min_cases,max_cases):
    if n<10: raise ValueError('--n must be at least 10 to retain reviewed pilot questions')
    raw,cases,groups=core.read_source(source)
    eligible,excluded=core.exclusions(cases)
    con=core.sql_connection(eligible)
    existing={(family,key(scope),'count') for _,family,_,_,scope,op in core.SPECS if op=='count'}
    # Generate scopes exclusively from raw source fields; never from conditions/gold.
    scopes={}
    fields=['CATEGORY','NEIGHBORHOOD','SUPERVISOR DISTRICT']
    field_sets=[(f,) for f in fields]+list(itertools.combinations(fields,2))
    for fs in field_sets:
        for r in eligible:
            if all(r[f] for f in fs):
                scope={f:r[f] for f in fs}
                scopes[key(scope)]=scope
    table_cache={}; scoped_cache={}
    def scoped(scope):
        k=key(scope)
        if k not in scoped_cache: scoped_cache[k]=core.select_scope(eligible,scope)
        return scoped_cache[k]
    candidates={family:[] for family in core.POLICIES}
    for scope in scopes.values():
        rows=scoped(scope)
        if not min_cases<=len(rows)<=max_cases: continue
        for family,policies in core.POLICIES.items():
            if (family,key(scope),'count') in existing: continue
            a=[core.answer_python(rows,p[3],'count')[0] for p in policies]
            if len(set(a))<2 or min(a)<1: continue
            candidates[family].append(scope)
    rng=random.Random(seed)
    for family in candidates:
        candidates[family].sort(key=lambda s:repr(key(s)))
        rng.shuffle(candidates[family])
    available={f:len(v) for f,v in candidates.items()}
    selected=list(core.SPECS)
    family_order=['pending','underway','active']
    i=0
    while len(selected)<n:
        family=family_order[i%3]; i+=1
        if not candidates[family]:
            if not any(candidates.values()): raise ValueError(f'Only {len(selected)} suitable candidates available; lower --n or change scope limits. No duplicates or paraphrases were added to fill the target.')
            continue
        scope=candidates[family].pop()
        query,zh=query_for(family,scope)
        selected.append((f'SF_ES_{len(selected)+1:04d}',family,query,zh,scope,'count'))
    out.mkdir(parents=True,exist_ok=True)
    originals=[]; reviews=[]; checks=0
    seen_queries=set()
    for qid,family,query,zh,scope,operation in selected:
        if query in seen_queries: raise AssertionError('Duplicate question text')
        seen_queries.add(query)
        rows=scoped(scope)
        if key(scope) not in table_cache: table_cache[key(scope)]=markdown_table(rows)
        branches=[]; pairs=[]
        for cid,cz,ce,allowed in core.POLICIES[family]:
            answer,matched=core.answer_python(rows,allowed,operation)
            core.check_sql(con,scope,allowed,operation,answer);checks+=1
            branches.append({'condition_id':cid,'condition_en':ce,'condition_zh':cz,'status_field':'WORK STATUS','allowed_status_values':allowed,'answer':answer,'matched_case_ids':matched})
            pairs.append({'conditions':{'Event Status':ce},'answer':answer})
        assert branches[0]['answer']!=branches[1]['answer']
        ids='\n'.join(sorted(r['CASE ID'] for r in rows))
        scope_id=hashlib.sha256(ids.encode()).hexdigest()[:16]
        gold={'ambiguous_conditions':[{'term':family,'dimension':'Event Status','conditions':[b['condition_en'] for b in branches]}],'condition_answer_pairs':pairs}
        record={'id':qid,'dataset':'SF311','query':query,'table':table_cache[key(scope)],'gold':gold,
                'query_zh':zh,'dimension':'Event Status','family':family,'scope':scope,'operation':operation,
                'scope_case_count':len(rows),'evidence_group_id':scope_id,'semantic_group_id':family,
                'naturalness_review':{'passed':True,'reviewer':'user','basis':'User said all 10 pilot questions are natural; condition approval was not stated.'} if qid.startswith('ES') else {'passed':None,'reviewer':None},
                'condition_reasonableness_review':None,'semantic_validation_complete':False,'official_status_mapping_verified':False,
                'constructed_query':True,'condition_set_exhaustive':False,'model_evaluated':False}
        originals.append(record)
        reviews.append((record,branches))
    con.close()
    # Call the user's actual converter, not a reimplemented approximation.
    converted=standard.convert(originals,require_table=True)
    standard.write_jsonl(out/'sf311_event_status_200_standard.jsonl',converted)
    model_inputs=[{k:r[k] for k in ('id','query','table')} for r in converted]
    assert all(set(x)=={'id','query','table'} for x in model_inputs)
    standard.write_jsonl(out/'sf311_event_status_200_model_inputs.jsonl',model_inputs)
    conditioned=[]
    for row in converted:
        for index,pair in enumerate(row['gold']['condition_answer_pairs'],1):
            conditioned.append({'id':row['id'],'condition_index':index,'query':row['query'],'table':row['table'],'condition':pair['conditions']['Event Status']})
    standard.write_jsonl(out/'sf311_event_status_200_condition_inputs.jsonl',conditioned)
    core.write_json(out/'sf311_event_status_200_candidates.json',originals)
    core.write_json(out/'excluded_cases.json',excluded)
    summary={'source':source.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
             'queries':len(converted),'condition_answer_pairs':checks,'python_sqlite_checks_passed':checks,
             'schema_validated_by':'unchanged supplied standardize_benchmark.py: convert(..., require_table=True)',
             'standardizer_sha256':hashlib.sha256(Path(standard.__file__).read_bytes()).hexdigest(),
             'raw_rows':len(raw),'distinct_cases':len(cases),'eligible_cases':len(eligible),
             'excluded_reasons':dict(collections.Counter(r['reason'] for r in excluded)),
             'family_counts':dict(collections.Counter(r['family'] for r in originals)),
             'available_new_scopes_by_family':available,'seed':seed,'new_scope_limits':[min_cases,max_cases],
             'retained_pilot':10,'new_unreviewed_candidates':n-10,'naturalness_user_passed':10,'conditions_human_approved':0,
             'unique_question_texts':len(seen_queries),'unique_evidence_groups':len({r['evidence_group_id'] for r in originals}),
             'semantic_families':3,'evaluation_ready_means':'Independent context is present and schema valid; NOT human semantic approval.',
             'model_run':False,'limitations':['Three semantic families only; 200 does not mean 200 independent ambiguity types.',
                 'Do not split randomly by query: shared evidence and rules would leak across train/test. Split by semantic family or explicitly grouped evidence, depending on the claim.',
                 'All questions are controlled constructions, not naturally collected ambiguous user questions.',
                 'Only the original 10 questions have user naturalness approval; no condition approval is inferred.',
                 'No claim of official fine-grained WORK STATUS definitions or actual physical resolution.',
                 'Full standard rows contain gold inside gold and metadata. Send only query/table to a model.'],
             'source_context_method':'Table constructed from deduplicated eligible source rows and fixed scope fields before applying status conditions. No gold-answer tables or candidate status mappings in context.'}
    core.write_json(out/'validation_summary.json',summary)
    lines=['# SF311 Event Status：200条候选样本审核','',
           f'共{n}条问题，全部Event Status，每题两种condition及答案。前10条问题自然度已由你确认；其condition仍待确认。其余{n-10}条尚未人工审核。',
           '每题的数字只针对该题所给独立数据表，不是城市总体或当前状态。缺失/冲突工作状态均不纳入。',
           '所有数值由Python与SQLite独立核对。三种状态映射是待审核分析口径，不声称是官方定义。','']
    for row,branches in reviews:
        lines += [f'## {row["id"]} · Event Status',f'**{row["query"]}**',row['query_zh'],
                  f'固定范围：{json.dumps(row["scope"],ensure_ascii=False) or "全表"}；输入表包含{row["scope_case_count"]}个不同案件。',
                  '自然度：'+('你已确认问题自然；condition待确认。' if row['id'].startswith('ES') else '待审核。'),'']
        for label,b in zip(['A','B'],branches):
            lines += [f'**Condition {label}：{b["condition_zh"]}**',b['condition_en'],
                      '字段规则：WORK STATUS ∈ '+', '.join(b['allowed_status_values']),
                      '**答案：'+core.answer_text(b['answer'])+'**','']
        lines += ['审核：问题自然 □是 □否；A合理 □是 □否；B合理 □是 □否。','']
    (out/'人工审核_200题.md').write_text('\n'.join(lines),encoding='utf-8')
    print(f'完成 {len(converted)} 题 / {checks} 组条件答案；SQL核对全部通过。')
    print('固定字段：id/query/table/gold/evaluation_ready/metadata。')
    print('前10题只确认过问题自然度；新增候选及所有condition仍待人工审核。')
    print('输出：'+str(out))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--output',type=Path,default=Path('sf311_event_status_200'))
    p.add_argument('--n',type=int,default=200)
    p.add_argument('--seed',type=int,default=20261008)
    p.add_argument('--min-scope-cases',type=int,default=12)
    p.add_argument('--max-scope-cases',type=int,default=250)
    a=p.parse_args()
    if a.min_scope_cases<1 or a.max_scope_cases<a.min_scope_cases: p.error('Invalid scope size bounds')
    generate(a.source.resolve(),a.output.resolve(),a.n,a.seed,a.min_scope_cases,a.max_scope_cases)

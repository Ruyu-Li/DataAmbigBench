#!/usr/bin/env python3
"""Build an Event Status diagnostic pilot from the supplied SF311 export.

Python 3 standard library only. All 20 candidate answers are independently
checked with SQLite. No model API calls and no invented human ratings.
"""
import argparse
import collections
import csv
import hashlib
import json
import shutil
import sqlite3
from pathlib import Path

DIMENSION = 'Event Status'
KNOWN_OPEN_WORK = {'open', 'accepted', 'in progress', 'sent', 'on hold'}
POLICIES = {
    'pending': [
        ('pending_unclosed', '尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。',
         'Pending means not yet closed, irrespective of processing stage.', sorted(KNOWN_OPEN_WORK)),
        ('pending_waiting', '仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。',
         'Pending means only the work-status open stage, excluding other recorded stages.', ['open']),
    ],
    'underway': [
        ('underway_accepted_or_progress', '已进入受理/处理阶段：工作状态为 accepted 或 in progress。',
         'Underway includes accepted and in progress.', ['accepted', 'in progress']),
        ('underway_progress_only', '仅指明确正在处理的阶段：工作状态为 in progress。',
         'Underway means only explicitly in progress.', ['in progress']),
    ],
    'active': [
        ('active_open_not_hold', '仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。',
         'Active includes open, sent, accepted, and in progress; excludes on hold.', ['open', 'sent', 'accepted', 'in progress']),
        ('active_progress_only', '仅指正在执行处理的案件：工作状态为 in progress。',
         'Active means only explicitly in progress.', ['in progress']),
    ],
}

SPECS = [
    ('ES01', 'pending', 'How many cases are pending?', '有多少案件待处理？', {}, 'count'),
    ('ES02', 'pending', 'How many public-graffiti cases are pending?', '有多少公共区域涂鸦案件待处理？', {'CATEGORY':'Graffiti Public'}, 'count'),
    ('ES03', 'pending', 'How many tree-maintenance cases are pending?', '有多少树木维护案件待处理？', {'CATEGORY':'Tree Maintenance'}, 'count'),
    ('ES04', 'pending', 'How many cases in Supervisor District 9 are pending?', '第9行政区有多少案件待处理？', {'SUPERVISOR DISTRICT':'9'}, 'count'),
    ('ES05', 'underway', 'How many cases are underway?', '有多少案件已经进入处理阶段？', {}, 'count'),
    ('ES06', 'underway', 'How many sidewalk-and-curb cases are underway?', '有多少人行道及路缘案件已经进入处理阶段？', {'CATEGORY':'Sidewalk and Curb'}, 'count'),
    ('ES07', 'underway', 'How many cases in the Mission neighborhood are underway?', 'Mission 社区有多少案件已经进入处理阶段？', {'NEIGHBORHOOD':'MISSION'}, 'count'),
    ('ES08', 'active', 'How many cases are active?', '有多少案件处于活跃处理状态？', {}, 'count'),
    ('ES09', 'active', 'Which category has the most active cases?', '哪个案件类别的活跃案件最多？', {}, 'argmax_category'),
    ('ES10', 'active', 'What percentage of cases are active?', '活跃案件占全部案件的百分之几？', {}, 'percentage'),
]

def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def write_jsonl(path, objects):
    path.write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in objects), encoding='utf-8')

def read_source(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        required = {'CASE ID', 'STATUS', 'WORK STATUS', 'CATEGORY', 'NEIGHBORHOOD', 'SUPERVISOR DISTRICT', 'OPEN DT', 'CLOSED DT'}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError('Missing required fields: ' + str(required - set(reader.fieldnames or [])))
        raw = list(reader)
    groups = collections.defaultdict(list)
    for r in raw:
        if not r['CASE ID'].strip(): raise ValueError('Blank CASE ID')
        groups[r['CASE ID']].append(r)
    used = sorted(required - {'CASE ID'})
    conflicts = []
    for case_id, group in groups.items():
        bad = [k for k in used if len({r[k] for r in group}) > 1]
        if bad: conflicts.append({'case_id':case_id,'fields':bad})
    if conflicts: raise ValueError('Conflicting relevant fields within repeated IDs: ' + repr(conflicts[:10]))
    cases = []
    for case_id, group in groups.items():
        r = dict(group[0])
        r['STATUS'] = r['STATUS'].strip().lower()
        r['WORK STATUS'] = r['WORK STATUS'].strip().lower()
        r['NEIGHBORHOOD'] = r['NEIGHBORHOOD'].strip().upper()
        r['SUPERVISOR DISTRICT'] = r['SUPERVISOR DISTRICT'].strip()
        cases.append(r)
    return raw, cases, groups

def exclusions(cases):
    eligible, rejected = [], []
    for r in cases:
        if not r['WORK STATUS']: reason='missing_work_status'
        elif (r['STATUS']=='open' and r['WORK STATUS']=='closed') or (r['STATUS']=='closed' and r['WORK STATUS'] in KNOWN_OPEN_WORK): reason='conflicting_status_fields'
        elif r['STATUS']!='open' or r['WORK STATUS'] not in KNOWN_OPEN_WORK: reason='unsupported_status_for_this_pilot'
        else:
            eligible.append(r)
            continue
        rejected.append({'case_id':r['CASE ID'],'status':r['STATUS'],'work_status':r['WORK STATUS'],'reason':reason})
    return eligible, rejected

def select_scope(rows, scope):
    return [r for r in rows if all(r[k]==v for k,v in scope.items())]

def answer_python(scoped, allowed, operation):
    matched = [r for r in scoped if r['WORK STATUS'] in allowed]
    ids = sorted(r['CASE ID'] for r in matched)
    if operation=='count': answer=len(matched)
    elif operation=='percentage':
        if not scoped: raise ValueError('Empty percentage denominator')
        answer={'numerator':len(matched),'denominator':len(scoped),'percent':round(100*len(matched)/len(scoped),4)}
    elif operation=='argmax_category':
        counts = collections.Counter(r['CATEGORY'] for r in matched)
        if not counts: raise ValueError('Empty category ranking')
        best=max(counts.values())
        answer={'categories':sorted(k for k,n in counts.items() if n==best),'case_count':best}
    else: raise ValueError(operation)
    return answer, ids

def sql_connection(eligible):
    con=sqlite3.connect(':memory:')
    con.execute('CREATE TABLE cases (case_id TEXT PRIMARY KEY, status TEXT, work_status TEXT, category TEXT, neighborhood TEXT, district TEXT)')
    con.executemany('INSERT INTO cases VALUES (?,?,?,?,?,?)',[(r['CASE ID'],r['STATUS'],r['WORK STATUS'],r['CATEGORY'],r['NEIGHBORHOOD'],r['SUPERVISOR DISTRICT']) for r in eligible])
    return con

def check_sql(con, scope, allowed, operation, expected):
    names={'CATEGORY':'category','NEIGHBORHOOD':'neighborhood','SUPERVISOR DISTRICT':'district'}
    filters=[names[k]+' = ?' for k in scope]
    base=' AND '.join(filters) or '1=1'
    params=list(scope.values())
    condition=base+' AND work_status IN ('+','.join('?' for _ in allowed)+')'
    n=con.execute('SELECT COUNT(*) FROM cases WHERE '+condition,params+allowed).fetchone()[0]
    if operation=='count': result=n
    elif operation=='percentage':
        d=con.execute('SELECT COUNT(*) FROM cases WHERE '+base,params).fetchone()[0]
        result={'numerator':n,'denominator':d,'percent':round(n/d*100,4)}
    else:
        ranks=con.execute('SELECT category,COUNT(*) FROM cases WHERE '+condition+' GROUP BY category ORDER BY COUNT(*) DESC,category',params+allowed).fetchall()
        result={'categories':sorted(k for k,c in ranks if c==ranks[0][1]),'case_count':ranks[0][1]}
    if result != expected: raise AssertionError((result,expected))

def answer_text(answer):
    if isinstance(answer,int): return f'{answer:,} 个案件'
    if 'percent' in answer: return f'{answer["percent"]:.4f}%（{answer["numerator"]:,} / {answer["denominator"]:,}）'
    return '、'.join(answer['categories'])+f'，{answer["case_count"]:,} 个案件'

def build(source, out):
    raw,cases,groups=read_source(source)
    eligible,rejected=exclusions(cases)
    if not eligible: raise ValueError('No eligible cases')
    out.mkdir(parents=True,exist_ok=True)
    con=sql_connection(eligible)
    context = {
        'universe':'Only the supplied status_review_table.csv. Each row is one distinct case ID with a nonblank supported WORK STATUS and consistent STATUS. Do not infer citywide or current counts.',
        'row_count':len(eligible),
        'fixed_rules':['Count distinct CASE ID.','Normalize NEIGHBORHOOD case and whitespace.','Category filters use exact labels.','No dates, geographical boundaries, or grouping levels are left unspecified.','Answers describe recorded labels in this export, not observed physical resolution.'],
        'columns':['CASE ID','STATUS','WORK STATUS','CATEGORY','NEIGHBORHOOD','SUPERVISOR DISTRICT'],
        'observed_work_status_values':sorted({r['WORK STATUS'] for r in eligible}),
    }
    pilot=[]; detection=[]; conditioned=[]; end_to_end=[]
    for qid,family,query,zh,scope,operation in SPECS:
        scoped=select_scope(eligible,scope)
        branches=[]
        for cid,cz,ce,allowed in POLICIES[family]:
            answer,ids=answer_python(scoped,allowed,operation)
            check_sql(con,scope,allowed,operation,answer)
            branch={
                'condition_id':cid, 'condition_zh':cz,'condition_en':ce,
                'status_rule':{'field':'WORK STATUS','allowed_values':allowed},
                'answer':answer,'matched_case_ids':ids,
                'matched_count':len(ids),'scope_count':len(scoped),
                'answer_verification':'Python aggregate agrees with independent SQLite aggregate',
            }
            branches.append(branch)
            conditioned.append({'query_id':qid,'condition_id':cid,'query':query,'context':context,'scope':scope,'condition':ce,'status_rule':branch['status_rule'],'expected_answer':answer,'input_table':'status_review_table.csv','validation_status':'provisional_semantic_mapping_not_human_approved'})
        sensitive=len({json.dumps(b['answer'],sort_keys=True) for b in branches})>1
        sample={'query_id':qid,'dimension':DIMENSION,'query':query,'query_zh':zh,'family':family,'scope':scope,'operation':operation,'universe':context,'conditions':branches,
                'answer_sensitive':sensitive,'semantic_status':'needs_human_review','naturalness_review':None,'condition_reasonableness_review':None,
                'construction':'controlled, author-constructed diagnostic query; not naturally collected user query',
                'condition_set_exhaustive':False,'official_mapping_verified':False,'model_evaluated':False}
        pilot.append(sample)
        inp={'query_id':qid,'query':query,'context':context,'scope':scope,'input_table':'status_review_table.csv'}
        detection.append(inp|{'task':'Identify whether the question has an underspecified interpretation and state the missing condition. Do not compute an answer.'})
        end_to_end.append(inp|{'task':'Identify plausible interpretations, state the corresponding status rules, and answer under each interpretation.'})
    con.close()
    assert len(pilot)==10 and all(x['dimension']==DIMENSION for x in pilot)
    assert all(x['answer_sensitive'] for x in pilot), 'A candidate does not change answers'
    assert len(conditioned)==20
    for x in pilot:
        for b in x['conditions']:
            assert len(b['matched_case_ids'])==len(set(b['matched_case_ids']))==b['matched_count']
            assert b['matched_count']<=b['scope_count']
    fieldnames=context['columns']
    with (out/'status_review_table.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fieldnames);w.writeheader()
        w.writerows({k:r[k] for k in fieldnames} for r in sorted(eligible,key=lambda r:r['CASE ID']))
    write_json(out/'pilot_10_event_status.json',pilot)
    write_jsonl(out/'detection_inputs.jsonl',detection)
    write_jsonl(out/'condition_given_inputs.jsonl',conditioned)
    write_jsonl(out/'end_to_end_inputs.jsonl',end_to_end)
    write_json(out/'excluded_cases.json',rejected)
    conflicts=collections.Counter(k for group in groups.values() if len(group)>1 for k in raw[0] if len({r[k] for r in group})>1)
    audit={
        'source':source.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'dimension':DIMENSION,
        'raw_rows':len(raw),'distinct_case_ids':len(cases),'eligible_case_ids':len(eligible),
        'excluded_by_reason':dict(collections.Counter(r['reason'] for r in rejected)),
        'normalized_work_status_unique_case_counts':dict(collections.Counter(r['WORK STATUS'] or '(missing)' for r in cases)),
        'duplicate_id_conflict_fields':dict(conflicts),'used_field_duplicate_conflicts':0,
        'candidate_queries':10,'conditions':20,'distinct_semantic_families':3,
        'python_sqlite_answer_checks_passed':20,'answer_sensitive_queries':sum(x['answer_sensitive'] for x in pilot),
        'all_labels_event_status':True,'human_review_completed':False,'official_mapping_verified':False,'llm_evaluation_completed':False,
        'limitations':['All STATUS values in this input are open.','No event history, so transition times and past statuses cannot be recovered.','No reliable resolved/completed distinction can be validated from this input.','Missing WORK STATUS is never imputed as unprocessed.','Condition mappings are candidate analyst interpretations, not confirmed city definitions.','Ten examples cover three reusable semantic families, not ten independent ambiguity types.','Closed WORK STATUS with Open STATUS is quarantined rather than used as status ambiguity evidence.'],
        'sources':[{'url':'https://data.sf.gov/-/SF311-Recent-Cases/d9fx-8m7k/about_data','purpose':'dataset source; downloaded CSV is authoritative for numbers'},
                   {'url':'https://data.sfgov.org/dataset/SF311-Recent-Cases/d9fx-8m7k','purpose':'public field listing exposes WORK STATUS; no sufficient detailed mapping retrieved'}]
    }
    write_json(out/'validation_summary.json',audit)
    lines=['# SF311：10条 Event Status 人工审核题','',
           '**只看这份文件即可：每条问题、中文、两种condition、精确字段规则和答案都在下面。**','',
           '上一版时间/区域/计数口径题不属于本轮。本轮10题的dimension统一为 **Event Status（事件状态）**。',
           '这些题是待审核的人工构造诊断题；尚未通过人工审核，也未跑模型。不同条件答案不同，只证明计算上有区别，不证明所有解释都自然合理。','',
           '## 固定数据范围',
           f'原始导出有 {len(raw):,} 行、{len(cases):,} 个不同案件。统一去重后，本轮只使用工作状态已记录且无状态冲突的 **{len(eligible):,} 个案件**。',
           f'工作状态缺失的 {sum(r["reason"]=="missing_work_status" for r in rejected):,} 个案件、状态字段冲突的 {sum(r["reason"]=="conflicting_status_fields" for r in rejected)} 个案件另存，不算作未处理。',
           '所有问题中的“案件”均指这份固定审核表中的案件；不是城市总体，也不是今天的状态。比例分母同样限定为这份表。',
           '区域/类别条件固定写明，计数固定按不同CASE ID，唯一待解释的是状态用语。Mission指NEIGHBORHOOD，不是警区。',
           '字段规则属于本轮待审核的分析口径，不声称是SF311官方状态定义。没有状态历史，不推断实际完成、解决、响应时间或状态转移。','',
           '## 你需要检查什么',
           '每题只检查两项：①问题读起来自然吗？②两个condition是否都是这个问题的合理解释？如果某个解释牵强，指出题号和condition A/B即可。',
           '请分别记录问题自然度和condition合理性；“问题自然”不自动等于两个condition都成立。答案已经由Python和SQLite分别计算核对。','']
    for x in pilot:
        lines += [f'## {x["query_id"]} · Event Status',f'**问题：{x["query"]}**',f'中文：{x["query_zh"]}',
                  f'固定范围：{json.dumps(x["scope"],ensure_ascii=False) if x["scope"] else "整个固定审核表"}；共 {x["conditions"][0]["scope_count"]:,} 个案件。','']
        for label,b in zip(['A','B'],x['conditions']):
            values=' / '.join(b['status_rule']['allowed_values'])
            lines += [f'**Condition {label}：{b["condition_zh"]}**',f'英文条件：{b["condition_en"]}',
                      f'字段规则：`WORK STATUS` 属于 `{values}`。',f'**答案：{answer_text(b["answer"])}**','']
        lines += ['人工审核：问题自然 □是 □否；A解释合理 □是 □否；B解释合理 □是 □否。','']
    lines += ['## 三组状态解释与数据限制',
              '- ES01–ES04：pending，全部未结案 vs 仅工作状态open。',
              '- ES05–ES07：underway，已受理或正在处理 vs 仅明确正在处理。',
              '- ES08–ES10：active，非暂停的开放流程 vs 仅明确正在处理。',
              '10题只有3组语义规则，不应当作10种独立歧义。pending、underway和active的广义解释需要你审核，不能为凑数量直接认定成立。',
              '目前不构造closed vs resolved/completed的标准答案：现有导出缺乏可靠的完成证据。','',
              '## 文件用途',
              '- `人工审核_10题_Event_Status.md`：你要看的唯一审核文件。',
              '- `pilot_10_event_status.json`：10题完整候选ground truth、condition、答案和匹配案件ID。',
              '- `status_review_table.csv`：固定输入表。',
              '- `detection_inputs.jsonl`：检测任务输入，未泄露ground truth标签及候选规则。',
              '- `condition_given_inputs.jsonl`：20条给定条件输入及预期答案；调用模型时应移除expected_answer。',
              '- `end_to_end_inputs.jsonl`：端到端输入，未泄露ground truth答案及候选规则。',
              '- `validation_summary.json`、`excluded_cases.json`：检查结果及排除原因。',
              '- `build_event_status.py`：从原始CSV重新构建所有文件的独立代码。',
              '通过condition审核后才能定稿ground truth。模型试跑尚未执行，不能报告F1或准确率。']
    (out/'人工审核_10题_Event_Status.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (out/'README.md').write_text(
        '# SF311 Event Status rebuild\n\n'
        'Start with 人工审核_10题_Event_Status.md. This version supersedes the earlier generic SF311 pilot for the Event Status goal.\n\n'
        'Reproduce using Python 3 (standard library only):\n\n'
        '```bash\npython build_event_status.py --source source/SF311_-_Recent_Cases_20261008.csv --output rebuilt\n```\n\n'
        'No API key is needed. No LLM is invoked. The builder creates 10 candidates, 20 condition answers, and checks Python results against SQLite.\n'
        'Mappings are provisional analyst interpretations. Human naturalness and condition reasonableness are separate, currently unfilled reviews.\n',encoding='utf-8')
    print(json.dumps({'eligible':len(eligible),'checks_passed':20,'questions':[{ 'id':x['query_id'],'answers':[b['answer'] for b in x['conditions']]} for x in pilot]},ensure_ascii=False,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    build(args.source.resolve(),args.output.resolve())

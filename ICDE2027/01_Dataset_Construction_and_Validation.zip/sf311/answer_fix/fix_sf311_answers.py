import argparse
import copy
import json
from pathlib import Path

def write_jsonl(path, rows):
    path.write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in rows), encoding='utf-8')

def fix(source, review, output):
    rows = [json.loads(line) for line in source.read_text(encoding='utf-8').splitlines() if line.strip()]
    before = copy.deepcopy(rows)
    changed = []
    for row in rows:
        if row['id'] not in ('ES09', 'ES10'):
            continue
        for pair in row['gold']['condition_answer_pairs']:
            old = pair['answer']
            if row['id'] == 'ES09':
                assert len(old['categories']) == 1, 'Cannot flatten a tied ranking'
                pair['answer'] = old['categories'][0]
            else:
                pair['answer'] = old['percent']
        original = row['metadata']['original_record']
        original['gold'] = copy.deepcopy(row['gold'])
        original['answer_format_revision'] = {
            'version':'v3', 'note':'ES09 is a category string; ES10 is a percentage number on the 0-100 scale.',
            'previous_condition_answer_pairs': next(r for r in before if r['id']==row['id'])['gold']['condition_answer_pairs']}
        if row['id'] == 'ES10':
            row['query'] = 'What percentage of cases are active? Give the percentage on a 0–100 scale.'
            original['query'] = row['query']
            original['query_zh'] = '活跃案件占全部案件的百分之几？请按0–100的百分比数值回答。'
        changed.append(row['id'])
    assert changed == ['ES09','ES10'] and len(rows)==200
    for old, new in zip(before, rows):
        assert old['table'] == new['table']
        if old['id'] not in changed:
            assert old == new
        assert all(isinstance(p['answer'],(str,int,float)) for p in new['gold']['condition_answer_pairs'])
    output.mkdir(parents=True,exist_ok=True)
    write_jsonl(output/'sf311_event_status_200_standard.jsonl',rows)
    inputs = [{k:r[k] for k in ('id','query','table')} for r in rows]
    assert all(set(r)=={'id','query','table'} for r in inputs)
    write_jsonl(output/'sf311_event_status_200_model_inputs.jsonl',inputs)
    conditioned = []
    for r in rows:
        for i,p in enumerate(r['gold']['condition_answer_pairs'],1):
            conditioned.append({'id':r['id'],'condition_index':i,'query':r['query'],
                                'table':r['table'],'condition':p['conditions']['Event Status']})
    write_jsonl(output/'sf311_event_status_200_condition_inputs.jsonl',conditioned)
    text = review.read_text(encoding='utf-8')
    for r in rows:
        if r['id'] not in changed:
            continue
        start=text.index('## '+r['id']+' ·')
        end=text.find('\n## ',start+1)
        if end<0: end=len(text)
        old_section=text[start:end]
        original=r['metadata']['original_record']
        lines=[f"## {r['id']} · Event Status",r['query'],original['query_zh'],
               f"表格行数：{original['revision']['source_scope_cases']} → {original['scope_case_count']}", '']
        for p in r['gold']['condition_answer_pairs']:
            label=p['conditions']['Event Status']
            lines.extend([f'**Condition：`{label}`**',
                          '状态集合：'+', '.join(original['revision']['status_rules'][label]),
                          '**答案：'+str(p['answer'])+('（百分比，0–100尺度）' if r['id']=='ES10' else '')+'**',''])
        lines.extend(['审核：问题自然 □是 □否；两个解释合理 □是 □否。',''])
        text=text[:start]+'\n'.join(lines)+text[end:]
    (output/'人工审核_200题.md').write_text(text,encoding='utf-8')
    print('完成：200题、400组答案；仅修改ES09/ES10，所有表格保持一致。')
    print('模型输入：sf311_event_status_200_model_inputs.jsonl')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--review',type=Path,required=True)
    p.add_argument('--output',type=Path,default=Path('results_final'))
    a=p.parse_args()
    fix(a.source,a.review,a.output)

# SF311 v2：200题人工审核

每张表最多100行；短标签沿用原状态集合。答案只针对所给表格，不代表城市总体。
抽样使用固定种子；若两种解释答案相同，则重新抽样。这是受控诊断构造。
缺失、冲突状态仍排除；状态解释仍需人工确认，不声称为官方定义。

## ES01 · Event Status
How many cases are pending?
有多少案件待处理？
表格行数：3782 → 100

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：100 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：42 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## ES02 · Event Status
How many public-graffiti cases are pending?
有多少公共区域涂鸦案件待处理？
表格行数：845 → 100

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：100 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：86 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## ES03 · Event Status
How many tree-maintenance cases are pending?
有多少树木维护案件待处理？
表格行数：309 → 100

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：100 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：51 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## ES04 · Event Status
How many cases in Supervisor District 9 are pending?
第9行政区有多少案件待处理？
表格行数：579 → 100

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：100 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：56 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## ES05 · Event Status
How many cases are underway?
有多少案件已经进入处理阶段？
表格行数：3782 → 100

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：43 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：17 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## ES06 · Event Status
How many sidewalk-and-curb cases are underway?
有多少人行道及路缘案件已经进入处理阶段？
表格行数：393 → 100

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：86 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：6 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## ES07 · Event Status
How many cases in the Mission neighborhood are underway?
Mission 社区有多少案件已经进入处理阶段？
表格行数：392 → 100

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：28 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## ES08 · Event Status
How many cases are active?
有多少案件处于活跃处理状态？
表格行数：3782 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：17 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## ES09 · Event Status
Which category has the most active cases?
哪个案件类别的活跃案件最多？
表格行数：3782 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：Graffiti Public，24 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：Street and Sidewalk Cleaning，13 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## ES10 · Event Status
What percentage of cases are active?
活跃案件占全部案件的百分之几？
表格行数：3782 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100.0000%（100 / 100）**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：17.0000%（17 / 100）**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0011 · Event Status
In the supplied table, how many cases in the Financial District neighborhood are pending?
在所给表格中，Financial District社区有多少待处理案件？
表格行数：16 → 16

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：16 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0012 · Event Status
In the supplied table, how many cases in Supervisor District 2 are underway?
在所给表格中，第2行政区有多少已进入处理阶段案件？
表格行数：238 → 100

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：38 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：8 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0013 · Event Status
In the supplied table, how many cases in the Hayes Valley neighborhood are active?
在所给表格中，Hayes Valley社区有多少活跃案件？
表格行数：53 → 53

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：53 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0014 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Bayview neighborhood are pending?
在所给表格中，Graffiti Public类别、Bayview社区有多少待处理案件？
表格行数：43 → 43

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：43 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：36 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0015 · Event Status
In the supplied table, how many cases in the Hayes Valley neighborhood in Supervisor District 5 are underway?
在所给表格中，Hayes Valley社区、第5行政区有多少已进入处理阶段案件？
表格行数：53 → 53

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：13 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0016 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in Supervisor District 5 are active?
在所给表格中，Graffiti Public类别、第5行政区有多少活跃案件？
表格行数：163 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0017 · Event Status
In the supplied table, how many cases in the Bret Harte neighborhood are pending?
在所给表格中，Bret Harte社区有多少待处理案件？
表格行数：12 → 12

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：12 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0018 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in the Golden Gate Heights neighborhood are underway?
在所给表格中，Sidewalk and Curb类别、Golden Gate Heights社区有多少已进入处理阶段案件？
表格行数：23 → 23

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：23 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0019 · Event Status
In the supplied table, how many cases in the Central Waterfront neighborhood are active?
在所给表格中，Central Waterfront社区有多少活跃案件？
表格行数：49 → 49

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：49 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：16 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0020 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in Supervisor District 3 are pending?
在所给表格中，Sidewalk and Curb类别、第3行政区有多少待处理案件？
表格行数：12 → 12

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：12 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0021 · Event Status
In the supplied table, how many cases in the Dogpatch neighborhood are underway?
在所给表格中，Dogpatch社区有多少已进入处理阶段案件？
表格行数：25 → 25

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：5 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0022 · Event Status
In the supplied table, how many cases in the Outer Richmond neighborhood in Supervisor District 1 are active?
在所给表格中，Outer Richmond社区、第1行政区有多少活跃案件？
表格行数：50 → 50

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：50 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0023 · Event Status
In the supplied table, how many cases in the West Portal neighborhood are pending?
在所给表格中，West Portal社区有多少待处理案件？
表格行数：16 → 16

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：16 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：6 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0024 · Event Status
In the supplied table, how many cases in the Excelsior neighborhood in Supervisor District 11 are underway?
在所给表格中，Excelsior社区、第11行政区有多少已进入处理阶段案件？
表格行数：27 → 27

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：12 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0025 · Event Status
In the supplied table, how many cases in the Fairmount neighborhood are active?
在所给表格中，Fairmount社区有多少活跃案件？
表格行数：15 → 15

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：15 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0026 · Event Status
In the supplied table, how many cases in the "Illegal Postings" category in Supervisor District 2 are pending?
在所给表格中，Illegal Postings类别、第2行政区有多少待处理案件？
表格行数：54 → 54

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：54 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：53 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0027 · Event Status
In the supplied table, how many cases in the Laurel Heights / Jordan Park neighborhood are underway?
在所给表格中，Laurel Heights / Jordan Park社区有多少已进入处理阶段案件？
表格行数：25 → 25

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：9 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0028 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in the Outer Sunset neighborhood are active?
在所给表格中，Sidewalk and Curb类别、Outer Sunset社区有多少活跃案件？
表格行数：13 → 13

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：13 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0029 · Event Status
In the supplied table, how many cases in the "Street Defect" category in Supervisor District 2 are pending?
在所给表格中，Street Defect类别、第2行政区有多少待处理案件？
表格行数：14 → 14

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：14 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0030 · Event Status
In the supplied table, how many cases in the Tenderloin neighborhood are underway?
在所给表格中，Tenderloin社区有多少已进入处理阶段案件？
表格行数：96 → 96

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：51 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：32 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0031 · Event Status
In the supplied table, how many cases in the Bernal Heights neighborhood in Supervisor District 9 are active?
在所给表格中，Bernal Heights社区、第9行政区有多少活跃案件？
表格行数：46 → 46

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：46 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：9 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0032 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Panhandle neighborhood are pending?
在所给表格中，Graffiti Public类别、Panhandle社区有多少待处理案件？
表格行数：17 → 17

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：17 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：16 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0033 · Event Status
In the supplied table, how many cases in the Forest Hill neighborhood in Supervisor District 7 are underway?
在所给表格中，Forest Hill社区、第7行政区有多少已进入处理阶段案件？
表格行数：15 → 15

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：7 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0034 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Cayuga neighborhood are active?
在所给表格中，Graffiti Public类别、Cayuga社区有多少活跃案件？
表格行数：43 → 43

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：43 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0035 · Event Status
In the supplied table, how many cases in the West Portal neighborhood in Supervisor District 7 are pending?
在所给表格中，West Portal社区、第7行政区有多少待处理案件？
表格行数：16 → 16

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：16 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：6 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0036 · Event Status
In the supplied table, how many cases in the Silver Terrace neighborhood in Supervisor District 10 are underway?
在所给表格中，Silver Terrace社区、第10行政区有多少已进入处理阶段案件？
表格行数：46 → 46

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：32 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：24 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0037 · Event Status
In the supplied table, how many cases in the Apparel City neighborhood are active?
在所给表格中，Apparel City社区有多少活跃案件？
表格行数：12 → 12

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：12 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0038 · Event Status
In the supplied table, how many cases in the Lower Pacific Heights neighborhood in Supervisor District 5 are pending?
在所给表格中，Lower Pacific Heights社区、第5行政区有多少待处理案件？
表格行数：26 → 26

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：26 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：16 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0039 · Event Status
In the supplied table, how many cases in the Parkside neighborhood in Supervisor District 4 are underway?
在所给表格中，Parkside社区、第4行政区有多少已进入处理阶段案件？
表格行数：32 → 32

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：12 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0040 · Event Status
In the supplied table, how many cases in the Sunnyside neighborhood are active?
在所给表格中，Sunnyside社区有多少活跃案件？
表格行数：31 → 31

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：31 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0041 · Event Status
In the supplied table, how many cases in the "Sewer" category are pending?
在所给表格中，Sewer类别有多少待处理案件？
表格行数：63 → 63

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：63 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：37 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0042 · Event Status
In the supplied table, how many cases in the Visitacion Valley neighborhood are underway?
在所给表格中，Visitacion Valley社区有多少已进入处理阶段案件？
表格行数：36 → 36

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：26 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：14 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0043 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in Supervisor District 10 are active?
在所给表格中，Sidewalk and Curb类别、第10行政区有多少活跃案件？
表格行数：115 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0044 · Event Status
In the supplied table, how many cases in the "Street and Sidewalk Cleaning" category in the Lower Nob Hill neighborhood are pending?
在所给表格中，Street and Sidewalk Cleaning类别、Lower Nob Hill社区有多少待处理案件？
表格行数：17 → 17

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：17 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0045 · Event Status
In the supplied table, how many cases in the Dolores Heights neighborhood in Supervisor District 8 are underway?
在所给表格中，Dolores Heights社区、第8行政区有多少已进入处理阶段案件？
表格行数：24 → 24

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：11 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0046 · Event Status
In the supplied table, how many cases in the Outer Sunset neighborhood in Supervisor District 4 are active?
在所给表格中，Outer Sunset社区、第4行政区有多少活跃案件？
表格行数：106 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：11 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0047 · Event Status
In the supplied table, how many cases in the North Beach neighborhood in Supervisor District 3 are pending?
在所给表格中，North Beach社区、第3行政区有多少待处理案件？
表格行数：34 → 34

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：34 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：10 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0048 · Event Status
In the supplied table, how many cases in the Portola neighborhood are underway?
在所给表格中，Portola社区有多少已进入处理阶段案件？
表格行数：94 → 94

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：46 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：21 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0049 · Event Status
In the supplied table, how many cases in the Nob Hill neighborhood in Supervisor District 3 are active?
在所给表格中，Nob Hill社区、第3行政区有多少活跃案件？
表格行数：47 → 47

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：45 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：8 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0050 · Event Status
In the supplied table, how many cases in the Japantown neighborhood in Supervisor District 5 are pending?
在所给表格中，Japantown社区、第5行政区有多少待处理案件？
表格行数：18 → 18

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：18 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0051 · Event Status
In the supplied table, how many cases in the Union Street neighborhood in Supervisor District 2 are underway?
在所给表格中，Union Street社区、第2行政区有多少已进入处理阶段案件？
表格行数：19 → 19

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：8 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0052 · Event Status
In the supplied table, how many cases in the Forest Hill neighborhood are active?
在所给表格中，Forest Hill社区有多少活跃案件？
表格行数：15 → 15

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：15 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0053 · Event Status
In the supplied table, how many cases in the Lower Nob Hill neighborhood are pending?
在所给表格中，Lower Nob Hill社区有多少待处理案件？
表格行数：49 → 49

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：49 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：14 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0054 · Event Status
In the supplied table, how many cases in the Glen Park neighborhood are underway?
在所给表格中，Glen Park社区有多少已进入处理阶段案件？
表格行数：14 → 14

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：6 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0055 · Event Status
In the supplied table, how many cases in the "Street Defect" category are active?
在所给表格中，Street Defect类别有多少活跃案件？
表格行数：180 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0056 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in the Mission Terrace neighborhood are pending?
在所给表格中，Sidewalk and Curb类别、Mission Terrace社区有多少待处理案件？
表格行数：13 → 13

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：13 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0057 · Event Status
In the supplied table, how many cases in the West Portal neighborhood are underway?
在所给表格中，West Portal社区有多少已进入处理阶段案件？
表格行数：16 → 16

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：6 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0058 · Event Status
In the supplied table, how many cases in the Sutro Heights neighborhood are active?
在所给表格中，Sutro Heights社区有多少活跃案件？
表格行数：16 → 16

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：15 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0059 · Event Status
In the supplied table, how many cases in the Alamo Square neighborhood are pending?
在所给表格中，Alamo Square社区有多少待处理案件？
表格行数：17 → 17

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：17 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：15 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0060 · Event Status
In the supplied table, how many cases in the North Beach neighborhood are underway?
在所给表格中，North Beach社区有多少已进入处理阶段案件？
表格行数：34 → 34

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：16 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：9 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0061 · Event Status
In the supplied table, how many cases in the Russian Hill neighborhood in Supervisor District 3 are active?
在所给表格中，Russian Hill社区、第3行政区有多少活跃案件？
表格行数：42 → 42

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：42 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0062 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in Supervisor District 3 are pending?
在所给表格中，Graffiti Public类别、第3行政区有多少待处理案件？
表格行数：43 → 43

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：43 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：38 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0063 · Event Status
In the supplied table, how many cases in the Sunnyside neighborhood are underway?
在所给表格中，Sunnyside社区有多少已进入处理阶段案件？
表格行数：31 → 31

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：17 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0064 · Event Status
In the supplied table, how many cases in the Glen Park neighborhood are active?
在所给表格中，Glen Park社区有多少活跃案件？
表格行数：14 → 14

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：14 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0065 · Event Status
In the supplied table, how many cases in the Excelsior neighborhood in Supervisor District 11 are pending?
在所给表格中，Excelsior社区、第11行政区有多少待处理案件？
表格行数：27 → 27

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：27 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：11 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0066 · Event Status
In the supplied table, how many cases in the Produce Market neighborhood in Supervisor District 10 are underway?
在所给表格中，Produce Market社区、第10行政区有多少已进入处理阶段案件？
表格行数：28 → 28

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：11 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：8 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0067 · Event Status
In the supplied table, how many cases in the Produce Market neighborhood in Supervisor District 10 are active?
在所给表格中，Produce Market社区、第10行政区有多少活跃案件？
表格行数：28 → 28

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：28 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：8 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0068 · Event Status
In the supplied table, how many cases in the Mission Dolores neighborhood in Supervisor District 8 are pending?
在所给表格中，Mission Dolores社区、第8行政区有多少待处理案件？
表格行数：37 → 37

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：37 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：21 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0069 · Event Status
In the supplied table, how many cases in the Lower Haight neighborhood are underway?
在所给表格中，Lower Haight社区有多少已进入处理阶段案件？
表格行数：45 → 45

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：15 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0070 · Event Status
In the supplied table, how many cases in the Noe Valley neighborhood are active?
在所给表格中，Noe Valley社区有多少活跃案件？
表格行数：60 → 60

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：60 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0071 · Event Status
In the supplied table, how many cases in the Cathedral Hill neighborhood are pending?
在所给表格中，Cathedral Hill社区有多少待处理案件？
表格行数：33 → 33

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：33 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：12 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0072 · Event Status
In the supplied table, how many cases in the Japantown neighborhood in Supervisor District 5 are underway?
在所给表格中，Japantown社区、第5行政区有多少已进入处理阶段案件？
表格行数：18 → 18

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：10 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0073 · Event Status
In the supplied table, how many cases in the "Damage Property" category are active?
在所给表格中，Damage Property类别有多少活跃案件？
表格行数：35 → 35

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：35 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0074 · Event Status
In the supplied table, how many cases in the "Graffiti Private" category in Supervisor District 2 are pending?
在所给表格中，Graffiti Private类别、第2行政区有多少待处理案件？
表格行数：19 → 19

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：19 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：18 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0075 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in Supervisor District 9 are underway?
在所给表格中，Sidewalk and Curb类别、第9行政区有多少已进入处理阶段案件？
表格行数：52 → 52

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：46 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0076 · Event Status
In the supplied table, how many cases in the Sunnyside neighborhood in Supervisor District 7 are active?
在所给表格中，Sunnyside社区、第7行政区有多少活跃案件？
表格行数：28 → 28

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：28 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0077 · Event Status
In the supplied table, how many cases in the "Tree Maintenance" category in Supervisor District 9 are pending?
在所给表格中，Tree Maintenance类别、第9行政区有多少待处理案件？
表格行数：42 → 42

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：42 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：21 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0078 · Event Status
In the supplied table, how many cases in the Financial District neighborhood are underway?
在所给表格中，Financial District社区有多少已进入处理阶段案件？
表格行数：16 → 16

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：6 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0079 · Event Status
In the supplied table, how many cases in the "Street and Sidewalk Cleaning" category in Supervisor District 8 are active?
在所给表格中，Street and Sidewalk Cleaning类别、第8行政区有多少活跃案件？
表格行数：27 → 27

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：27 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：26 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0080 · Event Status
In the supplied table, how many cases in the "Tree Maintenance" category in Supervisor District 10 are pending?
在所给表格中，Tree Maintenance类别、第10行政区有多少待处理案件？
表格行数：19 → 19

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：19 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：11 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0081 · Event Status
In the supplied table, how many cases in the Lower Nob Hill neighborhood in Supervisor District 3 are underway?
在所给表格中，Lower Nob Hill社区、第3行政区有多少已进入处理阶段案件？
表格行数：47 → 47

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：26 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：17 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0082 · Event Status
In the supplied table, how many cases in Supervisor District 11 are active?
在所给表格中，第11行政区有多少活跃案件？
表格行数：194 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：6 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0083 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in the Portola neighborhood are pending?
在所给表格中，Sidewalk and Curb类别、Portola社区有多少待处理案件？
表格行数：19 → 19

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：19 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0084 · Event Status
In the supplied table, how many cases in the Silver Terrace neighborhood are underway?
在所给表格中，Silver Terrace社区有多少已进入处理阶段案件？
表格行数：46 → 46

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：32 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：24 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0085 · Event Status
In the supplied table, how many cases in the Downtown / Union Square neighborhood are active?
在所给表格中，Downtown / Union Square社区有多少活跃案件？
表格行数：29 → 29

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：29 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：8 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0086 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in Supervisor District 11 are pending?
在所给表格中，Sidewalk and Curb类别、第11行政区有多少待处理案件？
表格行数：16 → 16

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：16 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0087 · Event Status
In the supplied table, how many cases in the Forest Hill neighborhood are underway?
在所给表格中，Forest Hill社区有多少已进入处理阶段案件？
表格行数：15 → 15

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：7 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0088 · Event Status
In the supplied table, how many cases in the Potrero Hill neighborhood in Supervisor District 10 are active?
在所给表格中，Potrero Hill社区、第10行政区有多少活跃案件？
表格行数：109 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：24 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0089 · Event Status
In the supplied table, how many cases in the "Street Defect" category in Supervisor District 5 are pending?
在所给表格中，Street Defect类别、第5行政区有多少待处理案件？
表格行数：15 → 15

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：15 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0090 · Event Status
In the supplied table, how many cases in the Lower Pacific Heights neighborhood in Supervisor District 5 are underway?
在所给表格中，Lower Pacific Heights社区、第5行政区有多少已进入处理阶段案件？
表格行数：26 → 26

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：9 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0091 · Event Status
In the supplied table, how many cases in the Tenderloin neighborhood in Supervisor District 5 are active?
在所给表格中，Tenderloin社区、第5行政区有多少活跃案件？
表格行数：68 → 68

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：68 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：24 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0092 · Event Status
In the supplied table, how many cases in the Buena Vista neighborhood are pending?
在所给表格中，Buena Vista社区有多少待处理案件？
表格行数：43 → 43

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：43 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：33 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0093 · Event Status
In the supplied table, how many cases in the Outer Sunset neighborhood are underway?
在所给表格中，Outer Sunset社区有多少已进入处理阶段案件？
表格行数：107 → 100

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：49 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：9 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0094 · Event Status
In the supplied table, how many cases in the Lone Mountain neighborhood in Supervisor District 1 are active?
在所给表格中，Lone Mountain社区、第1行政区有多少活跃案件？
表格行数：18 → 18

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：18 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0095 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Haight Ashbury neighborhood are pending?
在所给表格中，Graffiti Public类别、Haight Ashbury社区有多少待处理案件？
表格行数：21 → 21

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：21 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：18 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0096 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in Supervisor District 8 are underway?
在所给表格中，Graffiti Public类别、第8行政区有多少已进入处理阶段案件？
表格行数：67 → 67

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：7 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0097 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in Supervisor District 8 are active?
在所给表格中，Sidewalk and Curb类别、第8行政区有多少活跃案件？
表格行数：36 → 36

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：36 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0098 · Event Status
In the supplied table, how many cases in the "Request for City Services" category in Supervisor District 6 are pending?
在所给表格中，Request for City Services类别、第6行政区有多少待处理案件？
表格行数：20 → 20

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：20 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：13 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0099 · Event Status
In the supplied table, how many cases in the Polk Gulch neighborhood are underway?
在所给表格中，Polk Gulch社区有多少已进入处理阶段案件？
表格行数：16 → 16

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：7 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：4 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0100 · Event Status
In the supplied table, how many cases in the Buena Vista neighborhood are active?
在所给表格中，Buena Vista社区有多少活跃案件？
表格行数：43 → 43

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：43 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0101 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Portola neighborhood are pending?
在所给表格中，Graffiti Public类别、Portola社区有多少待处理案件？
表格行数：30 → 30

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：30 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：26 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0102 · Event Status
In the supplied table, how many cases in the Russian Hill neighborhood in Supervisor District 3 are underway?
在所给表格中，Russian Hill社区、第3行政区有多少已进入处理阶段案件？
表格行数：42 → 42

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：18 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0103 · Event Status
In the supplied table, how many cases in the Panhandle neighborhood are active?
在所给表格中，Panhandle社区有多少活跃案件？
表格行数：54 → 54

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：54 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：4 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0104 · Event Status
In the supplied table, how many cases in the Duboce Triangle neighborhood in Supervisor District 8 are pending?
在所给表格中，Duboce Triangle社区、第8行政区有多少待处理案件？
表格行数：23 → 23

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：23 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：16 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0105 · Event Status
In the supplied table, how many cases in the Cathedral Hill neighborhood in Supervisor District 5 are underway?
在所给表格中，Cathedral Hill社区、第5行政区有多少已进入处理阶段案件？
表格行数：24 → 24

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：14 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：6 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0106 · Event Status
In the supplied table, how many cases in the "Sewer" category are active?
在所给表格中，Sewer类别有多少活跃案件？
表格行数：63 → 63

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：63 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：18 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0107 · Event Status
In the supplied table, how many cases in the Panhandle neighborhood in Supervisor District 5 are pending?
在所给表格中，Panhandle社区、第5行政区有多少待处理案件？
表格行数：52 → 52

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：52 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：40 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0108 · Event Status
In the supplied table, how many cases in the Dolores Heights neighborhood are underway?
在所给表格中，Dolores Heights社区有多少已进入处理阶段案件？
表格行数：26 → 26

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：11 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0109 · Event Status
In the supplied table, how many cases in the Inner Richmond neighborhood are active?
在所给表格中，Inner Richmond社区有多少活跃案件？
表格行数：42 → 42

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：42 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：4 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0110 · Event Status
In the supplied table, how many cases in the Potrero Hill neighborhood are pending?
在所给表格中，Potrero Hill社区有多少待处理案件？
表格行数：116 → 100

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：100 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：52 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0111 · Event Status
In the supplied table, how many cases in the Haight Ashbury neighborhood in Supervisor District 5 are underway?
在所给表格中，Haight Ashbury社区、第5行政区有多少已进入处理阶段案件？
表格行数：42 → 42

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：9 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0112 · Event Status
In the supplied table, how many cases in the Downtown / Union Square neighborhood in Supervisor District 3 are active?
在所给表格中，Downtown / Union Square社区、第3行政区有多少活跃案件？
表格行数：24 → 24

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：24 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：8 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0113 · Event Status
In the supplied table, how many cases in the "Street Defect" category in Supervisor District 7 are pending?
在所给表格中，Street Defect类别、第7行政区有多少待处理案件？
表格行数：26 → 26

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：26 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0114 · Event Status
In the supplied table, how many cases in Supervisor District 1 are underway?
在所给表格中，第1行政区有多少已进入处理阶段案件？
表格行数：168 → 100

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：26 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：6 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0115 · Event Status
In the supplied table, how many cases in the Mission Bay neighborhood are active?
在所给表格中，Mission Bay社区有多少活跃案件？
表格行数：24 → 24

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：24 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0116 · Event Status
In the supplied table, how many cases in the Inner Richmond neighborhood in Supervisor District 1 are pending?
在所给表格中，Inner Richmond社区、第1行政区有多少待处理案件？
表格行数：42 → 42

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：42 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：19 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0117 · Event Status
In the supplied table, how many cases in the Downtown / Union Square neighborhood are underway?
在所给表格中，Downtown / Union Square社区有多少已进入处理阶段案件？
表格行数：29 → 29

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：21 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：8 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0118 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in the Mission neighborhood are active?
在所给表格中，Sidewalk and Curb类别、Mission社区有多少活跃案件？
表格行数：20 → 20

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：20 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0119 · Event Status
In the supplied table, how many cases in the Alamo Square neighborhood in Supervisor District 5 are pending?
在所给表格中，Alamo Square社区、第5行政区有多少待处理案件？
表格行数：17 → 17

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：17 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：15 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0120 · Event Status
In the supplied table, how many cases in the Cathedral Hill neighborhood are underway?
在所给表格中，Cathedral Hill社区有多少已进入处理阶段案件？
表格行数：33 → 33

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：18 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0121 · Event Status
In the supplied table, how many cases in the Mission Dolores neighborhood are active?
在所给表格中，Mission Dolores社区有多少活跃案件？
表格行数：58 → 58

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：58 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：8 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0122 · Event Status
In the supplied table, how many cases in the Civic Center neighborhood in Supervisor District 5 are pending?
在所给表格中，Civic Center社区、第5行政区有多少待处理案件？
表格行数：36 → 36

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：36 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：14 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0123 · Event Status
In the supplied table, how many cases in the Pacific Heights neighborhood are underway?
在所给表格中，Pacific Heights社区有多少已进入处理阶段案件？
表格行数：60 → 60

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：29 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0124 · Event Status
In the supplied table, how many cases in the Produce Market neighborhood are active?
在所给表格中，Produce Market社区有多少活跃案件？
表格行数：30 → 30

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：30 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：10 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0125 · Event Status
In the supplied table, how many cases in the Cathedral Hill neighborhood in Supervisor District 5 are pending?
在所给表格中，Cathedral Hill社区、第5行政区有多少待处理案件？
表格行数：24 → 24

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：24 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：9 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0126 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Bayview neighborhood are underway?
在所给表格中，Graffiti Public类别、Bayview社区有多少已进入处理阶段案件？
表格行数：43 → 43

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：4 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0127 · Event Status
In the supplied table, how many cases in the "Graffiti Private" category are active?
在所给表格中，Graffiti Private类别有多少活跃案件？
表格行数：247 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0128 · Event Status
In the supplied table, how many cases in the Portola neighborhood in Supervisor District 9 are pending?
在所给表格中，Portola社区、第9行政区有多少待处理案件？
表格行数：86 → 86

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：86 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：34 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0129 · Event Status
In the supplied table, how many cases in the Bret Harte neighborhood are underway?
在所给表格中，Bret Harte社区有多少已进入处理阶段案件？
表格行数：12 → 12

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：8 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0130 · Event Status
In the supplied table, how many cases in the Lower Nob Hill neighborhood in Supervisor District 3 are active?
在所给表格中，Lower Nob Hill社区、第3行政区有多少活跃案件？
表格行数：47 → 47

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：47 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：17 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0131 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Golden Gate Park neighborhood are pending?
在所给表格中，Graffiti Public类别、Golden Gate Park社区有多少待处理案件？
表格行数：15 → 15

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：15 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：12 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0132 · Event Status
In the supplied table, how many cases in the "Street and Sidewalk Cleaning" category in Supervisor District 8 are underway?
在所给表格中，Street and Sidewalk Cleaning类别、第8行政区有多少已进入处理阶段案件？
表格行数：27 → 27

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：27 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：26 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0133 · Event Status
In the supplied table, how many cases in the Excelsior neighborhood in Supervisor District 11 are active?
在所给表格中，Excelsior社区、第11行政区有多少活跃案件？
表格行数：27 → 27

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：27 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0134 · Event Status
In the supplied table, how many cases in the "Blocked Street and Sidewalk" category in Supervisor District 9 are pending?
在所给表格中，Blocked Street and Sidewalk类别、第9行政区有多少待处理案件？
表格行数：14 → 14

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：14 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0135 · Event Status
In the supplied table, how many cases in the Western Addition neighborhood are underway?
在所给表格中，Western Addition社区有多少已进入处理阶段案件？
表格行数：65 → 65

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：9 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：4 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0136 · Event Status
In the supplied table, how many cases in the University Mound neighborhood are active?
在所给表格中，University Mound社区有多少活跃案件？
表格行数：12 → 12

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：12 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0137 · Event Status
In the supplied table, how many cases in the Outer Richmond neighborhood in Supervisor District 1 are pending?
在所给表格中，Outer Richmond社区、第1行政区有多少待处理案件？
表格行数：50 → 50

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：50 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：25 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0138 · Event Status
In the supplied table, how many cases in the "Streetlights" category are underway?
在所给表格中，Streetlights类别有多少已进入处理阶段案件？
表格行数：44 → 44

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：22 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：4 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0139 · Event Status
In the supplied table, how many cases in the Dolores Heights neighborhood are active?
在所给表格中，Dolores Heights社区有多少活跃案件？
表格行数：26 → 26

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：26 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0140 · Event Status
In the supplied table, how many cases in the "Tree Maintenance" category in the Noe Valley neighborhood are pending?
在所给表格中，Tree Maintenance类别、Noe Valley社区有多少待处理案件？
表格行数：14 → 14

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：14 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0141 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Cayuga neighborhood are underway?
在所给表格中，Graffiti Public类别、Cayuga社区有多少已进入处理阶段案件？
表格行数：43 → 43

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：2 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0142 · Event Status
In the supplied table, how many cases in the Laurel Heights / Jordan Park neighborhood in Supervisor District 2 are active?
在所给表格中，Laurel Heights / Jordan Park社区、第2行政区有多少活跃案件？
表格行数：25 → 25

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：25 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0143 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Mission Dolores neighborhood are pending?
在所给表格中，Graffiti Public类别、Mission Dolores社区有多少待处理案件？
表格行数：19 → 19

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：19 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：15 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0144 · Event Status
In the supplied table, how many cases in the North Beach neighborhood in Supervisor District 3 are underway?
在所给表格中，North Beach社区、第3行政区有多少已进入处理阶段案件？
表格行数：34 → 34

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：16 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：9 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0145 · Event Status
In the supplied table, how many cases in the Union Street neighborhood in Supervisor District 2 are active?
在所给表格中，Union Street社区、第2行政区有多少活跃案件？
表格行数：19 → 19

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：19 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0146 · Event Status
In the supplied table, how many cases in the Mission Dolores neighborhood are pending?
在所给表格中，Mission Dolores社区有多少待处理案件？
表格行数：58 → 58

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：58 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：32 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0147 · Event Status
In the supplied table, how many cases in the "Street and Sidewalk Cleaning" category in Supervisor District 5 are underway?
在所给表格中，Street and Sidewalk Cleaning类别、第5行政区有多少已进入处理阶段案件？
表格行数：63 → 63

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：59 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：58 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0148 · Event Status
In the supplied table, how many cases in the Mission Terrace neighborhood are active?
在所给表格中，Mission Terrace社区有多少活跃案件？
表格行数：40 → 40

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：40 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0149 · Event Status
In the supplied table, how many cases in the Chinatown neighborhood are pending?
在所给表格中，Chinatown社区有多少待处理案件？
表格行数：39 → 39

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：39 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：17 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0150 · Event Status
In the supplied table, how many cases in the Castro neighborhood are underway?
在所给表格中，Castro社区有多少已进入处理阶段案件？
表格行数：59 → 59

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：23 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0151 · Event Status
In the supplied table, how many cases in the Cathedral Hill neighborhood in Supervisor District 5 are active?
在所给表格中，Cathedral Hill社区、第5行政区有多少活跃案件？
表格行数：24 → 24

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：24 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：6 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0152 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Hayes Valley neighborhood are pending?
在所给表格中，Graffiti Public类别、Hayes Valley社区有多少待处理案件？
表格行数：26 → 26

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：26 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：23 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0153 · Event Status
In the supplied table, how many cases in the Bernal Heights neighborhood are underway?
在所给表格中，Bernal Heights社区有多少已进入处理阶段案件？
表格行数：46 → 46

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：21 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：9 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0154 · Event Status
In the supplied table, how many cases in the Outer Sunset neighborhood are active?
在所给表格中，Outer Sunset社区有多少活跃案件？
表格行数：107 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：9 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0155 · Event Status
In the supplied table, how many cases in the "Street and Sidewalk Cleaning" category in Supervisor District 3 are pending?
在所给表格中，Street and Sidewalk Cleaning类别、第3行政区有多少待处理案件？
表格行数：61 → 61

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：61 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0156 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in Supervisor District 7 are underway?
在所给表格中，Sidewalk and Curb类别、第7行政区有多少已进入处理阶段案件？
表格行数：48 → 48

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：46 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0157 · Event Status
In the supplied table, how many cases in the "Request for City Services" category in Supervisor District 10 are active?
在所给表格中，Request for City Services类别、第10行政区有多少活跃案件？
表格行数：29 → 29

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：29 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：4 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0158 · Event Status
In the supplied table, how many cases in the Outer Richmond neighborhood are pending?
在所给表格中，Outer Richmond社区有多少待处理案件？
表格行数：50 → 50

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：50 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：25 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0159 · Event Status
In the supplied table, how many cases in the Inner Richmond neighborhood in Supervisor District 1 are underway?
在所给表格中，Inner Richmond社区、第1行政区有多少已进入处理阶段案件？
表格行数：42 → 42

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：14 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：4 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0160 · Event Status
In the supplied table, how many cases in the "Blocked Street and Sidewalk" category are active?
在所给表格中，Blocked Street and Sidewalk类别有多少活跃案件？
表格行数：111 → 100

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：100 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0161 · Event Status
In the supplied table, how many cases in the Fairmount neighborhood are pending?
在所给表格中，Fairmount社区有多少待处理案件？
表格行数：15 → 15

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：15 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：4 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0162 · Event Status
In the supplied table, how many cases in the Mission Dolores neighborhood in Supervisor District 9 are underway?
在所给表格中，Mission Dolores社区、第9行政区有多少已进入处理阶段案件？
表格行数：21 → 21

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：10 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0163 · Event Status
In the supplied table, how many cases in the "Street Defect" category in Supervisor District 8 are active?
在所给表格中，Street Defect类别、第8行政区有多少活跃案件？
表格行数：21 → 21

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：21 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0164 · Event Status
In the supplied table, how many cases in the Dogpatch neighborhood in Supervisor District 10 are pending?
在所给表格中，Dogpatch社区、第10行政区有多少待处理案件？
表格行数：25 → 25

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：25 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：17 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0165 · Event Status
In the supplied table, how many cases in the Hunters Point neighborhood in Supervisor District 10 are underway?
在所给表格中，Hunters Point社区、第10行政区有多少已进入处理阶段案件？
表格行数：17 → 17

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：11 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：8 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0166 · Event Status
In the supplied table, how many cases in the North Beach neighborhood in Supervisor District 3 are active?
在所给表格中，North Beach社区、第3行政区有多少活跃案件？
表格行数：34 → 34

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：34 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：9 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0167 · Event Status
In the supplied table, how many cases in the Golden Gate Heights neighborhood are pending?
在所给表格中，Golden Gate Heights社区有多少待处理案件？
表格行数：50 → 50

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：50 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：9 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0168 · Event Status
In the supplied table, how many cases in the Panhandle neighborhood are underway?
在所给表格中，Panhandle社区有多少已进入处理阶段案件？
表格行数：54 → 54

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：9 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：4 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0169 · Event Status
In the supplied table, how many cases in the "Tree Maintenance" category in Supervisor District 8 are active?
在所给表格中，Tree Maintenance类别、第8行政区有多少活跃案件？
表格行数：45 → 45

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：45 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0170 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Lower Haight neighborhood are pending?
在所给表格中，Graffiti Public类别、Lower Haight社区有多少待处理案件？
表格行数：22 → 22

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：22 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：18 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0171 · Event Status
In the supplied table, how many cases in the "Request for City Services" category in the Potrero Hill neighborhood are underway?
在所给表格中，Request for City Services类别、Potrero Hill社区有多少已进入处理阶段案件？
表格行数：12 → 12

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：7 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0172 · Event Status
In the supplied table, how many cases in the Financial District neighborhood are active?
在所给表格中，Financial District社区有多少活跃案件？
表格行数：16 → 16

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：16 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0173 · Event Status
In the supplied table, how many cases in the "Street and Sidewalk Cleaning" category in the Visitacion Valley neighborhood are pending?
在所给表格中，Street and Sidewalk Cleaning类别、Visitacion Valley社区有多少待处理案件？
表格行数：14 → 14

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：14 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0174 · Event Status
In the supplied table, how many cases in the Japantown neighborhood are underway?
在所给表格中，Japantown社区有多少已进入处理阶段案件？
表格行数：18 → 18

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：10 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0175 · Event Status
In the supplied table, how many cases in the "Sidewalk and Curb" category in Supervisor District 6 are active?
在所给表格中，Sidewalk and Curb类别、第6行政区有多少活跃案件？
表格行数：35 → 35

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：35 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0176 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in Supervisor District 5 are pending?
在所给表格中，Graffiti Public类别、第5行政区有多少待处理案件？
表格行数：163 → 100

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：100 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：89 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0177 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Golden Gate Park neighborhood are underway?
在所给表格中，Graffiti Public类别、Golden Gate Park社区有多少已进入处理阶段案件？
表格行数：15 → 15

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：2 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0178 · Event Status
In the supplied table, how many cases in the "Street Defect" category in Supervisor District 9 are active?
在所给表格中，Street Defect类别、第9行政区有多少活跃案件？
表格行数：18 → 18

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：18 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0179 · Event Status
In the supplied table, how many cases in the "Tree Maintenance" category in the Mission neighborhood are pending?
在所给表格中，Tree Maintenance类别、Mission社区有多少待处理案件？
表格行数：22 → 22

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：22 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：10 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0180 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in Supervisor District 9 are underway?
在所给表格中，Graffiti Public类别、第9行政区有多少已进入处理阶段案件？
表格行数：198 → 100

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：12 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：0 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0181 · Event Status
In the supplied table, how many cases in the South Beach neighborhood in Supervisor District 6 are active?
在所给表格中，South Beach社区、第6行政区有多少活跃案件？
表格行数：16 → 16

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：16 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：6 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0182 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Cayuga neighborhood are pending?
在所给表格中，Graffiti Public类别、Cayuga社区有多少待处理案件？
表格行数：43 → 43

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：43 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：38 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0183 · Event Status
In the supplied table, how many cases in the Fairmount neighborhood in Supervisor District 8 are underway?
在所给表格中，Fairmount社区、第8行政区有多少已进入处理阶段案件？
表格行数：15 → 15

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：9 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0184 · Event Status
In the supplied table, how many cases in the Showplace Square neighborhood are active?
在所给表格中，Showplace Square社区有多少活跃案件？
表格行数：21 → 21

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：21 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：7 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0185 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in the Mission neighborhood are pending?
在所给表格中，Graffiti Public类别、Mission社区有多少待处理案件？
表格行数：162 → 100

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：100 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：84 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0186 · Event Status
In the supplied table, how many cases in the Excelsior neighborhood are underway?
在所给表格中，Excelsior社区有多少已进入处理阶段案件？
表格行数：28 → 28

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：12 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0187 · Event Status
In the supplied table, how many cases in the "Street and Sidewalk Cleaning" category in Supervisor District 3 are active?
在所给表格中，Street and Sidewalk Cleaning类别、第3行政区有多少活跃案件？
表格行数：61 → 61

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：61 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：60 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0188 · Event Status
In the supplied table, how many cases in the Miraloma Park neighborhood are pending?
在所给表格中，Miraloma Park社区有多少待处理案件？
表格行数：13 → 13

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：13 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：6 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0189 · Event Status
In the supplied table, how many cases in the Parnassus Heights neighborhood are underway?
在所给表格中，Parnassus Heights社区有多少已进入处理阶段案件？
表格行数：13 → 13

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：3 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：2 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0190 · Event Status
In the supplied table, how many cases in the Lower Pacific Heights neighborhood in Supervisor District 5 are active?
在所给表格中，Lower Pacific Heights社区、第5行政区有多少活跃案件？
表格行数：26 → 26

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：26 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：3 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0191 · Event Status
In the supplied table, how many cases in the "Graffiti Public" category in Supervisor District 2 are pending?
在所给表格中，Graffiti Public类别、第2行政区有多少待处理案件？
表格行数：42 → 42

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：42 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：40 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0192 · Event Status
In the supplied table, how many cases in the Russian Hill neighborhood are underway?
在所给表格中，Russian Hill社区有多少已进入处理阶段案件？
表格行数：50 → 50

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：19 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：5 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0193 · Event Status
In the supplied table, how many cases in the Tenderloin neighborhood are active?
在所给表格中，Tenderloin社区有多少活跃案件？
表格行数：96 → 96

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：96 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：32 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0194 · Event Status
In the supplied table, how many cases in the Inner Sunset neighborhood in Supervisor District 7 are pending?
在所给表格中，Inner Sunset社区、第7行政区有多少待处理案件？
表格行数：38 → 38

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：38 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：14 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0195 · Event Status
In the supplied table, how many cases in the Civic Center neighborhood in Supervisor District 5 are underway?
在所给表格中，Civic Center社区、第5行政区有多少已进入处理阶段案件？
表格行数：36 → 36

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：16 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：10 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0196 · Event Status
In the supplied table, how many cases in the Visitacion Valley neighborhood are active?
在所给表格中，Visitacion Valley社区有多少活跃案件？
表格行数：36 → 36

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：36 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：14 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0197 · Event Status
In the supplied table, how many cases in the "Street Defect" category in Supervisor District 8 are pending?
在所给表格中，Street Defect类别、第8行政区有多少待处理案件？
表格行数：21 → 21

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：21 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0198 · Event Status
In the supplied table, how many cases in the "Damage Property" category are underway?
在所给表格中，Damage Property类别有多少已进入处理阶段案件？
表格行数：35 → 35

**Condition：`work status in {accepted, in progress}`**
已进入受理/处理阶段：工作状态为 accepted 或 in progress。
状态集合：accepted, in progress
**答案：20 个案件**

**Condition：`work status = in progress`**
仅指明确正在处理的阶段：工作状态为 in progress。
状态集合：in progress
**答案：1 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0199 · Event Status
In the supplied table, how many cases in the "Street and Sidewalk Cleaning" category in Supervisor District 7 are active?
在所给表格中，Street and Sidewalk Cleaning类别、第7行政区有多少活跃案件？
表格行数：17 → 17

**Condition：`work status in {open, sent, accepted, in progress}`**
仍在正常工作流程中：open、sent、accepted、in progress；不纳入 on hold。
状态集合：open, sent, accepted, in progress
**答案：17 个案件**

**Condition：`work status = in progress`**
仅指正在执行处理的案件：工作状态为 in progress。
状态集合：in progress
**答案：16 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

## SF_ES_0200 · Event Status
In the supplied table, how many cases in the "Request for City Services" category in Supervisor District 8 are pending?
在所给表格中，Request for City Services类别、第8行政区有多少待处理案件？
表格行数：34 → 34

**Condition：`not closed`**
尚未结案：包括待受理、已转送、已受理、处理中和暂缓的案件。
状态集合：accepted, in progress, on hold, open, sent
**答案：34 个案件**

**Condition：`work status = open`**
仅指工作状态仍为 open 的案件；不纳入已受理、处理中、转送或暂缓的案件。
状态集合：open
**答案：18 个案件**

审核：问题自然 □是 □否；两个解释合理 □是 □否。

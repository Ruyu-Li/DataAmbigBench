"""Native REST adapters. No SDK retries, no automatic model substitution."""
import json, os, time, urllib.request, urllib.error, urllib.parse

class APIError(RuntimeError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)

def request(url, key, headers, body=None, timeout=240):
    headers = {'Content-Type':'application/json', **headers}
    req = urllib.request.Request(url, headers=headers,
        data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        message = e.read().decode('utf-8','replace')[:8000].replace(key, '[REDACTED]')
        exc = APIError(e.code, message)
        exc.retry_after = e.headers.get('Retry-After')
        raise exc from None

def connection(c):
    key = os.environ.get(c['key_env'], '')
    if not key: raise ValueError('Missing secret: '+c['key_env'])
    base = os.environ.get(c.get('base_env',''), c['base_url']).rstrip('/')
    if c['provider']=='gemini': headers={'x-goog-api-key':key}
    elif c['provider']=='anthropic': headers={'x-api-key':key,'anthropic-version':'2023-06-01'}
    else: headers={'Authorization':'Bearer '+key}
    return base,key,headers

def list_models(c):
    base,key,headers=connection(c)
    url=base+'/models'; result=[]
    while url:
        obj=request(url,key,headers)
        if c['provider']=='gemini':
            result += [r['name'].removeprefix('models/') for r in obj.get('models',[])]
            token=obj.get('nextPageToken')
            url=base+'/models?pageToken='+urllib.parse.quote(token) if token else None
        else:
            result += [r['id'] for r in obj.get('data',[])]
            token=obj.get('last_id') if obj.get('has_more') else None
            url=base+'/models?after_id='+urllib.parse.quote(token) if token else None
    return result

def build_request(c, system, prompt, limit):
    p=c['provider']; model=c['id']; temp=c.get('temperature',0)
    if p=='gemini':
        body={'systemInstruction':{'parts':[{'text':system}]},
              'contents':[{'role':'user','parts':[{'text':prompt}]}],
              'generationConfig':{'maxOutputTokens':limit}}
        if temp is not None: body['generationConfig']['temperature']=temp
        body['generationConfig'].update(c.get('generation_config',{}))
        path='/models/'+urllib.parse.quote(model,safe='')+':generateContent'
    elif p=='anthropic':
        body={'model':model,'system':system,'messages':[{'role':'user','content':prompt}], 'max_tokens':limit}
        if temp is not None: body['temperature']=temp
        body.update(c.get('extra_payload',{})); path='/messages'
    else:
        body={'model':model,'messages':[{'role':'system','content':system},{'role':'user','content':prompt}],
              c.get('token_parameter','max_tokens'):limit,'stream':False}
        if temp is not None: body['temperature']=temp
        body.update(c.get('extra_payload',{})); path='/chat/completions'
    return path,body

def normalize(c, p):
    provider=c['provider']
    if provider=='gemini':
        choices=p.get('candidates') or [{}]; ch=choices[0]
        raw=''.join(x.get('text','') for x in ch.get('content',{}).get('parts',[]) if not x.get('thought'))
        u=p.get('usageMetadata') or {}; ip=u.get('promptTokenCount'); op=u.get('candidatesTokenCount')
        thought=u.get('thoughtsTokenCount',0)
        usage={'prompt_tokens':ip,'completion_tokens':op+thought if op is not None else None,
               'total_tokens':u.get('totalTokenCount'),'reasoning_tokens':thought,
               'cached_tokens':u.get('cachedContentTokenCount',0)}
        finish=ch.get('finishReason'); actual=p.get('modelVersion')
        response_id=p.get('responseId')
    elif provider=='anthropic':
        raw=''.join(x.get('text','') for x in p.get('content',[]) if x.get('type')=='text')
        u=p.get('usage') or {}; ip=u.get('input_tokens'); op=u.get('output_tokens')
        ip=ip+u.get('cache_read_input_tokens',0)+u.get('cache_creation_input_tokens',0) if ip is not None else None
        usage={'prompt_tokens':ip,'completion_tokens':op,'total_tokens':ip+op if ip is not None and op is not None else None}
        finish=p.get('stop_reason'); actual=p.get('model'); response_id=p.get('id')
    else:
        ch=(p.get('choices') or [{}])[0]; raw=ch.get('message',{}).get('content') or ''
        u=p.get('usage') or {}; usage=u; finish=ch.get('finish_reason'); actual=p.get('model'); response_id=p.get('id')
    if not isinstance(raw,str): raise ValueError('Non-text response content')
    return dict(raw=raw, usage=usage, provider_usage=u, actual_model=actual,
                response_id=response_id, finish_reason='length' if finish in ('MAX_TOKENS','max_tokens','length') else finish)

def complete(c, system, prompt, limit, timeout=240):
    base,key,headers=connection(c); path,body=build_request(c,system,prompt,limit)
    start=time.perf_counter(); p=request(base+path,key,headers,body,timeout)
    return {**normalize(c,p),'elapsed_ms':(time.perf_counter()-start)*1000}

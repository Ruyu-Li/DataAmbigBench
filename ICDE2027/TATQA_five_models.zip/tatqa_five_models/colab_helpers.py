"""Notebook helpers: streaming subprocess output and graceful stop."""
import os, signal, subprocess, sys
from pathlib import Path

def stream(command,cwd):
    child=subprocess.Popen(command,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
    print('Runner PID:',child.pid,flush=True)
    stopped=False
    while True:
        try:
            for line in child.stdout:print(line,end='',flush=True)
            code=child.wait();break
        except KeyboardInterrupt:
            if child.poll() is None:
                child.send_signal(signal.SIGINT);stopped=True
                print('\n正在停止提交新请求并保存进行中的结果，请等待，最长可能需要几分钟。',flush=True)
    if code and not stopped:raise subprocess.CalledProcessError(code,command)
    return code

def keys(project):
    import json
    from getpass import getpass
    from google.colab import userdata
    plan=json.loads((project['base']/'recovery_v2/plan.json').read_text())
    pending={r['model'] for r in plan if r['pending']}
    configs=json.loads((project['code']/'models.json').read_text())
    for name in sorted({c['key_env'] for c in configs if c.get('enabled',True) and c['id'] in pending}):
        if os.environ.get(name):continue
        try:value=userdata.get(name)
        except Exception:value=''
        if not value:value=getpass(f'{name}（隐藏输入；回车跳过该服务商）: ').strip()
        if value:os.environ[name]=value

"""Post-run quality reports plus separated execution cohorts."""
import argparse, collections, csv, json, statistics
from pathlib import Path
import batch, lab
from resume import choose, read_jsonl, finished, rejection

def report(base):
    base=Path(base);out=base/'multimodel_summary';out.mkdir(parents=True,exist_ok=True)
    batch.summarize(base)
    completion=[];groups=collections.defaultdict(list)
    for mp in sorted((base/'multimodel_v1').glob('*/*/manifest.json')):
        m=json.loads(mp.read_text());rs=list(choose(read_jsonl(mp.parent/'predictions.jsonl')[0]).values())
        model=m['config']['id'];ds=mp.parent.name;n=m['expected_jobs'];handled=sum(finished(r) for r in rs)
        completion.append(dict(model=model,dataset=ds,expected=n,recorded=len(rs),handled=handled,pending=n-handled,http_ok=sum(r.get('status')=='ok' for r in rs),terminal_rejections=sum(rejection(r) or r.get('terminal_rejection',False) for r in rs),complete=handled==n))
        for r in rs:
            groups[(model,ds,r['task'],r.get('execution_origin','unknown'),r.get('concurrency',1),r.get('configured_rpm','unknown'))].append(r)
    batch.write_csv(out/'completion.csv',completion)
    timings=[]
    for key,rs in groups.items():
        vals=[r['elapsed_ms'] for r in rs if isinstance(r.get('elapsed_ms'),(int,float))]
        totals=[r['total_elapsed_ms'] for r in rs if isinstance(r.get('total_elapsed_ms'),(int,float))]
        timings.append(dict(zip(['model','dataset','task','execution_origin','concurrency','configured_rpm'],key))|dict(n=len(rs),request_latency_n=len(vals),request_p50_ms=statistics.median(vals) if vals else None,request_p95_ms=lab.percentile(vals,.95),with_wait_p50_ms=statistics.median(totals) if totals else None,tokens=sum((r.get('usage') or {}).get('total_tokens',0) or 0 for r in rs)))
    batch.write_csv(out/'latency_by_execution.csv',timings)
    # Pooled latency from the old reporter is not a controlled comparison.
    metrics=out/'metrics_all.csv'
    if metrics.exists():
        with metrics.open(encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
        for r in rows:
            r.pop('p50_ms',None);r.pop('p95_ms',None)
            r['dataset_complete']=next(x['complete'] for x in completion if x['model']==r['model'] and x['dataset']==r['dataset'])
        batch.write_csv(metrics,rows)
    (out/'READ_ME.txt').write_text('Quality metrics retain model format errors and policy rejections. Incomplete datasets are provisional. Condition-Given is pair-weighted. Latency cohorts separate legacy serial and recovery parallel; this is not the controlled scalability experiment. Request latency describes the final HTTP attempt; with_wait also includes pacing/retries. API attempts are journaled per dataset. Provider charges may differ from returned token counts.\n')
    print('Handled:',sum(x['handled'] for x in completion),'Pending:',sum(x['pending'] for x in completion),flush=True)
    return completion
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();report(a.out)

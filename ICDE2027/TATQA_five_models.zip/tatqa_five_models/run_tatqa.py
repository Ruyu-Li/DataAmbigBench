"""Run exactly five configured models on the fixed 200 TAT-QA queries."""
import argparse
import collections
import concurrent.futures as cf
import contextlib
import fcntl
import json
import signal
from pathlib import Path

import batch
import lab
import resume as R
import resume_report

HERE = Path(__file__).resolve().parent
IDS = (
    'gpt-5-mini',
    'gemini-3.1-flash-lite',
    'gemini-3.5-flash-lite',
    'claude-haiku-4-5-20251001',
    'claude-haiku-5-5',
)


def validated_rows(path):
    if not path.is_file():
        raise FileNotFoundError(f'Missing prepared TAT-QA context: {path}')
    rows = lab.read_rows(path)
    reference = json.loads((HERE / 'tatqa_reference.json').read_text())
    if len(rows) != 200 or set(r['id'] for r in rows) != set(reference):
        raise ValueError('TAT-QA input must contain the exact fixed 200 unique IDs')
    seen = set()
    for r in rows:
        lab.valid_sample(r)
        if r['id'] in seen:
            raise ValueError('Duplicate ID: ' + r['id'])
        seen.add(r['id'])
        if lab.digest(r['query']) != reference[r['id']]['query_hash'] or lab.digest(r['gold']) != reference[r['id']]['gold_hash']:
            raise ValueError('Changed query or gold: ' + r['id'])
        context = lab.prompts.safe_get_table(r)
        if lab.is_answer_table(context):
            raise ValueError('Answer lookup table would leak gold: ' + r['id'])
        if r.get('metadata', {}).get('evidence_source') != 'TAT-QA train/dev' or not context.startswith('Financial table:\n'):
            raise ValueError('Expected verified original TAT-QA financial context: ' + r['id'])
    return rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--data', type=Path, required=True, help='preparation_v1/candidate/tatqa.jsonl')
    p.add_argument('--out', type=Path, required=True, help='Dedicated persistent TAT-QA result directory')
    p.add_argument('--execute', action='store_true', help='Send paid API requests; otherwise dry run')
    p.add_argument('--max-calls', type=int, default=0, help='Maximum API attempts, including retries')
    p.add_argument('--retries', type=int, default=4)
    p.add_argument('--timeout', type=float, default=240)
    p.add_argument('--max-wait', type=float, default=300)
    p.add_argument('--heartbeat', type=float, default=30)
    args = p.parse_args()
    if args.retries < 0 or args.timeout <= 0 or args.max_wait <= 0 or args.heartbeat <= 0:
        raise ValueError('Invalid runtime limits')
    if args.execute and args.max_calls <= 0:
        raise ValueError('Execute requires positive --max-calls')
    rows = validated_rows(args.data)
    configs = json.loads((HERE / 'models.json').read_text())
    if tuple(c['id'] for c in configs) != IDS or any(not c['enabled'] for c in configs):
        raise ValueError('Expected exactly the five requested enabled models')
    settings = json.loads((HERE / 'runner_settings.json').read_text())
    batch.DATASETS = ['tatqa']
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if out == args.data.resolve().parent or out == HERE:
        raise ValueError('Choose a dedicated output directory')
    progress = R.Progress(out / 'progress.json')
    staged = {}
    plan = []
    with contextlib.ExitStack() as stack:
        lock = stack.enter_context((out / 'runner.lock').open('a'))
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for c in configs:
            info = R.stage(out / '_no_legacy_import', out, c, 'tatqa', rows)
            staged[(c['id'], 'tatqa')] = info
            _, pending, best, expected, _ = info
            handled = sum(R.finished(r) for r in best.values())
            item = {'model': c['id'], 'dataset': 'tatqa', 'expected': expected,
                    'handled': handled, 'pending': len(pending)}
            plan.append(item)
            progress.set(c['id'], 'tatqa', **{k: v for k, v in item.items() if k not in ('model', 'dataset')},
                         state='completed' if not pending else 'pending')
        R.atomic(out / 'plan.json', plan)
        batch.write_csv(out / 'plan.csv', plan)
        progress.save(0)
        R.log(f'TAT-QA only: 200 queries; {sum(x["pending"] for x in plan)} pending jobs across five models')
        if not args.execute:
            R.log('DRY RUN: no API requests sent. Inspect plan.csv before executing.')
            return
        R.STOP.clear()
        signal.signal(signal.SIGINT, lambda *_: R.STOP.set())
        signal.signal(signal.SIGTERM, lambda *_: R.STOP.set())
        budget = R.Budget(args.max_calls)
        lanes = collections.defaultdict(list)
        for c in configs:
            # Gemini model quotas are distinct; let the two models progress
            # concurrently, each with its own conservative 12 RPM pacer.
            lane_key = c['id'] if c['provider'] == 'gemini' else c['provider']
            lanes[lane_key].append(c)
        states = []
        with cf.ThreadPoolExecutor(max_workers=len(lanes)) as pool:
            futures = {pool.submit(R.lane, cs, staged, budget, progress, args, settings[cs[0]['provider']]): lane_key
                       for lane_key, cs in lanes.items()}
            while futures:
                done, _ = cf.wait(futures, timeout=args.heartbeat, return_when=cf.FIRST_COMPLETED)
                for future in done:
                    lane_key = futures.pop(future)
                    try:
                        states.extend(future.result())
                    except Exception as exc:
                        states.append({'lane': lane_key, 'state': 'runner_error', 'detail': str(exc)})
                progress.save(budget.n)
                R.atomic(out / 'model_status.json', states)
        resume_report.report(out)
        R.log('Run ended; check multimodel_summary/completion.csv for any pending jobs.')


if __name__ == '__main__':
    main()

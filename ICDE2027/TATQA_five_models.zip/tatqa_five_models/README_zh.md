# TAT-QA 专用：五个模型

只跑 TAT-QA 的固定 200 条题，使用同一份由官方 TAT-QA train/dev 原始表和段落重建的上下文。五个模型为 `gpt-5-mini`、`gemini-3.1-flash-lite`、`gemini-3.5-flash-lite`、`claude-haiku-4-5-20251001`、`claude-haiku-5-5`。不跑 DeepSeek，也不跑其他七个数据集。

运行 `RUN_TATQA_COLAB.ipynb` 的三个单元：上传此 ZIP、查看 dry-run 计划、输入/读取 API key 后执行。旧的七数据集 runner 即使还在 Colab 中运行也不会被本脚本调用；输出独立存放于 `MyDrive/DataAmbigBench_supplemental/TATQA_five_models_v1`。同一个 TAT-QA 输出目录只能有一个运行进程。

输入 `data/tatqa.jsonl` 已随包附上。抽样原版 `TAT_QA_200_sampled_v1.jsonl` 的 `condition | answer` 速查表会泄漏答案，所以本包没有用它喂模型。重建时 200/200 条匹配 train/dev 原始证据；运行前逐条核对固定 ID、问题和 gold，并拒绝速查表。固定数据包含 496 个 condition-answer pairs。

每个模型执行 200 detection、496 condition_given、200 hinted e2e、200 e2e_open，合计 1096 次请求；五个模型共 5480 次（另有失败重试）。在 `models.json` 中未列出的模型不会运行。API 列表未列出模型时停下并报告，绝不替换成其他模型。缺少 key 的模型报告 missing_key；其余模型仍可运行。没有真实 API key，本包没有完成付费 API 验证。

提速版会让两个 Gemini 模型同时运行，各自保持 12 RPM，不增加单模型速率。它复用原输出目录中已完成的请求；从旧版切换时，先停止旧 runner 并等它退出，再用新版 ZIP 重新运行 notebook 的前三个代码单元。不要在同一目录同时运行两个 runner。若项目的 token、每日请求数或消费限额触发 429，仍可能暂停或变慢。

输出目录中的 `plan.csv` 是续跑前待补数量；`progress.json`、`model_status.json` 是运行状态；`multimodel_v1/<模型>/tatqa/predictions.jsonl` 是逐条结果；`multimodel_summary/completion.csv` 和 `metrics_all.csv` 是汇总。再次运行会核对数据、配置、prompt 和代码签名，复用已完成的记录，不重复提交已完成请求。修改这些输入需要另选输出目录。根据返回 token usage 估算成本时，不能把缺失 usage 的失败请求视为免费。

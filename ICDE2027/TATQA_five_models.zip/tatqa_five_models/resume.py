"""Recovery runner: strict reuse, provider lanes, bounded concurrency and paced retries."""
import argparse, collections, concurrent.futures as cf, contextlib, datetime, fcntl, hashlib, json, os, random, re, signal, sys, threading, time
from pathlib import Path
import batch, lab, providers
ROOT=Path(__file__).resolve().parent
STOP=threading.Event();PRINT=threading.Lock()
DEFAULTS={'openai':{'workers':4,'rpm':60},'anthropic':{'workers':4,'rpm':60},'deepseek':{'workers':2,'rpm':60},'gemini':{'workers':1,'rpm':12}}
def log(message):
    with PRINT: print(time.strftime('%H:%M:%S')+' '+message,flush=True)
def atomic(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False));os.replace(tmp,path)
def read_jsonl(path):
    if not path.exists():return [],False
    lines=path.read_text(encoding='utf-8-sig').splitlines();rows=[];partial=False
    for i,line in enumerate(lines):
        if not line.strip():continue
        try:rows.append(json.loads(line))
        except json.JSONDecodeError:
            if i==len(lines)-1:partial=True
            else:raise ValueError(f'Corrupt internal JSONL line: {path}:{i+1}; not silently ignored')
    return rows,partial
def rejection(row):
    code=row.get('http_status');msg=str(row.get('error','')).lower()
    return code in (400,403) and ('content_policy_violation' in msg or 'content_filter' in msg or ('invalid_prompt' in msg and ('policy' in msg or 'flagged' in msg)))
def finished(row):return row.get('status')=='ok' or rejection(row) or row.get('terminal_rejection',False)
def choose(rows):
    out={}
    for r in rows:
        k=lab.row_key(r)
        # Preserve the earliest terminal outcome; never choose a later answer by score.
        if k not in out or not finished(out[k]):out[k]=r
    return out

def request_signature(c):
    return {'provider':c['provider'],'base_url':os.getenv(c.get('base_env',''),c['base_url']).rstrip('/'),
            'request':providers.build_request(c,'SYSTEM','QUERY',3000)}
def valid_old_manifest(mp,c,rows):
    if not mp.exists():raise ValueError('Old results lack manifest: '+str(mp))
    old=json.loads(mp.read_text())
    oc=dict(old['config']);oc['base_url']=oc.get('resolved_base_url',oc['base_url']);oc.pop('base_env',None)
    if lab.digest(request_signature(oc))!=lab.digest(request_signature(c)):raise ValueError('Old model/request configuration differs: '+str(mp))
    if old['data_hash']!=lab.digest(rows):raise ValueError('Old dataset differs: '+str(mp))

def stage(base,out,c,ds,rows):
    model=c['id'];safe=re.sub(r'[^a-zA-Z0-9_.-]','_',model);folder=out/'multimodel_v1'/safe/ds;folder.mkdir(parents=True,exist_ok=True)
    js=list(batch.jobs(ds,rows));expected={lab.row_key({**j,'model':model}):j for j,_,_,_ in js}
    code_files=['resume.py','providers.py','lab.py','batch.py','geography_scoring_v2.py','scripts/prompts.py','scripts/evaluate.py','scripts/evaluate_open.py','scripts/common.py']
    manifest={'config':c,'data_hash':lab.digest(rows),'expected_jobs':len(js),'generation_signature':request_signature(c),'code_hash':lab.digest([(ROOT/f).read_text() for f in code_files])}
    manifest=json.loads(json.dumps(manifest));mp=folder/'manifest.json';dest=folder/'predictions.jsonl'
    if mp.exists() and json.loads(mp.read_text())!=manifest:raise ValueError('Recovery configuration changed: choose another --out')
    existing,partial=read_jsonl(dest)
    if existing and not mp.exists():raise ValueError('Recovery results missing manifest')
    if partial:
        backup=dest.with_name('predictions_partial_backup_'+str(time.time_ns())+'.jsonl')
        backup.write_bytes(dest.read_bytes());lab.save_rows(dest,existing)
    atomic(mp,manifest);best=choose(existing)
    old=base/'multimodel_v1'/safe/ds/'predictions.jsonl';imported=0
    if old.exists():
        valid_old_manifest(old.parent/'manifest.json',c,rows)
        source,tail=read_jsonl(old)
        if tail:log(f'{model}/{ds}: old final line incomplete; retained in source, missing job remains pending')
        candidates=choose(source)
        # Validate all matching records before importing any; never trust ID alone.
        for k,r in candidates.items():
            if k not in expected:raise ValueError('Unexpected old job: '+str(k))
            j=expected[k]
            if any(r.get(x)!=j[x] for x in ['context_hash','prompt_hash','gold','max_tokens','query']) or r.get('temperature')!=c.get('temperature'):
                raise ValueError('Old record input/config mismatch: '+str(k))
        with dest.open('a',encoding='utf-8') as f:
            for k,r in candidates.items():
                if not finished(r) or (k in best and finished(best[k])):continue
                r={**r,'imported_from':str(old),'terminal_rejection':rejection(r),'execution_origin':'legacy_serial'}
                if rejection(r):r['failure_category']='provider_policy_rejection'
                f.write(lab.canonical(r)+'\n');f.flush();best[k]=r;imported+=1
    pending=[x for x in js if not finished(best.get(lab.row_key({**x[0],'model':model}),{}))]
    return folder,pending,best,len(js),imported

class Budget:
    def __init__(self,maximum):self.maximum=maximum;self.n=0;self.lock=threading.Lock()
    def take(self):
        with self.lock:
            if self.n>=self.maximum:STOP.set();return False
            self.n+=1;return True
class Pacer:
    def __init__(self,rpm):self.spacing=60/rpm;self.next=0.;self.blocked_until=0.;self.lock=threading.Lock()
    def wait(self,abort):
        while not STOP.is_set() and not abort.is_set():
            with self.lock:
                now=time.monotonic();delay=max(self.next,self.blocked_until)-now
                if delay<=0:self.next=now+self.spacing;return True
            STOP.wait(min(delay,.5))
        return False
    def defer(self,seconds):
        with self.lock:self.blocked_until=max(self.blocked_until,time.monotonic()+seconds)

def error_kind(code,msg):
    if rejection({'http_status':code,'error':msg}):return 'rejection'
    t=msg.lower()
    if code==429 and (any(x in t for x in ['per day','per_day','perday','insufficient_quota','billing_hard_limit']) or re.search(r'limit:\s*0(?:\D|$)',t)):
        return 'quota_blocked'
    if code is None or code in (408,409,429) or (isinstance(code,int) and code>=500):return 'transient'
    return 'configuration_blocked'
def retry_delay(exc,attempt):
    msg=str(exc);v=getattr(exc,'retry_after',None)
    if v is not None:
        try:return max(0.,float(v))+1
        except (ValueError,TypeError):pass
    match=re.search(r'(?:retry in|retryDelay["\s:]+)\s*(\d+(?:\.\d+)?)\s*s',msg,re.I)
    if match:return float(match[1])+1
    return min(60,2**attempt)+(1 if getattr(exc,'code',None)==429 else 0)

def worker(c,job,pacer,budget,abort,attempt_log,args):
    j,s,system,prompt=job;attempts=[];started=time.perf_counter();res=None
    for a in range(args.retries+1):
        if not pacer.wait(abort) or not budget.take():break
        start=time.perf_counter()
        try:
            res=providers.complete(c,system,prompt,j['max_tokens'],args.timeout)
            parsed,error=lab.paper.E.parse_json_output(res['raw'])
            if not isinstance(parsed,dict):parsed=None;error=error or 'top-level JSON must be object'
            res.update(status='ok',parsed=parsed,parse_error=error)
            at={'attempt':a+1,'status':'ok','ms':(time.perf_counter()-start)*1000,'usage':res.get('usage')}
            attempts.append(at);attempt_log(j,at);break
        except Exception as exc:
            code=getattr(exc,'code',None);msg=str(exc);kind=error_kind(code,msg)
            at={'attempt':a+1,'status':'failed','http_status':code,'error':msg,'ms':(time.perf_counter()-start)*1000,'category':kind}
            attempts.append(at)
            res={'status':'failed','raw':'','parsed':None,'usage':None,'http_status':code,'error':msg,'failure_category':kind,'terminal_rejection':kind=='rejection'}
            if kind=='rejection':attempt_log(j,at);break
            if kind!='transient':abort.set();attempt_log(j,at);break
            if a==args.retries:abort.set();attempt_log(j,at);break
            delay=retry_delay(exc,a)
            if delay>args.max_wait:
                res['failure_category']='retry_wait_exceeds_limit';abort.set();attempt_log(j,at);break
            at['scheduled_backoff_seconds']=delay;attempt_log(j,at)
            log(f'{c["id"]}: HTTP {code}, wait {delay:.1f}s, retry {a+1}/{args.retries}')
            if code==429:pacer.defer(delay)
            else:
                until=time.monotonic()+delay
                while time.monotonic()<until and not STOP.is_set() and not abort.is_set():STOP.wait(min(.5,max(0,until-time.monotonic())))
    if res is None:return None
    res.update(total_elapsed_ms=(time.perf_counter()-started)*1000,attempts=attempts)
    return res

class Progress:
    def __init__(self,path):self.path=path;self.lock=threading.Lock();self.rows={}
    def set(self,model,ds,**kw):
        with self.lock:self.rows.setdefault((model,ds),{'model':model,'dataset':ds}).update(kw)
    def save(self,calls):
        with self.lock:rows=[dict(r) for r in self.rows.values()]
        atomic(self.path,{'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_api_attempts':calls,'rows':rows})
        active=[r for r in rows if r.get('state')=='running']
        log(' | '.join(f'{r["model"]}/{r["dataset"]}: {r.get("handled",0)}/{r.get("expected",0)}' for r in active) or 'Waiting / finishing; see progress.json')

def run_dataset(c,ds,stage_info,pacer,budget,progress,args,settings):
    folder,pending,best,expected,imported=stage_info;model=c['id'];abort=threading.Event();count=sum(finished(r) for r in best.values());initial=count
    log(f'{model}/{ds}: reuse={count}, pending={len(pending)}, workers={settings["workers"]}')
    progress.set(model,ds,expected=expected,handled=count,remaining=len(pending),state='running' if pending else 'completed',imported=imported)
    if not pending:return True
    journal_lock=threading.Lock();session=str(time.time_ns());start=time.perf_counter()
    with (folder/'attempts.jsonl').open('a',encoding='utf-8') as jf,(folder/'predictions.jsonl').open('a',encoding='utf-8') as output:
        def journal(j,at):
            with journal_lock:jf.write(lab.canonical({'session':session,'id':j['id'],'task':j['task'],'pair_index':j['pair_index'],**at})+'\n');jf.flush()
        with cf.ThreadPoolExecutor(max_workers=settings['workers']) as pool:
            queue=iter(pending);futures={}
            def fill():
                while len(futures)<settings['workers'] and not STOP.is_set() and not abort.is_set():
                    try:job=next(queue)
                    except StopIteration:return
                    futures[pool.submit(worker,c,job,pacer,budget,abort,journal,args)]=job
            fill()
            while futures:
                ready,_=cf.wait(futures,timeout=1,return_when=cf.FIRST_COMPLETED)
                for fut in ready:
                    j,s,_,_=futures.pop(fut);res=fut.result()
                    if res is None:continue
                    scores=lab.guarded_score(j['task'],s,res,ds,j['gold'])
                    row={**j,'model':model,'provider':c['provider'],'temperature':c.get('temperature'),**res,'scores':scores,
                         'execution_origin':'recovery_parallel','concurrency':settings['workers'],'configured_rpm':settings['rpm'],'session':session}
                    output.write(lab.canonical(row)+'\n');output.flush();best[lab.row_key(row)]=row
                    count+=finished(row)
                    progress.set(model,ds,handled=count,remaining=expected-count)
                    if (count-initial)%20==0:log(f'{model}/{ds}: {count}/{expected}; {time.perf_counter()-start:.0f}s this session')
                fill()
    state='completed' if count==expected else 'paused' if STOP.is_set() else 'blocked'
    progress.set(model,ds,state=state,handled=count,remaining=expected-count)
    with (folder/'batch_timing.jsonl').open('a') as f:f.write(lab.canonical({'session':session,'wall_seconds':time.perf_counter()-start,'newly_handled':count-initial,'concurrency':settings['workers'],'rpm':settings['rpm'],'state':state})+'\n')
    return count==expected

def lane(configs,staged,budget,progress,args,setting):
    pacer=Pacer(setting['rpm']);states=[]
    for c in configs:
        if STOP.is_set():break
        model=c['id'];datasets=c.get('datasets',batch.DATASETS)
        pending=sum(len(staged[(model,ds)][1]) for ds in datasets)
        if pending and not os.getenv(c['key_env']):
            for ds in datasets:
                if staged[(model,ds)][1]:progress.set(model,ds,state='missing_key')
            states.append({'model':model,'state':'missing_key','detail':c['key_env']});continue
        # Do not spend a request merely to validate a completed model.
        if pending:
            try:
                available=providers.list_models(c)
                if model not in available and not c.get('allow_unlisted',False):raise ValueError('Requested model not listed; no substitution')
            except Exception as e:
                if not c.get('allow_unlisted',False):
                    for ds in datasets:
                        if staged[(model,ds)][1]:progress.set(model,ds,state='model_list_blocked')
                    states.append({'model':model,'state':'model_list_blocked','detail':str(e)});continue
        complete=True
        for ds in datasets:
            if STOP.is_set():complete=False;break
            if not run_dataset(c,ds,staged[(model,ds)],pacer,budget,progress,args,setting):complete=False;break
        states.append({'model':model,'state':'completed' if complete else 'incomplete'})
    return states

def main():
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--out',type=Path);p.add_argument('--config',type=Path,default=ROOT/'models.json');p.add_argument('--settings',type=Path,default=ROOT/'runner_settings.json');p.add_argument('--execute',action='store_true');p.add_argument('--max-calls',type=int,default=0);p.add_argument('--retries',type=int,default=4);p.add_argument('--timeout',type=float,default=240);p.add_argument('--max-wait',type=float,default=300);p.add_argument('--heartbeat',type=float,default=30);args=p.parse_args()
    if args.retries<0 or args.timeout<=0 or args.max_wait<=0 or args.heartbeat<=0:raise ValueError('Invalid runtime limits')
    if not any((args.base/'multimodel_v1').glob('*/*/manifest.json')):raise ValueError('BASE does not contain the existing multimodel_v1 manifests; stop to avoid rerunning completed experiments')
    args.out=args.out or args.base/'recovery_v2';args.out.mkdir(parents=True,exist_ok=True)
    if args.out.resolve()==args.base.resolve():raise ValueError('Recovery output must be separate from legacy BASE')
    settings=json.loads(args.settings.read_text());configs=[c for c in json.loads(args.config.read_text()) if c.get('enabled',True)]
    if len({c['id'] for c in configs})!=len(configs):raise ValueError('Duplicate model IDs')
    for c in configs:
        s=settings[c['provider']]
        if not isinstance(s['workers'],int) or s['workers']<1 or s['rpm']<=0:raise ValueError('Invalid worker/rate setting')
    data,audit=batch.validate_data();atomic(args.out/'data_audit.json',audit)
    progress=Progress(args.out/'progress.json');staged={};plan=[]
    with contextlib.ExitStack() as locks:
        own=locks.enter_context((args.out/'resume.lock').open('a'));fcntl.flock(own,fcntl.LOCK_EX|fcntl.LOCK_NB)
        # Hold existing legacy locks while importing/running to prevent concurrent old writers locally.
        for path in sorted((args.base/'multimodel_v1').glob('*/runner.lock')):
            lock=locks.enter_context(path.open('r'));fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for c in configs:
            for ds in c.get('datasets',batch.DATASETS):
                if ds not in batch.DATASETS:raise ValueError('NASA/TAT-QA excluded from this recovery')
                info=stage(args.base,args.out,c,ds,data[ds]);staged[(c['id'],ds)]=info
                folder,pending,best,n,imported=info;handled=sum(finished(r) for r in best.values())
                row={'model':c['id'],'dataset':ds,'expected':n,'handled':handled,'pending':len(pending),'imported_this_time':imported,'terminal_rejections':sum(rejection(r) for r in best.values())}
                plan.append(row);progress.set(c['id'],ds,**{k:v for k,v in row.items() if k not in ('model','dataset')},state='completed' if not pending else 'pending')
        atomic(args.out/'plan.json',plan);batch.write_csv(args.out/'plan.csv',plan)
        total=sum(r['pending'] for r in plan);log(f'Reused terminal records: {sum(r["handled"] for r in plan)}; pending jobs: {total}')
        progress.save(0)
        if not args.execute:log('DRY RUN: no API calls. Review recovery_v2/plan.csv.');return
        if total and args.max_calls<=0:raise ValueError('Set an explicit positive max-calls budget')
        budget=Budget(args.max_calls);lanes=collections.defaultdict(list)
        for c in configs:lanes[c['provider']].append(c)
        session=str(time.time_ns());atomic(args.out/('runtime_'+session+'.json'),{'settings':settings,'retries':args.retries,'timeout':args.timeout,'max_calls':args.max_calls,'latency_note':'New parallel and imported serial latency must be analyzed separately'})
        def stop_signal(*_):STOP.set();log('Stopping submissions; waiting for in-flight requests to save (up to timeout).')
        signal.signal(signal.SIGINT,stop_signal);signal.signal(signal.SIGTERM,stop_signal)
        states=[]
        with cf.ThreadPoolExecutor(max_workers=len(lanes)) as pool:
            fs={pool.submit(lane,cs,staged,budget,progress,args,settings[provider]):provider for provider,cs in lanes.items()}
            while fs:
                done,_=cf.wait(fs,timeout=args.heartbeat,return_when=cf.FIRST_COMPLETED)
                for fut in done:
                    provider=fs.pop(fut)
                    try:states+=fut.result()
                    except Exception as e:states.append({'provider':provider,'state':'runner_error','detail':str(e)});log(f'{provider}: runner error: {e}')
                progress.save(budget.n);atomic(args.out/'model_status.json',states)
        atomic(args.out/'model_status.json',states);progress.save(budget.n)
    # Score variants mutate scorer globals, so analysis runs only after all inference threads end.
    import resume_report
    resume_report.report(args.out)
    log('Stopped safely.' if STOP.is_set() else 'Run finished; check completion.csv for pending/blocked items.')
if __name__=='__main__':main()

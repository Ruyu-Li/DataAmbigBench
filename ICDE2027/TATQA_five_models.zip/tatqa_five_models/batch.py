"""Seven-dataset resumable batch; originals preserved, supplementary scoring separate."""
import argparse, collections, contextlib, csv, hashlib, json, os, re, statistics, sys, time
from pathlib import Path
import lab, providers, geography_scoring_v2 as geo
ROOT=Path(__file__).resolve().parent
DATASETS=['sec','ambigdocs','opinionqa','retail','usc','sf311','nyc311']

def write_csv(path, rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)

def best_rows(path):
    best={}
    if path.exists():
        for r in lab.read_rows(path):
            k=lab.row_key(r)
            if k not in best or r.get('status')=='ok': best[k]=r
    return best

def jobs(ds, rows):
    for r in rows:
        for task in lab.TASKS:
            for pi in range(len(r['gold']['condition_answer_pairs'])) if task=='condition_given' else [None]:
                system,prompt,limit=lab.prompt_for(task,r,pi)
                gold=r['gold']['ambiguous_conditions'] if task=='detection' else r['gold']['condition_answer_pairs'][pi] if task=='condition_given' else r['gold']
                yield {'dataset':ds,'task':task,'id':r['id'],'pair_index':pi,'query':r['query'],'gold':gold,
                       'context_hash':lab.digest(r['table']),'prompt_hash':lab.digest([system,prompt]),
                       'max_tokens':limit,'prompt_chars':len(prompt),'table_rows':None},r,system,prompt

@contextlib.contextmanager
def retail_patch():
    original=lab.paper.canon_period
    def canon(text,unit):
        if unit=='by year-sheet':
            # Exact sheet label only: never treat a single year as a two-year sheet.
            t=str(text).strip().lower().replace('–','-').replace('—','-')
            m=re.fullmatch(r'(?:year\s*)?(\d{4})\s*-\s*(\d{4})',t)
            return f'{m[1]}-{m[2]}' if m else None
        return original(text,unit)
    lab.paper.canon_period=canon
    try: yield
    finally: lab.paper.canon_period=original

def supplemental(r):
    try:
        if r['dataset']=='retail':
            with retail_patch(): return lab.score_record(r)
        if r['dataset']=='nyc311' and r['task'] in ('detection','e2e'):
            sc=dict(r['scores']); g=geo.detection(r) if r['task']=='detection' else geo.e2e(r)
            sc['condition_f1_norm' if r['task']=='detection' else 'answer_relaxed_norm']=g['condition_f1_geo_v2' if r['task']=='detection' else 'answer_relaxed_geo_v2']
            return sc
    except (ValueError,KeyError,TypeError,AttributeError):
        return r['scores']
    return r['scores']

def answer_only(row):
    try:
        return lab.open_eval.score_open({"gold":row["gold"]},row.get("parsed"),row["dataset"])["gold_answer_recall"]
    except (TypeError, ValueError, KeyError, AttributeError):
        return 0.0

def summarize(base):
    all_rows=[]; status=[]
    for folder in sorted((base/'multimodel_v1').glob('*/*')):
        if not (folder/'predictions.jsonl').exists(): continue
        rows=list(best_rows(folder/'predictions.jsonl').values())
        if not rows: continue
        all_rows+=rows
        expected=json.loads((folder/'manifest.json').read_text())['expected_jobs']
        status.append({'model':rows[0]['model'],'dataset':rows[0]['dataset'], 'expected':expected,'recorded':len(rows),
                       'http_ok':sum(r['status']=='ok' for r in rows),'complete':len(rows)==expected and all(r['status']=='ok' for r in rows)})
    if not all_rows:return
    out=base/'multimodel_summary'; out.mkdir(exist_ok=True)
    groups=collections.defaultdict(list); failures=[]; scored=[]
    for r in all_rows:
        groups[(r['model'],r['dataset'],r['task'])].append(r)
        fixed=supplemental(r); scored.append({**r,'original_scores':r['scores'],'scores_supplemental_v1':fixed})
        for flag in lab.failure_flags(r,fixed): failures.append({**r,'category':flag,'scores_supplemental_v1':fixed})
    table=[]
    for (model,ds,task),rs in groups.items():
        latency=[r['elapsed_ms'] for r in rs if isinstance(r.get('elapsed_ms'),(float,int))]
        for variant in ['paper','supplemental_v1']:
            row={'model':model,'dataset':ds,'task':task,'scorer':variant,'n':len(rs),
                 'api_failed':sum(r['status']!='ok' for r in rs),
                 'invalid_json':sum(r.get('parsed') is None for r in rs),
                 'schema_errors':sum(bool(r.get('schema_error')) for r in rs),
                 'truncated':sum(r.get('finish_reason')=='length' for r in rs),
                 'p50_ms':statistics.median(latency) if latency else None,'p95_ms':lab.percentile(latency,.95),
                 'usage_n':sum(bool(r.get('usage')) for r in rs),
                 'reported_models':json.dumps(sorted({r.get('actual_model') or 'not_recorded' for r in rs})),
                 'tokens':sum((r.get('usage') or {}).get('total_tokens',0) or 0 for r in rs)}
            for metric in lab.PRIMARY[task]:
                values=[(r['scores'] if variant=='paper' else supplemental(r)).get(metric,0) for r in rs]
                row[metric]=100*statistics.mean(values)
            table.append(row)
    write_csv(out/'metrics_all.csv',table); write_csv(out/'completion.csv',status)
    lab.save_rows(out/'failure_examples_all.jsonl',failures)
    lab.save_rows(out/'predictions_scored.jsonl',scored)
    # Paired hinted/open comparison uses exactly the intersection of IDs.
    comparisons=[]
    for model,ds in sorted({k[:2] for k in groups}):
        a={r['id']:r for r in groups[(model,ds,'e2e')]}; b={r['id']:r for r in groups[(model,ds,'e2e_open')]}
        ids=sorted(a.keys() & b.keys())
        if ids:
            comparisons.append({'model':model,'dataset':ds,'paired_queries':len(ids),
                'hinted_condition_answer_accuracy':100*statistics.mean(supplemental(a[i]).get('answer_relaxed_norm',0) for i in ids),
                'hinted_answer_only_recall':100*statistics.mean(answer_only(a[i]) for i in ids),
                'open_answer_only_recall':100*statistics.mean(b[i]['scores']['gold_answer_recall'] for i in ids),
                'note':'Prompt-setting comparison; instructions AND output schema differ. Retail sheet fix applies to supplemental task metrics, not these paper answer-only scores.'})
    write_csv(out/'hinted_vs_open.csv',comparisons)
    print('Summary:',out,flush=True)

def validate_data():
    data={ds:lab.read_rows(ROOT/'data'/f'{ds}.jsonl') for ds in DATASETS}
    audit=[]
    for ds,rs in data.items():
        if len(rs)!=200 or len({r['id'] for r in rs})!=200:raise ValueError(ds+': expected 200 unique IDs')
        seen={}; query=collections.Counter()
        for r in rs:
            lab.valid_sample(r)
            if lab.is_answer_table(lab.prompts.safe_get_table(r)):raise ValueError(ds+': answer-lookup input')
            key=lab.digest([lab.normalized(r['query']),lab.prompts.safe_get_table(r)])
            if key in seen:raise ValueError(ds+': repeated exact input '+r['id'])
            seen[key]=r['id']; query[lab.normalized(r['query'])]+=1
        audit.append({'dataset':ds,'queries':200,'pairs':sum(len(r['gold']['condition_answer_pairs']) for r in rs),
                      'same_query_extra':sum(x-1 for x in query.values() if x>1),'data_hash':lab.digest(rs)})
    return data,audit

def run_model(c,data,args):
    model=c['id']; folder_name=re.sub(r'[^a-zA-Z0-9_.-]','_',model)
    base=args.base; root=base/'multimodel_v1'/folder_name; root.mkdir(parents=True,exist_ok=True)
    if not os.getenv(c['key_env']): return {'model':model,'state':'missing_key','detail':c['key_env']}
    # A model-list failure is not grounds to rename/substitute a requested model.
    try:
        available=providers.list_models(c)
        lab.save_json(root/'available_models.json',available)
        if model not in available and not c.get('allow_unlisted',False):
            return {'model':model,'state':'model_id_not_listed','detail':'See available_models.json; no substitution made'}
    except Exception as e:
        if not c.get('allow_unlisted',False):return {'model':model,'state':'model_list_failed','detail':str(e)}
    config={**c,'resolved_base_url':os.getenv(c.get('base_env',''),c['base_url'])}
    codehash=lab.digest([(ROOT/p).read_text() for p in ['batch.py','providers.py','lab.py','geography_scoring_v2.py','scripts/prompts.py','scripts/evaluate.py','scripts/evaluate_open.py','scripts/common.py']])
    import fcntl
    with (root/'runner.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for ds in c.get('datasets',DATASETS):
            if ds not in DATASETS:raise ValueError('NASA/TAT-QA excluded; invalid dataset '+ds)
            out=root/ds; out.mkdir(exist_ok=True); dest=out/'predictions.jsonl'
            js=list(jobs(ds,data[ds])); manifest={'config':config,'data_hash':lab.digest(data[ds]),'code_hash':codehash,'expected_jobs':len(js),'concurrency':1,'retries':0}
            mp=out/'manifest.json'
            if mp.exists() and json.loads(mp.read_text())!=manifest:raise ValueError('Changed configuration: use a new base/output version, '+str(out))
            if dest.exists() and not mp.exists():raise ValueError('Predictions without manifest: '+str(out))
            lab.save_json(mp,manifest)
            old=best_rows(dest)
            # Import only existing GPT-4.1-mini full runs after matching every input/gold/prompt.
            legacy=base/'runs'/f'{ds}_full_{model}'/'predictions.jsonl'
            if model=='gpt-4.1-mini' and legacy.exists() and c['provider']=='openai' and c.get('temperature')==0 and not c.get('extra_payload'):
                lookup={lab.row_key({**j,'model':model}):j for j,_,_,_ in js}
                with dest.open('a',encoding='utf-8') as f:
                    for k,r in best_rows(legacy).items():
                        expected=lookup.get(k)
                        if expected and k not in old and r.get('status')=='ok' and all(r.get(x)==expected[x] for x in ['context_hash','prompt_hash','gold','max_tokens']) and r.get('temperature')==0:
                            r={**r,'imported_from':str(legacy),'actual_model':r.get('actual_model')}
                            f.write(lab.canonical(r)+'\n'); old[k]=r
            pending=[x for x in js if old.get(lab.row_key({**x[0],'model':model}),{}).get('status')!='ok']
            print(model,ds,'pending',len(pending),'/',len(js),flush=True)
            failures=0; start=time.perf_counter(); executed=0
            try:
                with dest.open('a',encoding='utf-8') as f:
                    for j,s,system,prompt in pending:
                        if args.calls>=args.max_calls:raise RuntimeError('Global max-calls budget reached')
                        args.calls+=1; executed+=1; t=time.perf_counter()
                        try:
                            res=providers.complete(c,system,prompt,j['max_tokens'])
                            parsed,err=lab.paper.E.parse_json_output(res['raw'])
                            if not isinstance(parsed,dict):parsed=None;err=err or 'top-level JSON must be object'
                            res.update(status='ok',parsed=parsed,parse_error=err); failures=0
                        except Exception as e:
                            failures+=1
                            res={'status':'failed','raw':'','parsed':None,'usage':None,'error':str(e),'http_status':getattr(e,'code',None)}
                        elapsed=(time.perf_counter()-t)*1000
                        res.update(total_elapsed_ms=elapsed,attempts=[{'attempt':1,'status':res['status'],'ms':elapsed}])
                        sc=lab.guarded_score(j['task'],s,res,ds,j['gold'])
                        row={**j,'model':model,'provider':c['provider'],'temperature':c.get('temperature'),**res,'scores':sc}
                        f.write(lab.canonical(row)+'\n');f.flush()
                        if executed%20==0:print(model,ds,executed,'/',len(pending),flush=True)
                        if res.get('http_status') in (400,401,403,404) or failures>=3:
                            raise RuntimeError('Provider stopped after API error: '+str(res.get('error')))
                        if c.get('pause_seconds'):time.sleep(c['pause_seconds'])
            finally:
                with (out/'batch_timing.jsonl').open('a') as f:
                    f.write(lab.canonical({'new_attempts':executed,'wall_seconds':time.perf_counter()-start,'concurrency':1})+'\n')
                summarize(base)
    return {'model':model,'state':'completed'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,required=True);ap.add_argument('--config',type=Path,default=ROOT/'models.json');ap.add_argument('--execute',action='store_true');ap.add_argument('--max-calls',type=int,default=0);ap.add_argument('--summarize-only',action='store_true');args=ap.parse_args();args.calls=0
    args.base.mkdir(parents=True,exist_ok=True)
    if args.summarize_only:summarize(args.base);return
    data,audit=validate_data();lab.save_json(args.base/'seven_dataset_audit.json',audit)
    configs=json.loads(args.config.read_text()); plan=[]
    for c in configs:
        if not c.get('enabled',True):continue
        for ds in c.get('datasets',DATASETS):
            if ds not in DATASETS:raise ValueError('Excluded dataset '+ds)
            plan.append({'model':c['id'],'dataset':ds,'requests_before_resume':len(list(jobs(ds,data[ds]))),'key_present':bool(os.getenv(c['key_env']))})
    write_csv(args.base/'multimodel_plan.csv',plan)
    print('Maximum jobs before resume:',sum(x['requests_before_resume'] for x in plan),flush=True)
    if not args.execute:print('Dry run. Add --execute --max-calls N.');return
    if args.max_calls<=0:raise ValueError('Set a positive call budget')
    statuses=[]
    for c in configs:
        if not c.get('enabled',True):continue
        try:state=run_model(c,data,args)
        except Exception as e:state={'model':c['id'],'state':'stopped','detail':str(e)}
        statuses.append(state);lab.save_json(args.base/'model_status.json',statuses);print(state,flush=True)
        if args.calls>=args.max_calls:break
    summarize(args.base)
    if any(s['state']!='completed' for s in statuses):print('Some models blocked/incomplete: inspect model_status.json; completed results are retained.',flush=True)
if __name__=='__main__':main()

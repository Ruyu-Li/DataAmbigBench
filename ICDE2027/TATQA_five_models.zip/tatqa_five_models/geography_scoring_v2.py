#!/usr/bin/env python3
"""Versioned supplemental Geography scoring, alongside unchanged paper scores.

The supported benchmark slice has one Geography ambiguity per query and
borough-disambiguated gold interpretations. We match one predicted Geography
condition to at most one gold condition, then apply the paper answer matcher.
Unrelated predicted dimensions remain false positives in the detection F1.
"""
import argparse
import collections
import json
import re
from pathlib import Path

import lab

SCORER_VERSION = "nyc311-geography-v2.0"
BOROUGHS = r"bronx|brooklyn|manhattan|queens|staten island"
PLACE = re.compile(r"\b(?:in|as)\s+(?:the\s+)?(" + BOROUGHS + r")\b", re.I)


def borough(condition):
    matches = PLACE.findall(str(condition))
    return matches[-1].casefold() if matches else None


def gold_labels(row):
    gold = row["gold"]
    return gold if row["task"] == "detection" else gold["ambiguous_conditions"]


def geography_conditions(row):
    labels = gold_labels(row)
    geography = [label for label in labels if label.get("dimension") == "Geography"]
    if len(geography) != 1:
        raise ValueError(f"{row['id']}: expected one Geography ambiguity")
    gold = geography[0].get("conditions", [])
    canon = [borough(value) for value in gold]
    if len(canon) < 2 or any(x is None for x in canon) or len(set(canon)) != len(canon):
        raise ValueError(f"{row['id']}: gold borough conditions are missing or repeated")
    return canon


def safe_predictions(row):
    parsed = row.get("parsed")
    return parsed if isinstance(parsed, dict) else {}


def detection(row):
    gold = geography_conditions(row)
    all_predicted = []
    for label in safe_predictions(row).get("ambiguous_conditions", []) or []:
        if not isinstance(label, dict):
            continue
        for condition in label.get("possible_conditions", []) or []:
            all_predicted.append(borough(condition) if label.get("dimension") == "Geography" else None)
    available = collections.Counter(x for x in all_predicted if x)
    hits = sum(bool(available[x]) for x in gold)
    precision = hits / len(all_predicted) if all_predicted else 0.0
    recall = hits / len(gold)
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"condition_f1_geo_v2": f1, "geo_hits": hits,
            "predicted_conditions_all_dimensions": len(all_predicted), "gold_conditions": len(gold)}


def e2e(row):
    gold = geography_conditions(row)
    pairs = row["gold"]["condition_answer_pairs"]
    if [borough(pair["conditions"].get("Geography", "")) for pair in pairs] != gold:
        raise ValueError(f"{row['id']}: gold pair order differs from Geography labels")
    raw_answers = safe_predictions(row).get("answers", []) or []
    answers = [a for a in raw_answers if isinstance(a, dict)]
    used, details = set(), []
    for index, pair in enumerate(pairs):
        match = next(((j, a) for j, a in enumerate(answers)
                      if j not in used and isinstance(a.get("conditions"), dict)
                      and borough(a["conditions"].get("Geography", "")) == gold[index]), None)
        if match:
            used.add(match[0])
        prediction = match[1] if match else None
        correct = bool(prediction is not None and lab.paper.ans_relaxed(
            prediction.get("answer", ""), pair, "nyc311"))
        details.append({"borough": gold[index], "gold_condition": pair["conditions"]["Geography"],
                        "pred_condition": prediction["conditions"].get("Geography") if prediction else None,
                        "gold_answer": pair["answer"],
                        "pred_answer": prediction.get("answer") if prediction else None,
                        "matched": bool(match), "correct": correct})
    return {"coverage_geo_v2": sum(d["matched"] for d in details) / len(details),
            "answer_relaxed_geo_v2": sum(d["correct"] for d in details) / len(details),
            "matched_pairs": sum(d["matched"] for d in details),
            "correct_pairs": sum(d["correct"] for d in details),
            "gold_pairs": len(details), "details": details}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--results", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    best = {}
    for row in lab.load_results(args.results):
        if row.get("dataset") != "nyc311" or row.get("task") not in ("detection", "e2e"):
            continue
        key = (row["id"], row["model"], row["task"])
        if key not in best or row.get("status") == "ok":
            best[key] = row
    if not best:
        raise ValueError("no NYC311 detection or hinted E2E records")
    output = []
    for row in best.values():
        scored = detection(row) if row["task"] == "detection" else e2e(row)
        output.append({"dataset": row["dataset"], "model": row["model"], "id": row["id"],
                       "query": row["query"], "task": row["task"],
                       "scorer_version": SCORER_VERSION, "original_scores": row["scores"],
                       "scores_v2": scored})
    lab.save_rows(args.out / "nyc311_scored_v2.jsonl", output)
    summary = []
    for task in ("detection", "e2e"):
        group = [r for r in output if r["task"] == task]
        if not group:
            continue
        if task == "detection":
            summary.append({"task": task, "queries": len(group),
                            "condition_f1_geo_v2_pct": round(100 * sum(
                                r["scores_v2"]["condition_f1_geo_v2"] for r in group) / len(group), 2),
                            "paper_condition_f1_norm_pct": round(100 * sum(
                                r["original_scores"]["condition_f1_norm"] for r in group) / len(group), 2)})
        else:
            count = sum(r["scores_v2"]["gold_pairs"] for r in group)
            summary.append({"task": task, "queries": len(group), "gold_pairs": count,
                            "matched_pairs": sum(r["scores_v2"]["matched_pairs"] for r in group),
                            "correct_pairs": sum(r["scores_v2"]["correct_pairs"] for r in group),
                            "answer_relaxed_geo_v2_pair_pct": round(100 * sum(
                                r["scores_v2"]["correct_pairs"] for r in group) / count, 2),
                            "answer_relaxed_geo_v2_query_pct": round(100 * sum(
                                r["scores_v2"]["answer_relaxed_geo_v2"] for r in group) / len(group), 2),
                            "paper_answer_relaxed_norm_pct": round(100 * sum(
                                r["original_scores"]["answer_relaxed_norm"] for r in group) / len(group), 2)})
    report = {"scorer_version": SCORER_VERSION, "scope": "NYC311 Geography only",
              "note": "Original paper scores are preserved. Extra predicted dimensions remain false positives for Detection and are not used as answer-matching keys.",
              "metrics": summary}
    lab.save_json(args.out / "nyc311_summary_v2.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

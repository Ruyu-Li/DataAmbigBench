from typing import Any, Dict
from .utils import safe_get_table


SYSTEM_PROMPT = """You are an evaluator for ambiguous tabular question answering.
You must use only the provided table.
You must output valid JSON only.
Do not include markdown, explanations outside JSON, or extra text."""


ALLOWED_DIMENSIONS = "Definition-Metric, Temporal, Granularity, Geography, Other"


DIMENSION_DEFINITIONS = """
Dimension definitions:

1. Definition-Metric:
The query uses an abstract, underspecified, or overloaded metric term, and the table contains multiple possible concrete metrics.
The ambiguity comes from not knowing which metric definition should be used.

Examples:
- SEC: "profit" may refer to gross_profit or net_income.
- NASA: a high-level measurement term may refer to different concrete NASA POWER parameters.
- Online Retail: "best-performing product" may refer to highest revenue, highest quantity sold, most invoices, highest unit price, or most repeat customers.

2. Temporal:
The query contains a time expression or asks for trends, but the exact time period, comparison window, or temporal reference is unclear.
The ambiguity comes from not knowing which time condition should be used.

Examples:
- TAT-QA: a question about revenue may depend on whether the target year is 2018 or 2019.
- TAT-QA: "increase" or "growth" may depend on which previous year or comparison period is used.
- Online Retail: "What were the sales trends?" may refer to 2009-2010, 2010-2011, both years, monthly trends, weekly trends, seasonal trends, or holiday trends.

3. Granularity:
The query asks for analysis over time or another dimension, but does not specify the grouping level.
The ambiguity comes from not knowing how finely or coarsely to group the data.

Examples:
- Online Retail: "Analyze sales over time" may be grouped by day, week, month, quarter, or year-sheet.

4. Geography:
The query contains or implies a location-related scope, but the location or geographic level is unclear.
The ambiguity comes from not knowing which country, region, or geographic subset should be used.

Examples:
- Online Retail: product sales during a time period may refer to sales in the United Kingdom, Germany, France, or all countries.

5. Other:
Use this only if the ambiguity does not fit the above dimensions.
""".strip()


FEW_SHOT_EXAMPLES = """
Few-shot examples:

Example 1: Definition-Metric ambiguity in SEC

Table:
| company | period | gross_profit | net_income |
|---|---|---:|---:|
| ABC CORP | 2025 Q3 | 1000000 | 250000 |

Query:
What was the profit of ABC CORP in 2025 Q3?

Ambiguous condition:
{
  "term": "profit",
  "dimension": "Definition-Metric",
  "possible_conditions": ["gross_profit", "net_income"]
}

Condition-specific answers:
[
  {
    "conditions": {"Definition-Metric": "gross_profit"},
    "answer": "1000000"
  },
  {
    "conditions": {"Definition-Metric": "net_income"},
    "answer": "250000"
  }
]

Example 2: Temporal ambiguity in TAT-QA

Table:
| Year | Revenue |
|---|---:|
| 2018 | 100 |
| 2019 | 130 |
| 2020 | 160 |

Query:
What was the revenue increase?

Ambiguous condition:
{
  "term": "revenue increase",
  "dimension": "Temporal",
  "possible_conditions": ["2018 to 2019", "2019 to 2020"]
}

Condition-specific answers:
[
  {
    "conditions": {"Temporal": "2018 to 2019"},
    "answer": "30"
  },
  {
    "conditions": {"Temporal": "2019 to 2020"},
    "answer": "30"
  }
]

Example 3: Granularity ambiguity in Online Retail

Table:
| Invoice | InvoiceDate | Product | Quantity | Revenue | Country |
|---|---|---|---:|---:|---|
| 001 | 2010-12-01 | Gift Set | 10 | 100 | United Kingdom |
| 002 | 2010-12-02 | Gift Set | 5 | 50 | United Kingdom |
| 003 | 2010-12-08 | Gift Set | 20 | 200 | United Kingdom |

Query:
Analyze sales over time.

Ambiguous condition:
{
  "term": "over time",
  "dimension": "Granularity",
  "possible_conditions": ["day", "week", "month", "quarter", "year-sheet"]
}

Condition-specific answers:
[
  {
    "conditions": {"Granularity": "day"},
    "answer": "daily sales trend"
  },
  {
    "conditions": {"Granularity": "week"},
    "answer": "weekly sales trend"
  },
  {
    "conditions": {"Granularity": "month"},
    "answer": "monthly sales trend"
  }
]

Example 4: Definition-Metric ambiguity in Online Retail

Table:
| Product | Revenue | Quantity | InvoiceCount | UnitPrice | RepeatCustomers |
|---|---:|---:|---:|---:|---:|
| Product A | 1000 | 50 | 10 | 20 | 5 |
| Product B | 800 | 100 | 8 | 8 | 12 |

Query:
Which product performed best?

Ambiguous condition:
{
  "term": "performed best",
  "dimension": "Definition-Metric",
  "possible_conditions": ["highest revenue", "highest quantity sold", "most invoices", "highest unit price", "most repeat customers"]
}

Condition-specific answers:
[
  {
    "conditions": {"Definition-Metric": "highest revenue"},
    "answer": "Product A"
  },
  {
    "conditions": {"Definition-Metric": "highest quantity sold"},
    "answer": "Product B"
  },
  {
    "conditions": {"Definition-Metric": "most repeat customers"},
    "answer": "Product B"
  }
]

Example 5: Geography ambiguity in Online Retail

Table:
| Product | Country | Revenue |
|---|---|---:|
| Product A | United Kingdom | 1000 |
| Product A | Germany | 300 |
| Product B | France | 700 |
| Product B | United Kingdom | 500 |

Query:
Which product had the highest sales during the period?

Ambiguous condition:
{
  "term": "sales during the period",
  "dimension": "Geography",
  "possible_conditions": ["United Kingdom", "Germany", "France", "all countries"]
}

Condition-specific answers:
[
  {
    "conditions": {"Geography": "United Kingdom"},
    "answer": "Product A"
  },
  {
    "conditions": {"Geography": "France"},
    "answer": "Product B"
  },
  {
    "conditions": {"Geography": "all countries"},
    "answer": "Product A"
  }
]
""".strip()


def _few_shot_block(prompt_mode: str) -> str:
    if prompt_mode == "few_shot":
        return f"""

{FEW_SHOT_EXAMPLES}
"""
    return ""


def build_detection_prompt(sample: Dict[str, Any], prompt_mode: str = "zero_shot") -> str:
    table = safe_get_table(sample)
    query = sample["query"]
    few_shot_block = _few_shot_block(prompt_mode)

    return f"""
Task: Ambiguity Detection for Tabular QA

Given a table and a user query, identify ambiguous terms or phrases in the query.

You need to identify:
- the ambiguous term or phrase
- the ambiguity dimension
- the possible concrete conditions or interpretations

Allowed dimensions:
{ALLOWED_DIMENSIONS}

{DIMENSION_DEFINITIONS}
{few_shot_block}

Return JSON exactly in this schema:
{{
  "ambiguous_conditions": [
    {{
      "term": "...",
      "dimension": "Definition-Metric or Temporal or Granularity or Geography or Other",
      "possible_conditions": ["...", "..."]
    }}
  ]
}}

Now evaluate the following case.

Table:
{table}

Query:
{query}
""".strip()


def build_condition_answer_prompt(
    sample: Dict[str, Any],
    condition_obj: Dict[str, Any],
    prompt_mode: str = "zero_shot"
) -> str:
    table = safe_get_table(sample)
    query = sample["query"]
    conditions = condition_obj.get("conditions", {})
    few_shot_block = _few_shot_block(prompt_mode)

    return f"""
Task: Condition-Given Tabular QA

Given a table, a query, and gold conditions, answer the query using only the specified gold conditions.

Allowed dimensions:
{ALLOWED_DIMENSIONS}

{DIMENSION_DEFINITIONS}
{few_shot_block}

Critical rules:
1. The gold condition overrides the original ambiguous query wording.
2. Use only the column, grouping, time period, granularity, geography, or metric specified in the gold condition.
3. Do not use another condition that is not specified.
4. If the gold condition is gross_profit, return the value under gross_profit.
5. If the gold condition is net_income, return the value under net_income.
6. If the gold condition is a concrete NASA parameter, use that parameter only.
7. If the gold condition specifies a Temporal condition, use only that time period or comparison window.
8. If the gold condition specifies a Granularity condition, group the data at that level.
9. If the gold condition specifies a Geography condition, filter or group the data using only that geographic scope.
10. The final answer must be the numeric value, label, group, or trend requested by the gold condition.
11. Output only the answer value in the "answer" field. Do not include extra explanation in the answer field.

Return JSON exactly in this schema:
{{
  "filtered_rows": ["row ids or short row descriptions used"],
  "group_values": {{
    "metric name or group name": "computed value"
  }},
  "answer": "...",
  "calculation": "brief calculation from the table"
}}

Now evaluate the following case.

Table:
{table}

Query:
{query}

Gold Conditions:
{conditions}
""".strip()


def build_e2e_prompt(sample: Dict[str, Any], prompt_mode: str = "zero_shot") -> str:
    table = safe_get_table(sample)
    query = sample["query"]
    few_shot_block = _few_shot_block(prompt_mode)

    return f"""
Task: End-to-End Ambiguous Tabular QA

Given a table and an ambiguous query:
1. Identify ambiguous conditions in the query.
2. Generate possible specific interpretations.
3. Answer the query under each interpretation.

Use only the provided table.

Allowed dimensions:
{ALLOWED_DIMENSIONS}

{DIMENSION_DEFINITIONS}
{few_shot_block}

Output format requirement:
- In each answer, the "conditions" object must use actual dimension labels as keys.
- The condition key must be one of: Definition-Metric, Temporal, Granularity, Geography, Other.
- Do not use placeholder keys such as "DimensionName" or "AnotherDimension".
- The "answer" field should contain only the final answer value, not a full sentence.

Return JSON exactly in this schema:
{{
  "ambiguous_conditions": [
    {{
      "term": "...",
      "dimension": "Definition-Metric or Temporal or Granularity or Geography or Other",
      "possible_conditions": ["...", "..."]
    }}
  ],
  "answers": [
    {{
      "conditions": {{
        "Definition-Metric": "specific condition"
      }},
      "filtered_rows": ["row ids or short row descriptions used"],
      "group_values": {{
        "metric name or group name": "computed value"
      }},
      "answer": "...",
      "calculation": "brief calculation from the table"
    }}
  ]
}}

If the dimension is Temporal, use:
"conditions": {{"Temporal": "specific condition"}}

If the dimension is Granularity, use:
"conditions": {{"Granularity": "specific condition"}}

If the dimension is Geography, use:
"conditions": {{"Geography": "specific condition"}}

Now evaluate the following case.

Table:
{table}

Query:
{query}
""".strip()


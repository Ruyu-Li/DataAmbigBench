from typing import Any, Dict, List, Set, Tuple
from .utils import normalize_text
import re


DIMENSION_ALIASES = {
    "definition metric": "definition-metric",
    "definition-metric": "definition-metric",
    "metric definition": "definition-metric",
    "metric": "definition-metric",
    "financial metric": "definition-metric",

    "temporal": "temporal",
    "time": "temporal",
    "time period": "temporal",
    "time-period": "temporal",
    "date": "temporal",

    "granularity": "granularity",

    "geography": "geography",
    "geographic": "geography",
    "location": "geography",
    "country": "geography",

    "other": "other",
}


PLACEHOLDER_KEYS = {
    "dimensionname",
    "anotherdimension",
    "dimension",
    "condition",
}


def normalize_dimension(x: Any) -> str:
    x = normalize_text(x)
    x = x.replace("-", " ")
    return DIMENSION_ALIASES.get(x, x.replace(" ", "-"))


def extract_numbers(x: Any) -> List[float]:
    """
    Extract all numbers from a string.

    Example:
    "The gross profit of 1 800 FLOWERS in 2026 Q1 was 76,762,000."
    -> [1.0, 800.0, 2026.0, 1.0, 76762000.0]
    """
    if x is None:
        return []

    s = str(x).strip()
    s = s.replace(",", "")

    matches = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", s)

    nums = []
    for m in matches:
        try:
            nums.append(float(m))
        except Exception:
            pass

    return nums


def numeric_equal(a: Any, b: Any, rel_tol: float = 1e-6, abs_tol: float = 1e-6) -> bool:
    nums_a = extract_numbers(a)
    nums_b = extract_numbers(b)

    if not nums_a or not nums_b:
        return False

    for na in nums_a:
        for nb in nums_b:
            if abs(na - nb) <= max(abs_tol, rel_tol * max(abs(na), abs(nb))):
                return True

    return False


def soft_answer_match(gold_answer: Any, pred_answer: Any) -> bool:
    if numeric_equal(gold_answer, pred_answer):
        return True

    gold_norm = normalize_text(gold_answer)
    pred_norm = normalize_text(pred_answer)

    if not gold_norm or not pred_norm:
        return False

    return gold_norm == pred_norm or gold_norm in pred_norm or pred_norm in gold_norm


def soft_term_match(pred_term: str, gold_term: str) -> bool:
    p = normalize_text(pred_term)
    g = normalize_text(gold_term)

    if not p or not g:
        return False

    if p == g:
        return True

    if g in p or p in g:
        return True

    p_tokens = set(p.split())
    g_tokens = set(g.split())

    if not p_tokens or not g_tokens:
        return False

    overlap = len(p_tokens & g_tokens) / len(g_tokens)
    return overlap >= 0.5


def _gold_ambig_items(sample: Dict[str, Any]) -> List[Dict[str, str]]:
    gold_items = sample.get("gold", {}).get("ambiguous_conditions", [])

    return [
        {
            "term": x.get("term", ""),
            "dimension": normalize_dimension(x.get("dimension", "")),
        }
        for x in gold_items
    ]


def _pred_ambig_items(pred: Dict[str, Any]) -> List[Dict[str, str]]:
    pred_items = pred.get("ambiguous_conditions", [])

    if not isinstance(pred_items, list):
        return []

    return [
        {
            "term": x.get("term", ""),
            "dimension": normalize_dimension(x.get("dimension", "")),
        }
        for x in pred_items
        if isinstance(x, dict)
    ]


def match_ambiguous_items(pred_items: List[Dict[str, str]], gold_items: List[Dict[str, str]]) -> int:
    matched_gold = set()
    tp = 0

    for p in pred_items:
        for i, g in enumerate(gold_items):
            if i in matched_gold:
                continue

            same_dim = p["dimension"] == g["dimension"]
            same_term = soft_term_match(p["term"], g["term"])

            if same_dim and same_term:
                matched_gold.add(i)
                tp += 1
                break

    return tp


def precision_recall_f1_counts(tp: int, pred_count: int, gold_count: int) -> Dict[str, float]:
    if pred_count == 0 and gold_count == 0:
        return {"precision": 1.0, "recall": 1.0, "f1": 1.0}

    if pred_count == 0 or gold_count == 0:
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0}

    precision = tp / pred_count
    recall = tp / gold_count

    if precision + recall == 0:
        f1 = 0.0
    else:
        f1 = 2 * precision * recall / (precision + recall)

    return {
        "precision": precision,
        "recall": recall,
        "f1": f1,
    }


def precision_recall_f1(pred_set: Set[Any], gold_set: Set[Any]) -> Dict[str, float]:
    if not pred_set and not gold_set:
        return {"precision": 1.0, "recall": 1.0, "f1": 1.0}

    if not pred_set:
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0}

    if not gold_set:
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0}

    tp = len(pred_set & gold_set)
    return precision_recall_f1_counts(tp, len(pred_set), len(gold_set))


def score_detection(sample: Dict[str, Any], pred: Dict[str, Any]) -> Dict[str, Any]:
    gold_items = _gold_ambig_items(sample)
    pred_items = _pred_ambig_items(pred)

    tp = match_ambiguous_items(pred_items, gold_items)
    prf = precision_recall_f1_counts(tp, len(pred_items), len(gold_items))

    return {
        "setting": "detection",
        "gold_count": len(gold_items),
        "pred_count": len(pred_items),
        "true_positive": tp,
        "precision": prf["precision"],
        "recall": prf["recall"],
        "f1": prf["f1"],
        "exact_match_all": float(tp == len(gold_items) and len(pred_items) == len(gold_items)),
    }


def score_condition_answer(gold_answer: Any, pred: Dict[str, Any]) -> Dict[str, Any]:
    pred_answer = pred.get("answer", "")
    matched = soft_answer_match(gold_answer, pred_answer)

    return {
        "setting": "condition_answer",
        "gold_answer": gold_answer,
        "pred_answer": pred_answer,
        "answer_exact_match": float(matched),
        "answer_contains_gold": float(matched),
    }


def _gold_condition_lookup(sample: Dict[str, Any]) -> Dict[str, str]:
    """
    Build mapping from condition value to gold dimension.

    Example:
    gross_profit -> definition-metric
    net_income -> definition-metric
    2018 to 2019 -> temporal
    """
    lookup = {}

    for ac in sample.get("gold", {}).get("ambiguous_conditions", []):
        dim = normalize_dimension(ac.get("dimension", ""))

        for cond in ac.get("conditions", []):
            lookup[normalize_text(cond)] = dim

        for cond in ac.get("possible_conditions", []):
            lookup[normalize_text(cond)] = dim

    for pair in sample.get("gold", {}).get("condition_answer_pairs", []):
        conds = pair.get("conditions", {})
        if isinstance(conds, dict):
            for dim, value in conds.items():
                lookup[normalize_text(value)] = normalize_dimension(dim)

    return lookup


def normalize_conditions_dict(conditions: Dict[str, Any], sample: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize predicted condition dictionary.

    If model outputs:
    {"DimensionName": "gross_profit"}

    and gold says gross_profit belongs to Definition-Metric,
    convert it to:
    {"Definition-Metric": "gross_profit"}
    """
    if not isinstance(conditions, dict):
        return {}

    out = {}
    lookup = _gold_condition_lookup(sample)

    gold_dims = {
        normalize_dimension(ac.get("dimension", ""))
        for ac in sample.get("gold", {}).get("ambiguous_conditions", [])
    }

    for raw_key, raw_value in conditions.items():
        key_norm = normalize_dimension(raw_key)
        key_plain = normalize_text(raw_key)

        value_norm = normalize_text(raw_value)

        if key_plain in PLACEHOLDER_KEYS or key_norm in PLACEHOLDER_KEYS:
            inferred_dim = lookup.get(value_norm)

            if inferred_dim is None and len(gold_dims) == 1:
                inferred_dim = list(gold_dims)[0]

            if inferred_dim is not None:
                out[inferred_dim] = raw_value
            else:
                out[key_norm] = raw_value
        else:
            out[key_norm] = raw_value

    return out


def _conditions_to_key(conditions: Dict[str, Any], sample: Dict[str, Any] = None) -> Tuple[Tuple[str, str], ...]:
    if not isinstance(conditions, dict):
        return tuple()

    if sample is not None:
        conditions = normalize_conditions_dict(conditions, sample)

    return tuple(
        sorted(
            (normalize_dimension(k), normalize_text(v))
            for k, v in conditions.items()
        )
    )


def soft_condition_key_match(pred_key, gold_key) -> bool:
    if not pred_key or not gold_key:
        return False

    pred_dict = dict(pred_key)
    gold_dict = dict(gold_key)

    matched = 0

    for g_dim, g_val in gold_dict.items():
        p_val = pred_dict.get(g_dim)

        if p_val is None:
            continue

        if g_val == p_val or g_val in p_val or p_val in g_val:
            matched += 1
            continue

        g_tokens = set(g_val.split())
        p_tokens = set(p_val.split())

        if g_tokens and len(g_tokens & p_tokens) / len(g_tokens) >= 0.5:
            matched += 1

    return matched == len(gold_dict)


def score_e2e(sample: Dict[str, Any], pred: Dict[str, Any]) -> Dict[str, Any]:
    detection_scores = score_detection(sample, pred)

    gold_pairs = sample.get("gold", {}).get("condition_answer_pairs", [])

    gold_map = {
        _conditions_to_key(x.get("conditions", {}), sample): x.get("answer", "")
        for x in gold_pairs
    }

    pred_answers = pred.get("answers", [])

    if not isinstance(pred_answers, list):
        pred_answers = []

    pred_map = {
        _conditions_to_key(x.get("conditions", {}), sample): x.get("answer", "")
        for x in pred_answers
        if isinstance(x, dict)
    }

    matched_conditions = 0
    matched_answers = 0
    used_pred_keys = set()

    for gold_key, gold_answer in gold_map.items():
        for pred_key, pred_answer in pred_map.items():
            if pred_key in used_pred_keys:
                continue

            if soft_condition_key_match(pred_key, gold_key):
                matched_conditions += 1
                used_pred_keys.add(pred_key)

                if soft_answer_match(gold_answer, pred_answer):
                    matched_answers += 1

                break

    condition_prf = precision_recall_f1_counts(
        matched_conditions,
        len(pred_map),
        len(gold_map)
    )

    if gold_map:
        answer_em_rate = matched_answers / len(gold_map)
    else:
        answer_em_rate = 0.0

    return {
        "setting": "e2e",
        "detection_precision": detection_scores["precision"],
        "detection_recall": detection_scores["recall"],
        "detection_f1": detection_scores["f1"],
        "condition_precision": condition_prf["precision"],
        "condition_recall": condition_prf["recall"],
        "condition_f1": condition_prf["f1"],
        "answer_em_rate": answer_em_rate,
        "full_e2e_exact": float(
            detection_scores["exact_match_all"] == 1.0
            and condition_prf["f1"] == 1.0
            and answer_em_rate == 1.0
        ),
    }


def aggregate_scores(rows: List[Dict[str, Any]]) -> Dict[str, float]:
    metric_rows = [
        r.get("metrics", {})
        for r in rows
        if r.get("metrics")
    ]

    if not metric_rows:
        return {}

    allowed_metric_keys = {
        "gold_count",
        "pred_count",
        "true_positive",
        "precision",
        "recall",
        "f1",
        "exact_match_all",
        "answer_exact_match",
        "answer_contains_gold",
        "detection_precision",
        "detection_recall",
        "detection_f1",
        "condition_precision",
        "condition_recall",
        "condition_f1",
        "answer_em_rate",
        "full_e2e_exact",
    }

    keys = sorted(
        {
            k
            for row in metric_rows
            for k, v in row.items()
            if k in allowed_metric_keys and isinstance(v, (int, float))
        }
    )

    return {
        f"avg_{k}": sum(float(row.get(k, 0.0)) for row in metric_rows) / len(metric_rows)
        for k in keys
    }

import argparse
import json
from typing import Any, Dict, List

from tqdm import tqdm

from .llm_client import LLMClient
from .prompts import (
    build_detection_prompt,
    build_condition_answer_prompt,
    build_e2e_prompt,
)
from .metrics import (
    score_detection,
    score_condition_answer,
    score_e2e,
    aggregate_scores,
)
from .utils import extract_json_object, read_jsonl, write_jsonl


def run_detection(
    samples: List[Dict[str, Any]],
    client: LLMClient,
    prompt_mode: str = "zero_shot"
) -> List[Dict[str, Any]]:
    outputs = []

    for sample in tqdm(samples, desc=f"Running ambiguity detection [{prompt_mode}]"):
        prompt = build_detection_prompt(sample, prompt_mode=prompt_mode)
        raw = client.complete(prompt)
        pred = extract_json_object(raw)
        metrics = score_detection(sample, pred)

        outputs.append({
            "id": sample.get("id"),
            "setting": "detection",
            "prompt_mode": prompt_mode,
            "query": sample.get("query"),
            "raw_response": raw,
            "prediction": pred,
            "metrics": metrics,
        })

    return outputs


def run_condition_answer(
    samples: List[Dict[str, Any]],
    client: LLMClient,
    prompt_mode: str = "zero_shot"
) -> List[Dict[str, Any]]:
    outputs = []

    for sample in tqdm(samples, desc=f"Running condition-given answering [{prompt_mode}]"):
        pairs = sample.get("gold", {}).get("condition_answer_pairs", [])

        if not pairs:
            outputs.append({
                "id": sample.get("id"),
                "setting": "condition_answer",
                "prompt_mode": prompt_mode,
                "query": sample.get("query"),
                "error": "No gold.condition_answer_pairs found.",
                "metrics": {},
            })
            continue

        for idx, pair in enumerate(pairs):
            prompt = build_condition_answer_prompt(
                sample,
                pair,
                prompt_mode=prompt_mode
            )
            raw = client.complete(prompt)
            pred = extract_json_object(raw)
            metrics = score_condition_answer(pair.get("answer", ""), pred)

            outputs.append({
                "id": sample.get("id"),
                "pair_index": idx,
                "setting": "condition_answer",
                "prompt_mode": prompt_mode,
                "query": sample.get("query"),
                "gold_conditions": pair.get("conditions", {}),
                "gold_answer": pair.get("answer", ""),
                "raw_response": raw,
                "prediction": pred,
                "metrics": metrics,
            })

    return outputs


def run_e2e(
    samples: List[Dict[str, Any]],
    client: LLMClient,
    prompt_mode: str = "zero_shot"
) -> List[Dict[str, Any]]:
    outputs = []

    for sample in tqdm(samples, desc=f"Running end-to-end evaluation [{prompt_mode}]"):
        prompt = build_e2e_prompt(sample, prompt_mode=prompt_mode)
        raw = client.complete(prompt)
        pred = extract_json_object(raw)
        metrics = score_e2e(sample, pred)

        outputs.append({
            "id": sample.get("id"),
            "setting": "e2e",
            "prompt_mode": prompt_mode,
            "query": sample.get("query"),
            "raw_response": raw,
            "prediction": pred,
            "metrics": metrics,
        })

    return outputs


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--input",
        required=True,
        help="Input standardized evaluation JSONL file."
    )

    parser.add_argument(
        "--output",
        required=True,
        help="Output JSONL file."
    )

    parser.add_argument(
        "--setting",
        required=True,
        choices=["detection", "condition_answer", "e2e"],
        help="Evaluation setting."
    )

    parser.add_argument(
        "--prompt_mode",
        default="zero_shot",
        choices=["zero_shot", "few_shot"],
        help="Prompt version: zero_shot or few_shot."
    )

    parser.add_argument(
        "--model",
        default="gpt-4o-mini",
        help="OpenAI model name."
    )

    parser.add_argument(
        "--temperature",
        type=float,
        default=0.0,
        help="Sampling temperature."
    )

    parser.add_argument(
        "--mock",
        action="store_true",
        help="Run without API using deterministic mock responses."
    )

    args = parser.parse_args()

    samples = read_jsonl(args.input)

    client = LLMClient(
        model=args.model,
        temperature=args.temperature,
        mock=args.mock
    )

    if args.setting == "detection":
        outputs = run_detection(
            samples,
            client,
            prompt_mode=args.prompt_mode
        )

    elif args.setting == "condition_answer":
        outputs = run_condition_answer(
            samples,
            client,
            prompt_mode=args.prompt_mode
        )

    elif args.setting == "e2e":
        outputs = run_e2e(
            samples,
            client,
            prompt_mode=args.prompt_mode
        )

    else:
        raise ValueError(f"Unknown setting: {args.setting}")

    write_jsonl(args.output, outputs)

    summary = aggregate_scores(outputs)
    summary_path = args.output.replace(".jsonl", "_summary.json")

    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(f"Saved detailed outputs to: {args.output}")
    print(f"Saved summary metrics to: {summary_path}")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

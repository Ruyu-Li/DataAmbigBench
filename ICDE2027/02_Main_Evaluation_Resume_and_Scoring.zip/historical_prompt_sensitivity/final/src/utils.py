import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List


def read_jsonl(path: str) -> List[Dict[str, Any]]:
    rows = []

    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            line = line.strip()

            if not line:
                continue

            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as e:
                raise ValueError(
                    f"Invalid JSON at line {line_no} in {path}: {e}"
                ) from e

    return rows


def write_jsonl(path: str, rows: Iterable[Dict[str, Any]]) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(x: Any) -> str:
    if x is None:
        return ""

    x = str(x).lower().strip()
    x = re.sub(r"[\s_/-]+", " ", x)
    x = re.sub(r"[^a-z0-9.%$ ]+", "", x)
    x = re.sub(r"\s+", " ", x).strip()

    return x


def safe_get_table(sample: Dict[str, Any]) -> str:
    table = sample.get("table", "")

    if isinstance(table, dict):
        return str(table.get("content", ""))

    return str(table)


def extract_json_object(text: str) -> Dict[str, Any]:
    if not text:
        return {}

    cleaned = text.strip()

    fence_match = re.search(
        r"```(?:json)?\s*(.*?)```",
        cleaned,
        flags=re.DOTALL | re.IGNORECASE
    )

    if fence_match:
        cleaned = fence_match.group(1).strip()

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    start = cleaned.find("{")
    end = cleaned.rfind("}")

    if start != -1 and end != -1 and end > start:
        candidate = cleaned[start:end + 1]

        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            return {}

    return {}

import os
from .prompts import SYSTEM_PROMPT


class LLMClient:
    def __init__(self, model: str = "gpt-4o-mini", temperature: float = 0.0, mock: bool = False):
        self.model = model
        self.temperature = temperature
        self.mock = mock
        self._client = None

        if not mock:
            try:
                from openai import OpenAI
            except ImportError as e:
                raise ImportError("Please install openai: pip install openai") from e

            if not os.getenv("OPENAI_API_KEY"):
                raise EnvironmentError(
                    "OPENAI_API_KEY is not set. Set it or use --mock for local testing."
                )

            self._client = OpenAI()

    def complete(self, prompt: str) -> str:
        if self.mock:
            return self._mock_response(prompt)

        response = self._client.chat.completions.create(
            model=self.model,
            temperature=self.temperature,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        )

        return response.choices[0].message.content or ""

    def _mock_response(self, prompt: str) -> str:
        if "Ambiguity Detection" in prompt:
            return """{
              "ambiguous_conditions": [
                {
                  "term": "profit",
                  "dimension": "Definition-Metric",
                  "possible_conditions": ["gross_profit", "net_income"]
                }
              ]
            }"""

        if "Condition-Given" in prompt:
            return """{
              "filtered_rows": ["mock row"],
              "group_values": {
                "mock_metric": "100"
              },
              "answer": "100",
              "calculation": "This is a mock response for pipeline testing."
            }"""

        return """{
          "ambiguous_conditions": [
            {
              "term": "profit",
              "dimension": "Definition-Metric",
              "possible_conditions": ["gross_profit", "net_income"]
            }
          ],
          "answers": [
            {
              "conditions": {
                "Definition-Metric": "gross_profit"
              },
              "filtered_rows": ["mock row"],
              "group_values": {
                "gross_profit": "100"
              },
              "answer": "100",
              "calculation": "This is a mock response for pipeline testing."
            },
            {
              "conditions": {
                "Definition-Metric": "net_income"
              },
              "filtered_rows": ["mock row"],
              "group_values": {
                "net_income": "50"
              },
              "answer": "50",
              "calculation": "This is a mock response for pipeline testing."
            }
          ]
        }"""

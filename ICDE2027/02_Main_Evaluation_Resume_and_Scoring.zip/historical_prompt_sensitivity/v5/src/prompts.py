from typing import Any, Dict
from .utils import safe_get_table


SYSTEM_PROMPT = """You are an evaluator for ambiguous tabular question answering.
You must use only the provided table.
You must output valid JSON only.
Do not include markdown, explanations outside JSON, or extra text.
Be careful: the final answer must be consistent with your calculation."""


def build_detection_prompt(sample: Dict[str, Any]) -> str:
    table = safe_get_table(sample)
    query = sample["query"]

    return f"""
Task: Ambiguity Detection for Tabular QA

Given a table and a user query, identify ambiguous terms or phrases in the query.

For each ambiguous term, output:
- term: the exact ambiguous phrase in the query
- dimension: use one of these labels when possible:
  Definition-Metric, Time, Scope, Entity, Unit, Ranking, Aggregation, Other
- possible_conditions: possible specific interpretations/conditions

Important:
- If a phrase like "cost", "best", "performance", "highest", "largest", or "most expensive" depends on how a metric is defined, use Definition-Metric.
- If a phrase like "in 2023", "during 2023", or "this year" depends on which date column is used, use Time.

Return JSON exactly in this schema:
{{
  "ambiguous_conditions": [
    {{
      "term": "...",
      "dimension": "Definition-Metric or Time or Scope or Entity or Unit or Ranking or Aggregation or Other",
      "possible_conditions": ["...", "..."]
    }}
  ]
}}

Table:
{table}

Query:
{query}
""".strip()


def build_condition_answer_prompt(sample: Dict[str, Any], condition_obj: Dict[str, Any]) -> str:
    table = safe_get_table(sample)
    query = sample["query"]
    conditions = condition_obj.get("conditions", {})

    return f"""
Task: Condition-Given Tabular QA

Given a table, a query, and gold conditions, answer the query using only the specified gold conditions.

Critical rules:
1. The gold Time condition overrides the original query wording.
2. Apply the Time condition first.
3. Use ONLY the date column named in the Time condition.
4. Do NOT use any other date column for filtering.

Examples:
- If Time = "Date of Admission in 2023":
  Include rows whose Date of Admission is in 2023.
  Ignore Discharge Date.

- If Time = "Discharge Date in 2023":
  Include rows whose Discharge Date is in 2023.
  Ignore Date of Admission.

- If Time = "Enrollment Date in 2023":
  Include rows whose Enrollment Date is in 2023.
  Ignore Graduation Date.

- If Time = "Graduation Date in 2023":
  Include rows whose Graduation Date is in 2023.
  Ignore Enrollment Date.

After filtering rows by Time:
- "total billing amount" means sum Billing Amount by group.
- "average billing amount" means average Billing Amount by group.
- "highest average score" means average Score by group.
- "highest total credits" means sum Credits by group.

The final answer must be exactly the group with the highest computed value.
The final answer must be consistent with the group_values.

Return JSON exactly in this schema:
{{
  "filtered_rows": ["row ids or short row descriptions used after filtering"],
  "group_values": {{
    "group name": "computed value"
  }},
  "answer": "...",
  "calculation": "brief calculation from the filtered rows"
}}

Table:
{table}

Query:
{query}

Gold Conditions:
{conditions}
""".strip()


def build_e2e_prompt(sample: Dict[str, Any]) -> str:
    table = safe_get_table(sample)
    query = sample["query"]

    return f"""
Task: End-to-End Ambiguous Tabular QA

Given a table and an ambiguous query:
1. Identify ambiguous conditions in the query.
2. Generate possible specific interpretations.
3. Answer the query under each interpretation.

Use only the provided table.

Important rules:
- Use dimension names directly as keys in the "conditions" object.
- Do NOT use placeholder keys like "DimensionName" or "AnotherDimension".
- Prefer these dimension labels:
  Definition-Metric, Time, Scope, Entity, Unit, Ranking, Aggregation, Other.

For each answer:
1. Apply the Time condition first.
2. Use ONLY the date column named in the Time condition.
3. Do NOT use another date column for filtering.
4. Then compute the metric.
5. The final answer must match the highest value in group_values.

Time interpretation rules:
- "Date of Admission in 2023" means include rows whose Date of Admission is in 2023. Ignore Discharge Date.
- "Discharge Date in 2023" means include rows whose Discharge Date is in 2023. Ignore Date of Admission.
- "Enrollment Date in 2023" means include rows whose Enrollment Date is in 2023. Ignore Graduation Date.
- "Graduation Date in 2023" means include rows whose Graduation Date is in 2023. Ignore Enrollment Date.

Definition-Metric rules:
- "total billing amount" means sum Billing Amount by group.
- "average billing amount" means average Billing Amount by group.
- "highest average score" means average Score by group.
- "highest total credits" means sum Credits by group.

Example conditions format:
{{
  "Definition-Metric": "total billing amount",
  "Time": "Date of Admission in 2023"
}}

Return JSON exactly in this schema:
{{
  "ambiguous_conditions": [
    {{
      "term": "...",
      "dimension": "Definition-Metric or Time or Scope or Entity or Unit or Ranking or Aggregation or Other",
      "possible_conditions": ["...", "..."]
    }}
  ],
  "answers": [
    {{
      "conditions": {{
        "Definition-Metric": "specific metric interpretation",
        "Time": "specific time interpretation"
      }},
      "filtered_rows": ["row ids or short row descriptions used after filtering"],
      "group_values": {{
        "group name": "computed value"
      }},
      "answer": "...",
      "calculation": "brief calculation from the filtered rows"
    }}
  ]
}}

Table:
{table}

Query:
{query}
""".strip()

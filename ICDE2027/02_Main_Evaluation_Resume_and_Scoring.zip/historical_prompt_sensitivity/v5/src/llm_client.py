import os
from typing import Optional
from .prompts import SYSTEM_PROMPT


class LLMClient:
    def __init__(self, model: str = "gpt-4o-mini", temperature: float = 0.0, mock: bool = False):
        self.model = model
        self.temperature = temperature
        self.mock = mock
        self._client = None

        if not mock:
            try:
                from openai import OpenAI
            except ImportError as e:
                raise ImportError("Please install openai: pip install openai") from e

            if not os.getenv("OPENAI_API_KEY"):
                raise EnvironmentError("OPENAI_API_KEY is not set. Set it or use --mock for local testing.")
            self._client = OpenAI()

    def complete(self, prompt: str) -> str:
        if self.mock:
            return self._mock_response(prompt)

        response = self._client.chat.completions.create(
            model=self.model,
            temperature=self.temperature,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        )
        return response.choices[0].message.content or ""

    def _mock_response(self, prompt: str) -> str:
        """
        Deterministic fake response so you can test the whole pipeline without API cost.
        """
        if "Ambiguity Detection" in prompt:
            return """{
              "ambiguous_conditions": [
                {
                  "term": "cost",
                  "dimension": "Definition-Metric",
                  "possible_conditions": ["total billing amount", "average billing amount"]
                },
                {
                  "term": "in 2023",
                  "dimension": "Time",
                  "possible_conditions": ["Date of Admission in 2023", "Discharge Date in 2023"]
                }
              ]
            }"""
        if "Condition-Given" in prompt:
            return """{
              "answer": "Diabetes",
              "calculation": "Under the specified conditions, Diabetes has the highest value in the table."
            }"""
        return """{
          "ambiguous_conditions": [
            {
              "term": "cost",
              "dimension": "Definition-Metric",
              "possible_conditions": ["total billing amount", "average billing amount"]
            },
            {
              "term": "in 2023",
              "dimension": "Time",
              "possible_conditions": ["Date of Admission in 2023", "Discharge Date in 2023"]
            }
          ],
          "answers": [
            {
              "conditions": {
                "Definition-Metric": "total billing amount",
                "Time": "Date of Admission in 2023"
              },
              "answer": "Diabetes",
              "calculation": "Diabetes has the highest total billing amount among 2023 admissions."
            }
          ]
        }"""

"""
Optional helper:
Create a blank evaluation JSONL template from a CSV file.
You still need to fill gold labels manually or with your pipeline.
"""

import argparse
import json
import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True)
    parser.add_argument("--query", required=True)
    parser.add_argument("--id", default="sample_001")
    parser.add_argument("--domain", default="unknown")
    parser.add_argument("--max_rows", type=int, default=30)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    df = pd.read_csv(args.csv).head(args.max_rows)
    table_md = df.to_markdown(index=False)

    row = {
        "id": args.id,
        "domain": args.domain,
        "table": {
            "type": "markdown",
            "content": table_md
        },
        "query": args.query,
        "gold": {
            "ambiguous_conditions": [],
            "condition_answer_pairs": []
        }
    }

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")

    print(f"Wrote template to {args.output}")


if __name__ == "__main__":
    main()

# Downstream Evaluation Scripts for Ambiguous Tabular QA

This project runs three downstream evaluation settings for ambiguous tabular QA:

1. **Ambiguity Detection**
   - Input: table + ambiguous query
   - Model output: ambiguous terms, dimensions, possible conditions

2. **Condition-Given Answering**
   - Input: table + query + gold condition
   - Model output: answer under the given interpretation

3. **End-to-End Evaluation**
   - Input: table + ambiguous query
   - Model output: detect ambiguity + generate condition-specific answers

## 1. Install

```bash
cd downstream_eval_scripts
python -m venv .venv
source .venv/bin/activate   # Mac/Linux
# .venv\Scripts\activate    # Windows PowerShell

pip install -r requirements.txt
```

## 2. Set OpenAI API Key

```bash
export OPENAI_API_KEY="your_api_key_here"
```

On Windows PowerShell:

```powershell
$env:OPENAI_API_KEY="your_api_key_here"
```

## 3. Run a quick mock test without API

This checks that the pipeline works locally.

```bash
python -m src.run_eval --input sample_data/sample_eval.jsonl --setting detection --mock --output outputs/mock_detection.jsonl
python -m src.run_eval --input sample_data/sample_eval.jsonl --setting condition_answer --mock --output outputs/mock_condition_answer.jsonl
python -m src.run_eval --input sample_data/sample_eval.jsonl --setting e2e --mock --output outputs/mock_e2e.jsonl
```

## 4. Run with GPT

```bash
python -m src.run_eval --input sample_data/sample_eval.jsonl --setting detection --model gpt-4o-mini --output outputs/detection.jsonl
python -m src.run_eval --input sample_data/sample_eval.jsonl --setting condition_answer --model gpt-4o-mini --output outputs/condition_answer.jsonl
python -m src.run_eval --input sample_data/sample_eval.jsonl --setting e2e --model gpt-4o-mini --output outputs/e2e.jsonl
```

## 5. Input JSONL Format

Each line should be one sample:

```json
{
  "id": "healthcare_001",
  "domain": "healthcare",
  "table": {
    "type": "markdown",
    "content": "| Patient | Medical Condition | Date of Admission | Discharge Date | Billing Amount |\n|---|---|---|---|---|\n| A | Diabetes | 2023-01-02 | 2023-01-08 | 1000 |"
  },
  "query": "Which medical condition had the highest cost in 2023?",
  "gold": {
    "ambiguous_conditions": [
      {
        "term": "cost",
        "dimension": "Definition-Metric",
        "conditions": ["total billing amount", "average billing amount"]
      },
      {
        "term": "in 2023",
        "dimension": "Time",
        "conditions": ["Date of Admission in 2023", "Discharge Date in 2023"]
      }
    ],
    "condition_answer_pairs": [
      {
        "conditions": {
          "Definition-Metric": "total billing amount",
          "Time": "Date of Admission in 2023"
        },
        "answer": "Diabetes"
      }
    ]
  }
}
```

## 6. Output

Each output JSONL row contains:
- original sample id
- model raw response
- parsed model response
- metric scores

## 7. How to plug in your own dataset

Convert your generated examples from SEC/NASA/Retail/new dataset into the same JSONL format above.
Then run:

```bash
python -m src.run_eval --input your_dataset.jsonl --setting e2e --model gpt-4o-mini --output outputs/your_e2e.jsonl
```

#!/usr/bin/env python3
"""Conservative, read-only SF311 re-scoring of a frozen scalability ZIP.

Usage: python rescore_sf311.py frozen.zip --out sf311_rescore
This code never calls a model and never overwrites the frozen input.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import statistics
import zipfile
from collections import defaultdict
from pathlib import Path


STATUSES = ("in progress", "on hold", "accepted", "open", "sent")
GOLD = {
    "not closed": ("not_closed",),
    "work status = open": ("work", ("open",)),
    "work status = in progress": ("work", ("in progress",)),
    "work status in {accepted, in progress}": ("work", ("accepted", "in progress")),
    "work status in {open, sent, accepted, in progress}":
        ("work", ("accepted", "in progress", "open", "sent")),
}


def read_jsonl(z, name):
    return [json.loads(s) for s in z.read(name).decode("utf-8-sig").splitlines() if s.strip()]


def valid(r):
    return (r.get("status") == "ok" and isinstance(r.get("parsed"), dict)
            and not r.get("parse_error") and r.get("finish_reason") != "length")


def context_statuses(sample):
    """Read actual rows rather than assuming the sample design is all-open."""
    lines = sample["table"]["content"].splitlines()
    header = next(line for line in lines if line.startswith("| CASE ID |"))
    names = [x.strip() for x in header.strip().strip("|").split("|")]
    ix = names.index("STATUS")
    wi = names.index("WORK STATUS")
    statuses, work = set(), set()
    n = 0
    for line in lines:
        if not line.startswith("| "):
            continue
        cells = [x.strip() for x in line.strip().strip("|").split("|")]
        if len(cells) != len(names) or not cells[0].isdigit():
            continue
        n += 1
        statuses.add(cells[ix].casefold())
        work.add(cells[wi].casefold())
    if n != sample["scale_rows"]:
        raise ValueError(f"Case row mismatch {sample['id']}: {n} / {sample['scale_rows']}")
    return statuses, work


def parse_condition(raw, all_open, work_values):
    """Return an explicit column-specific predicate or None for human review.

    No naked 'open', guessed status, numeric answer, or word overlap is accepted.
    """
    if not isinstance(raw, str):
        return None
    t = raw.casefold().replace("’", "'").replace('"', "'")
    t = re.sub(r"\s+", " ", t).strip()
    if re.fullmatch(r"(?:pending\s*(?:means|=)\s*)?(?:status\s*(?:=|is|equals)\s*)?not closed", t):
        return ("not_closed",)

    work_pos = re.search(r"\bwork\s+status\b", t)
    if not work_pos:
        # Exact field name is mandatory; explanatory parentheses may follow a
        # clear status=open predicate but cannot introduce another field.
        q = re.sub(r"^(?:pending|underway|active)\s*(?:means|=)\s*", "", t)
        q = re.sub(r"^cases with\s+", "", q)
        m = re.fullmatch(r"status\s*(?:=|is|equals)\s*'?open'?(?:\s*\([^)]*\))?", q)
        if m and all_open:
            return ("not_closed",)
        return None

    prefix, w = t[:work_pos.start()], t[work_pos.end():]
    if "status" in prefix:
        # An explicit STATUS=open AND WORK STATUS=... reduces to the work
        # predicate only when all rows actually have STATUS=open.
        if not all_open or not re.search(r"\bstatus\s*(?:=|is|equals)\s*'?open'?\s+and\s*$", prefix):
            return None
    if re.search(r"\b(?:not|except|excluding|without|other than)\b|!=|≠", w):
        return None
    if re.search(r"\bstatus\b", w):
        return None
    # Optional explanatory parenthetical after a complete set. Preserve a
    # parenthesized list used as the set itself.
    w = re.sub(r"\([^)]*\)\s*$", lambda m: m.group() if
               re.search(r"^\s*(?:in|in\s+the\s+set)\s*$", w[:m.start()]) else "", w)
    values = tuple(sorted({s for s in STATUSES if re.search(r"\b" + re.escape(s) + r"\b", w)}))
    if not values:
        return None
    # Preserve the explicit WORK STATUS predicate. An enumerated set can
    # happen to cover all observed rows, but must first be scored against its
    # *own* work-status definition rather than being rewritten as not closed.
    return ("work", values)


def numeric_answer(value):
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and re.fullmatch(r"\s*\d{1,3}(?:,\d{3})*\s*|\s*\d+\s*", value):
        return int(value.strip().replace(",", ""))
    return None


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("frozen_zip", type=Path)
    ap.add_argument("--out", type=Path, default=Path("sf311_rescore"))
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.frozen_zip) as z:
        samples = {(s["dataset"], s["id"]): s for s in read_jsonl(z, "prepared_samples.jsonl")}
        attempts = read_jsonl(z, "predictions.jsonl")
    latest = {}
    for r in attempts:
        if valid(r):
            latest[(r["model"], r["dataset"], r["id"])] = r
    assert len(latest) == 180, f"Expected 180 valid final requests, got {len(latest)}"
    details, review = [], []
    for (model, ds, sid), r in latest.items():
        if ds != "sf311":
            continue
        sample = samples[(ds, sid)]
        statuses, work_values = context_statuses(sample)
        all_open = statuses == {"open"}
        gold = sample["gold"]["condition_answer_pairs"]
        predictions = [p for p in r["parsed"].get("answers", [])
                       if isinstance(p, dict) and isinstance(p.get("conditions"), dict)]
        signatures = []
        for i, p in enumerate(predictions):
            # Extra dimensions are not silently dropped. If present, retain
            # the row for review rather than deciding if they contradict gold.
            cond = p["conditions"]
            sig = parse_condition(cond.get("Event Status"), all_open, work_values) if set(cond) == {"Event Status"} else None
            signatures.append(sig)
            if sig is None:
                review.append(dict(model=model, id=sid, nominal_rows=sample["nominal_rows"],
                                   prediction_index=i, query=sample["query"],
                                   predicted_condition=json.dumps(cond, ensure_ascii=False),
                                   predicted_answer=str(p.get("answer", "")),
                                   reason="unrecognized_or_extra_dimension"))
        used = set()
        for gi, pair in enumerate(gold):
            target = GOLD.get(pair["conditions"]["Event Status"].casefold())
            if target is None:
                raise ValueError(f"Unexpected gold status condition: {pair['conditions']}")
            def equivalent(sig):
                if sig == target:
                    return True
                # Work-status enumeration denotes not closed only when every
                # observed case is open and every observed work value is in it.
                return (target == ("not_closed",) and isinstance(sig, tuple)
                        and len(sig) == 2 and sig[0] == "work" and all_open
                        and bool(work_values) and work_values.issubset(set(sig[1])))
            options = [i for i, sig in enumerate(signatures) if equivalent(sig) and i not in used]
            pi = options[0] if options else None  # first matching prediction, no answer-driven cherry-picking
            if pi is not None:
                used.add(pi)
            got = numeric_answer(predictions[pi].get("answer")) if pi is not None else None
            target_answer = numeric_answer(pair["answer"])
            correct = pi is not None and got == target_answer
            details.append(dict(model=model, dataset=ds, id=sid, nominal_rows=sample["nominal_rows"],
                                query=sample["query"], gold_condition=pair["conditions"]["Event Status"],
                                gold_answer=target_answer, matched_prediction_index="" if pi is None else pi,
                                predicted_condition="" if pi is None else json.dumps(predictions[pi]["conditions"], ensure_ascii=False),
                                predicted_answer="" if pi is None else str(predictions[pi].get("answer", "")),
                                condition_matched=pi is not None, answer_correct=bool(correct),
                                all_input_status_open=all_open,
                                original_score=r["scores"]["answer_relaxed_norm"]))
    groups = defaultdict(list)
    for row in details:
        groups[(row["model"], row["nominal_rows"])].append(row)
    summary = []
    for (model, size), group in sorted(groups.items()):
        assert len(group) == 20, (model, size, len(group))
        summary.append(dict(model=model, dataset="sf311", nominal_rows=size,
                            queries=10, gold_pairs=20,
                            condition_matched=sum(x["condition_matched"] for x in group),
                            correct_pairs=sum(x["answer_correct"] for x in group),
                            contextual_accuracy_pct=round(100 * sum(x["answer_correct"] for x in group) / 20, 2),
                            original_accuracy_pct=round(100 * statistics.mean(
                                {x["id"]: x["original_score"] for x in group}.values()), 2)))
    write_csv(args.out / "sf311_pair_rescore.csv", details)
    write_csv(args.out / "sf311_summary_rescore.csv", summary)
    write_csv(args.out / "sf311_manual_review.csv", review)
    print(json.dumps(dict(summary=summary, pairs=len(details), review_rows=len(review)),
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

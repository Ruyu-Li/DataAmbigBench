# SF311 scalability: conservative contextual rescore

Input: frozen 8k scalability ZIP from 2026-11-10. This is a **post-hoc sensitivity analysis**, not a modification of the frozen model outputs, gold answers, or paper's original scoring rules. The script uses only the Python standard library and makes zero API requests.

## Rules

1. Verify all 500/1,500/3,000 input rows in each SF311 context; in this freeze all recorded `STATUS` values are `open`.
2. Match predictions to the gold `Event Status` condition by explicit field and status set. `WORK STATUS = open` and `STATUS = open` are different predicates. Bare `open` and unrecognized or negative conditions require manual review.
3. In these all-open snapshots only, accept an explicit `STATUS = open` expression for gold `not closed`; also accept a complete enumerated work-status set that covers every observed status. First match each gold condition to at most one predicted answer, without consulting the predicted number during matching.
4. Accept a count only when the returned final answer is an exact integer (commas permitted) equal to the recalculated gold. Approximate answers are incorrect. Extra predicted condition keys go to manual review, rather than being dropped.
5. Keep the original score and the contextual score in separate columns. No model outputs were edited.

## Nine groups (20 gold pairs each)

| Model | 500: original → contextual | 1,500: original → contextual | 3,000: original → contextual |
|---|---:|---:|---:|
| GPT-4.1 mini | 5% → 10% | 0% → 5% | 0% → 5% |
| Claude Haiku 5.5 | 10% → 15% | 0% → 5% | 0% → 5% |
| Gemini 3.1 Flash-Lite | 0% → 5% | 0% → 0% | 0% → 5% |

Across these 180 gold interpretation–answer pairs, the conservative scorer credits 11 pairs: GPT 4, Haiku 5, Gemini 2. The original scorer credits 3 pairs. Only one group still scores 0% under the conservative policy, Gemini 1,500 rows. These are very small denominators: 5% = 1/20 gold pairs.

The extra matches are attributable to a clear column-equivalent status expression in this *restricted all-open sample*, plus exact spellings of work-status sets. The remaining low scores are substantive in many cases: for `ES01__n1500`, gold `WORK STATUS = open` is 695, whereas Gemini answered 338; other models omitted the required work-open interpretation or approximated its count.

## Manual triage

The automatic parser routes 110 predicted condition expressions to `sf311_manual_review.csv`. This does **not** mean 110 correct answers were omitted: most have wrong numeric answers. Exactly three unparsed predicted answers equal some gold count; all three appear in `sf311_score_sensitive_review.csv`:

- Haiku `ES07__n500` supplies the query's Mission-neighborhood scope under an extra Geography key and answers 7 for in-progress (gold 7). Its explanatory calculation contradicts itself, mentioning an eighth case. Under a final-value-only rubric the answer would earn credit; under a reasoning-consistency requirement it would need further review.
- Haiku `ES06__n500` supplies the query's Sidewalk-and-Curb scope under an extra Definition-Metric key and answers 2 for in-progress (gold 2). This would earn credit if consistent extra scope keys are allowed.
- Haiku `ES01__n1500` returns 1,500 for a four-value WORK STATUS set while calling it "not closed". The supplied table contains work-status values beyond those four; the condition does not specify all not-closed cases. **Do not credit merely because the answer equals 1,500.**

Accepting both consistent extra-scope cases as an explicitly different rubric would increase Haiku's 500-row score from 15% to at most 25% (5/20). This package does not silently add them to the conservative summary. Selection of an official scorer should be fixed for all datasets rather than changed after inspecting one model.

## Study limitations

- SF311 samples were filtered to `STATUS=open` *before* taking nested 500/1,500/3,000-row tables. The `not closed` gold count is therefore the size of the relevant sample; it does not test closed-case discrimination.
- Ten fixed queries per scale, with changing rows and recalculated answers, permit a descriptive comparison but do not isolate table length as a causal explanation for accuracy changes.
- Final result format and original attempts should be reported separately; this SF311 rescore has no new model calls.

Files: `rescore_sf311.py` (standalone rerunnable scorer), `sf311_summary_rescore.csv`, `sf311_pair_rescore.csv`, `sf311_manual_review.csv`, and `sf311_score_sensitive_review.csv`.

To reproduce in Colab, put `rescore_sf311.py` next to the frozen ZIP and run:

```bash
python rescore_sf311.py scalability_mixed_8k_frozen_20261110_225911.zip --out sf311_rescore
```

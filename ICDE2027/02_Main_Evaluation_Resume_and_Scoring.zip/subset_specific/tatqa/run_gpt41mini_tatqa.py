"""Run GPT-4.1 mini on the TAT-QA version used by Table II in Google Colab."""
from collections import Counter
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from hashlib import sha256
from pathlib import Path
from statistics import mean
import json
import os
import subprocess
import sys
import tempfile
import time
import zipfile

from google.colab import drive, userdata

MODEL = "gpt-4.1-mini"
WORKERS = 10
TASKS = {"detection": 200, "condition_given": 496, "e2e": 200, "e2e_open": 200}
MATCH_FIELDS = ("query", "context_hash", "prompt_hash", "max_tokens", "gold")
REFERENCE_SIGNATURE = "ed34240b688a6e52b7cdd4ec3e4177bccd78b206d1e5b910fda724fe5f1d577d"

def read_rows(path):
    with path.open(encoding="utf-8-sig") as stream:
        return [json.loads(line) for line in stream if line.strip()]

def write_rows(path, rows):
    with path.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")

def key(row):
    return (str(row["id"]), row["task"], row.get("pair_index"))

def signature(expected):
    records = sorted((list(k), [row[f] for f in MATCH_FIELDS]) for k, row in expected.items())
    return sha256(json.dumps(records, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

def job_specs(samples, lab):
    expected = {}
    for sample in samples:
        gold = sample["gold"]
        pairs = gold["condition_answer_pairs"]
        for task in TASKS:
            for pair_index in range(len(pairs)) if task == "condition_given" else [None]:
                system, prompt, max_tokens = lab.prompt_for(task, sample, pair_index)
                target = {
                    "detection": gold["ambiguous_conditions"],
                    "condition_given": pairs[pair_index] if pair_index is not None else None,
                }.get(task, gold)
                expected[str(sample["id"]), task, pair_index] = dict(
                    query=sample["query"], context_hash=lab.digest(sample["table"]),
                    prompt_hash=lab.digest([system, prompt]), max_tokens=max_tokens, gold=target,
                )
    return expected

def main():
    content = Path("/content")
    mounts = [content / n for n in ("drive", "dab_drive_mount", "dab_final_drive")]
    mount = next((p for p in mounts if (p / "MyDrive").is_dir()), None)
    if mount is None:
        mount = mounts[0]
        drive.mount(str(mount))
    base = mount / "MyDrive/DataAmbigBench_supplemental"
    project_name = "DataAmbigBench_multimodel"
    projects = [content / project_name] + [
        content / folder / project_name
        for folder in ("tatqa_original_project_restored", "dab_final_project", "dab_tatqa_project")
    ]
    if not any((p / "lab.py").is_file() for p in projects):
        archives = list(content.glob("DataAmbigBench_multimodel*.zip"))
        assert archives, "请先上传原项目 DataAmbigBench_multimodel ZIP 到 Colab 左侧 Files"
        archive = max(archives, key=lambda p: p.stat().st_mtime)
        with zipfile.ZipFile(archive) as z:
            assert f"{project_name}/lab.py" in z.namelist(), archive
            z.extractall(projects[-1].parent)

    project = next(p for p in projects if (p / "lab.py").is_file())
    sys.path.insert(0, str(project))
    import lab

    preferred = [
        base / "inputs/tatqa_source_context_full_v1/tatqa.jsonl",
        base / "preparation_v1/candidate/tatqa.jsonl",
        project / "data/tatqa.jsonl",
        content / "tatqa.jsonl",
    ]
    candidates = dict.fromkeys([*preferred, *sorted(base.rglob("tatqa.jsonl"))])
    for path in candidates:
        if not path.is_file():
            continue
        try:
            samples = read_rows(path)
            if len(samples) != 200:
                continue
            expected = job_specs(samples, lab)
            if len(expected) == sum(TASKS.values()) and signature(expected) == REFERENCE_SIGNATURE:
                break
        except (KeyError, TypeError, ValueError, IndexError):
            continue
    else:
        raise RuntimeError("找不到与主表逐题一致的 TAT-QA 输入及 prompt。请确认使用上次跑主表的项目 ZIP 和输入。")

    print("匹配 Table II 输入及 prompt：", path, flush=True)
    output = base / "runs/tatqa_gpt41mini_table2"
    output.mkdir(parents=True, exist_ok=True)

    def reuse(paths, best):
        for file in paths:
            if not file.is_file():
                continue
            with file.open(encoding="utf-8-sig") as stream:
                for line in stream:
                    try:
                        row = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if not isinstance(row, dict) or row.get("model") != MODEL or row.get("dataset") != "tatqa":
                        continue
                    want = expected.get(key(row))
                    if want is None or any(row.get(k) != v for k, v in want.items()):
                        continue
                    if row.get("status") == "ok" and isinstance(row.get("scores"), dict):
                        best.setdefault(key(row), row)

    paths = set(base.rglob("predictions*tatqa*.jsonl"))
    paths.update(p for p in base.rglob("predictions*.jsonl") if "tatqa" in str(p).lower()
                 or MODEL in str(p).lower() or p.parent == output)
    best = {}
    reuse(sorted(paths), best)
    print(f"同版本已有 {len(best)}/1096 条。", flush=True)
    missing_ids = {k[0] for k in expected.keys() - best.keys()}
    if missing_ids:
        if not os.environ.get("OPENAI_API_KEY"):
            os.environ["OPENAI_API_KEY"] = userdata.get("OPENAI_API_KEY")
        pending = [s for s in samples if str(s["id"]) in missing_ids]
        print(f"启动补跑：{len(pending)} 道题，最多 {WORKERS} 个并发进程。", flush=True)
        run_dir = Path(tempfile.mkdtemp(prefix="batch-", dir=output))
        local_data = Path(tempfile.mkdtemp(prefix="tatqa-shards-"))
        batches = [pending[i::WORKERS] for i in range(WORKERS)]

        def run_shard(i, batch):
            data = local_data / str(i)
            data.mkdir()
            write_rows(data / "tatqa.jsonl", batch)
            shard = run_dir / f"shard-{i:02d}"
            shard.mkdir()
            calls = sum(3 + len(s["gold"]["condition_answer_pairs"]) for s in batch)
            cmd = [sys.executable, "-u", "lab.py", "run",
                   "--data", str(data), "--out", str(shard), "--datasets", "tatqa",
                   "--model", MODEL, "--temperature", "0", "--retries", "1",
                   "--execute", "--max-calls", str(calls)]
            with (shard / "run.log").open("w", encoding="utf-8") as log:
                completed = subprocess.run(cmd, cwd=project, stdout=log, stderr=subprocess.STDOUT)
            return shard, completed.returncode

        start = time.monotonic()
        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            jobs = {pool.submit(run_shard, i, batch) for i, batch in enumerate(batches) if batch}
            while jobs:
                done, jobs = wait(jobs, timeout=30, return_when=FIRST_COMPLETED)
                for job in done:
                    shard, status = job.result()
                    if status:
                        print(f"{shard.name}: exit={status}，查看日志：{shard / 'run.log'}", flush=True)
                reuse(sorted(run_dir.glob("shard-*/predictions.jsonl")), best)
                print(f"{len(best)}/1096，同版本请求完成；"
                      f"已运行 {(time.monotonic() - start) / 60:.1f} 分钟", flush=True)

    merged = output / "predictions.jsonl"
    write_rows(merged, best.values())
    counts = Counter(row["task"] for row in best.values())
    print("覆盖：", dict(counts), flush=True)
    print("结果：", merged, flush=True)
    if counts != TASKS:
        raise RuntimeError("四种设置还未跑齐。再次运行此脚本会复用已保存的结果。")

    columns = {
        "detection": ("dimension_f1", "condition_f1_strict", "condition_f1_norm"),
        "condition_given": ("answer_exact", "answer_relaxed"),
        "e2e": ("answer_exact_strict", "answer_relaxed_strict", "answer_exact_norm", "answer_relaxed_norm"),
        "e2e_open": ("multi_answer_rate", "gold_answer_recall", "single_answer_correct"),
    }
    latex = ["", "GPT-4.1 mini"]
    for task, names in columns.items():
        group = [r for r in best.values() if r["task"] == task]
        print(task, "JSON 解析失败：", sum(r.get("parsed") is None for r in group))
        for name in names:
            scores = [r["scores"].get(name) for r in group]
            if any(not isinstance(score, (int, float)) for score in scores):
                raise RuntimeError(f"{task}/{name} 有缺失分数。请先检查逐题结果。")
            latex.append(f"{100 * mean(scores):.1f}")
    row = " & ".join(latex) + r" \\"
    (output / "table2_row.tex").write_text(row + "\n", encoding="utf-8")
    print("\nTable II 行：\n" + row, flush=True)

if __name__ == "__main__":
    main()

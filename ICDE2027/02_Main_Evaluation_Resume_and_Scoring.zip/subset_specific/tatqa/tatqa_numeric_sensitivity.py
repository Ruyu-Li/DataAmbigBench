#!/usr/bin/env python3
"""Offline TAT-QA answer matching sensitivity; never edits paper results.

The alternative score applies transparent accounting-sign, percent/fraction,
unit-omission, and decimal-rounding rules to every prediction, then reports
all changed rows for manual review. It does not learn aliases from predictions.
"""
import argparse
import csv
import json
import re
import sys
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
from statistics import mean


def read_jsonl(path):
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]


def numeric(text):
    """Parse an entire scalar string, never extract a number from a sentence."""
    s = str(text).strip().lower().replace("−", "-").replace("‐", "-")
    s = s.replace("\u00a0", " ").replace("\u2019", "'")
    s = re.sub(r"^\s*[$€£]\s*", "", s)
    if s in {"—", "–", "-"}:
        return Decimal(0), Decimal(0), "", "dash"
    s = re.sub(r"\s+", " ", s).strip()
    m = re.fullmatch(r"(?P<sign>-|\()?\s*(?P<num>(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?|\.\d+)\s*(?P<close>\))?\s*(?P<unit>%|percent|thousand|million|billion)?", s)
    if not m:
        return None
    if (m["sign"] == "(") != (m["close"] == ")"):
        return None
    literal = m["num"].replace(",", "")
    value = Decimal(literal) * (-1 if m["sign"] in {"-", "("} else 1)
    places = len(literal.partition(".")[2]) if "." in literal else 0
    half = Decimal("0.5") * Decimal(10) ** (-places)
    unit = m["unit"] or ""
    if unit in {"%", "percent"}:
        unit = "percent"
    return value, half, unit, "number"


def scalar_equal(pred, gold):
    p, g = numeric(pred), numeric(gold)
    if p is None or g is None:
        return False, "non_scalar"
    pv, pe, pu, pk = p
    gv, ge, gu, gk = g
    if pk == "dash":
        # Dash in a numeric table cell represents zero/none; exclude negative values.
        return (pv == 0, "dash_zero")
    if gk == "dash":
        return (pv == 0, "dash_zero")
    units = {pu, gu} - {"", "percent"}
    if len(units) > 1:
        return False, "conflicting_explicit_units"
    if pu == "percent" and gu != "percent":
        if abs(gv) <= 1 and abs(pv) > 1:
            pv, pe = pv / 100, pe / 100
            reason = "percent_vs_fraction"
        elif abs(pv) <= 1 and abs(gv) <= 1:
            return False, "ambiguous_small_percent_without_unit"
        else:
            reason = "unit_omission"
    elif gu == "percent" and pu != "percent":
        if abs(pv) <= 1 and abs(gv) > 1:
            gv, ge = gv / 100, ge / 100
            reason = "percent_vs_fraction"
        elif abs(pv) <= 1 and abs(gv) <= 1:
            return False, "ambiguous_small_percent_without_unit"
        else:
            reason = "unit_omission"
    else:
        reason = "accounting_sign_or_unit_or_rounding"
    # Intervals must overlap with positive width; mere touching at a boundary
    # would count neighboring hundredths (7.15 vs 7.16) as equivalent.
    overlap = min(pv + pe, gv + ge) - max(pv - pe, gv - ge)
    return (overlap > 0, reason)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True, type=Path)
    ap.add_argument("--results", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    sys.path.insert(0, str(args.project))
    import lab  # noqa: E402
    original_match = lab.paper.ans_relaxed

    def candidate_match(pred, pair, ds=""):
        if original_match(pred, pair, ds):
            return True
        if ds != "tatqa":
            return False
        return any(scalar_equal(pred, answer)[0] for answer in lab.paper.golds_for(pair))

    recs = read_jsonl(args.results)
    assert len(recs) == 1083 and {r["dataset"] for r in recs} == {"tatqa"}
    before = [lab.score_record(r) for r in recs]
    lab.paper.ans_relaxed = candidate_match
    after = [lab.score_record(r) for r in recs]
    changed = []
    metrics = defaultdict(lambda: defaultdict(list))
    for r, old, new in zip(recs, before, after):
        for metric in set(old) & set(new):
            if metric in {"answer_relaxed", "answer_relaxed_norm", "gold_answer_recall"}:
                metrics[r["task"]][metric].append((old[metric], new[metric]))
            if old[metric] != new[metric] and metric in {
                "answer_relaxed", "answer_relaxed_norm", "gold_answer_recall", "single_answer_correct"
            }:
                parsed = r.get("parsed") or {}
                pred = parsed.get("answer", "") if r["task"] == "condition_given" else json.dumps(parsed.get("answers", []), ensure_ascii=False)
                reasons = []
                if r["task"] == "condition_given":
                    for gold in lab.paper.golds_for(r["gold"]):
                        yes, why = scalar_equal(pred, gold)
                        if yes: reasons.append(why)
                changed.append({"id": r["id"], "task": r["task"], "pair_index": r.get("pair_index"),
                                "metric": metric, "before": old[metric], "after": new[metric],
                                "gold": json.dumps(r["gold"], ensure_ascii=False),
                                "predicted_answer": pred, "match_reason": ";".join(reasons)})
    args.out.mkdir(parents=True, exist_ok=True)
    with (args.out / "changed_scores.csv").open("w", encoding="utf-8-sig", newline="") as f:
        cols = ["id", "task", "pair_index", "metric", "before", "after", "gold", "predicted_answer", "match_reason"]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader(); w.writerows(changed)
    summary = {task: {metric: {"old_pct": round(100 * mean(x for x, _ in vals), 4),
                                 "alternative_pct": round(100 * mean(y for _, y in vals), 4)}
                       for metric, vals in m.items()} for task, m in metrics.items()}
    (args.out / "score_sensitivity.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("Changed score cells:", len(changed))
    print("Sensitivity summary:", json.dumps(summary, indent=2))
    print("Per-case review:", args.out / "changed_scores.csv")
    print("Original results and original evaluator were not changed")


if __name__ == "__main__":
    main()

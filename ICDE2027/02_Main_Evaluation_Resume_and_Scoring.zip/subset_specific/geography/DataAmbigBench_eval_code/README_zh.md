# DataAmbigBench 补充实验

入口是 `lab.py`，适用于 Colab 或 Linux 上的 Python 3.10+。`scripts/` 是 Ruyu 发布的原评测脚本，补充实验直接调用其中的 prompt 与 scorer。原始输出 ZIP 单独保存，离线分析直接读 ZIP。所有命令在解压后的项目目录运行。

## 任务和当前状态

**数量口径必须区分论文原版与本轮补充实验：**论文 Table 1 有 8 个数据集、**4,498 条 query**，分别是 SEC 648、NASA POWER 2,240、TAT-QA 610，以及 Retail、AmbigDocs、OpinionQA、U.S. Code、SF311 各 200。论文原版并不是每个数据集 200 条；如果只给原版增加 200 条 NYC311，且原有数据不减量，总数应为 **4,698**。本轮统一评测的设计则是将原有 8 个数据集各固定为 200 条，再增加 200 条 NYC311 Geography，目标 **9 × 200 = 1,800 条**。目前 `prepared/data/` 有 SEC、Retail、AmbigDocs、OpinionQA、USC、SF311，共 **1,200 条结构上可进入试跑**；NASA 和 TAT-QA 各有 200 条抽样，待修复独立源上下文后可增加 **400 条**；NYC311 的 200 条正式评测文件尚未纳入，待构建与核验后再增加 **200 条**。论文原版的 8 个数据集覆盖 7 个歧义维度（SEC 和 NASA 都属于 Definition-Metric）；加入 NYC311 Geography 后是 9 个数据集、8 个维度。这里的“可运行”仅表示结构与输入防泄漏检查通过，不代表已经完成人工语义审核或模型调用。

| 任务 | 操作与结果 |
|---|---|
| 数据格式、完整性和去重 | `prepare` 检查字段、唯一 ID、条件与答案配对、重复 query/context 和答案对照表。同问句配不同上下文保留。精确重复且 gold 相同才合并，冲突列出。语义近重复仍需人工复核。 |
| SEC 固定 200 | 从完整 648 按财年 × 报告期比例抽样，seed 20261107。输出与配额及 ID 清单在 `prepared/`。 |
| AmbigDocs、OpinionQA、Retail、USC、SF311 | 加上 SEC 共 6×200 条通过结构检查。AmbigDocs 采用上传的 (2) 版，维度键统一为 Name Ambiguity。仍应核查题意、gold 和来源。 |
| NASA / TAT-QA | 当前两个固定 200 文件含 condition–answer 对照表。正式入口拦下。找到独立源证据并核验 gold 后，用 `attach-context` 合并；旧协议复现需要显式 `--legacy-lookup`。 |
| NYC311 Geography | 用户另有 200 条 `nyc311_geography_200_standard.jsonl`，包含两个各 100 条的 geography 家族，格式通过基础检查。原始源快照未附在此包内，需核对源计数与地理覆盖后再作正式数据结论。 |
| 四种评测设置 | Detection 同时产出 Type F1 和 Interpretation F1；Condition-Given 每个 gold pair 调用一次并按 pair 平均；hinted E2E、E2E-open 各一次。 |
| 评分 bug 和论文口径 | 原 scorer 保留，数值误判用独立敏感性审计定位。论文 Condition-Given 描述应写成 “Within each subset, Given-Condition Accuracy is averaged over all interpretation–answer pairs.” |
| 旧结果复核与失败分析 | `analyze` 导出重评分差异、平均方式对比、失败类别统计和带原始回答的样例。规则标签是人工复核入口，不直接判定错误原因。 |
| 模型比较 | `compare` 按相同数据集、题目、pair、prompt 对齐，输出百分点差和按 query 聚类的配对 bootstrap 95% 区间。发布的同一旧结果 ZIP 视为同一输入版本。 |
| Ablation | `compare --ablation` 在同模型、同题上比较 hinted E2E 和 E2E-open，用同一套 Surfacing Rate 与 Answer Recall scorer。两种提示的任务措辞和输出 schema 一起变化，因此是整个提示设置对照。 |
| Efficiency / Latency | 新实验保存 usage、请求耗时、包含退避的单 job 耗时、各次尝试和批次耗时。报告给出 P50/P95 和 token；历史 ZIP 只能分析日志中记录的成功请求耗时及 token。 |
| Scalability | `run --scale` 检查同一批 query 的 1k/5k/20k 真实结构化表格和条件口径，并按规模汇总。各规模的证据和 gold 需要先构建与核验。 |

`historical_analysis/` 已包含整份旧预测的离线审计、一个 GPT-4o-mini 提示设置对照，以及本轮数据和旧结果的 ID/query/gold 对齐检查。旧预测 ZIP 只存 query/gold，不足以验证六个补充数据集的旧表格上下文。复用时请对齐输入版本。现有文件支持的是 DataAmbigBench 的任务；SemBench 的 Label Library、WDI 和 HybridQA 属于另一套实验。

### Geography 评分诊断

`predictions.jsonl` 的 `status=ok` 只代表 API 请求成功。还要检查 `parsed`、`scores.json_valid` 与 `finish_reason`；例如 Retail 的初始试跑有 3 次 API 成功但模型输出了无效 JSON，不能计作有效预测。

针对新 NYC311 Geography 的两个 borough 消歧家族，`geography_diagnostic.py` 以 Geography 字段的 borough 建立一对一条件配对，再用原答案匹配器检查答案；输出每个 gold pair 的预测、匹配状态和汇总。它不覆盖原论文评分，不改 Detection 或 Interpretation F1；若模型输出其他歧义维度，原分数仍会惩罚。初始 10 题试跑的原 E2E 分数为 0，而这一诊断显示 35 个 pair 中有 33 个匹配条件、28 个答案正确。请核查逐条记录并在正式报告中注明新维度评分协议，不能将诊断数字悄悄替换为论文原指标。

`geography_scoring_v2.py` 是可复用的 **NYC311 Geography 专用补充评分版本**：同时输出 Detection 中匹配 borough 的解释 F1，以及 E2E 的条件覆盖率、答案正确率（按 pair 与按 query 两种平均）；原论文分数逐条保留在 `original_scores`。不按答案反推条件，重复预测只能用一次，预测中的其他维度会计入 Detection 的额外条件数量。全 200 条的 gold 在此解析规则下逐条自检通过。初始 pilot 的 Detection 解释 F1 从原匹配器的 6.33% 变为 53.19%；E2E 的 35 个 pair 配对 33、答对 28，pair 平均 80%，query 平均 74%。这些不同平均方式须明确标注，不能互换。要比较模型，请对同一批 raw predictions 全部使用同一冻结版本评分，并保留原分数供核对。

```bash
python geography_scoring_v2.py --results runs/remaining6_pilot_gpt-4.1-mini/predictions.jsonl \
  --out analysis/nyc311_geography_v2
```

```bash
python geography_diagnostic.py --results runs/remaining6_pilot_gpt-4.1-mini/predictions.jsonl \
  --out analysis/nyc311_geography_diagnostic
```

## 在 Colab 跑

解压本包并进入 `DataAmbigBench_eval_code`。Colab 的命令格请加 `!`，或把整段放到 `%%bash`。先看已经生成的 `prepared/audit.json`，再预览第一批模型输入：

```bash
python lab.py run --data prepared/data --out runs/sec_pilot \
  --datasets sec --model gpt-4o-mini --limit 5 --preview
```

默认只生成请求计划与预览。确认后，在 Colab Secrets 读取 API key 到 `OPENAI_API_KEY` 环境变量，再执行下列命令。先用 5 个 query、4 种设置试跑，SEC 每题 2 个 pair，所以共 25 个请求。

```bash
python lab.py run --data prepared/data --out runs/sec_pilot \
  --datasets sec --model gpt-4o-mini --limit 5 --execute --max-calls 25
python lab.py analyze --results runs/sec_pilot/predictions.jsonl --out analysis/sec_pilot
```

`--max-calls` 约束这次执行可能发出的请求数，含设置的重试上限。原命令和目录可续跑。更换数据、模型、设置或代码后使用新目录。当前执行器按顺序发请求，便于做可比的单请求延迟测量。完整 200 条运行时移除 `--limit`，先查看 `plan.json` 并按预算填请求上限。结果目录建议放在 Drive。

默认使用 Ruyu 的 OpenAI / DeepSeek / Qwen 端点与密钥变量。其他模型须配置兼容原 `/chat/completions` 请求格式的端点，`--models models.json` 对应 JSON 格式如下。原生 Gemini 和 Anthropic 接口、以及要求其他 token 上限字段或特殊参数的模型需要对应适配器，先按模型实测可用性再加入正式矩阵。

```json
{"your-model-id":{"base_url":"https://YOUR_COMPATIBLE_GATEWAY/v1","base_url_env":"LAB_GATEWAY_URL","key_env":"LAB_GATEWAY_KEY","extra_payload":{}}}
```

可将各模型的已核对费率另存为 JSON，例如 `{"your-model-id":{"input_per_million":0.0,"output_per_million":0.0}}`（这里 0 只是占位），给 `analyze --prices`。估算基于完整记录的输入/输出 token，未覆盖折扣、缓存价或失败计费。

## 复跑离线分析或准备新版数据

```bash
python lab.py analyze --results /content/DataAmbigBench_raw_outputs.zip \
  --out analysis/old --rescore --scalar-audit
python lab.py compare --left /content/DataAmbigBench_raw_outputs.zip \
  --right /content/DataAmbigBench_raw_outputs.zip \
  --left-model gpt-4o-mini --right-model deepseek-v4-flash --task e2e \
  --out analysis/historical_e2e_comparison.json
```

`--write-rescored` 可另存逐条重评分。数值审计仅针对能够解析为单个数值的预测和 gold，保留原评分的别名与规则作为主结果。失败例见 `failure_examples.jsonl`。先核查 scorer 导致的误判，再将模型错误分为维度识别、解释覆盖、已识别条件下的作答与输出错误。

重新准备输入时，把 JSONL 放在同一目录。可以用多次 `--file 数据集=文件名` 指定精确版本。缺文件和不合格数据集会标在 audit，建议每次用新输出目录避免误用先前的文件。

```bash
python lab.py prepare --inputs /content/inputs --out prepared_next
```

NASA/TAT-QA 的证据 JSONL 每行提供 `id`、原 `query`、源 `table`、经核验的完整 `gold` 和 `source_ref`。TAT-QA 应根据原题和来源信息对齐金融表格与相关段落。NASA 按原地点和时间取数，核对口径、指标、单位和答案。找不到原口径时，把重建版标为新数据版本并重新算 gold。合并工具只验证格式、ID 和是否仍为答案对照表，证据与 gold 的正确性需人工复核。

```bash
python lab.py attach-context --sample /content/TAT_QA_200_sampled_v1.jsonl \
  --evidence /content/tatqa_evidence.jsonl --out /content/inputs/tatqa_source_context_v1.jsonl
python lab.py prepare --inputs /content/inputs --out prepared_next \
  --file tatqa=tatqa_source_context_v1.jsonl
```

Scalability 文件放在 `scales/1000/retail.jsonl`、`scales/5000/retail.jsonl`、`scales/20000/retail.jsonl`。使用同一查询、同一表结构和同一条件。若新增记录改变答案，按每张实际输入表重算 gold。用 `run --data scales --datasets retail --scale --tasks e2e --model gpt-4o-mini --out runs/retail_scale --preview` 先生成计划。验证后再加执行参数。规模报告应在相同模型与设置下比较质量、token、延迟和失败率。

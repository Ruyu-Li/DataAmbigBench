#!/usr/bin/env python3
"""Additional Geography diagnostic; preserves the original paper scores.

Only supports the two NYC311 Geography families whose gold conditions name a
borough. It does not alter Detection F1 or count answer-only coincidences.
"""
import argparse
import json
import re
from pathlib import Path

import lab

BOROUGHS = r"bronx|brooklyn|manhattan|queens|staten island"
LOCATION = re.compile(r"\b(?:in|as)\s+(?:the\s+)?(" + BOROUGHS + r")\b", re.I)


def borough(condition):
    matches = LOCATION.findall(str(condition))
    return matches[-1].casefold() if matches else None


def audit(row):
    if row.get("dataset") != "nyc311" or row.get("task") != "e2e":
        return None
    gold = row["gold"]["condition_answer_pairs"]
    predicted = (row.get("parsed") or {}).get("answers") or []
    used = set()
    details = []
    for pair in gold:
        gold_condition = pair["conditions"].get("Geography", "")
        target = borough(gold_condition)
        candidates = [
            (i, answer) for i, answer in enumerate(predicted)
            if i not in used and isinstance(answer, dict)
            and isinstance(answer.get("conditions"), dict)
            and target and borough(answer["conditions"].get("Geography", "")) == target
        ]
        index, answer = candidates[0] if candidates else (None, None)
        if index is not None:
            used.add(index)
        correct = bool(answer is not None and lab.paper.ans_relaxed(
            answer.get("answer", ""), pair, "nyc311"))
        details.append({
            "borough": target, "gold_condition": gold_condition,
            "gold_answer": pair["answer"],
            "predicted_geography": answer["conditions"].get("Geography") if answer else None,
            "predicted_answer": answer.get("answer") if answer else None,
            "matched": answer is not None, "correct": correct,
        })
    return {
        "id": row["id"], "query": row["query"],
        "gold_pairs": len(gold),
        "matched_pairs": sum(item["matched"] for item in details),
        "correct_pairs": sum(item["correct"] for item in details),
        "paper_answer_relaxed_norm": row["scores"]["answer_relaxed_norm"],
        "diagnostic_answer_accuracy": sum(item["correct"] for item in details) / len(gold),
        "details": details,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    rows = [item for row in lab.load_results(args.results) if (item := audit(row))]
    if not rows:
        raise ValueError("no NYC311 hinted E2E predictions in results")
    args.out.mkdir(parents=True, exist_ok=True)
    lab.save_rows(args.out / "geography_pair_review.jsonl", rows)
    total = sum(item["gold_pairs"] for item in rows)
    report = {
        "setting": "NYC311 hinted E2E; geography borough match diagnostic only",
        "queries": len(rows), "gold_pairs": total,
        "matched_pairs": sum(item["matched_pairs"] for item in rows),
        "correct_pairs": sum(item["correct_pairs"] for item in rows),
        "diagnostic_accuracy_pct": round(100 * sum(item["correct_pairs"] for item in rows) / total, 2),
        "paper_mean_accuracy_pct": round(100 * sum(item["paper_answer_relaxed_norm"] for item in rows) / len(rows), 2),
        "warning": "Extra predicted dimensions remain visible in original Detection/Interpretation scores. Review every pairing before publication; do not replace the paper scorer with this diagnostic silently.",
    }
    lab.save_json(args.out / "geography_diagnostic_summary.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

# Main evaluation, resume, and scoring

- **four_settings** preserves the prompt, scoring, configuration, bootstrap scripts, and sample inputs for Detection, Condition-Given, Hinted E2E, and E2E-open.
- **multimodel** contains the batch runner, provider adapters, model configuration, Colab entry point, and the seven data files from the archived project.
- **resume** contains the resume runner, resume report, Colab entry point, configuration, and the seven data files from the archived project.
- **subset_specific** contains Geography scoring and diagnostics, the SF311 contextual rescore, and TAT-QA rerun and numeric sensitivity scripts. The two TAT-QA export filenames identify distinct files.
- **historical_prompt_sensitivity** contains the earlier runner, prompts and metrics. The exact experiment arguments remain to be confirmed.

The multimodel and resume projects include ZIPs with the original filenames expected by the Colab notebooks. Follow each project's original instructions before issuing model calls. The exact runner revision, settings, and input files used for the final Table II remain to be confirmed. The duplicate multimodel and resume archive variants were dropped after confirming that their Python and notebook files match.

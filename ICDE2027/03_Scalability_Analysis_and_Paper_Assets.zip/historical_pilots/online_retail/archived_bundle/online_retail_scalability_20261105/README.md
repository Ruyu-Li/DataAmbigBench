# Online Retail II Scalability Inputs

This is a scalability experiment package, not a newly human-reviewed benchmark. It reuses 100 queries sampled evenly across the eight families in the selected 200-query Unit candidate; it does not generate new query wording.

## Files

- `tables/online_retail_unit_n{1000,5000,20000}.csv`: nested, complete-invoice tables. Exact row counts are in `summary.json`; full invoices make the counts slightly exceed their targets.
- `scalability_query_manifest.jsonl`: 300 query-by-size records with recalculated gold and references to the table CSVs.
- `scalability_condition_manifest.jsonl`: 1,500 condition-answer records (five interpretations per query-size pair).
- `selected_100_queries.csv`: the reproducible query selection.
- `materialize_online_retail_scale.py`: creates one scale's model inputs, standard records, or one condition slice in inline-table JSONL format. Use one condition at a time to avoid creating huge files.

## Sampling and golds

Each scale balances Germany and United Kingdom rows to keep both query scopes represented. This deliberate 50/50 balance differs from the source workbook's natural country proportions. All tables are nested samples of complete invoices. Gold answers are recalculated from each scaled table for by day, by week, by month, by quarter, and by year. Old golds from the input package are not reused.

Manual review was skipped per instruction. No model calls were made. The output remains a candidate experiment input.

## Materialize one slice

```bash
python materialize_online_retail_scale.py --package <package-folder> --size 1000 --task model --out <output-folder>
python materialize_online_retail_scale.py --package <package-folder> --size 1000 --task standard --out <output-folder>
python materialize_online_retail_scale.py --package <package-folder> --size 1000 --task condition --condition 'by day' --out <output-folder>
```

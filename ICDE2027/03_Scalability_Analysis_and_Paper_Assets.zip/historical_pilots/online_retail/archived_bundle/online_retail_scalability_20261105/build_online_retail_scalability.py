#!/usr/bin/env python3
"""Build a reproducible Online Retail II table-size scalability package.

Uses existing Unit queries as-is, samples 100 of 200 queries with balanced
family coverage, creates nested complete-invoice samples at nominal 1k/5k/20k
rows, and recomputes condition golds from each generated table.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import tempfile
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd

CONDITIONS = ["by day", "by week", "by month", "by quarter", "by year"]
SIZES = [1000, 5000, 20000]
TARGET_COUNTRIES = ["Germany", "United Kingdom"]
SOURCE_COLUMNS = ["Invoice", "StockCode", "Description", "Quantity", "InvoiceDate", "Price", "CustomerID", "Country", "source_sheet"]
ANSWER_NAMES = {
    "revenue_max": "total revenue", "revenue_min": "total revenue",
    "revenue_increase_max": "revenue increase", "revenue_decrease_max": "revenue decrease",
    "invoices_max": "distinct invoices", "identified_invoice_count_max": "invoices from identified customers",
    "line_items_max": "transaction line items", "sku_count_max": "distinct products",
    "top_product_share_min": "top product revenue share", "customers_max": "unique customers",
    "avg_invoice_value_max": "average invoice value", "avg_invoice_value_min": "average invoice value",
    "avg_units_per_invoice_max": "average units per invoice",
    "avg_skus_per_invoice_max": "average distinct products per invoice",
    "weighted_unit_price_max": "weighted average selling price per unit",
    "weighted_unit_price_min": "weighted average selling price per unit",
    "quantity_max": "total quantity",
}


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_jsonl(path: Path, records: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")


def workbook_frame(raw_zip: Path) -> tuple[pd.DataFrame, str]:
    with zipfile.ZipFile(raw_zip) as z:
        candidates = [n for n in z.namelist() if n.lower().endswith(".xlsx")]
        if len(candidates) != 1:
            raise ValueError(f"Expected exactly one workbook in {raw_zip}; found {candidates}")
        workbook_bytes = z.read(candidates[0])
    source_sha = hashlib.sha256(workbook_bytes).hexdigest()
    with tempfile.TemporaryDirectory() as tmp:
        xlsx = Path(tmp) / "source.xlsx"
        xlsx.write_bytes(workbook_bytes)
        excel = pd.ExcelFile(xlsx)
        parts = []
        usecols = ["Invoice", "StockCode", "Description", "Quantity", "InvoiceDate", "Price", "Customer ID", "Country"]
        for sheet in excel.sheet_names:
            frame = pd.read_excel(xlsx, sheet_name=sheet, usecols=usecols)
            frame["source_sheet"] = sheet
            parts.append(frame)
    df = pd.concat(parts, ignore_index=True)
    df = df[df["Country"].isin(TARGET_COUNTRIES)].copy()
    df["Invoice"] = df["Invoice"].astype("string")
    df["StockCode"] = df["StockCode"].astype("string")
    df["CustomerID"] = df.pop("Customer ID").astype("string")
    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"], errors="coerce")
    df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")
    df["Price"] = pd.to_numeric(df["Price"], errors="coerce")
    df = df.dropna(subset=["Invoice", "InvoiceDate", "Quantity", "Price"])
    df = df[df["Invoice"].str.strip().ne("")].copy()
    df["CustomerID"] = df["CustomerID"].replace({"<NA>": None, "nan": None, "None": None})
    return df[SOURCE_COLUMNS].reset_index(drop=True), source_sha


def choose_queries(records: list[dict], seed: int) -> list[dict]:
    rng = random.Random(seed)
    groups: dict[str, list[dict]] = defaultdict(list)
    for rec in records:
        groups[rec["metadata"]["family"]].append(rec)
    if len(groups) != 8 or any(len(rows) != 25 for rows in groups.values()):
        raise ValueError(f"Expected 8 families with 25 queries each; found { {k: len(v) for k,v in groups.items()} }")
    selected = []
    # Balanced sample: 12 from each family, then one extra from four families.
    extra_families = set(rng.sample(sorted(groups), 4))
    for family in sorted(groups):
        rows = sorted(groups[family], key=lambda x: x["id"])
        count = 13 if family in extra_families else 12
        selected.extend(rng.sample(rows, count))
    return sorted(selected, key=lambda x: x["id"])


def nested_complete_invoice_tables(df: pd.DataFrame, seed: int) -> dict[int, pd.DataFrame]:
    """Create nested tables with roughly equal Germany/UK row quotas."""
    rng = random.Random(seed)
    invoice_sizes = df.groupby(["Country", "Invoice"], sort=False).size()
    country_sequences: dict[str, list[str]] = {}
    # Same invoice cannot be split across sizes; grouping is country + invoice.
    for country in TARGET_COUNTRIES:
        inv = df.loc[df.Country == country, "Invoice"].drop_duplicates().tolist()
        rng.shuffle(inv)
        country_sequences[country] = inv
    result: dict[int, pd.DataFrame] = {}
    for target in SIZES:
        portions = []
        quota = target // 2
        for country in TARGET_COUNTRIES:
            invs = country_sequences[country]
            chosen, row_total = [], 0
            for invoice in invs:
                chosen.append(invoice)
                row_total += int(invoice_sizes.loc[(country, invoice)])
                if row_total >= quota:
                    break
            if row_total < quota:
                raise ValueError(f"Not enough source rows for {country}: needed {quota}, got {row_total}")
            portions.append(df.loc[(df.Country == country) & (df.Invoice.isin(chosen))])
        table = pd.concat(portions, ignore_index=True)
        table = table.sort_values(["InvoiceDate", "Country", "Invoice", "StockCode"], kind="stable").reset_index(drop=True)
        result[target] = table
    # Nestedness check: every smaller table's full invoice set is in each larger one.
    for small, large in zip(SIZES, SIZES[1:]):
        a = set(zip(result[small].Country, result[small].Invoice))
        b = set(zip(result[large].Country, result[large].Invoice))
        if not a.issubset(b):
            raise AssertionError(f"Invoice samples are not nested: {small} -> {large}")
    return result


def bucketize(df: pd.DataFrame, condition: str) -> pd.Series:
    dt = df["InvoiceDate"]
    if condition == "by day":
        return dt.dt.strftime("%Y-%m-%d")
    if condition == "by week":
        return dt.dt.strftime("%G-W%V")
    if condition == "by month":
        return dt.dt.strftime("%Y-%m")
    if condition == "by quarter":
        return dt.dt.year.astype(str) + "Q" + dt.dt.quarter.astype(str).astype(str)
    if condition == "by year":
        return dt.dt.year.astype(str)
    raise ValueError(condition)


def calculate_answer(table: pd.DataFrame, query: dict, condition: str) -> dict:
    meta = query["metadata"]
    data = table.loc[table.Country == meta["country"]].copy()
    if meta.get("stock_code"):
        data = data.loc[data.StockCode == str(meta["stock_code"])].copy()
    if data.empty:
        raise ValueError(f"No rows for {query['id']} / {condition}")
    data["bucket"] = bucketize(data, condition)
    data["revenue"] = data.Quantity * data.Price
    metric = meta["metric_code"]

    if metric in {"revenue_max", "revenue_min", "revenue_increase_max", "revenue_decrease_max"}:
        values = data.groupby("bucket", sort=True).revenue.sum()
        if metric == "revenue_increase_max":
            values = values.diff().dropna()
        elif metric == "revenue_decrease_max":
            values = -values.diff().dropna()
        maximize = metric not in {"revenue_min"}
    elif metric in {"invoices_max", "identified_invoice_count_max"}:
        if metric == "identified_invoice_count_max":
            data = data[data.CustomerID.notna() & data.CustomerID.astype(str).ne("")]
        values = data.groupby("bucket", sort=True).Invoice.nunique()
        maximize = True
    elif metric == "line_items_max":
        values = data.groupby("bucket", sort=True).size()
        maximize = True
    elif metric == "sku_count_max":
        values = data.groupby("bucket", sort=True).StockCode.nunique()
        maximize = True
    elif metric == "customers_max":
        data = data[data.CustomerID.notna() & data.CustomerID.astype(str).ne("")]
        values = data.groupby("bucket", sort=True).CustomerID.nunique()
        maximize = True
    elif metric in {"avg_invoice_value_max", "avg_invoice_value_min", "avg_units_per_invoice_max", "avg_skus_per_invoice_max"}:
        if metric.startswith("avg_invoice_value"):
            inv = data.groupby(["bucket", "Invoice"], sort=True).revenue.sum().rename("value").reset_index()
        elif metric == "avg_units_per_invoice_max":
            inv = data.groupby(["bucket", "Invoice"], sort=True).Quantity.sum().rename("value").reset_index()
        else:
            inv = data.groupby(["bucket", "Invoice"], sort=True).StockCode.nunique().rename("value").reset_index()
        values = inv.groupby("bucket", sort=True).value.mean()
        maximize = metric != "avg_invoice_value_min"
    elif metric == "top_product_share_min":
        sku_revenue = data.groupby(["bucket", "StockCode"], sort=True).revenue.sum()
        top = sku_revenue.groupby(level=0).max()
        totals = data.groupby("bucket", sort=True).revenue.sum()
        values = (top / totals.replace(0, pd.NA)).dropna()
        maximize = False
    elif metric in {"weighted_unit_price_max", "weighted_unit_price_min"}:
        grouped = data.groupby("bucket", sort=True).agg(revenue=("revenue", "sum"), quantity=("Quantity", "sum"))
        values = (grouped.revenue / grouped.quantity.replace(0, pd.NA)).dropna()
        maximize = metric.endswith("_max")
    elif metric == "quantity_max":
        values = data.groupby("bucket", sort=True).Quantity.sum()
        maximize = True
    else:
        raise ValueError(f"Unsupported metric: {metric}")

    values = values.dropna()
    if values.empty:
        raise ValueError(f"No valid grouped values: {query['id']} / {metric} / {condition}")
    winner = values.idxmax() if maximize else values.idxmin()
    value = float(values.loc[winner])
    # Use stable 6-decimal gold precision, matching the existing package convention.
    value = round(value, 6)
    winner_rows = data[data.bucket == winner]
    return {
        "condition": condition,
        "answer": str(winner),
        "answer_value": value,
        "num_time_buckets": int(len(values)),
        "winner_invoices": int(winner_rows.Invoice.nunique()),
        "clear_query": query["query"] + f" Aggregate the records {condition.replace('by ', 'by ')}.",
        "answer_value_name": ANSWER_NAMES[metric],
    }


def json_table(df: pd.DataFrame, title: str) -> dict:
    rows = df.copy()
    rows["InvoiceDate"] = rows.InvoiceDate.dt.strftime("%Y-%m-%d %H:%M:%S")
    rows["Quantity"] = rows.Quantity.astype(int)
    rows["Price"] = rows.Price.astype(float)
    rows["CustomerID"] = rows.CustomerID.where(rows.CustomerID.notna(), None)
    return {"title": title, "header": SOURCE_COLUMNS, "rows": rows.to_dict(orient="records")}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-zip", type=Path, required=True, help="ZIP containing online_retail_II.xlsx")
    parser.add_argument("--benchmark-zip", type=Path, required=True, help="ONLINE_RETAIL_UNIT_V2_200_VERIFIED ZIP")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20261105)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    raw, source_hash = workbook_frame(args.raw_zip)
    with zipfile.ZipFile(args.benchmark_zip) as z:
        standard_name = next(n for n in z.namelist() if n.endswith("online_retail_unit_200_standard.jsonl"))
        query_records = [json.loads(line) for line in z.read(standard_name).decode("utf-8").splitlines()]
    selected = choose_queries(query_records, args.seed)
    tables = nested_complete_invoice_tables(raw, args.seed)

    query_path = args.out / "scalability_query_manifest.jsonl"
    condition_path = args.out / "scalability_condition_manifest.jsonl"
    selected_path = args.out / "selected_100_queries.csv"
    scale_stats = {}
    experiment_rows, condition_rows = [], []
    for size, table in tables.items():
        table_file = f"tables/online_retail_unit_n{size}.csv"
        target = args.out / table_file
        target.parent.mkdir(parents=True, exist_ok=True)
        table.to_csv(target, index=False, date_format="%Y-%m-%d %H:%M:%S")
        title = f"Online Retail II complete-invoice sample (nominal n={size}, actual n={len(table)})"
        serialized_table = json_table(table, title)
        table_json_bytes = len(json.dumps(serialized_table, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
        scale_stats[str(size)] = {
            "nominal_rows": size,
            "actual_rows": int(len(table)),
            "rows_by_country": {k: int(v) for k, v in table.Country.value_counts().to_dict().items()},
            "unique_invoices": int(table.groupby(["Country", "Invoice"]).ngroups),
            "date_min": table.InvoiceDate.min().isoformat(),
            "date_max": table.InvoiceDate.max().isoformat(),
            "table_file": table_file,
            "csv_file_bytes": target.stat().st_size,
            "serialized_table_json_bytes": table_json_bytes,
            "estimated_100_model_calls_table_bytes": table_json_bytes * 100,
            "estimated_500_condition_calls_table_bytes": table_json_bytes * 500,
        }
        for query in selected:
            qid = f"{query['id']}__n{size}"
            answers = [calculate_answer(table, query, condition) for condition in CONDITIONS]
            gold = {
                "ambiguous_conditions": query["gold"].get("ambiguous_conditions", []),
                "condition_answer_pairs": [{"conditions": {"Unit": a["condition"]}, "answer": a["answer"], "condition": a["condition"], "answer_value": a["answer_value"]} for a in answers],
                "dimension": "Unit",
                "gold_conditions": CONDITIONS,
                "gold_answers": answers,
                "answer_by_condition": {a["condition"]: a["answer"] for a in answers},
                "answer_type": query["gold"].get("answer_type", "time_period"),
                "gold_condition_count": len(answers),
            }
            meta = {**query["metadata"], "scale_nominal_rows": size, "scale_actual_rows": len(table), "table_file": table_file, "gold_recomputed": True, "human_review_status": "not_performed_by_user_decision"}
            benchmark_fields = {key: query.get(key) for key in ["dataset", "dimension", "question", "ambiguous_query", "query_type", "ambiguity_family", "answer_type"]}
            experiment_rows.append({"id": qid, "base_query_id": query["id"], "query": query["query"], "table_file": table_file, "nominal_rows": size, "actual_rows": int(len(table)), "gold": gold, "metadata": meta, "benchmark_fields": benchmark_fields})
            for ans in answers:
                condition_rows.append({"id": f"{qid}::{ans['condition']}", "parent_id": qid, "base_query_id": query["id"], "query": ans["clear_query"], "table_file": table_file, "condition": ans["condition"], "gold_answer": ans["answer"], "gold_answer_value": ans["answer_value"], "nominal_rows": size, "actual_rows": int(len(table))})

    write_jsonl(query_path, experiment_rows)
    write_jsonl(condition_path, condition_rows)
    with selected_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "family", "metric_code", "country", "query"])
        writer.writeheader()
        for q in selected:
            writer.writerow({"id": q["id"], "family": q["metadata"]["family"], "metric_code": q["metadata"]["metric_code"], "country": q["metadata"]["country"], "query": q["query"]})
    summary = {
        "dataset": "Online Retail II",
        "dimension": "Unit",
        "source_sha256": source_hash,
        "benchmark_source": args.benchmark_zip.name,
        "seed": args.seed,
        "selected_queries": len(selected),
        "selection_design": "stratified, 12 or 13 queries per each of 8 families",
        "query_family_counts": dict(Counter(q["metadata"]["family"] for q in selected)),
        "nominal_table_sizes": SIZES,
        "sampling": "Nested, country-stratified (50% Germany / 50% United Kingdom by target rows), complete-invoice samples; actual sizes are reported because invoice groups are indivisible.",
        "scale_tables": scale_stats,
        "generated_query_scale_pairs": len(experiment_rows),
        "generated_condition_answer_pairs": len(condition_rows),
        "gold_recomputed_from_each_scale_table": True,
        "api_calls": 0,
        "human_review": "not performed per user instruction; candidate benchmark only",
        "note": "Original query wording was reused. No new queries were generated. Golds are recalculated for each sampled table.",
    }
    (args.out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    readme = """# Online Retail II Scalability Inputs\n\nThis is a scalability experiment package, not a newly human-reviewed benchmark. It reuses 100 queries sampled evenly across the eight families in the selected 200-query Unit candidate; it does not generate new query wording.\n\n## Files\n\n- `tables/online_retail_unit_n{1000,5000,20000}.csv`: nested, complete-invoice tables. Exact row counts are in `summary.json`; full invoices make the counts slightly exceed their targets.\n- `scalability_query_manifest.jsonl`: 300 query-by-size records with recalculated gold and a reference to the table CSV.\n- `scalability_condition_manifest.jsonl`: 1,500 condition-answer records (five interpretations per query-size pair).\n- `selected_100_queries.csv`: the reproducible query selection.\n- `materialize_online_retail_scale.py`: creates one scale's model inputs, standard records, or one condition slice in the evaluator's inline-table JSONL format. Use one condition at a time to avoid creating huge files.\n\n## Sampling and golds\n\nEach scale balances Germany and United Kingdom rows to keep both query scopes represented. This deliberate 50/50 balance differs from the source workbook's natural country proportions. All tables are nested samples of complete invoices. Gold answers are recalculated from each scaled table for by day, by week, by month, by quarter, and by year. Old golds from the input package are not reused.\n\nManual review was skipped per instruction. No model calls were made. The output remains a candidate experiment input.\n\n## Materialize one slice\n\n```bash\npython materialize_online_retail_scale.py --package <package-folder> --size 1000 --task model --out <output-folder>\npython materialize_online_retail_scale.py --package <package-folder> --size 1000 --task standard --out <output-folder>\npython materialize_online_retail_scale.py --package <package-folder> --size 1000 --task condition --condition 'by day' --out <output-folder>\n```\n"""
    (args.out / "README.md").write_text(readme, encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Materialize one table-size slice into evaluator/API-friendly JSONL files."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def load_table(path: Path, nominal: int) -> dict:
    df = pd.read_csv(path, dtype={"Invoice": "string", "StockCode": "string", "CustomerID": "string", "Country": "string", "source_sheet": "string"}, parse_dates=["InvoiceDate"])
    df["CustomerID"] = df["CustomerID"].where(df["CustomerID"].notna(), None)
    rows = df.to_dict(orient="records")
    for row in rows:
        row["InvoiceDate"] = row["InvoiceDate"].strftime("%Y-%m-%d %H:%M:%S")
        row["Quantity"] = int(row["Quantity"])
        row["Price"] = float(row["Price"])
        if pd.isna(row["CustomerID"]):
            row["CustomerID"] = None
    return {
        "title": f"Online Retail II complete-invoice sample (nominal n={nominal}, actual n={len(rows)})",
        "header": ["Invoice", "StockCode", "Description", "Quantity", "InvoiceDate", "Price", "CustomerID", "Country", "source_sheet"],
        "rows": rows,
    }


def write_jsonl(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--package", type=Path, required=True)
    ap.add_argument("--size", type=int, choices=[1000, 5000, 20000], required=True)
    ap.add_argument("--task", choices=["model", "standard", "condition"], default="model")
    ap.add_argument("--condition", choices=["by day", "by week", "by month", "by quarter", "by year"], help="Required for --task condition; materializes just one condition slice.")
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    table_path = args.package / "tables" / f"online_retail_unit_n{args.size}.csv"
    table = load_table(table_path, args.size)
    manifest = [json.loads(s) for s in (args.package / "scalability_query_manifest.jsonl").read_text(encoding="utf-8").splitlines() if s]
    selected = [r for r in manifest if r["nominal_rows"] == args.size]
    args.out.mkdir(parents=True, exist_ok=True)

    cond_manifest = [json.loads(s) for s in (args.package / "scalability_condition_manifest.jsonl").read_text(encoding="utf-8").splitlines() if s]
    if args.task == "condition" and not args.condition:
        ap.error("--condition is required with --task condition")
    if args.task != "condition" and args.condition:
        ap.error("--condition can only be used with --task condition")
    condition_suffix = f"_{args.condition.replace(' ', '_')}" if args.condition else ""
    out_path = args.out / f"online_retail_unit_n{args.size}_{args.task}{condition_suffix}.jsonl"
    count = 0
    with out_path.open("w", encoding="utf-8", newline="\n") as f:
        if args.task in {"model", "standard"}:
            for record in selected:
                if args.task == "model":
                    output = {"id": record["id"], "query": record["query"], "table": table}
                else:
                    fields = record.get("benchmark_fields") or {}
                    output = {
                        "id": record["id"], "query": record["query"], "table": table, "gold": record["gold"], "metadata": record["metadata"],
                        "dataset": fields.get("dataset", "Online Retail II"), "dimension": fields.get("dimension", "Unit"),
                        "question": fields.get("question", record["query"]), "ambiguous_query": fields.get("ambiguous_query", record["query"]),
                        "query_type": fields.get("query_type"), "ambiguity_family": fields.get("ambiguity_family", record["metadata"].get("family")),
                        "gold_conditions": record["gold"]["gold_conditions"], "gold_answers": record["gold"]["gold_answers"],
                        "answer_by_condition": record["gold"]["answer_by_condition"], "answer_type": record["gold"].get("answer_type", "time_period"),
                        "gold_condition_count": record["gold"]["gold_condition_count"],
                    }
                f.write(json.dumps(output, ensure_ascii=False, separators=(",", ":")) + "\n")
                count += 1
    if args.task == "condition":
        # Keep one condition slice per file to avoid creating 500 copies of a 20k-row table at once.
        with out_path.open("w", encoding="utf-8", newline="\n") as f:
            for row in cond_manifest:
                if row["nominal_rows"] != args.size or row["condition"] != args.condition:
                    continue
                output = {"id": row["id"], "condition_index": ["by day", "by week", "by month", "by quarter", "by year"].index(row["condition"]), "query": row["query"], "table": table, "condition": row["condition"]}
                f.write(json.dumps(output, ensure_ascii=False, separators=(",", ":")) + "\n")
                count += 1
    print(json.dumps({"nominal_size": args.size, "actual_rows": len(table["rows"]), "task": args.task, "records": count, "output": str(out_path)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

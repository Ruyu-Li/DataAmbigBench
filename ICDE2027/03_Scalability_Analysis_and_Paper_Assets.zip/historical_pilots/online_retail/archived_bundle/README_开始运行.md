# Online Retail scalability pilot（先预检，再决定是否调用 API）

## 这个 pilot 做什么

- 固定抽取同一组 10 条 Online Retail Unit queries。
- 在 1k、5k、20k 三种表规模上各跑一次 End-to-End（E2E），共 30 次 API 请求。
- 记录 API 实际输入/输出 tokens、延迟、费用和答案指标；同时记录表格行数、CSV 字节数。
- 只测 E2E；不会生成更多 query，也不包含主评测中的三个任务。
- 默认只做 dry-run 预检，不会产生 API 请求或消耗 tokens。只有加 `--execute` 才会真的调用 API。

## 在 Colab 运行

1. 把本 zip 上传到 Google Drive 并解压。
2. 安装依赖：

```python
!pip -q install openai pandas
```

3. 如果还没有 API key，只做免费预检：

```python
!python run_online_retail_e2e_pilot.py \
  --package online_retail_scalability_20261105 \
  --out pilot_preflight.jsonl \
  --n-queries 10 \
  --model gpt-4.1-mini
```

4. 收到 API key 后，建议放在 Colab 左侧 Secrets 中，名称设为 `OPENAI_API_KEY`，然后在 notebook 读取：

```python
from google.colab import userdata
import os
os.environ["OPENAI_API_KEY"] = userdata.get("OPENAI_API_KEY")
```

5. 经确认要花费 API 额度后，在上面的命令末尾加 `--execute`。结果会写到 `pilot_results.jsonl` 和 `pilot_results_summary.json`。

也可以把 `--model gpt-4.1-mini` 改成 `--model gpt-5-mini`。脚本对 20k 表有输入 token 安全阈值，估计超过阈值时会跳过该请求。估算只用于预检，最终以 API 返回的 usage 为准。

## Pilot 预估

按当前紧凑 CSV 序列化、每 3 个字符约 1 token 的粗略代理值，30 次请求约 **4,384,031 输入 tokens**；每次最多生成 2,000 tokens，输出上限合计 **60,000 tokens**。按 GPT-4.1 mini 当前标准价粗算并加 20% 余量约 **$2.22**。实际费用以 API usage、模型定价和输出长度为准；本估算不含免费额度、缓存折扣或批处理折扣。

## 重要限制

- 这是小规模 smoke test，用来确认格式、延迟、token 量和评分链路，不等于全量模型评测。
- 这份 runner 当前只支持 OpenAI 的 GPT-4.1 mini / GPT-5 mini；Gemini、Claude、DeepSeek 需各自适配器，不能直接套用 OpenAI key。
- GPT-4.1 mini 官方页面目前标记为 Deprecated，计划运行前请再核对可用性和 API 价格。
- 此 pilot 的费用不计入主评测的预算表。

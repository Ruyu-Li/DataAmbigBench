#!/usr/bin/env python3
"""Dry-run or run a 10-query Online Retail II Unit E2E scalability pilot.

Default behavior is preflight only. Add --execute to make paid API calls.
Currently supports OpenAI GPT-4.1 mini and GPT-5 mini.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import random
import re
import statistics
import time
from pathlib import Path
from typing import Any

import pandas as pd

SYSTEM_PROMPT = "You are an evaluator for ambiguous tabular question answering. Use only the supplied table. Return valid JSON only, with no markdown or text outside the JSON object."

MODEL_CONFIG = {
    "gpt-4.1-mini": {"input_usd_per_million": 0.40, "output_usd_per_million": 1.60, "safe_input_token_limit": 1_000_000},
    "gpt-5-mini": {"input_usd_per_million": 0.25, "output_usd_per_million": 2.00, "safe_input_token_limit": 380_000},
}
SIZES = [1000, 5000, 20000]
CONDITIONS = ["by day", "by week", "by month", "by quarter", "by year"]


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def load_compact_table(path: Path) -> tuple[str, int]:
    """Render only the seven fields used by the existing Unit query set."""
    df = pd.read_csv(
        path,
        dtype={"Invoice": "string", "StockCode": "string", "CustomerID": "string", "Country": "string"},
        parse_dates=["InvoiceDate"],
    )
    cols = ["Invoice", "StockCode", "Quantity", "InvoiceDate", "Price", "CustomerID", "Country"]
    out = [",".join(cols)]
    for row in df[cols].itertuples(index=False, name=None):
        values = list(row)
        values[2] = str(int(values[2]))
        values[3] = values[3].strftime("%Y-%m-%d")
        values[4] = format(float(values[4]), ".10g")
        values[5] = "" if pd.isna(values[5]) else str(values[5])
        # Use CSV escaping only for fields that contain separators or quotes.
        encoded = []
        for value in values:
            value = str(value)
            if any(ch in value for ch in ',"\n'):
                value = '"' + value.replace('"', '""') + '"'
            encoded.append(value)
        out.append(",".join(encoded))
    return "\n".join(out), len(df)


def build_prompt(query: str, table_csv: str) -> str:
    return f"""Task: End-to-End Unit Ambiguity Evaluation

Use the supplied table to answer the user's query. Identify the ambiguity, state the dimension as Unit, list the plausible time aggregation units, and answer under each interpretation.

For this benchmark, Unit means the unspecified time aggregation level. Use only the supplied table. Do not use outside data. Each answer field must contain only the resulting period label. In every answer object, use the condition key \"Unit\" and a condition label such as \"by day\".

Return exactly this JSON structure:
{{
  \"ambiguous_conditions\": [
    {{\"term\": \"...\", \"dimension\": \"Unit\", \"possible_conditions\": [\"...\"]}}
  ],
  \"answers\": [
    {{\"conditions\": {{\"Unit\": \"by day\"}}, \"answer\": \"...\"}}
  ]
}}

Table (CSV):
{table_csv}

Query:
{query}
"""


def parse_json(text: str) -> dict:
    text = (text or "").strip()
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.I | re.S)
    if fenced:
        text = fenced.group(1).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, flags=re.S)
        if not match:
            return {}
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            return {}


def canonical_condition(value: Any) -> str | None:
    text = str(value or "").lower().strip().replace("_", " ")
    text = re.sub(r"\s+", " ", text)
    aliases = {
        "day": "by day", "daily": "by day", "by day": "by day",
        "week": "by week", "weekly": "by week", "by week": "by week", "iso week": "by week", "by iso week": "by week",
        "month": "by month", "monthly": "by month", "by month": "by month", "calendar month": "by month",
        "quarter": "by quarter", "quarterly": "by quarter", "by quarter": "by quarter", "calendar quarter": "by quarter",
        "year": "by year", "yearly": "by year", "annual": "by year", "by year": "by year", "calendar year": "by year",
    }
    if text in aliases:
        return aliases[text]
    for unit in ("day", "week", "month", "quarter", "year"):
        if re.search(rf"\b{unit}\b", text):
            return f"by {unit}"
    return None


def norm_answer(value: Any) -> str:
    text = str(value or "").strip().lower()
    return re.sub(r"[^a-z0-9]+", "", text)


def score_prediction(record: dict, prediction: dict) -> dict:
    gold = record["gold"]
    gold_pairs = {p["condition"]: str(p["answer"]) for p in gold["condition_answer_pairs"]}
    pred_answers = prediction.get("answers", [])
    if not isinstance(pred_answers, list):
        pred_answers = []
    pred_map = {}
    for item in pred_answers:
        if not isinstance(item, dict):
            continue
        conditions = item.get("conditions", {})
        if not isinstance(conditions, dict):
            continue
        condition_value = conditions.get("Unit")
        if condition_value is None and len(conditions) == 1:
            condition_value = next(iter(conditions.values()))
        key = canonical_condition(condition_value)
        if key:
            pred_map.setdefault(key, str(item.get("answer", "")))
    matched_conditions = set(gold_pairs) & set(pred_map)
    matched_answers = {c for c in matched_conditions if norm_answer(gold_pairs[c]) == norm_answer(pred_map[c])}
    dim_items = prediction.get("ambiguous_conditions", [])
    dim_ok = any(isinstance(x, dict) and str(x.get("dimension", "")).lower().replace("-", " ").strip() == "unit" for x in dim_items) if isinstance(dim_items, list) else False
    condition_precision = len(matched_conditions) / max(1, len(pred_map))
    condition_recall = len(matched_conditions) / max(1, len(gold_pairs))
    answer_accuracy = len(matched_answers) / max(1, len(gold_pairs))
    return {
        "unit_dimension_detected": int(dim_ok),
        "gold_conditions": len(gold_pairs),
        "predicted_conditions": len(pred_map),
        "matched_conditions": len(matched_conditions),
        "condition_precision": condition_precision,
        "condition_recall": condition_recall,
        "matched_answers": len(matched_answers),
        "answer_accuracy": answer_accuracy,
        "full_e2e_exact": int(dim_ok and len(matched_conditions) == len(gold_pairs) and len(matched_answers) == len(gold_pairs) and len(pred_map) == len(gold_pairs)),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--package", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--model", choices=sorted(MODEL_CONFIG), default="gpt-4.1-mini")
    ap.add_argument("--sizes", type=int, nargs="+", choices=SIZES, default=SIZES)
    ap.add_argument("--n-queries", type=int, default=10)
    ap.add_argument("--seed", type=int, default=20261105)
    ap.add_argument("--max-input-tokens", type=int, help="Safety threshold; defaults to the selected model's configured headroom limit.")
    ap.add_argument("--max-output-tokens", type=int, default=2000)
    ap.add_argument("--execute", action="store_true", help="Make paid API calls. Without this flag, only write a preflight plan.")
    args = ap.parse_args()

    records = read_jsonl(args.package / "scalability_query_manifest.jsonl")
    base_ids = sorted({r["base_query_id"] for r in records})
    if not 1 <= args.n_queries <= len(base_ids):
        ap.error(f"--n-queries must be between 1 and {len(base_ids)}")
    chosen = set(random.Random(args.seed).sample(base_ids, args.n_queries))
    token_limit = args.max_input_tokens or MODEL_CONFIG[args.model]["safe_input_token_limit"]
    cfg = MODEL_CONFIG[args.model]
    args.out.parent.mkdir(parents=True, exist_ok=True)

    client = None
    if args.execute:
        if not os.getenv("OPENAI_API_KEY"):
            ap.error("Set OPENAI_API_KEY in the environment before using --execute.")
        try:
            from openai import OpenAI
        except ImportError:
            ap.error("Install the OpenAI SDK first: pip install openai")
        client = OpenAI(max_retries=0)

    results = []
    for size in args.sizes:
        scale_records = [r for r in records if r["nominal_rows"] == size and r["base_query_id"] in chosen]
        table_path = args.package / "tables" / f"online_retail_unit_n{size}.csv"
        table_csv, actual_rows = load_compact_table(table_path)
        for record in sorted(scale_records, key=lambda r: r["base_query_id"]):
            prompt = build_prompt(record["query"], table_csv)
            est_input_tokens = math.ceil((len(SYSTEM_PROMPT) + len(prompt)) / 3)
            result = {
                "id": record["id"], "base_query_id": record["base_query_id"], "model": args.model,
                "task": "End-to-End", "nominal_rows": size, "actual_rows": actual_rows,
                "table_csv_bytes_utf8": len(table_csv.encode("utf-8")),
                "table_csv_characters": len(table_csv),
                "estimated_input_tokens_char_proxy": est_input_tokens,
                "max_estimated_input_tokens": token_limit,
                "status": "preflight_only" if not args.execute else "pending",
                "input_tokens": None, "output_tokens": None, "latency_seconds": None,
                "cost_usd": None, "scores": None, "prediction": None, "error": None,
            }
            if est_input_tokens > token_limit:
                result["status"] = "skipped_preflight_context_threshold"
                results.append(result)
                continue
            if not args.execute:
                results.append(result)
                continue
            started = time.perf_counter()
            try:
                response = client.chat.completions.create(
                    model=args.model,
                    temperature=0,
                    max_completion_tokens=args.max_output_tokens,
                    response_format={"type": "json_object"},
                    messages=[{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}],
                )
                latency = time.perf_counter() - started
                raw = response.choices[0].message.content or ""
                prediction = parse_json(raw)
                usage = response.usage
                input_tokens = int(usage.prompt_tokens) if usage and usage.prompt_tokens is not None else None
                output_tokens = int(usage.completion_tokens) if usage and usage.completion_tokens is not None else None
                cost = None
                if input_tokens is not None and output_tokens is not None:
                    cost = (input_tokens * cfg["input_usd_per_million"] + output_tokens * cfg["output_usd_per_million"]) / 1_000_000
                result.update({
                    "status": "success", "input_tokens": input_tokens, "output_tokens": output_tokens,
                    "latency_seconds": latency, "cost_usd": cost, "scores": score_prediction(record, prediction),
                    "prediction": prediction, "raw_response": raw,
                })
            except Exception as exc:
                result.update({"status": "api_error", "latency_seconds": time.perf_counter() - started, "error": f"{type(exc).__name__}: {exc}"})
            results.append(result)
            # Persist after each call so an interrupted pilot retains completed work.
            args.out.write_text("\n".join(json.dumps(x, ensure_ascii=False) for x in results) + "\n", encoding="utf-8")

    args.out.write_text("\n".join(json.dumps(x, ensure_ascii=False) for x in results) + "\n", encoding="utf-8")
    completed = [r for r in results if r["status"] == "success"]
    latencies = [r["latency_seconds"] for r in completed if r["latency_seconds"] is not None]
    by_size = {}
    for size in args.sizes:
        size_results = [r for r in results if r["nominal_rows"] == size]
        size_completed = [r for r in size_results if r["status"] == "success"]
        size_latencies = [r["latency_seconds"] for r in size_completed if r["latency_seconds"] is not None]
        scored = [r["scores"] for r in size_completed if r["scores"] is not None]
        by_size[str(size)] = {
            "actual_table_rows": size_results[0]["actual_rows"] if size_results else None,
            "table_csv_bytes_utf8": size_results[0]["table_csv_bytes_utf8"] if size_results else None,
            "planned_calls": len(size_results),
            "successful_calls": len(size_completed),
            "input_tokens_actual": sum(r["input_tokens"] or 0 for r in size_completed),
            "output_tokens_actual": sum(r["output_tokens"] or 0 for r in size_completed),
            "cost_usd_actual": round(sum(r["cost_usd"] or 0 for r in size_completed), 6),
            "mean_latency_seconds": statistics.mean(size_latencies) if size_latencies else None,
            "median_latency_seconds": statistics.median(size_latencies) if size_latencies else None,
            "full_e2e_exact_rate": statistics.mean(x["full_e2e_exact"] for x in scored) if scored else None,
        }
    summary = {
        "model": args.model, "task": "End-to-End", "sizes": args.sizes,
        "sampled_queries": len(chosen), "planned_calls": len(results),
        "executed_calls": len(completed), "skipped": sum(r["status"].startswith("skipped") for r in results),
        "errors": sum(r["status"] == "api_error" for r in results),
        "input_token_estimator": "ceil((system + user prompt characters)/3); actual usage is recorded after API calls",
        "input_tokens_actual": sum(r["input_tokens"] or 0 for r in completed),
        "output_tokens_actual": sum(r["output_tokens"] or 0 for r in completed),
        "cost_usd_actual": round(sum(r["cost_usd"] or 0 for r in completed), 6),
        "mean_latency_seconds": statistics.mean(latencies) if latencies else None,
        "median_latency_seconds": statistics.median(latencies) if latencies else None,
        "full_e2e_exact_rate": statistics.mean(r["scores"]["full_e2e_exact"] for r in completed if r["scores"]) if any(r["scores"] for r in completed) else None,
        "results_by_size": by_size,
        "execute_flag_used": args.execute,
        "manual_review": "not performed per user decision",
    }
    summary_path = args.out.with_name(args.out.stem + "_summary.json")
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

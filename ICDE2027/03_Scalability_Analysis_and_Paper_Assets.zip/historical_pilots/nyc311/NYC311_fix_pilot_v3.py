from google.colab import drive
from pathlib import Path
from datetime import datetime
import csv
import io
import json
import re
import shutil
import tempfile
import zipfile

import pandas as pd


drive.mount("/content/drive")
ROOT = Path("/content/drive/MyDrive")

pilot_zips = list(ROOT.rglob("Geography_PilotV2_10_*.zip"))
profile_zips = list(ROOT.rglob("Geography_Family_Profile_*.zip"))
assert pilot_zips, "找不到 Geography_PilotV2_10_*.zip"
assert profile_zips, "找不到 Geography_Family_Profile_*.zip"
pilot_zip = max(pilot_zips, key=lambda p: p.stat().st_mtime)
profile_zip = max(profile_zips, key=lambda p: p.stat().st_mtime)

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
out_dir = ROOT / "NYC311_2024" / f"Geography_PilotV3_10_{stamp}"
out_dir.mkdir(parents=True, exist_ok=False)


def read_jsonl_from_zip(zip_path, member):
    with zipfile.ZipFile(zip_path) as zf:
        text = zf.read(member).decode("utf-8")
    return [json.loads(line) for line in text.splitlines() if line.strip()]


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def markdown_table(label, items):
    frame = pd.DataFrame([{label: location, "Request Count": answer} for location, answer, _ in items])
    return frame.to_markdown(index=False)


with zipfile.ZipFile(pilot_zip) as zf:
    standard_member = next(n for n in zf.namelist() if n.endswith("_standard.jsonl"))
old_rows = read_jsonl_from_zip(pilot_zip, standard_member)

# Read the independently generated profile and obtain the Grand Avenue counts.
with zipfile.ZipFile(profile_zip) as zf:
    member = next(n for n in zf.namelist() if n.endswith("street_name_across_borough_candidates.csv"))
    profile = pd.read_csv(io.BytesIO(zf.read(member)))

grand = profile[
    (profile["month"] == "2024-05")
    & (profile["complaint"] == "ILLEGAL PARKING")
    & (profile["street"] == "GRAND AVENUE")
].copy()
assert len(grand) >= 3, "Grand Avenue候选不足"
grand_counts = {
    str(row["Borough"]).title(): int(row["count"])
    for _, row in grand.iterrows()
    if int(row["count"]) > 0
}
assert grand_counts == {"Bronx": 27, "Brooklyn": 31, "Queens": 19}, grand_counts

standard = []
model_inputs = []
condition_inputs = []
review_rows = []

for old in old_rows:
    qid = old["id"]
    family = old["ambiguity_family"]

    if qid == "G08":
        query = "How many Illegal Parking service requests were recorded on Grand Avenue in May 2024?"
        term = "Grand Avenue"
        items = []
        for location in ["Bronx", "Brooklyn", "Queens"]:
            condition = f"Interpret 'Grand Avenue' as the street located in {'the ' if location == 'Bronx' else ''}{location}."
            items.append((location, grand_counts[location], condition))
        table_label = "Street Location"
    else:
        query = old["query"]
        pairs = old["condition_answer_pairs"]
        items = []
        if family == "community_board_borough_omission":
            match = re.search(r"Community Board (\d+)", query)
            assert match, qid
            board = match.group(1)
            term = f"Community Board {board}"
            table_label = "Community Board Location"
            for pair in pairs:
                condition = pair["condition"]
                m = re.search(r"as (.+?) Community Board \d+\.$", condition)
                assert m, condition
                location = m.group(1)
                items.append((location, int(pair["answer_numeric"]), condition))
        else:
            match = re.search(r"recorded on (.+?) in [A-Z][a-z]+ 2024\?", query)
            assert match, query
            term = match.group(1)
            table_label = "Street Location"
            for pair in pairs:
                answer = int(pair["answer_numeric"])
                if answer == 0:
                    continue
                condition = pair["condition"]
                m = re.search(r"located in (?:the )?(.+?)\.$", condition)
                assert m, condition
                location = m.group(1)
                items.append((location, answer, condition))

    assert len(items) >= 2, f"{qid}少于两个有效解释"
    table = markdown_table(table_label, items)
    conditions = [condition for _, _, condition in items]
    answer_pairs = [
        {"conditions": {"Geography": condition}, "answer": answer}
        for _, answer, condition in items
    ]

    record = {
        "id": qid,
        "query": query,
        "table": table,
        "gold": {
            "ambiguous_conditions": [{
                "term": term,
                "dimension": "Geography",
                "conditions": conditions,
            }],
            "condition_answer_pairs": answer_pairs,
        },
        "evaluation_ready": False,
        "metadata": {
            "dataset": "NYC311",
            "dimension": "Geography",
            "family": family,
            "source_period": "2024-02-01 inclusive to 2024-12-01 exclusive",
            "constructed_query": True,
            "manual_review_status": "pending",
            "condition_set_exhaustive_within_supplied_table": True,
            "official_geographic_exhaustiveness_verified": False,
        },
    }
    standard.append(record)
    model_inputs.append({"id": qid, "query": query, "table": table})

    for index, ((location, answer, condition)) in enumerate(items, 1):
        condition_inputs.append({
            "id": qid,
            "condition_index": index,
            "query": query,
            "table": table,
            "condition": condition,
        })
        review_rows.append({
            "query_id": qid,
            "family": family,
            "query": query,
            "condition": condition,
            "answer": answer,
            "query_natural": "",
            "genuine_geography_ambiguity": "",
            "dimension_correct": "",
            "condition_valid": "",
            "answer_correct": "",
            "notes": "",
        })

assert len(standard) == 10
assert len(condition_inputs) == 42
assert len({r["id"] for r in standard}) == 10
assert all(len(r["gold"]["condition_answer_pairs"]) >= 2 for r in standard)
assert all(pair["answer"] > 0 for r in standard for pair in r["gold"]["condition_answer_pairs"])

write_jsonl(out_dir / "nyc311_geography_pilot_v3_standard.jsonl", standard)
write_jsonl(out_dir / "nyc311_geography_pilot_v3_model_inputs.jsonl", model_inputs)
write_jsonl(out_dir / "nyc311_geography_pilot_v3_condition_inputs.jsonl", condition_inputs)
pd.DataFrame(review_rows).to_csv(out_dir / "nyc311_geography_pilot_v3_manual_review.csv", index=False)

summary = {
    "version": "v3-pilot",
    "source_pilot": str(pilot_zip),
    "source_profile": str(profile_zip),
    "query_count": len(standard),
    "condition_answer_pair_count": len(condition_inputs),
    "families": {
        "community_board_borough_omission": 5,
        "street_name_borough_omission": 5,
    },
    "changes_from_v2": [
        "Converted standard/model/condition files to the existing SF311 evaluation schema.",
        "Replaced the unnatural '3 Avenue' query with Grand Avenue.",
        "Removed zero-answer street interpretations from the supplied pilot tables.",
        "Marked all records as pending manual review rather than evaluation-ready.",
    ],
    "validation": {
        "jsonl_parseable": True,
        "unique_query_ids": True,
        "all_answers_positive": True,
        "grand_avenue_profile_counts_verified": True,
    },
}
(out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

readme = """# NYC311 Geography Pilot V3

This package contains 10 pilot queries across two Geography ambiguity families.

- `standard.jsonl`: complete records with `query`, `table`, nested `gold`, and metadata.
- `model_inputs.jsonl`: ambiguous query and table only.
- `condition_inputs.jsonl`: one gold-condition input per condition-answer pair.
- `manual_review.csv`: human-review sheet. Fill the five review columns before setting `evaluation_ready=true`.

The pilot is not yet approved for benchmark evaluation. It first requires human review.
"""
(out_dir / "README.md").write_text(readme, encoding="utf-8")

zip_path = shutil.make_archive(str(out_dir), "zip", root_dir=out_dir)
print("========== V3完成 ==========")
print(json.dumps(summary, ensure_ascii=False, indent=2))
print("ZIP：", zip_path)

from google.colab import drive
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict
import json
import shutil

import pandas as pd


drive.mount("/content/drive")

ROOT = Path("/content/drive/MyDrive")
matches = list(ROOT.rglob("311_Service_Requests_from_2020_to_Present_20261008.csv"))
assert matches, "找不到原始 NYC311 CSV"
source = max(matches, key=lambda p: p.stat().st_mtime)

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
out_dir = ROOT / "NYC311_2024" / f"Geography_PilotV2_10_{stamp}"
out_dir.mkdir(parents=True, exist_ok=False)

header = pd.read_csv(source, nrows=0).columns.tolist()
complaint_col = (
    "Problem (formerly Complaint Type)"
    if "Problem (formerly Complaint Type)" in header
    else "Complaint Type"
)
usecols = [
    "Created Date", complaint_col, "Borough", "Community Board", "Street Name"
]
assert not [c for c in usecols if c not in header], "原始CSV缺少必要字段"

BOROUGHS = ["BRONX", "BROOKLYN", "MANHATTAN", "QUEENS", "STATEN ISLAND"]
DISPLAY = {
    "BRONX": "the Bronx",
    "BROOKLYN": "Brooklyn",
    "MANHATTAN": "Manhattan",
    "QUEENS": "Queens",
    "STATEN ISLAND": "Staten Island",
}


def clean(series):
    return (
        series.fillna("").astype(str).str.strip().str.upper()
        .str.replace(r"\s+", " ", regex=True)
    )


cb_specs = [
    {
        "id": "G01", "month": "2024-03", "complaint": "ILLEGAL PARKING", "board": 1,
        "query": "How many Illegal Parking service requests were recorded for Community Board 1 in March 2024?",
    },
    {
        "id": "G02", "month": "2024-05", "complaint": "NOISE - RESIDENTIAL", "board": 2,
        "query": "How many Noise - Residential service requests were recorded for Community Board 2 in May 2024?",
    },
    {
        "id": "G03", "month": "2024-07", "complaint": "BLOCKED DRIVEWAY", "board": 3,
        "query": "How many Blocked Driveway service requests were recorded for Community Board 3 in July 2024?",
    },
    {
        "id": "G04", "month": "2024-09", "complaint": "STREET CONDITION", "board": 1,
        "query": "How many Street Condition service requests were recorded for Community Board 1 in September 2024?",
    },
    {
        "id": "G05", "month": "2024-11", "complaint": "HEAT/HOT WATER", "board": 2,
        "query": "How many HEAT/HOT WATER service requests were recorded for Community Board 2 in November 2024?",
    },
]

street_specs = [
    {
        "id": "G06", "month": "2024-07", "complaint": "NOISE - STREET/SIDEWALK", "street": "BROADWAY",
        "query": "How many Noise - Street/Sidewalk service requests were recorded on Broadway in July 2024?",
    },
    {
        "id": "G07", "month": "2024-06", "complaint": "ILLEGAL PARKING", "street": "PARK AVENUE",
        "query": "How many Illegal Parking service requests were recorded on Park Avenue in June 2024?",
    },
    {
        "id": "G08", "month": "2024-04", "complaint": "NOISE - COMMERCIAL", "street": "3 AVENUE",
        "query": "How many Noise - Commercial service requests were recorded on 3 Avenue in April 2024?",
    },
    {
        "id": "G09", "month": "2024-08", "complaint": "NOISE - RESIDENTIAL", "street": "METROPOLITAN AVENUE",
        "query": "How many Noise - Residential service requests were recorded on Metropolitan Avenue in August 2024?",
    },
    {
        "id": "G10", "month": "2024-06", "complaint": "ILLEGAL PARKING", "street": "PRINCE STREET",
        "query": "How many Illegal Parking service requests were recorded on Prince Street in June 2024?",
    },
]

cb_counts = {s["id"]: Counter() for s in cb_specs}
street_counts = {s["id"]: Counter() for s in street_specs}
street_presence = {s["street"]: Counter() for s in street_specs}
selected_streets = set(street_presence)

source_rows = 0
retained_rows = 0
print("正在扫描：", source)
for chunk in pd.read_csv(source, usecols=usecols, chunksize=200_000, low_memory=False):
    source_rows += len(chunk)
    dt = pd.to_datetime(
        chunk["Created Date"], format="%m/%d/%Y %I:%M:%S %p", errors="coerce"
    )
    mask = (dt >= "2024-02-01") & (dt < "2024-12-01")
    chunk = chunk.loc[mask].copy()
    dt = dt.loc[mask]
    chunk["borough"] = clean(chunk["Borough"])
    chunk = chunk[chunk["borough"].isin(BOROUGHS)].copy()
    dt = dt.loc[chunk.index]
    retained_rows += len(chunk)
    chunk["month"] = dt.dt.to_period("M").astype(str)
    chunk["complaint"] = clean(chunk[complaint_col])
    chunk["community_board"] = clean(chunk["Community Board"])
    chunk["street"] = clean(chunk["Street Name"])

    present = chunk[chunk["street"].isin(selected_streets)]
    if len(present):
        x = present.groupby(["street", "borough"]).size()
        for (street, borough), n in x.items():
            street_presence[street][borough] += int(n)

    for spec in cb_specs:
        x = chunk[
            (chunk["month"] == spec["month"])
            & (chunk["complaint"] == spec["complaint"])
        ]
        if len(x):
            counts = x["community_board"].value_counts()
            for borough in BOROUGHS:
                cb_counts[spec["id"]][borough] += int(
                    counts.get(f"{spec['board']:02d} {borough}", 0)
                )

    for spec in street_specs:
        x = chunk[
            (chunk["month"] == spec["month"])
            & (chunk["complaint"] == spec["complaint"])
            & (chunk["street"] == spec["street"])
        ]
        if len(x):
            counts = x["borough"].value_counts()
            for borough, n in counts.items():
                street_counts[spec["id"]][borough] += int(n)

    print(f"已扫描 {source_rows:,} 行")

assert retained_rows == 2_853_404, f"有效行数异常：{retained_rows}"

expected_cb = {
    "G01": [293, 1081, 510, 1469, 526],
    "G02": [258, 561, 426, 371, 165],
    "G03": [111, 168, 23, 542, 67],
    "G04": [17, 137, 45, 152, 117],
    "G05": [666, 221, 433, 362, 47],
}
for qid, expected in expected_cb.items():
    actual = [cb_counts[qid][b] for b in BOROUGHS]
    assert actual == expected, f"{qid}答案异常：{actual} != {expected}"

expected_street_subsets = {
    "G06": {"BRONX": 27, "BROOKLYN": 20, "MANHATTAN": 367, "QUEENS": 10, "STATEN ISLAND": 12},
    "G07": {"BRONX": 31, "BROOKLYN": 54, "MANHATTAN": 61},
    "G08": {"BRONX": 80, "BROOKLYN": 29, "MANHATTAN": 31},
    "G09": {"BRONX": 55, "BROOKLYN": 21, "QUEENS": 20},
    "G10": {"BROOKLYN": 144, "MANHATTAN": 53, "QUEENS": 18},
}
for qid, expected in expected_street_subsets.items():
    for borough, value in expected.items():
        assert street_counts[qid][borough] == value, (
            f"{qid}/{borough}答案异常：{street_counts[qid][borough]} != {value}"
        )


def md_table(rows):
    return pd.DataFrame(rows).to_markdown(index=False)


standard = []
model_inputs = []
condition_inputs = []
review_rows = []


def add_record(spec, family, boroughs, counts, label):
    rows = [{label: DISPLAY[b].replace("the ", "").title(), "Request Count": int(counts[b])} for b in boroughs]
    context = md_table(rows)
    pairs = []
    for i, borough in enumerate(boroughs, 1):
        if family == "community_board_borough_omission":
            condition = (
                f"Interpret 'Community Board {spec['board']}' as "
                f"{DISPLAY[borough].replace('the ', '').title()} Community Board {spec['board']}."
            )
        else:
            condition = (
                f"Interpret '{spec['street'].title()}' as the street located in {DISPLAY[borough]}."
            )
        pair = {
            "condition_id": f"{spec['id']}_C{i}",
            "condition": condition,
            "answer": str(int(counts[borough])),
            "answer_numeric": int(counts[borough]),
        }
        pairs.append(pair)
        condition_inputs.append({
            "id": pair["condition_id"],
            "query_id": spec["id"],
            "dataset": "NYC311",
            "ambiguity_dimension": "Geography",
            "query": spec["query"],
            "context": context,
            "condition": condition,
        })
        review_rows.append({
            "query_id": spec["id"],
            "family": family,
            "query": spec["query"],
            "condition": condition,
            "answer": int(counts[borough]),
            "query_natural": "",
            "genuine_geography_ambiguity": "",
            "dimension_correct": "",
            "condition_valid": "",
            "answer_correct": "",
            "notes": "",
        })
    record = {
        "id": spec["id"],
        "dataset": "NYC311",
        "ambiguity_dimension": "Geography",
        "ambiguity_family": family,
        "query": spec["query"],
        "context": context,
        "condition_answer_pairs": pairs,
        "source_period": "2024-02-01 inclusive to 2024-12-01 exclusive",
    }
    standard.append(record)
    model_inputs.append({
        "id": spec["id"], "dataset": "NYC311",
        "query": spec["query"], "context": context,
    })


for spec in cb_specs:
    add_record(
        spec, "community_board_borough_omission", BOROUGHS,
        cb_counts[spec["id"]], "Community Board Location",
    )

for spec in street_specs:
    supported = [b for b in BOROUGHS if street_presence[spec["street"]][b] > 0]
    assert len(supported) >= 2, f"{spec['street']}没有跨Borough"
    add_record(
        spec, "street_name_borough_omission", supported,
        street_counts[spec["id"]], "Street Location",
    )


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


write_jsonl(out_dir / "nyc311_geography_pilot_v2_standard.jsonl", standard)
write_jsonl(out_dir / "nyc311_geography_pilot_v2_model_inputs.jsonl", model_inputs)
write_jsonl(out_dir / "nyc311_geography_pilot_v2_condition_inputs.jsonl", condition_inputs)
pd.DataFrame(review_rows).to_csv(out_dir / "nyc311_geography_pilot_v2_manual_review.csv", index=False)

summary = {
    "source": str(source),
    "query_count": len(standard),
    "condition_answer_pair_count": len(condition_inputs),
    "families": {
        "community_board_borough_omission": 5,
        "street_name_borough_omission": 5,
    },
    "source_rows_scanned": source_rows,
    "valid_period_and_borough_rows": retained_rows,
    "validation": "All reviewed Community Board answers and all profiled street-answer subsets matched exactly.",
    "design_decision": "New York scope, park-name, Park Borough, and locality mechanisms were not retained.",
}
with open(out_dir / "summary.json", "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)

zip_path = shutil.make_archive(str(out_dir), "zip", root_dir=out_dir)
print("\n========== 完成 ==========")
print(json.dumps(summary, ensure_ascii=False, indent=2))
print("输出文件夹：", out_dir)
print("ZIP：", zip_path)

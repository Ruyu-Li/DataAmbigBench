from google.colab import drive
from pathlib import Path
from datetime import datetime
import json
import shutil

import pandas as pd


drive.mount("/content/drive")

ROOT = Path("/content/drive/MyDrive")
candidates = list(ROOT.rglob("NYC311_2024_Feb_Nov.parquet"))
assert candidates, "找不到 NYC311_2024_Feb_Nov.parquet"
source = max(candidates, key=lambda p: p.stat().st_mtime)

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
out_dir = ROOT / "NYC311_2024" / f"Geography_Pilot10_{stamp}"
out_dir.mkdir(parents=True, exist_ok=False)

print("读取：", source)
df = pd.read_parquet(
    source,
    columns=["Created Date", "Complaint Type", "Borough", "Community Board"],
)
df["Created Date"] = pd.to_datetime(df["Created Date"], errors="raise")
df["month"] = df["Created Date"].dt.to_period("M").astype(str)
df["date"] = df["Created Date"].dt.normalize()
df["weekday"] = df["Created Date"].dt.dayofweek < 5

BOROUGHS = ["BRONX", "BROOKLYN", "MANHATTAN", "QUEENS", "STATEN ISLAND"]
DISPLAY = {
    "BRONX": "Bronx",
    "BROOKLYN": "Brooklyn",
    "MANHATTAN": "Manhattan",
    "QUEENS": "Queens",
    "STATEN ISLAND": "Staten Island",
}


def markdown_table(frame):
    return frame.to_markdown(index=False)


def borough_counts(month, complaint, mode="total"):
    x = df[(df["month"] == month) & (df["Complaint Type"] == complaint)].copy()
    if mode == "total":
        s = x.groupby("Borough").size()
        table = pd.DataFrame({
            "Borough": [DISPLAY[b] for b in BOROUGHS],
            "Request Count": [int(s.get(b, 0)) for b in BOROUGHS],
        })
        answers = dict(zip(BOROUGHS, table["Request Count"].astype(int)))
    elif mode == "daily_max":
        daily = x.groupby(["date", "Borough"]).size().rename("count").reset_index()
        s = daily.groupby("Borough")["count"].max()
        table = pd.DataFrame({
            "Borough": [DISPLAY[b] for b in BOROUGHS],
            "Highest Daily Request Count": [int(s.get(b, 0)) for b in BOROUGHS],
        })
        answers = dict(zip(BOROUGHS, table["Highest Daily Request Count"].astype(int)))
    elif mode == "weekday_total":
        s = x.groupby(["Borough", "weekday"]).size()
        table = pd.DataFrame({
            "Borough": [DISPLAY[b] for b in BOROUGHS],
            "Monday-Friday": [int(s.get((b, True), 0)) for b in BOROUGHS],
            "Saturday-Sunday": [int(s.get((b, False), 0)) for b in BOROUGHS],
        })
        answers = dict(zip(BOROUGHS, table["Monday-Friday"].astype(int)))
    else:
        raise ValueError(mode)
    return table, answers


def community_board_counts(month, complaint, board_number):
    x = df[(df["month"] == month) & (df["Complaint Type"] == complaint)].copy()
    codes = {b: f"{board_number:02d} {b}" for b in BOROUGHS}
    s = x.groupby("Community Board").size()
    table = pd.DataFrame({
        "Community Board": [f"{DISPLAY[b]} Community Board {board_number}" for b in BOROUGHS],
        "Request Count": [int(s.get(codes[b], 0)) for b in BOROUGHS],
    })
    answers = dict(zip(BOROUGHS, table["Request Count"].astype(int)))
    return table, answers


specs = [
    ("G01", "borough_scope_omission", "How many HEAT/HOT WATER service requests were created in February 2024?", "2024-02", "HEAT/HOT WATER", "total", None),
    ("G02", "borough_scope_omission", "How many Illegal Parking service requests were created in April 2024?", "2024-04", "Illegal Parking", "total", None),
    ("G03", "borough_scope_omission", "What was the highest daily number of Noise - Residential service requests created in June 2024?", "2024-06", "Noise - Residential", "daily_max", None),
    ("G04", "borough_scope_omission", "How many Blocked Driveway service requests were created on weekdays (Monday through Friday) in August 2024?", "2024-08", "Blocked Driveway", "weekday_total", None),
    ("G05", "borough_scope_omission", "How many Water System service requests were created in October 2024?", "2024-10", "Water System", "total", None),
    ("G06", "community_board_borough_omission", "How many Illegal Parking service requests were created in Community Board 1 in March 2024?", "2024-03", "Illegal Parking", "community_board", 1),
    ("G07", "community_board_borough_omission", "How many Noise - Residential service requests were created in Community Board 2 in May 2024?", "2024-05", "Noise - Residential", "community_board", 2),
    ("G08", "community_board_borough_omission", "How many Blocked Driveway service requests were created in Community Board 3 in July 2024?", "2024-07", "Blocked Driveway", "community_board", 3),
    ("G09", "community_board_borough_omission", "How many Street Condition service requests were created in Community Board 1 in September 2024?", "2024-09", "Street Condition", "community_board", 1),
    ("G10", "community_board_borough_omission", "How many HEAT/HOT WATER service requests were created in Community Board 2 in November 2024?", "2024-11", "HEAT/HOT WATER", "community_board", 2),
]

expected = {
    "G01": [11656, 7682, 6408, 4258, 312],
    "G02": [6560, 15569, 6770, 12635, 1180],
    "G03": [1124, 656, 282, 739, 114],
    "G04": [1390, 3160, 279, 3746, 226],
    "G05": [696, 1127, 645, 1562, 422],
    "G06": [293, 1081, 510, 1469, 526],
    "G07": [258, 561, 426, 371, 165],
    "G08": [111, 168, 23, 542, 67],
    "G09": [17, 137, 45, 152, 117],
    "G10": [666, 221, 433, 362, 47],
}

standard = []
model_inputs = []
condition_inputs = []
review_rows = []

for qid, family, query, month, complaint, mode, board in specs:
    if mode == "community_board":
        table, answers = community_board_counts(month, complaint, board)
    else:
        table, answers = borough_counts(month, complaint, mode)

    actual = [int(answers[b]) for b in BOROUGHS]
    assert actual == expected[qid], f"{qid} 数字不一致：{actual} != {expected[qid]}"

    context = markdown_table(table)
    pairs = []
    for idx, borough in enumerate(BOROUGHS, 1):
        if family == "borough_scope_omission":
            condition = f"Restrict the geographic scope to {DISPLAY[borough]}."
        else:
            condition = f"Interpret 'Community Board {board}' as {DISPLAY[borough]} Community Board {board}."
        pair = {
            "condition_id": f"{qid}_C{idx}",
            "condition": condition,
            "answer": str(int(answers[borough])),
            "answer_numeric": int(answers[borough]),
        }
        pairs.append(pair)
        condition_inputs.append({
            "id": pair["condition_id"],
            "query_id": qid,
            "dataset": "NYC311",
            "ambiguity_dimension": "Geography",
            "query": query,
            "context": context,
            "condition": condition,
        })
        review_rows.append({
            "query_id": qid,
            "family": family,
            "query": query,
            "condition": condition,
            "answer": int(answers[borough]),
            "query_natural": "",
            "genuine_geography_ambiguity": "",
            "condition_valid": "",
            "answer_correct": "",
            "notes": "",
        })

    record = {
        "id": qid,
        "dataset": "NYC311",
        "ambiguity_dimension": "Geography",
        "ambiguity_family": family,
        "query": query,
        "context": context,
        "condition_answer_pairs": pairs,
        "source_period": "2024-02-01 inclusive to 2024-12-01 exclusive",
    }
    standard.append(record)
    model_inputs.append({
        "id": qid,
        "dataset": "NYC311",
        "query": query,
        "context": context,
    })


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


write_jsonl(out_dir / "nyc311_geography_pilot10_standard.jsonl", standard)
write_jsonl(out_dir / "nyc311_geography_pilot10_model_inputs.jsonl", model_inputs)
write_jsonl(out_dir / "nyc311_geography_pilot10_condition_inputs.jsonl", condition_inputs)
pd.DataFrame(review_rows).to_csv(out_dir / "nyc311_geography_pilot10_manual_review.csv", index=False)

summary = {
    "source": str(source),
    "query_count": len(standard),
    "condition_answer_pair_count": len(condition_inputs),
    "ambiguity_dimension": "Geography",
    "families": {
        "borough_scope_omission": 5,
        "community_board_borough_omission": 5,
    },
    "validation": "All 50 answers matched the independently reviewed expected values.",
    "design_note": "The first family is controlled scope omission and is weaker; the community-board family is genuine repeated-number geographic ambiguity.",
}
with open(out_dir / "summary.json", "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)

zip_path = shutil.make_archive(str(out_dir), "zip", root_dir=out_dir)

print("\n========== 完成 ==========")
print("输出文件夹：", out_dir)
print("ZIP：", zip_path)
print("Queries：", len(standard))
print("Condition-answer pairs：", len(condition_inputs))
print("所有 50 个答案均通过断言检查。")

#!/usr/bin/env python3
"""Concurrent, resumable model runners for the frozen 200-query scalability inputs.

Each worker streams the prepared file and appends only to its own model shard.
The original predictions.jsonl is read only. Never run alongside scale_study.py run.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import statistics
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path


MODELS = ("gpt-4.1-mini", "claude-haiku-5-5", "gemini-3.1-flash-lite")
INTERVAL = {"gpt-4.1-mini": 1.0, "claude-haiku-5-5": 1.0,
            "gemini-3.1-flash-lite": 6.0}


def iter_rows(path):
    if path.exists():
        with path.open(encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    yield json.loads(line)


def shard(base, model):
    return base / f"predictions_parallel_{model}.jsonl"


def completed(base, S):
    done = set()
    for path in [base / "predictions.jsonl"] + [shard(base, m) for m in MODELS]:
        for row in iter_rows(path):
            if S.valid_completion(row):
                done.add((row["model"], row["dataset"], row["id"]))
    return done


def worker(base, model, catalog, S, done, limit, output_cap, input_gate, timeout):
    sent, failed, invalid, blocked = 0, 0, 0, 0
    consecutive_429 = 0
    path = shard(base, model)
    with path.open("a", encoding="utf-8") as out:
        for sample in iter_rows(base / "prepared_samples.jsonl"):
            key = model, sample["dataset"], sample["id"]
            if key in done or sent >= limit:
                continue
            system, prompt, default_cap = S.lab.prompt_for("e2e", sample, None)
            cap = output_cap or default_cap
            rough = (len(system) + len(prompt)) // 3
            identity = {"model": model, "dataset": sample["dataset"], "id": sample["id"],
                        "base_query_id": sample["base_query_id"],
                        "nominal_rows": sample["nominal_rows"],
                        "scale_rows": sample["scale_rows"],
                        "rough_input_tokens": rough}
            if rough + cap > input_gate:
                blocked += 1
                row = {**identity, "status": "blocked_context_estimate"}
            else:
                sent += 1
                try:
                    result = S.providers.complete(catalog[model], system, prompt, cap, timeout=timeout)
                    parsed, err = S.lab.paper.E.parse_json_output(result["raw"])
                    if not isinstance(parsed, dict):
                        parsed, err = None, err or "top-level JSON is not an object"
                    row = {**identity, "status": "ok", "max_output_tokens": cap,
                           "parse_error": err, "parsed": parsed,
                           "scores": S.lab.score("e2e", sample, parsed, sample["dataset"]),
                           "scores_dimension_aware": S.dimension_aware_score(
                               sample, parsed, sample["dataset"]),
                           "scores_contextual_alias": S.sf_contextual_alias_score(
                               sample, parsed) if sample["dataset"] == "sf311" else None,
                           **result}
                    invalid += not S.valid_completion(row)
                    consecutive_429 = 0
                except Exception as exc:
                    failed += 1
                    row = {**identity, "status": "failed", "error": str(exc)[:500]}
                    consecutive_429 = consecutive_429 + 1 if "429" in str(exc) else 0
            out.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
            out.flush()
            if sent and (sent % 20 == 0 or sent == limit):
                print(f"{model}: {sent}/{limit} new calls; API failures={failed}, "
                      f"invalid JSON={invalid}, local blocks={blocked}", flush=True)
            if consecutive_429 >= 3:
                print(f"STOP {model}: three consecutive HTTP 429 errors; "
                      "lower its rate or check the project quota before resuming", flush=True)
                break
            if sent and INTERVAL[model]:
                time.sleep(INTERVAL[model])
    print(f"DONE {model}: calls={sent}, failed={failed}, invalid={invalid}, blocked={blocked}", flush=True)
    return sent, failed, invalid, blocked


def report(base, S):
    best = {}
    attempts = Counter()
    for path in [base / "predictions.jsonl"] + [shard(base, m) for m in MODELS]:
        for row in iter_rows(path):
            key = row["model"], row["dataset"], row["id"]
            attempts[key] += 1
            if key not in best or S.valid_completion(row):
                best[key] = row
    valid = [r for r in best.values() if S.valid_completion(r)]
    counts = Counter((r["model"], r["dataset"], r["nominal_rows"]) for r in valid)
    print(f"Valid unique requests: {len(valid)}/3600; remaining: {3600-len(valid)}")
    groups = defaultdict(list)
    for row in valid:
        groups[(row["model"], row["dataset"], row["nominal_rows"])].append(row)
    summary = []
    for model in MODELS:
        for ds, sizes in (("retail", (1000, 5000, 8000)),
                          ("sf311", (500, 1500, 3000))):
            for n in sizes:
                rows = groups[model, ds, n]
                times = sorted(r["elapsed_ms"] / 1000 for r in rows)
                quality = [r["scores"]["answer_relaxed_norm"] for r in rows]
                record = {"model": model, "dataset": ds, "nominal_rows": n,
                          "valid": len(rows), "expected": 200,
                          "e2e_accuracy": round(100 * statistics.mean(quality), 2) if quality else "",
                          "latency_mean_s": round(statistics.mean(times), 2) if times else "",
                          "input_tokens": sum((r.get("usage") or {}).get("prompt_tokens") or 0 for r in rows),
                          "output_tokens": sum((r.get("usage") or {}).get("completion_tokens") or 0 for r in rows)}
                summary.append(record)
                print(model, ds, n, f"{len(rows)}/200")
    with (base / "parallel_completion.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, summary[0]); w.writeheader(); w.writerows(summary)
    return len(valid)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=("plan", "run", "summary"))
    ap.add_argument("--project", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--max-calls-per-model", type=int, default=1140)
    ap.add_argument("--max-output-tokens", type=int, default=8000)
    ap.add_argument("--max-rough-input-tokens", type=int, default=800000)
    ap.add_argument("--timeout", type=float, default=300)
    args = ap.parse_args()
    sys.path.insert(0, str(args.project.resolve()))
    import scale_study as S
    base = args.out.resolve()
    audit = json.loads((base / "audit.json").read_text(encoding="utf-8"))
    if S.checksum(base / "prepared_samples.jsonl") != audit["prepared_sha256"]:
        raise ValueError("Prepared inputs differ from audit; no calls made")
    if audit.get("reused_valid_model_requests") != 180:
        raise ValueError("Expected frozen 10-query run with 180 valid predictions")
    if args.action == "summary":
        report(base, S); return
    done = completed(base, S)
    print("Existing valid:", len(done), "Pending:", 3600 - len(done), flush=True)
    if args.action == "plan":
        for m in MODELS:
            print(m, "completed", sum(x[0] == m for x in done),
                  "pending", 1200 - sum(x[0] == m for x in done))
        return
    catalog = {m["id"]: m for m in json.loads((args.project / "models.json").read_text())}
    if not all(os.environ.get(catalog[m]["key_env"]) for m in MODELS):
        raise ValueError("API key missing; no calls made")
    # Separate output shards are the only files written by workers. Never run
    # this alongside another runner in the same output directory.
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(worker, base, m, catalog, S, done,
                               args.max_calls_per_model, args.max_output_tokens,
                               args.max_rough_input_tokens, args.timeout) for m in MODELS]
        for f in futures: f.result()
    report(base, S)


if __name__ == "__main__":
    main()

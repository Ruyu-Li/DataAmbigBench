#!/usr/bin/env python3
"""Concurrent, resumable model runners for the frozen 200-query scalability inputs.

Each worker streams the prepared file and appends only to its own model shard.
The original predictions.jsonl is read only. Never run alongside scale_study.py run.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import statistics
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from pathlib import Path


MODELS = ("gpt-4.1-mini", "claude-haiku-5-5", "gemini-3.1-flash-lite")
INTERVAL = {"gpt-4.1-mini": 1.0, "claude-haiku-5-5": 1.0,
            "gemini-3.1-flash-lite": 6.0}


def iter_rows(path):
    if path.exists():
        with path.open(encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    yield json.loads(line)


def shard(base, model):
    return base / f"predictions_parallel_{model}.jsonl"


def completed(base, S):
    done = set()
    for path in [base / "predictions.jsonl"] + [shard(base, m) for m in MODELS]:
        for row in iter_rows(path):
            if S.valid_completion(row):
                done.add((row["model"], row["dataset"], row["id"]))
    return done


def fetch(S, config, sample, identity, system, prompt, cap, timeout):
    try:
        result = S.providers.complete(config, system, prompt, cap, timeout=timeout)
    except Exception as exc:
        return ({**identity, "status": "failed", "error": str(exc)[:500]},
                getattr(exc, "code", None))

    parsed, err = S.lab.paper.E.parse_json_output(result["raw"])
    if not isinstance(parsed, dict):
        parsed, err = None, err or "top-level JSON is not an object"
    dataset = sample["dataset"]
    row = {**identity, "status": "ok", "max_output_tokens": cap,
           "parse_error": err, "parsed": parsed,
           "scores": S.lab.score("e2e", sample, parsed, dataset),
           "scores_dimension_aware": S.dimension_aware_score(sample, parsed, dataset),
           "scores_contextual_alias": S.sf_contextual_alias_score(sample, parsed)
           if dataset == "sf311" else None, **result}
    return row, None


def worker(base, model, catalog, S, done, limit, output_cap, input_gate, timeout, workers):
    sent = valid = failed = invalid = blocked = rate_errors = 0
    started = time.monotonic()
    next_send = started
    finished_input = stopped = False
    pending = set()
    samples = (s for s in iter_rows(base / "prepared_samples.jsonl")
               if (model, s["dataset"], s["id"]) not in done)
    print(f"START {model}: concurrency={workers}, request cap={limit}", flush=True)
    with shard(base, model).open("a", encoding="utf-8") as out, \
            ThreadPoolExecutor(max_workers=workers) as pool:

        def save(row):
            out.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
            out.flush()

        while True:
            can_send = not stopped and not finished_input and sent < limit
            can_send = can_send and len(pending) < workers
            delay = max(0, next_send - time.monotonic())
            ready = {f for f in pending if f.done()}
            if not ready and can_send and delay == 0:
                sample = next(samples, None)
                if sample is None:
                    finished_input = True
                    continue
                system, prompt, default_cap = S.lab.prompt_for("e2e", sample, None)
                cap = output_cap or default_cap
                rough = (len(system) + len(prompt)) // 3
                identity = {"model": model, "dataset": sample["dataset"], "id": sample["id"],
                            "base_query_id": sample["base_query_id"],
                            "nominal_rows": sample["nominal_rows"],
                            "scale_rows": sample["scale_rows"], "rough_input_tokens": rough}
                if rough + cap > input_gate:
                    blocked += 1
                    save({**identity, "status": "blocked_context_estimate"})
                    continue
                pending.add(pool.submit(fetch, S, catalog[model], sample, identity,
                                        system, prompt, cap, timeout))
                sent += 1
                next_send = time.monotonic() + INTERVAL[model]
                continue
            if not ready:
                if pending:
                    ready, _ = wait(pending, timeout=delay if can_send else None,
                                    return_when=FIRST_COMPLETED)
                elif can_send:
                    time.sleep(delay)
                    continue
                else:
                    break
            for future in ready:
                pending.remove(future)
                row, code = future.result()
                save(row)
                if row["status"] == "failed":
                    failed += 1
                    error = row["error"].lower()
                    billing = code == 402 or any(word in error for word in (
                        "credit balance is too low", "insufficient_quota",
                        "billing quota", "payment required"))
                    if billing or code in (401, 403):
                        if not stopped:
                            print(f"STOP {model}: billing or API key error; saving in-flight results",
                                  flush=True)
                        stopped = True
                    elif code == 429 and not stopped:
                        rate_errors += 1
                        workers = max(1, workers - 1)
                        next_send = max(next_send, time.monotonic() + 20)
                        stopped = rate_errors >= 3
                        state = "stopping" if stopped else f"pausing 20s; concurrency={workers}"
                        print(f"{model}: HTTP 429; {state}", flush=True)
                elif S.valid_completion(row):
                    valid += 1
                else:
                    invalid += 1
                count = valid + failed + invalid
                if count % 10 == 0:
                    elapsed = max(time.monotonic() - started, 0.01)
                    print(f"{model}: valid={valid}, failures={failed}, invalid={invalid}, "
                          f"rate={60 * valid / elapsed:.1f} valid/min", flush=True)
    elapsed = max(time.monotonic() - started, 0.01)
    print(f"DONE {model}: calls={sent}, valid={valid}, failed={failed}, invalid={invalid}, "
          f"blocked={blocked}, rate={60 * valid / elapsed:.1f} valid/min", flush=True)


def report(base, S):
    best = {}
    attempts = Counter()
    for path in [base / "predictions.jsonl"] + [shard(base, m) for m in MODELS]:
        for row in iter_rows(path):
            key = row["model"], row["dataset"], row["id"]
            attempts[key] += 1
            if key not in best or S.valid_completion(row):
                best[key] = row
    valid = [r for r in best.values() if S.valid_completion(r)]
    counts = Counter((r["model"], r["dataset"], r["nominal_rows"]) for r in valid)
    print(f"Valid unique requests: {len(valid)}/3600; remaining: {3600-len(valid)}")
    groups = defaultdict(list)
    for row in valid:
        groups[(row["model"], row["dataset"], row["nominal_rows"])].append(row)
    summary = []
    for model in MODELS:
        for ds, sizes in (("retail", (1000, 5000, 8000)),
                          ("sf311", (500, 1500, 3000))):
            for n in sizes:
                rows = groups[model, ds, n]
                times = sorted(r["elapsed_ms"] / 1000 for r in rows)
                quality = [r["scores"]["answer_relaxed_norm"] for r in rows]
                record = {"model": model, "dataset": ds, "nominal_rows": n,
                          "valid": len(rows), "expected": 200,
                          "e2e_accuracy": round(100 * statistics.mean(quality), 2) if quality else "",
                          "latency_mean_s": round(statistics.mean(times), 2) if times else "",
                          "input_tokens": sum((r.get("usage") or {}).get("prompt_tokens") or 0 for r in rows),
                          "output_tokens": sum((r.get("usage") or {}).get("completion_tokens") or 0 for r in rows)}
                summary.append(record)
                print(model, ds, n, f"{len(rows)}/200")
    with (base / "parallel_completion.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, summary[0]); w.writeheader(); w.writerows(summary)
    return len(valid)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=("plan", "run", "summary"))
    ap.add_argument("--project", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--max-calls-per-model", type=int, default=1140)
    ap.add_argument("--models", nargs="+", choices=MODELS, default=list(MODELS),
                    help="Only run selected model(s); plan/summary still inspect all shards")
    ap.add_argument("--max-output-tokens", type=int, default=8000)
    ap.add_argument("--max-rough-input-tokens", type=int, default=800000)
    ap.add_argument("--timeout", type=float, default=300)
    ap.add_argument("--claude-workers", type=int, default=5, choices=range(1, 6))
    ap.add_argument("--gpt-workers", type=int, default=2, choices=range(1, 3))
    args = ap.parse_args()
    args.models = list(dict.fromkeys(args.models))
    workers = {"claude-haiku-5-5": args.claude_workers,
               "gpt-4.1-mini": args.gpt_workers, "gemini-3.1-flash-lite": 1}
    sys.path.insert(0, str(args.project.resolve()))
    import scale_study as S
    base = args.out.resolve()
    audit = json.loads((base / "audit.json").read_text(encoding="utf-8"))
    if S.checksum(base / "prepared_samples.jsonl") != audit["prepared_sha256"]:
        raise ValueError("Prepared inputs differ from audit; no calls made")
    if audit.get("reused_valid_model_requests") != 180:
        raise ValueError("Expected frozen 10-query run with 180 valid predictions")
    if args.action == "summary":
        report(base, S); return
    done = completed(base, S)
    print("Existing valid:", len(done), "Pending:", 3600 - len(done), flush=True)
    if args.action == "plan":
        for m in MODELS:
            print(m, "completed", sum(x[0] == m for x in done),
                  "pending", 1200 - sum(x[0] == m for x in done))
        return
    catalog = {m["id"]: m for m in json.loads((args.project / "models.json").read_text())}
    if not all(os.environ.get(catalog[m]["key_env"]) for m in args.models):
        raise ValueError("API key missing; no calls made")
    # Separate output shards are the only files written by workers. Never run
    # this alongside another runner in the same output directory.
    with ThreadPoolExecutor(max_workers=len(args.models)) as pool:
        futures = [pool.submit(worker, base, m, catalog, S, done,
                               args.max_calls_per_model, args.max_output_tokens,
                               args.max_rough_input_tokens, args.timeout, workers[m]) for m in args.models]
        for f in futures: f.result()
    report(base, S)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Two-dataset, asymmetric-scale, paper-prompt scalability study (Python 3.10+)."""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import os
import random
import re
import statistics
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "retail"))
import build_online_retail_scalability as retail_gold
import lab
import providers

RETAIL_SIZES = (1000, 5000, 15000)
SF_SIZES = (500, 1500, 3000)
RETAIL_SAMPLING_SEED = 20261115  # chosen before any model runs to limit complete-invoice row overshoot
DEFAULT_MODELS = ("gpt-4.1-mini", "claude-haiku-5-5", "gemini-3.1-flash-lite")
SF_COLS = ("CASE ID", "STATUS", "WORK STATUS", "CATEGORY", "NEIGHBORHOOD", "SUPERVISOR DISTRICT")


def read_jsonl(p):
    with open(p, encoding="utf-8-sig") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_jsonl(p, rows):
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")


def checksum(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def retail_samples():
    base = HERE / "retail"
    manifest = read_jsonl(base / "scalability_query_manifest.jsonl")
    entries = {r["base_query_id"]: r for r in manifest if r["nominal_rows"] == 1000}
    ids = sorted(entries)
    # The prior 20k source is a nested, country-balanced set of real complete invoices.
    # Re-sample complete invoices at 1000/5000/15000, preserving nested invoices.
    full = pd.read_csv(base / "online_retail_unit_n20000.csv",
                       dtype={"Invoice": str, "StockCode": str, "CustomerID": str})
    full["InvoiceDate"] = pd.to_datetime(full["InvoiceDate"])
    saved_sizes = retail_gold.SIZES
    try:
        retail_gold.SIZES = list(RETAIL_SIZES)
        frames = retail_gold.nested_complete_invoice_tables(full, RETAIL_SAMPLING_SEED)
    finally:
        retail_gold.SIZES = saved_sizes
    for size, frame in frames.items():
        frame.to_csv(base / f"online_retail_unit_n{size}.csv", index=False)
        if not (size <= len(frame) < size + 300):
            raise ValueError(f"Retail complete-invoice overshoot is excessive: {size} -> {len(frame)}")

    # Fixed query IDs covering the original eight families; require a valid gold
    # for every interpretation at every scale, without selecting on model outputs.
    groups = defaultdict(list)
    for qid in ids:
        old = entries[qid]
        try:
            for size in RETAIL_SIZES:
                for cond in retail_gold.CONDITIONS:
                    retail_gold.calculate_answer(frames[size], old, cond)
        except (ValueError, KeyError, IndexError, TypeError):
            continue
        groups[old["metadata"]["family"]].append(qid)
    selected = []
    for group in sorted(groups):
        selected.append(sorted(groups[group])[0])
    if len(selected) != 8:
        raise ValueError(f"Only {len(selected)} valid Retail query families at 1000 rows")
    for qid in sorted(qid for values in groups.values() for qid in values):
        if len(selected) == 10:
            break
        if qid not in selected:
            selected.append(qid)
    if len(selected) != 10:
        raise ValueError("Retail manifest needs at least 10 fixed queries")

    samples = []
    for size in RETAIL_SIZES:
        frame = frames[size]
        table = retail_gold.json_table(frame, f"Online Retail II; actual rows={len(frame)}; complete invoices")
        # source_sheet is workbook provenance, not a transaction attribute. Its
        # labels look like alternate year definitions and bias the Unit task.
        table["header"] = [c for c in table["header"] if c != "source_sheet"]
        for row in table["rows"]:
            row.pop("source_sheet", None)
        for qid in selected:
            old = entries[qid]
            gold = dict(old["gold"])
            answers = [retail_gold.calculate_answer(frame, old, cond) for cond in retail_gold.CONDITIONS]
            gold["condition_answer_pairs"] = [{"conditions": {"Unit": a["condition"]},
                "answer": a["answer"]} for a in answers]
            samples.append({"dataset": "retail", "id": f"{qid}__n{size}", "base_query_id": qid,
                "query": old["query"], "scale_rows": len(frame), "nominal_rows": size,
                "table": table, "gold": gold, "source_file": str(base / f"online_retail_unit_n{size}.csv")})
    return samples


def sf_frame(path):
    if path.suffix.lower() == ".parquet":
        df = pd.read_parquet(path)
    elif path.suffix.lower() == ".csv":
        df = pd.read_csv(path, dtype=str, low_memory=False, encoding="utf-8-sig")
    else:
        raise ValueError("SF311 source must be a raw CSV or Parquet with individual CASE ID records")
    lookup = {str(c).upper().replace("_", " ").strip(): c for c in df.columns}
    missing = [c for c in SF_COLS if c not in lookup]
    if missing:
        raise ValueError(f"SF311 raw source missing {missing}. Available columns: {list(df.columns)}")
    df = df.rename(columns={lookup[c]: c for c in SF_COLS})[list(SF_COLS)].copy()
    for c in SF_COLS:
        df[c] = df[c].fillna("").astype(str).str.strip()
    df["STATUS"] = df["STATUS"].str.lower()
    df["WORK STATUS"] = df["WORK STATUS"].str.lower()
    df["NEIGHBORHOOD"] = df["NEIGHBORHOOD"].str.upper()
    df["SUPERVISOR DISTRICT"] = df["SUPERVISOR DISTRICT"].str.replace(r"\.0$", "", regex=True)
    df = df[df["CASE ID"].ne("") & df["STATUS"].eq("open") &
            df["WORK STATUS"].isin(["open", "sent", "accepted", "in progress", "on hold"])].copy()
    clashes = df.groupby("CASE ID")[list(SF_COLS)[1:]].nunique().gt(1).any(axis=1)
    df = df[~df["CASE ID"].isin(clashes[clashes].index)].drop_duplicates("CASE ID")
    if len(df) < max(SF_SIZES):
        raise ValueError(f"Only {len(df)} eligible distinct SF311 cases; {max(SF_SIZES)} required")
    return df


def sf_answer(frame, condition):
    w = frame["WORK STATUS"]
    if condition == "not closed":
        return int(frame["STATUS"].ne("closed").sum())
    if condition == "work status = open":
        return int(w.eq("open").sum())
    if condition == "work status = in progress":
        return int(w.eq("in progress").sum())
    if condition == "work status in {accepted, in progress}":
        return int(w.isin(["accepted", "in progress"]).sum())
    if condition == "work status in {open, sent, accepted, in progress}":
        return int(w.isin(["open", "sent", "accepted", "in progress"]).sum())
    raise ValueError(f"Unrecognized SF311 condition: {condition}")


def sf_samples(source):
    df = sf_frame(source)
    # One citywide nested sample, fixed across all queries; the same CASE IDs persist at larger sizes.
    df = df.sample(frac=1, random_state=20261110).reset_index(drop=True)
    levels = {size: df.iloc[:size].copy() for size in SF_SIZES}
    candidates = read_jsonl(HERE / "reference/sf311.jsonl")
    groups = defaultdict(list)
    for q in candidates:
        meta = q["metadata"]["original_record"]
        if meta.get("operation") != "count":
            continue
        scope = meta.get("scope") or {}
        scoped = levels[min(SF_SIZES)]
        for col, value in scope.items():
            if col not in SF_COLS:
                raise ValueError(f"Unsupported SF311 scope field {col!r}")
            scoped = scoped[scoped[col].str.casefold() == str(value).casefold()]
        if len(scoped) >= 20:
            pair_answers = [sf_answer(scoped, p["conditions"]["Event Status"])
                            for p in q["gold"]["condition_answer_pairs"]]
            if len(pair_answers) == 2 and pair_answers[0] > pair_answers[1] > 0:
                groups[meta["family"]].append((len(scoped), q))
    chosen = []
    for family, quota in (("pending", 4), ("underway", 4), ("active", 2)):
        ranked = sorted(groups[family], key=lambda x: (-x[0], x[1]["id"]))
        if len(ranked) < quota:
            raise ValueError(f"Only {len(ranked)} eligible {family} queries; need {quota}")
        chosen.extend(q for _, q in ranked[:quota])
    out = []
    for size in SF_SIZES:
        frame = levels[size]
        for q in chosen:
            scope = q["metadata"]["original_record"].get("scope") or {}
            scoped = frame
            for col, value in scope.items():
                scoped = scoped[scoped[col].str.casefold() == str(value).casefold()]
            # Keep all sampled records in the model input, so actual input scale is truthful.
            data = frame[list(SF_COLS)].astype(str)
            lines = ["Scope: supplied rows are a nested sample of distinct SF311 cases. Count CASE ID once.",
                     f"Actual input rows: {len(frame)}. Case statuses are recorded values, not citywide totals.",
                     "", "| " + " | ".join(SF_COLS) + " |", "|" + "---|" * len(SF_COLS)]
            lines += ["| " + " | ".join(str(v).replace("|", "/") for v in vals) + " |"
                      for vals in data.itertuples(index=False, name=None)]
            pairs = [{"conditions": p["conditions"], "answer": sf_answer(scoped, p["conditions"]["Event Status"])}
                     for p in q["gold"]["condition_answer_pairs"]]
            out.append({"dataset": "sf311", "id": f"{q['id']}__n{size}", "base_query_id": q["id"],
                        "query": q["query"], "table": {"type": "markdown", "content": "\n".join(lines)},
                        "gold": {"ambiguous_conditions": q["gold"]["ambiguous_conditions"],
                                 "condition_answer_pairs": pairs},
                        "nominal_rows": size, "scale_rows": len(frame), "scope_rows": len(scoped),
                        "source_file": str(source)})
    return out


def sf_contextual_alias_score(sample, parsed):
    """Separate diagnostic: STATUS=open equals not closed in this all-open sample.

    Never overwrite the paper scorer or the raw parsed prediction. This alias
    only applies when every supplied SF311 case has STATUS=open.
    """
    if not isinstance(parsed, dict):
        return lab.score("e2e", sample, parsed, "sf311")
    if not all(line.split("|")[2].strip().lower() == "open" for line in
               sample["table"]["content"].splitlines() if line.startswith("| ")
               and line.split("|")[1].strip().isdigit()):
        raise ValueError("SF311 contextual alias requires all input STATUS=open")
    transformed = copy.deepcopy(parsed)
    count = 0
    for answer in transformed.get("answers", []):
        conditions = answer.get("conditions") if isinstance(answer, dict) else None
        if not isinstance(conditions, dict):
            continue
        value = conditions.get("Event Status")
        if isinstance(value, str) and re.fullmatch(r"\s*STATUS\s*=\s*['\"]?open['\"]?\s*", value, re.I):
            conditions["Event Status"] = "not closed"
            count += 1
    scores = lab.score("e2e", sample, transformed, "sf311")
    scores["contextual_status_alias_count"] = count
    return scores


def dimension_aware_score(sample, parsed, ds):
    """Diagnostic: match conditions only when dimension labels also agree."""
    gold = sample["gold"]["condition_answer_pairs"]
    preds = [x for x in ((parsed or {}).get("answers") or [])
             if isinstance(x, dict) and isinstance(x.get("conditions"), dict)] if isinstance(parsed, dict) else []
    edges = []
    for gi, gp in enumerate(gold):
        gc = gp["conditions"]
        for pi, pp in enumerate(preds):
            pc = pp["conditions"]
            if set(gc) != set(pc):
                continue
            sims = [lab.paper.cond_match_norm(v, pc[k], ds) for k, v in gc.items()]
            if sims and min(sims) > 0:
                edges.append((min(sims), gi, pi))
    used_g, used_p, matched = set(), set(), []
    for _, gi, pi in sorted(edges, reverse=True):
        if gi not in used_g and pi not in used_p:
            used_g.add(gi); used_p.add(pi); matched.append((gi, pi))
    n = max(1, len(gold))
    return {"coverage": len(matched) / n,
            "answer_relaxed": sum(lab.paper.ans_relaxed(preds[pi].get("answer", ""), gold[gi], ds)
                                  for gi, pi in matched) / n}


def valid_completion(row):
    return (row.get("status") == "ok" and isinstance(row.get("parsed"), dict)
            and not row.get("parse_error") and row.get("finish_reason") != "length")


def prepare(args):
    samples = retail_samples()
    if args.sf_source:
        sf_path = Path(args.sf_source).expanduser().resolve()
        if not sf_path.is_file():
            raise FileNotFoundError(sf_path)
        samples += sf_samples(sf_path)
    path = Path(args.out) / "prepared_samples.jsonl"
    sample_hash = hashlib.sha256("".join(
        json.dumps(s, ensure_ascii=False, default=str) + "\n" for s in samples
    ).encode("utf-8")).hexdigest()
    previous_audit = Path(args.out) / "audit.json"
    if (Path(args.out) / "predictions.jsonl").exists():
        previous = json.loads(previous_audit.read_text()) if previous_audit.exists() else {}
        if previous.get("prepared_sha256") != sample_hash:
            raise ValueError("Existing predictions refer to different inputs; choose a new --out directory")
    write_jsonl(path, samples)
    audit = {"prepared_sha256": sample_hash,
             "source_sf311": str(args.sf_source or "MISSING"), "source_sf311_sha256":
             checksum(Path(args.sf_source)) if args.sf_source else None,
             "counts": dict(Counter((s["dataset"], s["nominal_rows"]) for s in samples)),
             "scales": sorted(set((s["dataset"], s["nominal_rows"], s["scale_rows"]) for s in samples))}
    # JSON keys must be strings.
    audit["counts"] = {f"{ds}/{n}": c for (ds, n), c in audit["counts"].items()}
    audit["selected_queries"] = {ds: [s["base_query_id"] for s in samples
                                  if s["dataset"] == ds and s["nominal_rows"] ==
                                  min(RETAIL_SIZES if ds == "retail" else SF_SIZES)]
                                 for ds in sorted({s["dataset"] for s in samples})}
    audit["sf311_scope_rows"] = {f"{s['base_query_id']}/{s['nominal_rows']}": s["scope_rows"]
                                 for s in samples if s["dataset"] == "sf311"}
    sizes = defaultdict(list)
    for s in samples:
        system, prompt, limit = lab.prompt_for("e2e", s, None)
        sizes[f"{s['dataset']}/{s['nominal_rows']}"] += [(len(system)+len(prompt))//3 + limit]
    audit["conservative_token_proxy_with_output"] = {
        k: {"min": min(v), "max": max(v), "over_default_cap": sum(n > 600000 for n in v)}
        for k, v in sizes.items()}
    audit["token_proxy_warning"] = "chars/3 is a conservative approximation, not provider tokenizer or context guarantee"
    audit["experimental_design"] = {"retail": list(RETAIL_SIZES), "sf311": list(SF_SIZES),
                                   "query_count_per_dataset": 10, "task": "hinted_e2e",
                                   "retail_sampling_seed": RETAIL_SAMPLING_SEED,
                                   "sf311_sampling_seed": 20261110}
    audit["source_retail_sha256"] = checksum(HERE / "retail/online_retail_unit_n20000.csv")
    (Path(args.out) / "audit.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False))
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    print("Prepared:", path)


def preflight(args):
    """Offline prompt size audit. No API requests and no context-limit claims."""
    audit = json.loads((Path(args.out) / "audit.json").read_text(encoding="utf-8"))
    path = Path(args.out) / "prepared_samples.jsonl"
    if checksum(path) != audit["prepared_sha256"]:
        raise ValueError("Prepared samples have changed since audit")
    records = []
    for s in read_jsonl(path):
        system, prompt, default_output = lab.prompt_for("e2e", s, None)
        chars = len(system) + len(prompt)
        records.append({"dataset": s["dataset"], "id": s["id"], "nominal_rows": s["nominal_rows"],
                        "actual_rows": s["scale_rows"], "prompt_chars": chars,
                        "rough_input_tokens_chars_div_3": chars // 3,
                        "output_tokens_reserved": args.max_output_tokens or default_output,
                        "within_local_safety_gate": chars // 3 + (args.max_output_tokens or default_output)
                        <= args.max_rough_input_tokens,
                        "prompt_sha256": hashlib.sha256((system + "\n" + prompt).encode()).hexdigest()})
    target = Path(args.out) / "prompt_size_preflight.csv"
    with target.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader(); writer.writerows(records)
    by = defaultdict(list)
    for r in records:
        by[(r["dataset"], r["nominal_rows"])].append(r)
    for (ds, n), rs in sorted(by.items()):
        print(f"{ds}/{n}: actual_rows={rs[0]['actual_rows']}; "
              f"estimated_input_tokens={min(r['rough_input_tokens_chars_div_3'] for r in rs):,}.."
              f"{max(r['rough_input_tokens_chars_div_3'] for r in rs):,}; "
              f"blocked_by_local_gate={sum(not r['within_local_safety_gate'] for r in rs)}/{len(rs)}")
    print("Preflight:", target)
    print("WARNING: char/3 is only a rough proxy. For large prompts verify provider token counts, "
          "model context and per-request quota before overriding the safety gate.")


def import_previous(args):
    """Reuse valid calls only when exact data, gold, and prompt agree."""
    if not args.from_out:
        raise ValueError("--from-out must point to the prior result directory")
    new = {(s["dataset"], s["id"]): s for s in read_jsonl(Path(args.out) / "prepared_samples.jsonl")}
    old = {(s["dataset"], s["id"]): s for s in read_jsonl(Path(args.from_out) / "prepared_samples.jsonl")}
    old_predictions = read_jsonl(Path(args.from_out) / "predictions.jsonl")
    target = Path(args.out) / "predictions.jsonl"
    done = {(r["model"], r["dataset"], r["id"]) for r in read_jsonl(target) if valid_completion(r)} if target.exists() else set()
    imported = []
    for row in old_predictions:
        if args.action == "import-sf-pilot" and row.get("dataset") != "sf311":
            continue
        if not valid_completion(row):
            continue
        k = (row["dataset"], row["id"])
        if k not in new or k not in old:
            continue
        a, b = new[k], old[k]
        if any(a[field] != b[field] for field in ("query", "table", "gold", "scale_rows", "nominal_rows")):
            raise ValueError(f"Cannot reuse {row['id']}: old and new inputs differ")
        if lab.prompt_for("e2e", a, None) != lab.prompt_for("e2e", b, None):
            raise ValueError(f"Cannot reuse {row['id']}: exact prompt differs")
        identity = (row["model"], row["dataset"], row["id"])
        if identity in done:
            continue
        copied = dict(row)
        copied["scores"] = lab.score("e2e", a, row["parsed"], a["dataset"])
        copied["scores_contextual_alias"] = sf_contextual_alias_score(a, row["parsed"]) if a["dataset"] == "sf311" else None
        copied["scores_dimension_aware"] = dimension_aware_score(a, row["parsed"], a["dataset"])
        copied["reused_from"] = str(Path(args.from_out) / "predictions.jsonl")
        imported.append(copied)
        done.add(identity)
    if imported:
        with open(target, "a", encoding="utf-8") as f:
            for row in imported:
                f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    print(f"Imported {len(imported)} verified predictions without API calls")


def run(args):
    prepared_path = Path(args.out) / "prepared_samples.jsonl"
    audit_path = Path(args.out) / "audit.json"
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    if checksum(prepared_path) != audit["prepared_sha256"]:
        raise ValueError("Prepared samples changed after audit; stop to avoid mixing results")
    samples = read_jsonl(prepared_path)
    if not args.retail_only and {s["dataset"] for s in samples} != {"retail", "sf311"}:
        raise ValueError("SF311 source missing: prepare with --sf-source first, or explicitly use --retail-only")
    if args.retail_only:
        samples = [s for s in samples if s["dataset"] == "retail"]
    catalog = {m["id"]: m for m in json.loads((HERE / "models.json").read_text())}
    models = args.models or list(DEFAULT_MODELS)
    if any(m not in catalog for m in models):
        raise ValueError(f"Unknown model; choose from {list(catalog)}")
    path = Path(args.out) / "predictions.jsonl"
    existing = read_jsonl(path) if path.exists() else []
    done = {(r["model"], r["dataset"], r["id"]) for r in existing if valid_completion(r)}
    jobs = [(m, s) for m in models for s in samples if (m, s["dataset"], s["id"]) not in done]
    if args.pilot:
        first = {ds: next(s["base_query_id"] for s in samples if s["dataset"] == ds)
                 for ds in sorted({s["dataset"] for s in samples})}
        jobs = [(m, s) for m, s in jobs if s["nominal_rows"] ==
                (args.pilot_size or max(RETAIL_SIZES if s["dataset"] == "retail" else SF_SIZES))
                and s["base_query_id"] == first[s["dataset"]]]
    print(f"Prepared jobs: {len(jobs)}; existing ok: {len(done)}; projected maximum: {len(models)*len(samples)}")
    # Plan only unless explicitly executed. The safety cap limits only new API requests this invocation.
    if not args.execute:
        for m, s in jobs[:5]:
            print(m, s["dataset"], s["id"], s["scale_rows"])
        return
    if not all(os.environ.get(catalog[m]["key_env"]) for m in models):
        raise ValueError("API credentials missing for one or more selected providers")
    sent = 0
    for m, s in jobs:
        if sent >= args.max_calls:
            break
        system, prompt, limit = lab.prompt_for("e2e", s, None)
        limit = args.max_output_tokens or limit
        # Conservative preview, never automatically replace or truncate data.
        rough_tokens = (len(system) + len(prompt)) // 3
        if rough_tokens + limit > args.max_rough_input_tokens:
            row = {"model": m, "dataset": s["dataset"], "id": s["id"], "base_query_id": s["base_query_id"],
                   "nominal_rows": s["nominal_rows"], "scale_rows": s["scale_rows"],
                   "status": "blocked_context_estimate", "rough_input_tokens": rough_tokens}
        else:
            sent += 1
            try:
                result = providers.complete(catalog[m], system, prompt, limit, timeout=args.timeout)
                parsed, err = lab.paper.E.parse_json_output(result["raw"])
                if not isinstance(parsed, dict):
                    parsed, err = None, err or "top-level JSON is not an object"
                primary_scores = lab.score("e2e", s, parsed, s["dataset"])
                alias_scores = sf_contextual_alias_score(s, parsed) if s["dataset"] == "sf311" else None
                dimension_scores = dimension_aware_score(s, parsed, s["dataset"])
                row = {"model": m, "dataset": s["dataset"], "id": s["id"], "base_query_id": s["base_query_id"],
                       "nominal_rows": s["nominal_rows"], "scale_rows": s["scale_rows"],
                       "status": "ok", "rough_input_tokens": rough_tokens, "parse_error": err,
                       "max_output_tokens": limit, "parsed": parsed, "scores": primary_scores,
                       "scores_dimension_aware": dimension_scores,
                       "scores_contextual_alias": alias_scores, **result}
            except Exception as exc:
                row = {"model": m, "dataset": s["dataset"], "id": s["id"], "base_query_id": s["base_query_id"],
                       "nominal_rows": s["nominal_rows"], "scale_rows": s["scale_rows"],
                       "status": "failed", "error": str(exc)[:500]}
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
            f.flush()
        print(f"{sent}/{min(args.max_calls,len(jobs))} {m} {s['dataset']} {s['id']}: {row['status']}", flush=True)
        if sent and args.seconds_between_calls:
            time.sleep(args.seconds_between_calls)
    summarize(args)


def summarize(args):
    path = Path(args.out) / "predictions.jsonl"
    if not path.exists():
        print("No predictions yet")
        return
    best = {}
    for r in read_jsonl(path):
        key = (r["model"], r["dataset"], r["id"])
        if key not in best or (valid_completion(r) and not valid_completion(best[key])) or (
                valid_completion(r) == valid_completion(best[key])):
            best[key] = r
    groups = defaultdict(list)
    for r in best.values():
        groups[(r["model"], r["dataset"], r["nominal_rows"])].append(r)
    rows = []
    for (model, ds, nominal), results in sorted(groups.items()):
        ok = [r for r in results if valid_completion(r)]
        timing = sorted(r["elapsed_ms"] / 1000 for r in ok)
        quality = [r["scores"]["answer_relaxed_norm"] for r in ok if r.get("scores")]
        alias_quality = [r["scores_contextual_alias"]["answer_relaxed_norm"] for r in ok
                         if r.get("scores_contextual_alias")]
        aware_quality = [r["scores_dimension_aware"]["answer_relaxed"] for r in ok
                         if r.get("scores_dimension_aware")]
        tokens = [r.get("usage") or {} for r in ok]
        rows.append(dict(model=model, dataset=ds, nominal_rows=nominal,
                         actual_rows=results[0]["scale_rows"], n=len(results), ok=len(ok),
                         errors=len(results)-len(ok), json_invalid=sum(
                             r.get("status") == "ok" and r.get("parsed") is None for r in results),
                         truncated=sum(r.get("finish_reason") == "length" for r in results),
                         e2e_accuracy=round(100*statistics.mean(quality),2) if quality else "",
                         sf_contextual_alias_accuracy=round(100*statistics.mean(alias_quality),2)
                         if alias_quality else "",
                         dimension_aware_accuracy=round(100*statistics.mean(aware_quality),2)
                         if aware_quality else "",
                         latency_mean_s=round(statistics.mean(timing),2) if timing else "",
                         latency_p50_s=round(statistics.median(timing),2) if timing else "",
                         latency_p95_s=round(timing[min(len(timing)-1, int(.95*len(timing)))],2) if timing else "",
                         input_tokens=sum(u.get("prompt_tokens") or 0 for u in tokens),
                         output_tokens=sum(u.get("completion_tokens") or 0 for u in tokens)))
    target = Path(args.out) / "summary.csv"
    with open(target, "w", newline="", encoding="utf-8") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ["model","dataset"])
        writer.writeheader();writer.writerows(rows)
    print("Summary:", target)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=("prepare", "preflight", "import-sf-pilot", "import-previous", "run", "summary"))
    ap.add_argument("--sf-source", default=str(HERE / "reference/sf311_raw.csv")
                    if (HERE / "reference/sf311_raw.csv").exists() else None,
                    help="SF311 raw case-level CSV or Parquet; defaults to the bundled raw snapshot")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--from-out", help="Prior run directory for verified import")
    ap.add_argument("--models", nargs="+", default=None)
    ap.add_argument("--retail-only", action="store_true")
    ap.add_argument("--pilot", action="store_true", help="One largest-scale question per dataset and model")
    ap.add_argument("--pilot-size", type=int, choices=tuple(sorted(set(RETAIL_SIZES+SF_SIZES))),
                    help="Use with --pilot to select one shared nominal row scale, if available")
    ap.add_argument("--max-output-tokens", type=int, help="Override the paper prompt's 4000 output-token cap")
    ap.add_argument("--execute", action="store_true")
    ap.add_argument("--max-calls", type=int, default=6)
    ap.add_argument("--max-rough-input-tokens", type=int, default=300000,
                    help="Local char/3 proxy INCLUDING reserved output; larger prompts are blocked unless explicitly raised")
    ap.add_argument("--timeout", type=float, default=300)
    ap.add_argument("--seconds-between-calls", type=float, default=1)
    args = ap.parse_args()
    Path(args.out).mkdir(parents=True, exist_ok=True)
    {"prepare":prepare,"preflight":preflight,"import-sf-pilot":import_previous,"import-previous":import_previous,
     "run":run,"summary":summarize}[args.action](args)

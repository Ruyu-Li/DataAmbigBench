#!/usr/bin/env python3
"""Rebuild 200 original Retail + 200 original SF311 queries at three nested row scales.

Offline only. API calls remain in scale_study.py and require --execute. Each
query gets a deterministic, scope-enriched nested sample of *real* source rows;
gold is recomputed from exactly those rows. Never mix outputs with the old
10-query experiment: its Retail questions and contexts are different.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
from collections import Counter
from pathlib import Path

import pandas as pd

import scale_study as S

ROOT = Path(__file__).resolve().parent
RETAIL_SIZES = (1000, 5000, 8000)
SF_SIZES = (500, 1500, 3000)
FROZEN_PREPARED_SHA256 = 'bfa9e00180c78a9ba2e9dbf151147026c29b527f352dbeca27ff0fd1e66378ba'
FROZEN_PREDICTIONS_SHA256 = 'd3771238cbad948ae6eb71e35208dcb8f7ec86ac2360ca747bdfe7dd75c512f6'


def retail_raw(path: Path, queries: list[dict]) -> pd.DataFrame:
    parts = []
    for sheet, frame in pd.read_excel(path, sheet_name=None,
            usecols=["Invoice", "StockCode", "Description", "Quantity",
                     "InvoiceDate", "Price", "Customer ID", "Country"]).items():
        frame["source_sheet"] = sheet
        parts.append(frame)
    df = pd.concat(parts, ignore_index=True)
    countries = {q["metadata"]["country"] for q in queries}
    df = df[df.Country.isin(countries)].copy()
    df["Invoice"] = df.Invoice.astype("string")
    df["StockCode"] = df.StockCode.astype("string")
    df["CustomerID"] = df.pop("Customer ID").astype("string")
    df["InvoiceDate"] = pd.to_datetime(df.InvoiceDate, errors="coerce")
    df["Quantity"] = pd.to_numeric(df.Quantity, errors="coerce")
    df["Price"] = pd.to_numeric(df.Price, errors="coerce")
    df = df.dropna(subset=["Invoice", "InvoiceDate", "Quantity", "Price"])
    df = df[df.Invoice.str.strip().ne("")].copy()
    df["CustomerID"] = df.CustomerID.replace({"<NA>": None, "nan": None, "None": None})
    return df[S.retail_gold.SOURCE_COLUMNS].reset_index(drop=True)


def retail_frames(df: pd.DataFrame, q: dict) -> dict[int, pd.DataFrame]:
    """Complete invoices, >= one relevant invoice, nested, deterministic.

    At each scale about half the rows target the query's country. The other
    half are real distractors. The exact row count may exceed the nominal size
    because an invoice is indivisible; actual_rows is saved in every sample.
    """
    meta = q["metadata"]
    country, sku = meta["country"], str(meta.get("stock_code") or "")
    seed = int.from_bytes(hashlib.sha256(q["id"].encode()).digest()[:8], "big")
    rng = random.Random(seed)
    groups = df.groupby(["Country", "Invoice"], sort=False).indices
    own = [key for key in groups if key[0] == country]
    others = [key for key in groups if key[0] != country]
    rng.shuffle(own); rng.shuffle(others)
    if sku:
        matches = df[(df.Country == country) & (df.StockCode == sku)]
        anchors = [(country, inv) for inv in matches.Invoice.drop_duplicates()]
        rng.shuffle(anchors)
        if not anchors:
            raise ValueError(f"No source invoice for {q['id']} / {country} / {sku}")
        # Keep a few spread-out occurrences so temporal changes can be measured.
        anchors = anchors[:min(8, len(anchors))]
        own = anchors + [k for k in own if k not in set(anchors)]
    out = {}
    for n in RETAIL_SIZES:
        chosen, count = [], 0
        own_capacity = sum(len(groups[k]) for k in own)
        other_capacity = sum(len(groups[k]) for k in others)
        own_target = min(n // 2, own_capacity)
        other_target = n - own_target
        if other_target > other_capacity:
            other_target = other_capacity
            own_target = n - other_target
        for keys, target in ((own, own_target), (others, other_target)):
            subtotal = 0
            for key in keys:
                chosen.append(key)
                subtotal += len(groups[key])
                if subtotal >= target:
                    break
            if subtotal < target:
                raise ValueError(f"Insufficient source rows: {q['id']} {n}")
            count += subtotal
        indices = [i for k in chosen for i in groups[k]]
        frame = df.iloc[indices].sort_values(
            ["InvoiceDate", "Country", "Invoice", "StockCode"], kind="stable").reset_index(drop=True)
        out[n] = frame
    for a, b in zip(RETAIL_SIZES, RETAIL_SIZES[1:]):
        ka = set(zip(out[a].Country, out[a].Invoice))
        kb = set(zip(out[b].Country, out[b].Invoice))
        if not ka <= kb:
            raise AssertionError(f"Retail samples are not nested: {q['id']}")
    return out


def retail_answer(frame: pd.DataFrame, q: dict, condition: str) -> str:
    if q['metadata']['metric_code'] != 'invoices_min':
        return S.retail_gold.calculate_answer(frame, q, condition)['answer']
    data = frame[frame.Country == q['metadata']['country']].copy()
    if data.empty:
        raise ValueError(f"No rows for {q['id']} / {condition}")
    data['bucket'] = S.retail_gold.bucketize(data, condition)
    values = data.groupby('bucket', sort=True).Invoice.nunique()
    return str(values.idxmin())


def retail_record(q: dict, frame: pd.DataFrame, n: int) -> dict:
    answers = [(c, retail_answer(frame, q, c)) for c in S.retail_gold.CONDITIONS]
    table = S.retail_gold.json_table(frame,
        f"Online Retail II; actual rows={len(frame)}; complete invoices")
    table["header"] = [c for c in table["header"] if c != "source_sheet"]
    for row in table["rows"]:
        row.pop("source_sheet", None)
    return {"dataset": "retail", "id": f"{q['id']}__n{n}",
            "base_query_id": q["id"], "query": q["query"],
            "scale_rows": len(frame), "nominal_rows": n, "table": table,
            "gold": {"ambiguous_conditions": q["gold"]["ambiguous_conditions"],
                     "condition_answer_pairs": [
                         {"conditions": {"Unit": c}, "answer": answer}
                         for c, answer in answers]}}


def scoped(frame: pd.DataFrame, q: dict) -> pd.DataFrame:
    for col, value in (q["metadata"]["original_record"].get("scope") or {}).items():
        frame = frame[frame[col].str.casefold() == str(value).casefold()]
    return frame


def sf_frames(df: pd.DataFrame, q: dict) -> dict[int, pd.DataFrame]:
    seed = int.from_bytes(hashlib.sha256(q["id"].encode()).digest()[:8], "big")
    rng = random.Random(seed)
    eligible = scoped(df, q)
    if eligible.empty:
        raise ValueError(f"No source cases for {q['id']}")
    keys = eligible.index.tolist()
    rng.shuffle(keys)
    # Scope enrichment makes rare neighborhoods observable even at 500 rows.
    # Include both narrow and broad status interpretations when available.
    conds = [p["conditions"]["Event Status"] for p in q["gold"]["condition_answer_pairs"]]
    narrow = "in progress" if "work status = in progress" in conds else "open"
    prioritized = [i for i in keys if df.at[i, "WORK STATUS"] == narrow][:10]
    prioritized += [i for i in keys if df.at[i, "WORK STATUS"] != narrow][:10]
    prioritized += keys[:max(20, min(40, len(keys)))]
    forced = list(dict.fromkeys(prioritized))
    if len(forced) > 500:
        raise AssertionError("Too many mandatory cases")
    background = df.index.tolist()
    rng.shuffle(background)
    sequence = forced + [i for i in background if i not in set(forced)]
    out = {n: df.loc[sequence[:n]].reset_index(drop=True) for n in SF_SIZES}
    return out


def sf_answer(frame: pd.DataFrame, cond: str, operation: str):
    w = frame["WORK STATUS"]
    if cond == "not closed":
        mask = frame.STATUS.ne("closed")
    elif cond == "work status = open":
        mask = w.eq("open")
    elif cond == "work status = in progress":
        mask = w.eq("in progress")
    elif cond == "work status in {accepted, in progress}":
        mask = w.isin(["accepted", "in progress"])
    elif cond == "work status in {open, sent, accepted, in progress}":
        mask = w.isin(["open", "sent", "accepted", "in progress"])
    else:
        raise ValueError(f"Unknown status condition: {cond}")
    if operation == "count":
        return int(mask.sum())
    if operation == "percentage":
        return round(100 * int(mask.sum()) / len(frame), 2) if len(frame) else 0.0
    if operation == "argmax_category":
        counts = frame.loc[mask & frame.CATEGORY.ne(""), "CATEGORY"].value_counts()
        if counts.empty:
            raise ValueError("No category under status condition")
        return sorted(counts[counts == counts.max()].index.tolist())[0]
    raise ValueError(f"Unknown operation: {operation}")


def sf_record(q: dict, frame: pd.DataFrame, n: int) -> dict:
    scope = scoped(frame, q)
    cols = list(S.SF_COLS)
    lines = ["Scope: supplied rows are a nested sample of distinct SF311 cases. Count CASE ID once.",
             f"Actual input rows: {len(frame)}. Case statuses are recorded values, not citywide totals.",
             "", "| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    lines += ["| " + " | ".join(str(v).replace("|", "/").replace("\n", " ")
                 for v in vals) + " |" for vals in frame[cols].itertuples(index=False, name=None)]
    op = q["metadata"]["original_record"]["operation"]
    pairs = []
    for p in q["gold"]["condition_answer_pairs"]:
        cond = p["conditions"]["Event Status"]
        pair = {"conditions": p["conditions"], "answer": sf_answer(scope, cond, op)}
        if op == "argmax_category":
            # The selected category is scored by exact label. Retain ties as
            # aliases only when they satisfy the same status predicate.
            from_cond = scope[scope["WORK STATUS"].isin(
                ["open", "sent", "accepted", "in progress"] if cond.startswith("work status in")
                else ["in progress"])]
            counts = from_cond.loc[from_cond.CATEGORY.ne(""), "CATEGORY"].value_counts()
            ties = sorted(counts[counts == counts.max()].index.tolist())
            pair["acceptable_answers"] = ties
        pairs.append(pair)
    return {"dataset": "sf311", "id": f"{q['id']}__n{n}", "base_query_id": q["id"],
            "query": q["query"], "nominal_rows": n, "scale_rows": len(frame),
            "scope_rows": len(scope), "table": {"type": "markdown", "content": "\n".join(lines)},
            "gold": {"ambiguous_conditions": q["gold"]["ambiguous_conditions"],
                     "condition_answer_pairs": pairs}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--retail-source", type=Path, required=True)
    ap.add_argument("--retail-queries", type=Path, required=True)
    ap.add_argument("--sf-source", type=Path, default=ROOT / "reference/sf311_raw.csv")
    ap.add_argument("--sf-queries", type=Path, default=ROOT / "reference/sf311.jsonl")
    ap.add_argument("--previous-prepared", type=Path, required=True,
                    help="Frozen 10-query prepared_samples.jsonl")
    ap.add_argument("--previous-predictions", type=Path, required=True,
                    help="Frozen 10-query predictions.jsonl")
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if (args.out / "predictions.jsonl").exists():
        raise ValueError("Existing predictions in --out: prepare in a new directory")
    if S.checksum(args.previous_prepared) != FROZEN_PREPARED_SHA256:
        raise ValueError('Frozen 10-query input file checksum does not match')
    if S.checksum(args.previous_predictions) != FROZEN_PREDICTIONS_SHA256:
        raise ValueError('Frozen 10-query prediction file checksum does not match')
    retail = S.read_jsonl(args.retail_queries)
    sf = S.read_jsonl(args.sf_queries)
    prior_samples = S.read_jsonl(args.previous_prepared)
    prior_predictions = S.read_jsonl(args.previous_predictions)
    old_ids = {ds: {s['base_query_id'] for s in prior_samples if s['dataset'] == ds}
               for ds in ('retail', 'sf311')}
    if (len(prior_samples) != 60 or len(old_ids['retail']) != 10 or len(old_ids['sf311']) != 10
            or len({(s['dataset'], s['id']) for s in prior_samples}) != 60):
        raise ValueError('Frozen inputs must be 10 unique questions × 3 scales × 2 datasets')
    for ds, scales in (('retail', RETAIL_SIZES), ('sf311', SF_SIZES)):
        for size in scales:
            if sum(s['dataset'] == ds and s['nominal_rows'] == size for s in prior_samples) != 10:
                raise ValueError(f'Frozen {ds}/{size} is not 10 questions')
    if {s['base_query_id'] for s in prior_samples if s['dataset'] == 'retail'} - {q['id'] for q in retail}:
        raise ValueError('Old Retail IDs do not occur in the 200-query source')
    if {s['base_query_id'] for s in prior_samples if s['dataset'] == 'sf311'} - {q['id'] for q in sf}:
        raise ValueError('Old SF311 IDs do not occur in the 200-query source')
    old_keys = {(s['dataset'], s['id']) for s in prior_samples}
    valid = {}
    for row in prior_predictions:
        if not S.valid_completion(row):
            continue
        key = (row['model'], row['dataset'], row['id'])
        if (row['dataset'], row['id']) in old_keys:
            valid[key] = row
    if len(valid) != 180 or {m for m, _, _ in valid} != set(S.DEFAULT_MODELS):
        raise ValueError(f'Frozen results lack 180 valid unique model requests: {len(valid)}')
    for name, queries in (("Retail", retail), ("SF311", sf)):
        if len(queries) != 200 or len({q['id'] for q in queries}) != 200:
            raise ValueError(f"{name} source must contain exactly 200 unique queries")
    raw = retail_raw(args.retail_source, retail)
    sfraw = S.sf_frame(args.sf_source)
    source_hashes = {str(p): S.checksum(p) for p in
                     (args.retail_source, args.retail_queries, args.sf_source, args.sf_queries,
                      args.previous_prepared, args.previous_predictions)}
    counts = Counter(); failures = []
    path = args.out / "prepared_samples.jsonl"
    with path.open("w", encoding="utf-8") as file:
        for record in prior_samples:
            file.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
            counts[f"{record['dataset']}/{record['nominal_rows']}"] += 1
        for dataset, questions, frame, sizes in (
            ("retail", retail, raw, RETAIL_SIZES),
            ("sf311", sf, sfraw, SF_SIZES)):
            for j, q in enumerate(questions, 1):
                if q['id'] in old_ids[dataset]:
                    continue
                try:
                    frames = retail_frames(frame, q) if dataset == "retail" else sf_frames(frame, q)
                    records = [retail_record(q, frames[n], n) if dataset == "retail"
                               else sf_record(q, frames[n], n) for n in sizes]
                    if dataset == "sf311" and len({p['answer'] for p in records[0]['gold']['condition_answer_pairs']}) < 2:
                        raise ValueError("Small-scale interpretations collapse to the same answer")
                    for record in records:
                        file.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
                        counts[f"{dataset}/{record['nominal_rows']}"] += 1
                except Exception as exc:
                    failures.append({"dataset": dataset, "id": q['id'], "error": str(exc)[:240]})
                if j % 25 == 0:
                    print(f"{dataset}: {j}/200 generated; failed={len(failures)}", flush=True)
    if not failures and all(counts[f"{ds}/{size}"] == 200 for ds, sizes in
                           (("retail", RETAIL_SIZES), ("sf311", SF_SIZES)) for size in sizes):
        with (args.out / 'predictions.jsonl').open('w', encoding='utf-8') as file:
            for row in valid.values():
                copied = dict(row)
                copied['reused_from'] = str(args.previous_predictions)
                file.write(json.dumps(copied, ensure_ascii=False, default=str) + '\n')
    report = {"counts": dict(counts), "failures": failures, "source_sha256": source_hashes,
              "prepared_sha256": S.checksum(path),
              "old_query_ids": {k: sorted(v) for k, v in old_ids.items()},
              "reused_valid_model_requests": len(valid),
              "experimental_design": {"retail": RETAIL_SIZES, "sf311": SF_SIZES,
                 "query_count_per_dataset": 200, "task": "hinted_e2e",
                 "sampling": "old 10 preserved verbatim; new 190 deterministic per-query scope-enriched nested real rows"}}
    (args.out / "audit.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"counts": dict(counts), "failed_count": len(failures),
                      "reused_valid_model_requests": len(valid),
                      "first_failures": failures[:10], "output": str(path)}, ensure_ascii=False, indent=2))
    if failures or any(counts[f"{ds}/{size}"] != 200 for ds, sizes in
                       (("retail", RETAIL_SIZES), ("sf311", SF_SIZES)) for size in sizes):
        raise SystemExit("Preflight incomplete. Inspect audit.json; do not run any API requests.")


if __name__ == "__main__":
    main()

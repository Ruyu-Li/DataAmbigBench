# DataAmbigBench：两个数据集各 200 题的 scalability 实验

范围：Online Retail II／Unit（1,000、5,000、8,000 行），SF311／Event Status（500、1,500、3,000 行），每个数据集 200 个原始题目，各档仍是同一道题；三个模型分别为 `gpt-4.1-mini`、`claude-haiku-5-5`、`gemini-3.1-flash-lite`。共 1,200 个不同的题目与档位组合、3,600 次模型请求。

`prepare_200.py` 首先从本包内的冻结结果原样复用两个数据集各 10 题及其 180 个有效模型请求，然后从 Retail 原始工作簿、Retail 200 题和 SF311 原始案件及 200 题中，按 ID 排除旧 10 题，分别新增 190 道题。新题采用固定种子的范围增强真实记录样本；其三个档位的完整发票／独立案件逐档嵌套，gold 均针对该档的实际输入重新计算。由于有些国家和状态筛选范围很稀疏，各题的样本表并不完全相同。实际行数和每题的可重复性均写入结果。**不能将 200 道题理解为对同一张固定 8,000 行表重复提问**。

原来 10 题中 Retail 的版本与主实验同 ID 题目存在不同国家和指标。因此复用 10 题意味着这 200 题中有 10 题沿用旧版定义，另 190 题采用当前主实验定义。请在论文中明确说明这一版本差异；不应将这 200 题描述为“同一版主实验 200 题”。旧预测逐条对应的是原样保留的旧题目和上下文，不覆盖、不重新请求。

## 在 Colab 运行

只需上传本 ZIP 一次，里面已有 Retail 原始工作簿、两份 200 题源数据、冻结的旧 10 题输入与 180 个有效预测。解压后将 `PROJECT` 改成实际目录；新输出目录 `OUT` 建议放在已挂载的 Google Drive 中，确保断线可续跑。

```python
from pathlib import Path
import subprocess, sys

PROJECT = Path('/content/DataAmbigBench_scalability_dual')  # 按解压后的实际路径修改
OUT = Path('/content/drive/MyDrive/DataAmbigBench_supplemental/scalability_200_v1')
OUT.mkdir(parents=True, exist_ok=True)

# 完全离线：复用旧 60 条题目档位记录，新增 1,140 条，并导入旧 180 个预测。
subprocess.run([
    sys.executable, '-u', str(PROJECT/'prepare_200.py'),
    '--retail-source', str(PROJECT/'inputs/online_retail_II.xlsx'),
    '--retail-queries', str(PROJECT/'inputs/retail_200.jsonl'),
    '--previous-prepared', str(PROJECT/'inputs/previous_prepared_samples.jsonl'),
    '--previous-predictions', str(PROJECT/'inputs/previous_predictions.jsonl'),
    '--out', str(OUT)
], check=True)
```

```python
import json
audit = json.loads((OUT/'audit.json').read_text(encoding='utf-8'))
print('各档题数：', audit['counts'])
print('构造失败：', len(audit['failures']))
assert len(audit['failures']) == 0
assert len(audit['counts']) == 6 and set(audit['counts'].values()) == {200}
```

```python
# 只列待跑计划，不调用 API。
subprocess.run([sys.executable, str(PROJECT/'scale_study.py'),
    'run', '--out', str(OUT)], check=True)
```

如果要正式运行，先在 Colab 当前运行时设置 `OPENAI_API_KEY`、`ANTHROPIC_API_KEY` 和 `GEMINI_API_KEY`。计划数应是 3,420 个待补请求、180 个已完成请求。下面每次最多新增 30 次调用，运行完可重复执行并跳过有效完成记录；逐步增加 `--max-calls`，大档必须提前检查模型真实 token 限制与项目额度。`--max-rough-input-tokens` 只是本地按字符长度预估的安全阈值，不是模型 token 计数。

```python
subprocess.run([sys.executable, '-u', str(PROJECT/'scale_study.py'),
    'run', '--out', str(OUT), '--execute', '--max-calls', '30',
    '--max-output-tokens', '8000', '--max-rough-input-tokens', '800000'], check=True)
```

输出为 `prepared_samples.jsonl`、`audit.json`、`predictions.jsonl` 与 `summary.csv`。结果文件按请求增量追加。不要对这个新目录运行旧包的 `prepare` 命令，也不要把旧 `predictions.jsonl` 复制进新目录。

## 计数与解释

- 原始题目：每个数据集 200 道；每道题在三档都有独立 gold。
- 每模型：两个数据集 × 每集 200 题 × 三档 = 1,200 个请求。
- 三模型：3,600 个请求，其中复用旧 180 个，新增 3,420 个。每个模型必须逐档覆盖 200 道题才能称为全量完成。
- `summary.csv` 中的回答分数基于**有效 JSON 请求**；同时报告无效 JSON／请求失败的数量，论文应注明分母与补跑次数。
- Retail 主实验原先的每题短表与这里的长表不同；本实验衡量模型面对更多真实记录时的回答变化，不等同于在固定答案上重复生成同一输入。

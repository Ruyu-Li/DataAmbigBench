"""Offline-first DataAmbigBench supplemental experiments. Python 3.10+."""
import argparse
import collections
import copy
import hashlib
import json
import math
import os
import random
import re
import statistics
import sys
import time
import unicodedata
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "scripts"))
import evaluate as paper
import evaluate_open as open_eval
import prompts

TASKS = ("detection", "condition_given", "e2e", "e2e_open")
PRIMARY = {
    "detection": ("dimension_f1", "condition_f1_norm"),
    "condition_given": ("answer_relaxed",),
    "e2e": ("answer_relaxed_norm",),
    "e2e_open": ("multi_answer_rate", "gold_answer_recall", "single_answer_correct"),
}
DEFAULT_FILES = {
    "sec": ("sec_eval_standard.jsonl", "sec_eval_standard(2).jsonl", "sec_eval_standard(1).jsonl"),
    "nasa": ("NASA_POWER_200_sampled_v1.jsonl", "NASA_POWER_200_sampled_v1(1).jsonl"),
    "tatqa": ("TAT_QA_200_sampled_v1.jsonl", "TAT_QA_200_sampled_v1(1).jsonl"),
    "ambigdocs": ("ambigdocs_eval_standard(2).jsonl", "ambigdocs_eval_standard.jsonl"),
    "opinionqa": ("opinionqa_eval_standard.jsonl",),
    "usc": ("usc_eval_standard.jsonl",),
    "sf311": ("sf311_event_status_200_standard(2).jsonl", "sf311_event_status_200_standard.jsonl"),
    "retail": ("online_retail_unit_200_standard.jsonl",),
    "nyc311": ("NYC311_Geography_200_standard.jsonl",),
}
DIMENSIONS = set(prompts.ALLOWED_DIMENSIONS.split(", "))
ALIASES = {"Entity Disambiguation": "Name Ambiguity"}
ORIGINAL_MATCH = paper.ans_relaxed
NUMBER = re.compile(r"(?P<currency>[$€£])?\s*(?P<value>[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)\s*(?P<percent>%|percent)?", re.I)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def jsonl(lines):
    for line in lines:
        if line.strip():
            yield json.loads(line)


def read_rows(path):
    with path.open(encoding="utf-8-sig") as source:
        return list(jsonl(source))


def save_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def save_rows(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as output:
        for row in rows:
            output.write(canonical(row) + "\n")


def normalized(text):
    return " ".join(unicodedata.normalize("NFKC", text).casefold().split())


def is_answer_table(text):
    for line in text.splitlines():
        cells = [normalized(x) for x in line.strip().strip("|").split("|")]
        if cells[:2] == ["condition", "answer"]:
            return True
    return False


def valid_sample(row):
    if not all(isinstance(row.get(k), str) and row[k].strip() for k in ("id", "query")):
        raise ValueError("missing id/query")
    table = row.get("table")
    if not isinstance(table, (dict, str)) or not table:
        raise ValueError("missing table")
    if isinstance(table, dict):
        if "content" in table:
            if not isinstance(table["content"], str) or not table["content"].strip():
                raise ValueError("empty table.content")
        elif not (isinstance(table.get("header"), list) and table["header"]
                  and all(isinstance(h, str) for h in table["header"])
                  and isinstance(table.get("rows"), list) and table["rows"]
                  and all(isinstance(r, dict) for r in table["rows"])):
            raise ValueError("unrecognized or empty structured table")
    gold = row.get("gold")
    if not isinstance(gold, dict):
        raise ValueError("missing gold")
    labels = gold.get("ambiguous_conditions")
    pairs = gold.get("condition_answer_pairs")
    if not isinstance(labels, list) or not labels or not isinstance(pairs, list) or len(pairs) < 2:
        raise ValueError("expected ambiguity labels and at least two pairs")
    allowed = collections.defaultdict(set)
    for label in labels:
        values = label.get("conditions")
        if label.get("dimension") not in DIMENSIONS or not isinstance(values, list) or not values:
            raise ValueError("invalid dimension or conditions")
        allowed[label["dimension"]].update(normalized(str(v)) for v in values)
    seen = set()
    for pair in pairs:
        cond = pair.get("conditions")
        if not isinstance(cond, dict) or not cond or pair.get("answer") is None or not str(pair["answer"]).strip():
            raise ValueError("incomplete condition-answer pair")
        if any(normalized(str(value)) not in allowed[dim] for dim, value in cond.items()):
            raise ValueError("pair condition absent from declared gold labels")
        key = canonical({k: normalized(str(v)) for k, v in cond.items()})
        if key in seen:
            raise ValueError("duplicate gold condition")
        seen.add(key)


def sec_sample(rows, seed):
    groups = collections.defaultdict(list)
    for row in rows:
        meta = row["metadata"]
        groups[(str(meta["fy"]), str(meta["fp"]))].append(row)
    quota = {k: 200 * len(v) // len(rows) for k, v in groups.items()}
    order = sorted(groups, key=lambda k: (-(200 * len(groups[k]) % len(rows)), k))
    for k in order[:200 - sum(quota.values())]:
        quota[k] += 1
    rng = random.Random(seed)
    selected = [r for k in sorted(groups) for r in rng.sample(groups[k], quota[k])]
    return sorted(selected, key=lambda r: r["id"]), [
        {"fy": k[0], "fp": k[1], "available": len(groups[k]), "selected": quota[k]} for k in sorted(groups)
    ]


def prepare(args):
    if (args.out / "audit.json").exists() or (args.out / "data").exists():
        raise ValueError("choose a fresh --out directory for preparation")
    files = dict(DEFAULT_FILES)
    overrides = dict(item.split("=", 1) for item in args.file)
    for ds, file in overrides.items():
        files[ds] = (file,)
    audit = {}
    for ds, candidates in files.items():
        source = next((args.inputs / name for name in candidates if (args.inputs / name).is_file()), None)
        if source is None:
            audit[ds] = {"state": "missing_input", "expected_names": candidates}
            continue
        rows = read_rows(source)
        records, flagged, issues = [], [], []
        ids, questions, inputs = set(), collections.Counter(), {}
        duplicate_rows = []
        for row in rows:
            row = copy.deepcopy(row)
            try:
                if ds == "ambigdocs":
                    for label in row["gold"]["ambiguous_conditions"]:
                        label["dimension"] = ALIASES.get(label["dimension"], label["dimension"])
                    for pair in row["gold"]["condition_answer_pairs"]:
                        pair["conditions"] = {ALIASES.get(k, k): v for k, v in pair["conditions"].items()}
                valid_sample(row)
                if row["id"] in ids:
                    raise ValueError("duplicate id")
                ids.add(row["id"])
                context = prompts.safe_get_table(row)
                key = (normalized(row["query"]), context.strip().replace("\r\n", "\n"))
                questions[key[0]] += 1
                gold_hash = digest(row["gold"])
                if key in inputs:
                    first_id, first_gold = inputs[key]
                    if first_gold != gold_hash:
                        raise ValueError(f"duplicate input with conflicting gold ({first_id})")
                    duplicate_rows.append({"kept_id": first_id, "duplicate_id": row["id"]})
                    continue
                inputs[key] = (row["id"], gold_hash)
                if is_answer_table(context):
                    flagged.append(row["id"])
                records.append(row)
            except (ValueError, TypeError, KeyError, AttributeError) as exc:
                issues.append({"id": row.get("id"), "error": str(exc)})
        entry = {"source": str(source), "source_hash": hashlib.sha256(source.read_bytes()).hexdigest(),
                 "source_count": len(rows), "eligible_count": len(records), "issues": issues,
                 "answer_lookup_ids": flagged, "exact_duplicates": duplicate_rows,
                 "same_question_extra": sum(n - 1 for n in questions.values() if n > 1)}
        audit[ds] = entry
        if issues or len(records) < 200 or (ds != "sec" and len(records) != 200):
            entry["state"] = "review_required"
            continue
        if flagged:
            entry["state"] = "blocked_answer_lookup"
            continue
        if ds == "sec":
            if len(records) == 200:
                entry["sampling"] = "provided fixed 200"
            else:
                records, strata = sec_sample(records, args.seed)
                entry.update(seed=args.seed, strata=strata)
        path = args.out / "data" / f"{ds}.jsonl"
        save_rows(path, records)
        entry.update(state="structurally_ready", output=str(path), count=len(records),
                     ids=[r["id"] for r in records], data_hash=digest(records))
    save_json(args.out / "audit.json", audit)
    print({ds: item["state"] for ds, item in audit.items()})


def attach_context(args):
    rows = read_rows(args.sample)
    evidence = read_rows(args.evidence)
    by_id = {r["id"]: r for r in evidence}
    if (len(by_id) != len(evidence) or len(rows) != 200 or
            len({r["id"] for r in rows}) != 200 or set(by_id) != {r["id"] for r in rows}):
        raise ValueError("evidence must match all 200 unique sample IDs")
    output = []
    for row in rows:
        new = by_id[row["id"]]
        if new.get("query") != row["query"] or not new.get("source_ref"):
            raise ValueError(f"{row['id']}: provide exact query and source_ref")
        rebuilt = copy.deepcopy(row)
        rebuilt.update(table=new["table"], gold=new["gold"])
        rebuilt.setdefault("metadata", {})["context_source_ref"] = new["source_ref"]
        rebuilt["metadata"]["previous_gold_hash"] = digest(row["gold"])
        valid_sample(rebuilt)
        if is_answer_table(prompts.safe_get_table(rebuilt)):
            raise ValueError(f"{row['id']}: evidence still contains an answer lookup table")
        output.append(rebuilt)
    if args.out.resolve() in {args.sample.resolve(), args.evidence.resolve()}:
        raise ValueError("choose a separate output file")
    save_rows(args.out, output)
    print(f"Attached evidence to {len(output)} queries")

def prompt_for(task, sample, pi):
    if task == "detection":
        return prompts.SYSTEM_PROMPT, prompts.build_detection_prompt(sample), 2000
    if task == "condition_given":
        pair = sample["gold"]["condition_answer_pairs"][pi]
        return prompts.SYSTEM_PROMPT, prompts.build_condition_answer_prompt(sample, pair), 3000
    if task == "e2e":
        return prompts.SYSTEM_PROMPT, prompts.build_e2e_prompt(sample), 4000
    return prompts.OPEN_SYSTEM_PROMPT, prompts.build_open_prompt(sample), 4000


def score(task, sample, parsed, ds, pair=None):
    if task == "condition_given":
        return paper.score_cg(pair, parsed, ds)
    scorer = {"detection": paper.score_detection, "e2e": paper.score_e2e, "e2e_open": open_eval.score_open}[task]
    return scorer(sample, parsed, ds)


def score_record(row):
    task = row["task"]
    gold = row["gold"]
    sample = {"gold": {"ambiguous_conditions": gold} if task == "detection" else gold}
    return score(task, sample, row.get("parsed"), row["dataset"], gold if task == "condition_given" else None)


def row_key(row):
    return tuple(row.get(k) for k in ("dataset", "task", "model", "id", "pair_index"))


def build_jobs(args):
    datasets = {}
    if args.scale:
        # Same query IDs, order, wording, condition definitions and schema across scales.
        if len(args.datasets) != 1:
            raise ValueError("--scale requires exactly one dataset")
        ds = args.datasets[0]
        reference = None
        for size in (1000, 5000, 20000):
            rows = read_rows(args.data / str(size) / f"{ds}.jsonl")
            if not rows:
                raise ValueError(f"empty scale {size}")
            for row in rows:
                t = row["table"]
                if not isinstance(t, dict) or len(t.get("rows", [])) != size:
                    raise ValueError(f"{row['id']} needs {size} actual structured rows")
            shape = [(r["id"], r["query"], r["table"].get("header"),
                      r["gold"]["ambiguous_conditions"],
                      [p["conditions"] for p in r["gold"]["condition_answer_pairs"]]) for r in rows]
            if reference is not None and shape != reference:
                raise ValueError("scale inputs must align in ID, order, query, schema and conditions")
            reference = shape
            datasets[(ds, size)] = rows
    else:
        for ds in args.datasets:
            datasets[(ds, None)] = read_rows(args.data / f"{ds}.jsonl")

    for (ds, size), rows in datasets.items():
        if not rows or len({r["id"] for r in rows}) != len(rows):
            raise ValueError(f"{ds}: empty data or duplicate IDs")
        for sample in rows[:args.limit]:
            valid_sample(sample)
            if is_answer_table(prompts.safe_get_table(sample)) and not args.legacy_lookup:
                raise ValueError(f"{ds}/{sample['id']}: condition-answer input requires source context")
            for task in args.tasks:
                pairs = sample["gold"]["condition_answer_pairs"]
                indices = range(len(pairs)) if task == "condition_given" else [None]
                for pi in indices:
                    system, prompt, max_tokens = prompt_for(task, sample, pi)
                    yield ds, size, sample, task, pi, system, prompt, max_tokens


def model_config(args):
    config = json.loads(args.models.read_text()) if args.models else {}
    original_endpoint = paper.E.model_endpoint
    def endpoint(model):
        if model not in config:
            if not model.startswith(("gpt-", "qwen", "deepseek")):
                raise ValueError(f"configure a compatible endpoint for {model}")
            return original_endpoint(model)
        value = config[model]
        return paper.E.EndpointConfig(value["key_env"], "", value["base_url_env"],
                                      value["base_url"], value.get("extra_payload", {}))
    paper.E.model_endpoint = endpoint
    return {m: endpoint(m) for m in args.model}


def run(args):
    endpoints = model_config(args)
    code_hash = digest([Path(__file__).read_text()] + [
        (Path(__file__).parent / "scripts" / name).read_text()
        for name in ("prompts.py", "evaluate.py", "evaluate_open.py", "common.py", "config.py")
    ])
    batch = collections.defaultdict(lambda: {"jobs": 0, "prompt_chars": 0})
    jobs, previews = [], {}
    for ds, size, sample, task, pi, system, prompt, limit in build_jobs(args):
        group = batch[(ds, size, task)]
        group["jobs"] += len(args.model)
        group["prompt_chars"] += len(prompt) * len(args.model)
        jobs.append((ds, size, sample, task, pi, digest([system, prompt]), limit, len(prompt)))
        if args.preview:
            previews.setdefault((ds, size, task), {"dataset": ds, "table_rows": size, "task": task,
                                                    "id": sample["id"], "system": system, "prompt": prompt})
    plan = [{"dataset": d, "table_rows": s, "task": t, **v} for (d, s, t), v in batch.items()]
    save_json(args.out / "plan.json", plan)
    if args.preview:
        save_rows(args.out / "prompt_previews.jsonl", previews.values())
    print(f"{len(jobs) * len(args.model):,} planned requests", flush=True)
    if not args.execute:
        return
    if args.max_calls is None:
        raise ValueError("--execute requires an explicit --max-calls budget")
    for model, ep in endpoints.items():
        if not os.getenv(ep.api_key_env):
            raise ValueError(f"{model}: missing environment variable {ep.api_key_env}")

    manifest = {"code_hash": code_hash, "models": args.model, "temperature": args.temperature,
                "retries": args.retries, "timeout": args.timeout, "legacy_lookup": args.legacy_lookup,
                "endpoints": {m: {"base_url": os.getenv(ep.base_url_env, ep.default_base_url),
                                  "extra_payload": ep.extra_payload}
                              for m, ep in endpoints.items()},
                "jobs_hash": digest([(d, s, r["id"], digest(r["gold"]), t, i, h, lim)
                                     for d, s, r, t, i, h, lim, _ in jobs])}
    manifest_path = args.out / "run_manifest.json"
    result_path = args.out / "predictions.jsonl"
    with (args.out / "run.lock").open("a") as lock:
        import fcntl
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if manifest_path.exists() and json.loads(manifest_path.read_text()) != manifest:
            raise ValueError("run configuration changed. Choose a fresh --out directory")
        if result_path.exists() and not manifest_path.exists():
            raise ValueError("existing predictions have no run manifest")
        done = {(row_key(r), r.get("table_rows")) for r in read_rows(result_path) if r["status"] == "ok"} if result_path.exists() else set()
        pending = [(j, m) for j in jobs for m in args.model
                   if ((j[0], j[3], m, j[2]["id"], j[4]), j[1]) not in done]
        max_attempts = len(pending) * (args.retries + 1)
        if max_attempts > args.max_calls:
            raise ValueError(f"{len(pending)} pending jobs can use up to {max_attempts} attempts, above --max-calls")
        save_json(manifest_path, manifest)
        started = time.perf_counter()
        with result_path.open("a", encoding="utf-8") as output:
            for (ds, size, sample, task, pi, prompt_hash, limit, chars), model in pending:
                system, prompt, _ = prompt_for(task, sample, pi)
                gold = sample["gold"]
                if task == "detection":
                    gold = gold["ambiguous_conditions"]
                elif task == "condition_given":
                    gold = gold["condition_answer_pairs"][pi]
                res = call(model, system, prompt, args, limit)
                scores = guarded_score(task, sample, res, ds, gold)
                row = {"dataset": ds, "task": task, "model": model, "id": sample["id"],
                       "pair_index": pi, "query": sample["query"], "gold": gold, "table_rows": size,
                       "context_hash": digest(sample["table"]), "prompt_hash": prompt_hash,
                       "max_tokens": limit, "temperature": args.temperature,
                       "prompt_chars": chars, **res, "scores": scores}
                output.write(canonical(row) + "\n")
                output.flush()
        wall = time.perf_counter() - started
        timing = {"jobs": len(pending), "wall_seconds": wall,
                  "jobs_per_second": len(pending) / wall if wall else None}
        with (args.out / "batch_timing.jsonl").open("a", encoding="utf-8") as output:
            output.write(canonical(timing) + "\n")


def call(model, system, prompt, args, limit):
    call_args = argparse.Namespace(max_tokens=limit, temperature=args.temperature, timeout=args.timeout)
    attempts = []
    started = time.perf_counter()
    for n in range(args.retries + 1):
        begin = time.perf_counter()
        try:
            payload = paper.E.chat_completion(model, system, prompt, call_args)
            raw = paper.E.response_text(payload)
            parsed, error = paper.E.parse_json_output(raw)
            if not isinstance(parsed, dict):
                parsed, error = None, error or "top-level JSON is not an object"
            attempts.append({"attempt": n + 1, "status": "ok", "ms": (time.perf_counter() - begin) * 1000})
            return {"status": "ok", "raw": raw, "parsed": parsed, "parse_error": error,
                    "finish_reason": (payload.get("choices") or [{}])[0].get("finish_reason"),
                    "usage": payload.get("usage"), "elapsed_ms": payload.get("_elapsed_ms"),
                    "total_elapsed_ms": (time.perf_counter() - started) * 1000, "attempts": attempts}
        except (OSError, ValueError, RuntimeError) as exc:
            status_code = getattr(exc, "code", None)
            attempts.append({"attempt": n + 1, "status": "failed", "error": type(exc).__name__,
                             "http_status": status_code, "ms": (time.perf_counter() - begin) * 1000})
            if n == args.retries or (status_code and status_code < 500 and status_code not in (408, 429)):
                break
            time.sleep(min(30, 2 ** n))
    return {"status": "failed", "raw": "", "parsed": None, "usage": None,
            "total_elapsed_ms": (time.perf_counter() - started) * 1000, "attempts": attempts}


def guarded_score(task, sample, res, ds, gold):
    try:
        return score(task, sample, res["parsed"], ds, gold)
    except (TypeError, AttributeError, KeyError, ValueError) as exc:
        res["schema_error"] = type(exc).__name__
        return score(task, sample, None, ds, gold)


def load_results(path):
    if path.suffix != ".zip":
        yield from read_rows(path)
        return
    with zipfile.ZipFile(path) as archive:
        for name in sorted(archive.namelist()):
            if name.endswith("_results.jsonl"):
                with archive.open(name) as file:
                    yield from jsonl(file)


def numeric_parts(value):
    m = NUMBER.fullmatch(str(value).strip().replace(",", "").replace("−", "-"))
    if m is None:
        return None
    return m["currency"], float(m["value"]), bool(m["percent"])


def scalar_guard(pred, pair, ds):
    original = ORIGINAL_MATCH(pred, pair, ds)
    if not original or ds == "retail":
        return original
    p = numeric_parts(pred)
    aliases = paper.golds_for(pair)
    if p is None or any(numeric_parts(g) is None for g in aliases):
        return original
    for alias in aliases:
        g = numeric_parts(alias)
        if (p[0], p[2]) == (g[0], g[2]) and math.isclose(p[1], g[1], rel_tol=1e-3, abs_tol=1e-3):
            return True
    return False


def failure_flags(row, scores):
    flags = []
    task = row["task"]
    if row.get("status") != "ok":
        return ["api_failure"]
    if row.get("finish_reason") == "length":
        flags.append("truncated")
    if not scores.get("json_valid") or row.get("schema_error"):
        return flags + ["invalid_json_or_schema"]
    if scores.get("dimension_f1", 1) < 1:
        flags.append("dimension_mismatch")
    if scores.get("condition_f1_norm", 1) < 1:
        flags.append("interpretation_mismatch")
    if scores.get("coverage_norm", 1) < 1:
        flags.append("missing_or_unmatched_condition")
    if scores.get("answer_relaxed_norm", 1) < scores.get("coverage_norm", 1) or (
        task == "condition_given" and scores.get("answer_relaxed", 1) < 1
    ):
        flags.append("answer_mismatch")
    if task == "e2e_open":
        if not scores.get("multi_answer_rate"):
            flags.append("multiple_readings_not_surfaced")
        if scores.get("gold_answer_recall", 1) < 1:
            flags.append("open_answer_recall_incomplete")
    return flags


def percentile(values, fraction):
    return round(statistics.quantiles(values, n=100, method="inclusive")[round(fraction * 100) - 1], 4) if len(values) > 1 else (values[0] if values else None)


def summarize_scores(groups, prices):
    report = []
    for (ds, size, task, model), data in sorted(groups.items(), key=lambda kv: str(kv[0])):
        metrics = {k: round(100 * statistics.mean(v), 4) for k, v in data["metrics"].items()}
        latency = data["latency"]
        total = data["total_latency"]
        rate = prices.get(model)
        token_cost = None
        if rate and data["billable_usage_n"] == data["n"]:
            token_cost = round((data["tokens"]["prompt_tokens"] * rate["input_per_million"]
                                + data["tokens"]["completion_tokens"] * rate["output_per_million"]) / 1e6, 6)
        report.append({"dataset": ds, "table_rows": size, "task": task, "model": model,
                       "n": data["n"], "failures": data["failed"], "metrics_pct": metrics,
                       "latency_n": len(latency), "request_p50_ms": statistics.median(latency) if latency else None,
                       "request_p95_ms": percentile(latency, .95), "job_p95_ms": percentile(total, .95),
                       "tokens": dict(data["tokens"]), "usage_n": data["usage_n"],
                       "estimated_usd": token_cost, "logged_attempts": data["attempts"] or None,
                       "logged_retries": data["retries"] if data["attempts"] else None, "truncated": data["truncated"],
                       "failures_by_type": dict(data["flags"])})
    return report


def analyze(args):
    best = {}
    for row in load_results(args.results):
        key = (row_key(row), row.get("table_rows"))
        if key not in best or row["status"] == "ok":
            best[key] = row
    if not best:
        raise ValueError("no results found")
    groups = collections.defaultdict(lambda: {
        "metrics": collections.defaultdict(list), "latency": [], "total_latency": [],
        "flags": collections.Counter(), "tokens": collections.Counter(),
        "usage_n": 0, "billable_usage_n": 0, "n": 0, "failed": 0,
        "attempts": 0, "retries": 0, "truncated": 0,
    })
    discrepancy, variants = collections.Counter(), collections.Counter()
    changed_rows = 0
    examples = collections.Counter()
    failures = []
    clusters = collections.defaultdict(lambda: collections.defaultdict(list))
    rescored_rows = []
    for row in best.values():
        group = (row["dataset"], row.get("table_rows"), row["task"], row["model"])
        data = groups[group]
        scores = row["scores"]
        if args.rescore:
            try:
                rescored = score_record(row)
                for name, value in rescored.items():
                    if name in scores and not math.isclose(value, scores[name], abs_tol=1e-8):
                        discrepancy[(group, name)] += 1
                if args.scalar_audit:
                    paper.ans_relaxed = scalar_guard
                    try:
                        sensitivity = score_record(row)
                    finally:
                        paper.ans_relaxed = ORIGINAL_MATCH
                    for name in PRIMARY[row["task"]]:
                        if rescored[name] != sensitivity[name]:
                            variants[(group, name)] += 1
                    if any(rescored[name] != sensitivity[name] for name in PRIMARY[row["task"]]):
                        changed_rows += 1
                        failures.append({"category": "scalar_match_sensitivity", **row,
                                         "rescored": rescored, "scalar_guard_scores": sensitivity})
                scores = rescored
                rescored_rows.append({**row, "scores": scores})
            except (TypeError, AttributeError, KeyError, ValueError):
                discrepancy[(group, "schema_error")] += 1
        for metric in PRIMARY[row["task"]]:
            if metric in scores:
                data["metrics"][metric].append(scores[metric])
        if row["task"] == "condition_given" and "answer_relaxed" in scores:
            clusters[group][row["id"]].append(scores["answer_relaxed"])
        data["n"] += 1
        data["failed"] += row["status"] != "ok"
        if row["status"] == "ok" and isinstance(row.get("elapsed_ms"), (int, float)):
            data["latency"].append(row["elapsed_ms"])
        if isinstance(row.get("total_elapsed_ms"), (int, float)):
            data["total_latency"].append(row["total_elapsed_ms"])
        usage = row.get("usage") or {}
        data["usage_n"] += bool(usage)
        data["billable_usage_n"] += all(isinstance(usage.get(k), int) for k in ("prompt_tokens", "completion_tokens"))
        if row.get("attempts"):
            data["attempts"] += len(row["attempts"])
            data["retries"] += len(row["attempts"]) - 1
        data["truncated"] += row.get("finish_reason") == "length"
        for k in ("prompt_tokens", "completion_tokens", "total_tokens"):
            if isinstance(usage.get(k), int):
                data["tokens"][k] += usage[k]
        for flag in failure_flags(row, scores):
            data["flags"][flag] += 1
            key = (group, flag)
            if examples[key] < args.examples:
                failures.append({"category": flag, **row, "scores": scores})
                examples[key] += 1
    prices = json.loads(args.prices.read_text()) if args.prices else {}
    summary = summarize_scores(groups, prices)
    averaging = []
    for (ds, size, task, model), q in clusters.items():
        pair = statistics.mean(v for values in q.values() for v in values)
        query = statistics.mean(statistics.mean(values) for values in q.values())
        averaging.append({"dataset": ds, "table_rows": size, "model": model, "queries": len(q),
                          "pair_mean_pct": round(100 * pair, 4), "query_mean_pct": round(100 * query, 4),
                          "query_minus_pair_pp": round(100 * (query - pair), 4)})
    save_json(args.out / "metrics.json", summary)
    save_json(args.out / "condition_given_averaging.json", averaging)
    save_rows(args.out / "failure_examples.jsonl", failures)
    if args.rescore:
        save_json(args.out / "rescoring_audit.json", {
            "records": len(best),
            "rows_changed_by_scalar_guard": changed_rows,
            "paper_score_differences": [[*g, k, n] for (g, k), n in discrepancy.items()],
            "scalar_guard_changes": [[*g, k, n] for (g, k), n in variants.items()],
        })
        if args.write_rescored:
            save_rows(args.out / "rescored_predictions.jsonl", rescored_rows)
    print(f"Analyzed {len(best):,} jobs in {len(groups)} groups")


def compare(args):
    # Compare matched query/pair instances, with confidence intervals clustered by query.
    def index(path, model, task):
        out = {}
        for row in load_results(path):
            if row["model"] != model or row["task"] != task:
                continue
            key = (row["dataset"], row.get("table_rows"), row["id"], row.get("pair_index"))
            if key not in out or row["status"] == "ok":
                out[key] = row
        return out
    right_task = "e2e_open" if args.ablation else args.task
    left, right = index(args.left, args.left_model, args.task), index(args.right, args.right_model, right_task)
    same_archive = args.left.resolve() == args.right.resolve() and args.left.suffix == ".zip"
    differences = collections.defaultdict(lambda: collections.defaultdict(list))
    mismatch = 0
    for key in sorted(left.keys() & right.keys(), key=str):
        a, b = left[key], right[key]
        if a["query"] != b["query"] or a["gold"] != b["gold"] or (
            not same_archive and (
                not a.get("context_hash") or a.get("context_hash") != b.get("context_hash")
                or (not args.ablation and (not a.get("prompt_hash") or a["prompt_hash"] != b.get("prompt_hash")))
                or a.get("temperature") != b.get("temperature")
                or a.get("max_tokens") != b.get("max_tokens")
            )
        ):
            mismatch += 1
            continue
        if args.ablation:
            # Both output formats provide answers[].answer; use the same scorer on both.
            a_scores = open_eval.score_open({"gold": a["gold"]}, a.get("parsed"), a["dataset"])
            b_scores = open_eval.score_open({"gold": b["gold"]}, b.get("parsed"), b["dataset"])
            metrics = ("multi_answer_rate", "gold_answer_recall")
        else:
            a_scores, b_scores = a["scores"], b["scores"]
            metrics = PRIMARY[args.task]
        for metric in metrics:
            differences[(*key[:2], metric)][key[2]].append(b_scores[metric] - a_scores[metric])
    if not differences:
        raise ValueError("no comparable matched predictions")
    rng = random.Random(args.seed)
    report = []
    for (ds, size, metric), clusters in sorted(differences.items(), key=lambda kv: str(kv[0])):
        entries = [(sum(v), len(v)) for v in clusters.values()]
        point = sum(v for v, _ in entries) / sum(n for _, n in entries)
        boots = []
        for _ in range(args.resamples):
            sample = rng.choices(entries, k=len(entries))
            boots.append(100 * sum(v for v, _ in sample) / sum(n for _, n in sample))
        report.append({"dataset": ds, "table_rows": size, "metric": metric,
                       "matched_queries": len(entries), "matched_jobs": sum(n for _, n in entries),
                       "right_minus_left_pp": round(100 * point, 4),
                       "ci95_pp": [percentile(boots, .025), percentile(boots, .975)]})
    save_json(args.out, {"left_model": args.left_model, "right_model": args.right_model,
                         "left_task": args.task, "right_task": right_task, "unmatched_left": len(left.keys() - right.keys()),
                         "unmatched_right": len(right.keys() - left.keys()), "incompatible": mismatch,
                         "historical_context_assumed_from_same_release": same_archive, "results": report})


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    commands = cli.add_subparsers(dest="command", required=True)
    prep = commands.add_parser("prepare")
    prep.add_argument("--inputs", type=Path, required=True)
    prep.add_argument("--out", type=Path, required=True)
    prep.add_argument("--file", action="append", default=[], metavar="DATASET=FILENAME")
    prep.add_argument("--seed", type=int, default=20261107)
    prep.set_defaults(action=prepare)

    attach = commands.add_parser("attach-context")
    attach.add_argument("--sample", type=Path, required=True)
    attach.add_argument("--evidence", type=Path, required=True)
    attach.add_argument("--out", type=Path, required=True)
    attach.set_defaults(action=attach_context)

    runner = commands.add_parser("run")
    runner.add_argument("--data", type=Path, required=True)
    runner.add_argument("--out", type=Path, required=True)
    runner.add_argument("--datasets", nargs="+", required=True)
    runner.add_argument("--tasks", nargs="+", choices=TASKS, default=list(TASKS))
    runner.add_argument("--model", nargs="+", required=True)
    runner.add_argument("--models", type=Path, help="optional OpenAI-compatible endpoint map")
    runner.add_argument("--limit", type=int)
    runner.add_argument("--scale", action="store_true")
    runner.add_argument("--legacy-lookup", action="store_true", help="only for reproducing old input setting")
    runner.add_argument("--preview", action="store_true")
    runner.add_argument("--execute", action="store_true")
    runner.add_argument("--max-calls", type=int)
    runner.add_argument("--temperature", type=float, default=0.0)
    runner.add_argument("--timeout", type=float, default=180)
    runner.add_argument("--retries", type=int, default=0)
    runner.set_defaults(action=run)

    analysis = commands.add_parser("analyze")
    analysis.add_argument("--results", type=Path, required=True)
    analysis.add_argument("--out", type=Path, required=True)
    analysis.add_argument("--examples", type=int, default=3)
    analysis.add_argument("--prices", type=Path, help="model to input_per_million/output_per_million USD")
    analysis.add_argument("--rescore", action="store_true")
    analysis.add_argument("--scalar-audit", action="store_true")
    analysis.add_argument("--write-rescored", action="store_true")
    analysis.set_defaults(action=analyze)

    comparison = commands.add_parser("compare")
    comparison.add_argument("--left", type=Path, required=True)
    comparison.add_argument("--right", type=Path, required=True)
    comparison.add_argument("--left-model", required=True)
    comparison.add_argument("--right-model", required=True)
    comparison.add_argument("--task", choices=TASKS, required=True)
    comparison.add_argument("--ablation", action="store_true", help="compare hinted E2E against E2E-open for one model")
    comparison.add_argument("--resamples", type=int, default=1000)
    comparison.add_argument("--seed", type=int, default=20261107)
    comparison.add_argument("--out", type=Path, required=True)
    comparison.set_defaults(action=compare)
    args = cli.parse_args()
    if args.command == "run" and (args.retries < 0 or args.timeout <= 0 or (args.limit is not None and args.limit <= 0)
                                   or len(set(args.model)) != len(args.model) or len(set(args.tasks)) != len(args.tasks)
                                   or len(set(args.datasets)) != len(args.datasets)):
        cli.error("use positive limits/timeouts and unique model/task/dataset lists")
    if args.command == "analyze" and (args.scalar_audit or args.write_rescored) and not args.rescore:
        cli.error("--scalar-audit and --write-rescored require --rescore")
    if args.command == "compare" and args.resamples < 2:
        cli.error("--resamples must be at least 2")
    if args.command == "compare" and args.ablation and (args.task != "e2e" or args.left_model != args.right_model):
        cli.error("--ablation requires --task e2e and the same left/right model")
    args.action(args)


if __name__ == "__main__":
    main()

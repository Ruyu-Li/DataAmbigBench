# Main experiment: token and request-latency summary

**Source coverage.** Five models (GPT-5 mini, Gemini 3.1/3.5 Flash-Lite, Claude Haiku 4.5/5.5) each have complete final request records for eight subsets: SEC, AmbigDocs, OpinionQA, Online Retail II, USC, SF311, NYC311 Geography, and TAT-QA. GPT-4.1 mini has complete records for the first seven subsets, with no TAT-QA record in these supplied sources. NASA POWER is not included. Claude Sonnet 5 and DeepSeek V4 Flash are excluded from this comparable table because the supplied source snapshot is incomplete for Sonnet and only contains NYC311 for DeepSeek.

**Interpretation.** Values are weighted by recorded API requests: Condition-Given has one request per gold pair, while the other tasks have one request per query. Input tokens are returned `prompt_tokens` (including any cached prompt tokens in providers that report them), output tokens are returned `completion_tokens`. P50 and P95 are quantiles of individual successful HTTP request durations, with P95 using nearest rank. No total wall-clock, concurrency throughput, or cost is inferred.

| Model | Task | Final requests | Usage/latency recorded | Avg input tokens/request | Avg output tokens/request | Request P50 (s) | Request P95 (s) |
|---|---|---:|---:|---:|---:|---:|---:|
| GPT-4.1 mini | Detection | 1,400 | 1,400 | 1,618.0 | 93.0 | 1.11 | 1.75 |
| GPT-4.1 mini | Condition-Given | 3,966 | 3,966 | 2,134.6 | 126.1 | 1.09 | 3.14 |
| GPT-4.1 mini | Hinted E2E | 1,400 | 1,400 | 1,796.0 | 383.9 | 3.06 | 6.31 |
| GPT-4.1 mini | E2E-open | 1,400 | 1,400 | 1,136.0 | 114.1 | 1.37 | 2.29 |
| GPT-5 mini | Detection | 1,600 | 1,600 | 1,557.0 | 286.7 | 3.94 | 7.15 |
| GPT-5 mini | Condition-Given | 4,462 | 4,461 | 2,032.3 | 184.3 | 2.10 | 6.75 |
| GPT-5 mini | Hinted E2E | 1,600 | 1,599 | 1,732.7 | 602.5 | 6.87 | 14.50 |
| GPT-5 mini | E2E-open | 1,600 | 1,600 | 1,075.0 | 158.8 | 2.33 | 4.11 |
| Gemini 3.1 Flash-Lite | Detection | 1,600 | 1,600 | 1,903.1 | 112.5 | 0.85 | 1.28 |
| Gemini 3.1 Flash-Lite | Condition-Given | 4,462 | 4,462 | 2,560.5 | 183.9 | 0.93 | 2.05 |
| Gemini 3.1 Flash-Lite | Hinted E2E | 1,600 | 1,600 | 2,105.1 | 388.0 | 1.35 | 2.06 |
| Gemini 3.1 Flash-Lite | E2E-open | 1,600 | 1,600 | 1,390.1 | 169.3 | 0.94 | 1.77 |
| Gemini 3.5 Flash-Lite | Detection | 1,600 | 1,600 | 1,903.1 | 93.1 | 0.71 | 1.02 |
| Gemini 3.5 Flash-Lite | Condition-Given | 4,462 | 4,462 | 2,560.5 | 175.3 | 0.82 | 1.63 |
| Gemini 3.5 Flash-Lite | Hinted E2E | 1,600 | 1,600 | 2,105.1 | 423.6 | 1.26 | 1.89 |
| Gemini 3.5 Flash-Lite | E2E-open | 1,600 | 1,600 | 1,390.1 | 155.1 | 0.82 | 1.29 |
| Claude Haiku 4.5 | Detection | 1,600 | 1,600 | 1,818.7 | 151.0 | 1.47 | 2.97 |
| Claude Haiku 4.5 | Condition-Given | 4,462 | 4,462 | 2,359.2 | 207.6 | 1.63 | 5.41 |
| Claude Haiku 4.5 | Hinted E2E | 1,600 | 1,600 | 2,032.7 | 588.6 | 4.24 | 10.74 |
| Claude Haiku 4.5 | E2E-open | 1,600 | 1,600 | 1,238.7 | 187.9 | 1.79 | 4.81 |
| Claude Haiku 5.5 | Detection | 1,600 | 1,600 | 2,423.5 | 422.6 | 2.15 | 3.87 |
| Claude Haiku 5.5 | Condition-Given | 4,462 | 4,462 | 3,050.9 | 608.6 | 1.53 | 9.01 |
| Claude Haiku 5.5 | Hinted E2E | 1,600 | 1,600 | 2,702.5 | 1,343.4 | 4.30 | 14.14 |
| Claude Haiku 5.5 | E2E-open | 1,600 | 1,600 | 1,570.5 | 652.3 | 2.15 | 7.69 |

## Checks and limits

- The selection reconciles to 47 complete model–dataset groups, 54,476 distinct final task requests, and 188 model–dataset–task rows in the detailed CSV. The five fully covered models each have 9,262 requests; GPT-4.1 mini has 8,166 requests across seven datasets.
- GPT-5 mini has two Retail requests with a terminal prompt-policy rejection; they have no returned usage or HTTP latency. Its Condition-Given row uses 4,461/4,462 measured requests, and Hinted E2E uses 1,599/1,600. These records are not assigned zero tokens or zero latency.
- This is a summary of the selected final request record per job, not an attempt-inclusive billing ledger. Provider-specific retries may have consumed additional resources. Do not use total tokens as invoice totals.
- Request duration was logged across legacy serial and later parallel recovery runs. It is an observed request-latency distribution, not a controlled model-speed experiment; traffic, load, caching and tokenizer differences can affect comparisons.
- `efficiency_by_model_dataset_task.csv` preserves the 188 detailed rows, token-coverage counts, execution origins and per-task dataset results. `source_coverage.csv` identifies the source snapshot used for each model/dataset.

## Compact statement for the paper (draft)

Across eight benchmark subsets and four evaluation tasks, per-request token use and observed API latency vary substantially by task and model. Condition-Given requires a separate request for each gold interpretation, whereas detection and each E2E setting use one request per query. We therefore report request-weighted input/output tokens and median/P95 request latency separately by task. These figures characterize the resource use of the evaluated runs; they do not estimate deployment throughput or provider billing.

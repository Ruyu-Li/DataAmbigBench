# Table II 更新说明

## Overleaf 操作

1. 上传 `table2_detailed_results.tex` 到项目根目录。在 `eval.tex` 的 Results 小节保留一个 `\input{table2_detailed_results}`，表格标签沿用 `tab:main-results`。如果原先使用 `\input{main_results_5models}`，删掉该行。
2. 在当前 Overleaf 稿中搜索 “DeepSeek-V4-Flash results on NYC311 Geography”。删除该标题所在的整个独立表格环境和指向该表的重复介绍。若正文仍引用旧标签，把指向旧表的交叉引用改为 `Table~\ref{tab:main-results}` 的 Panel A。NYC311 DeepSeek 的五个原表数值已核对并转入该行。
3. 用 `manuscript_edits.patch` 核对 Experimental Setup、Metrics、Figure 3 图注、Results、Efficiency、摘要和结论。改动以可用的源稿快照为基准，逐段应用到当前 Overleaf 稿，保留当前稿的 Scalability 数据和其他后续修改。摘要、Results、Figure 3 和结论的汇总数字沿用原先参与汇总比较的五个模型。GPT-4.1 mini 的主表结果覆盖八个子集，Efficiency 分析中的记录覆盖七个。
4. 如果 `details.tex` 仍有旧的 Full Results 小节，删除该小节以及 `\input{full_results_5models}`，保留 Evaluation Details 和评分规则。全文查找 `app:full-results`、`tab:full-results` 和手写的 Table III / IV，表号使用对应的 `\ref{...}`。
5. 从头重新编译。检查大表两个部分共用 Table II，且 Efficiency 与 Scalability 的引用分别指向 `tab:efficiency-e2e` 和 `tab:scalability`。按当前稿确认跨栏位置与投稿页数。

## 数字口径

- Panel A 收录最终 1,600 题版本。原五模型 40 行数值沿用上一版详细表。GPT-4.1 mini 覆盖全部八个子集。TAT-QA 一行来自已与主表归档核对版本的原始全量结果，共 1,096 次请求。Hinted E2E 的两次 JSON 解析失败包含在 200 次请求的分母中。原 Table III 的 DeepSeek-V4-Flash 从逐题评分扩展为 NYC311 Geography 一整行。两个补入模型使用与其他行对应的评分字段。
- Panel B 收录 Ruyu 的 DeepSeek-V4-Flash，在旧版 4,498 题上的八个子集和已报告的五个平均值。使用原稿详细表的 Hinted E2E 栏位，其中 Acc. S/N 分别使用严格及归一化解释匹配。表内 Avg. 为八个旧版子集等权平均，破折号表示原稿未报告该列平均值。
- Panel A 的 NYC311 EN/RN 使用原版及修订的 geography scorer。Retail 的 Open AR 沿用 Figure 3 的评分，SC 沿用详细表的评分。原 Table III 的 NYC311 DeepSeek Hinted Acc. 71.1% 对应 Panel A 的 RN。

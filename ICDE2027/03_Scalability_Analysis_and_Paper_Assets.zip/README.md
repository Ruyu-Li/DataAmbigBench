# Scalability, offline analysis, and paper assets

- **scalability/colab_and_parallel** holds the exported Colab script and the parallel and resume runners.
- **scalability/colab_project** holds the pilot preparation, table scaling, audit, and a project ZIP with the filename expected by its Colab notebook. **scalability/dual_200** holds the 200-query workflow, its inputs and run scripts. The raw retail workbook and SF311 raw CSV expected by that workflow are external dependencies. The archived predictions and audit for Table V are in **scalability/table_v_outputs**. The exact runner revision used to produce Table V remains to be confirmed.
- **offline_analysis** holds the coverage audit and offline analysis of saved predictions.
- **paper** holds the efficiency CSVs, Table II sources and later DeepSeek revision, and the archived Overleaf figure PDFs. The standalone efficiency aggregation and Figure 2/3 generation code remains to be located.
- **historical_pilots** holds the NYC311 Geography and Online Retail II pilot scripts. The historical NASA POWER and WDI builders remain to be located.

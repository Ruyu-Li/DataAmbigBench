#!/usr/bin/env python3
"""Freeze TAT-QA reporting rules and audit model/task coverage without API calls."""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import sys
from pathlib import Path
from statistics import mean

TASKS = ("detection", "condition_given", "e2e", "e2e_open")


def load(path):
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def save_csv(path, rows, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def digest_file(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def attach_project(project):
    if not (project / "lab.py").is_file():
        raise FileNotFoundError(project / "lab.py")
    sys.path.insert(0, str(project))
    import lab
    return lab


def freeze(args):
    lab = attach_project(args.project)
    records = load(args.results)
    if len(records) != 1083 or len({r["id"] for r in records}) != 200:
        raise ValueError("Expected 1083 responses for the fixed 200-query TAT-QA")
    data = load(args.data)
    if len(data) != 200 or sum(len(r["gold"]["condition_answer_pairs"]) for r in data) != 483:
        raise ValueError("Expected 200 queries and 483 gold pairs")
    reported = collections.defaultdict(lambda: collections.defaultdict(list))
    for row in records:
        if row["dataset"] != "tatqa": raise ValueError(row["dataset"])
        for metric, value in row["scores"].items():
            if isinstance(value, (int, float)):
                reported[row["task"]][metric].append(value)
    baseline = {task: {m: round(100 * mean(v), 4) for m, v in metrics.items()}
                for task, metrics in reported.items()}

    # This diagnostic requires the exact same numeric policy already uploaded.
    spec = __import__("importlib.util", fromlist=["spec_from_file_location"]).spec_from_file_location(
        "tatqa_numeric_sensitivity", args.numeric_script)
    import importlib.util
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    old_match = lab.paper.ans_relaxed
    def alternative(pred, pair, ds=""):
        if old_match(pred, pair, ds): return True
        return ds == "tatqa" and any(mod.scalar_equal(pred, gold)[0]
                                      for gold in lab.paper.golds_for(pair))
    lab.paper.ans_relaxed = alternative
    detail = []
    try:
        for row in records:
            if row["task"] != "e2e": continue
            sample = {"gold": row["gold"]}
            pairs = row["gold"]["condition_answer_pairs"]
            parsed = row.get("parsed") if isinstance(row.get("parsed"), dict) else {}
            answers = [a for a in parsed.get("answers", [])
                       if isinstance(a, dict) and isinstance(a.get("conditions"), dict)]
            regular = lab.paper.score_e2e(sample, row.get("parsed"), "tatqa")["answer_relaxed_norm"]
            allowed = [a for a in answers if set(a["conditions"]) == set(pairs[0]["conditions"])]
            gt = [" ".join(str(v) for v in p["conditions"].values()) for p in pairs]
            pt = [" ".join(str(v) for v in p["conditions"].values()) for p in allowed]
            assignment = lab.paper.assign(gt, pt, "tatqa", lab.paper._term(sample))
            consistent = sum(alternative(allowed[j].get("answer", ""), pairs[i], "tatqa")
                             for i, j in assignment.items()) / len(pairs)
            detail.append({"id": row["id"],
                           "main_paper_score": row["scores"]["answer_relaxed_norm"],
                           "numeric_diagnostic": regular,
                           "dimension_consistent_diagnostic": consistent,
                           "predicted_dimension_keys": json.dumps([sorted(a["conditions"]) for a in answers])})
    finally:
        lab.paper.ans_relaxed = old_match
    assert len(detail) == 200
    sensitivity = json.loads(args.sensitivity.read_text(encoding="utf-8"))
    policy = {
        "status": "frozen_for_reporting",
        "main_metric_policy": "Original paper scorer (scripts/evaluate.py and evaluate_open.py), applied to repaired gold; retain invalid JSON as zero",
        "numeric_sensitivity": "Diagnostic only; never substitute for the main metric or select model-specific aliases",
        "dimension_consistent_e2e": "Diagnostic only; condition key set must equal the gold key set",
        "data_sha256": digest_file(args.data),
        "results_sha256": digest_file(args.results),
        "paper_metrics_pct": baseline,
        "numeric_sensitivity_pct": sensitivity,
        "dimension_consistent_e2e_pct": round(100 * mean(x["dimension_consistent_diagnostic"] for x in detail), 4),
        "e2e_dimension_disagreement_cases": sum(x["numeric_diagnostic"] > x["dimension_consistent_diagnostic"] for x in detail),
        "review_cases": ["tatqa_000607: 5.85% vs 6% is whole-percent rounding in sensitivity only",
                         "tatqa_000467: 0.615 vs 0.62 is rounded equivalent in sensitivity only"],
    }
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "tatqa_scoring_policy.json").write_text(json.dumps(policy, indent=2, ensure_ascii=False), encoding="utf-8")
    save_csv(args.out / "tatqa_e2e_dimension_diagnostic.csv", detail, list(detail[0]))
    print("Frozen main paper metrics:", {t: {k:v for k,v in m.items() if k in
          ("dimension_f1", "condition_f1_norm", "answer_relaxed", "answer_relaxed_norm", "multi_answer_rate", "gold_answer_recall", "single_answer_correct")}
          for t,m in baseline.items()})
    print("Dimension-consistent E2E diagnostic:", policy["dimension_consistent_e2e_pct"])
    print("E2E cases whose answer score exceeds dimension-consistent score:", policy["e2e_dimension_disagreement_cases"])
    print("Policy:", args.out / "tatqa_scoring_policy.json")


def planned_jobs(lab, ds, rows):
    for r in rows:
        for task in TASKS:
            indices = range(len(r["gold"]["condition_answer_pairs"])) if task == "condition_given" else [None]
            for pi in indices:
                system, prompt, limit = lab.prompt_for(task, r, pi)
                gold = r["gold"]["ambiguous_conditions"] if task == "detection" else (
                    r["gold"]["condition_answer_pairs"][pi] if task == "condition_given" else r["gold"])
                yield (ds, task, r["id"], pi), {
                    "dataset": ds, "task": task, "id": r["id"], "pair_index": pi,
                    "query": r["query"], "gold": gold,
                    "context_hash": lab.digest(r["table"]),
                    "prompt_hash": lab.digest([system, prompt]), "max_tokens": limit,
                }


def rank(row):
    return (row.get("status") == "ok" and isinstance(row.get("parsed"), dict) and
            not row.get("schema_error") and row.get("finish_reason") != "length",
            row.get("status") == "ok")


def coverage(args):
    lab = attach_project(args.project)
    cfg = json.loads(args.config.read_text(encoding="utf-8"))
    ids = [c["id"] for c in cfg if c.get("enabled", True)]
    if len(ids) != len(set(ids)): raise ValueError("Duplicate model IDs in config")
    datasets = ["sec", "ambigdocs", "opinionqa", "retail", "usc", "sf311", "nyc311", "tatqa"]
    expected = {}
    counts = collections.Counter()
    dataset_hashes = {}
    for ds in datasets:
        path = (args.tatqa_data if ds == "tatqa" else args.project / "data" / f"{ds}.jsonl")
        rows = load(path)
        if len(rows) != 200 or len({r["id"] for r in rows}) != 200:
            raise ValueError(f"{ds} must have 200 unique queries: {path}")
        dataset_hashes[ds] = lab.digest(rows)
        jobs = list(planned_jobs(lab, ds, rows))
        for c in cfg:
            if not c.get("enabled", True): continue
            model = c["id"]
            if ds == "tatqa":
                if c.get("datasets") and "tatqa" not in c["datasets"]: continue
            elif ds not in c.get("datasets", datasets[:7]):
                continue
            for jkey, entry in jobs:
                expected[(model,) + jkey] = entry
                counts[(model, ds, entry["task"])] += 1
    assert expected

    files = set()
    for root in args.roots:
        if root.is_file() and root.suffix == ".jsonl": files.add(root)
        elif root.is_dir():
            files.update(p for p in root.rglob("*.jsonl") if
                         "prediction" in p.name.lower() or p.name.lower().endswith("results.jsonl"))
    files.add(args.tatqa_results)
    best = {}
    inspected = collections.Counter()
    rejected = collections.Counter()
    input_mismatch = []
    for path in sorted(files):
        if not path.is_file(): continue
        with path.open(encoding="utf-8-sig") as source:
          for line_no, line in enumerate(source, 1):
            if not line.strip(): continue
            try: row = json.loads(line)
            except json.JSONDecodeError:
                rejected["corrupt_jsonl_lines"] += 1
                continue
            if not isinstance(row, dict):
                rejected["non_object_rows"] += 1
                continue
            inspected[str(path)] += 1
            key = (row.get("model"), row.get("dataset"), row.get("task"), row.get("id"), row.get("pair_index"))
            e = expected.get(key)
            if not e:
                rejected["not_in_plan"] += 1
                continue
            mismatches = [field for field in ("query", "context_hash", "prompt_hash", "gold", "max_tokens")
                          if row.get(field) != e[field]]
            if mismatches:
                rejected["input_or_prompt_mismatch"] += 1
                if len(input_mismatch) < 50:
                    input_mismatch.append({"file": str(path), "model": key[0], "dataset": key[1],
                                           "task": key[2], "id": key[3], "pair_index": key[4],
                                           "mismatched_fields": ";".join(mismatches)})
                continue
            if key not in best or rank(row) > rank(best[key][0]): best[key] = (row, path)
    report = collections.defaultdict(lambda: collections.Counter())
    missing = []
    for key, e in expected.items():
        model, ds, task, sid, pi = key
        group = report[(model, ds, task)]
        group["expected"] += 1
        chosen = best.get(key)
        if not chosen:
            reason = "missing"
        else:
            row, path = chosen
            group["recorded_matching_input"] += 1
            reason = ""
            if row.get("status") == "ok": group["api_ok"] += 1
            if row.get("status") != "ok": reason = "api_failed"
            elif not isinstance(row.get("parsed"), dict) or row.get("schema_error"):
                reason = "invalid_json_or_schema"
            elif row.get("finish_reason") == "length": reason = "truncated"
        if reason:
            group[reason] += 1
            missing.append({"model": model, "dataset": ds, "task": task, "id": sid,
                            "pair_index": pi, "reason": reason})
        else: group["usable"] += 1
    summary = []
    for (model, ds, task), cnt in sorted(report.items()):
        row = {"model": model, "dataset": ds, "task": task, "expected": cnt["expected"],
               "recorded_matching_input": cnt["recorded_matching_input"],
               "api_ok": cnt["api_ok"], "usable": cnt["usable"],
               "missing": cnt["missing"], "api_failed": cnt["api_failed"],
               "invalid_json_or_schema": cnt["invalid_json_or_schema"],
               "truncated": cnt["truncated"],
               "state": "missing_or_api_failed" if cnt["api_ok"] != cnt["expected"] else
                        "complete_with_output_issues" if cnt["usable"] != cnt["expected"] else
                        "complete_clean"}
        summary.append(row)
    args.out.mkdir(parents=True, exist_ok=True)
    save_csv(args.out / "model_dataset_task_coverage.csv", summary, list(summary[0]))
    save_csv(args.out / "pending_requests.csv", missing,
             ["model", "dataset", "task", "id", "pair_index", "reason"])
    missing_or_failed = [x for x in missing if x["reason"] in {"missing", "api_failed"}]
    save_csv(args.out / "only_missing_or_api_failed.csv", missing_or_failed,
             ["model", "dataset", "task", "id", "pair_index", "reason"])
    save_csv(args.out / "input_mismatch_examples.csv", input_mismatch,
             ["file", "model", "dataset", "task", "id", "pair_index", "mismatched_fields"])
    compact = collections.defaultdict(lambda: collections.Counter())
    for row in summary:
        c = compact[(row["model"], row["dataset"])]
        c["expected"] += row["expected"]
        c["api_ok"] += row["api_ok"]
        c["usable"] += row["usable"]
        c["missing"] += row["missing"]
        c["invalid_json_or_schema"] += row["invalid_json_or_schema"]
        c["api_failed"] += row["api_failed"]
    grid = [{"model": m, "dataset": d, "expected": c["expected"],
             "api_ok": c["api_ok"], "usable": c["usable"],
             "missing": c["missing"], "invalid_json_or_schema": c["invalid_json_or_schema"],
             "api_failed": c["api_failed"],
             "state": "missing_or_api_failed" if c["api_ok"] != c["expected"] else
                      "complete_with_output_issues" if c["usable"] != c["expected"] else
                      "complete_clean"}
            for (m,d),c in sorted(compact.items())]
    save_csv(args.out / "model_dataset_grid.csv", grid, list(grid[0]))
    meta = {"expected_model_dataset_cells": len(grid),
            "request_complete_cells": sum(r["api_ok"] == r["expected"] for r in grid),
            "fully_usable_cells": sum(r["usable"] == r["expected"] for r in grid),
            "total_expected_requests": sum(r["expected"] for r in grid),
            "total_api_ok_requests": sum(r["api_ok"] for r in grid),
            "total_usable_requests": sum(r["usable"] for r in grid),
            "pending_by_reason": dict(collections.Counter(x["reason"] for x in missing)),
            "input_mismatch_count": rejected["input_or_prompt_mismatch"],
            "corrupt_jsonl_lines": rejected["corrupt_jsonl_lines"],
            "not_in_plan_count": rejected["not_in_plan"],
            "dataset_hashes": dataset_hashes,
            "scanned_files": len(inspected),
            "models_from_config": ids}
    (args.out / "coverage_summary.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Expected model×dataset cells:", len(grid),
          "requests finished:", meta["request_complete_cells"],
          "all JSON usable:", meta["fully_usable_cells"])
    print("API ok:", meta["total_api_ok_requests"],
          "JSON usable:", meta["total_usable_requests"], "/", meta["total_expected_requests"])
    print("Pending by reason:", meta["pending_by_reason"])
    print("Input/prompt mismatches excluded:", meta["input_mismatch_count"])
    print("Damaged JSONL lines skipped:", meta["corrupt_jsonl_lines"])
    print("Summary:", args.out / "model_dataset_grid.csv")
    print("Only missing/API failed (no format errors):", args.out / "only_missing_or_api_failed.csv")


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="command", required=True)
    f = sub.add_parser("freeze-tatqa")
    for n in ("project", "data", "results", "sensitivity", "numeric-script", "out"):
        f.add_argument("--" + n, required=True, type=Path)
    f.set_defaults(action=freeze)
    c = sub.add_parser("coverage")
    for n in ("project", "config", "tatqa-data", "tatqa-results", "out"):
        c.add_argument("--" + n, required=True, type=Path)
    c.add_argument("--roots", nargs="+", required=True, type=Path)
    c.set_defaults(action=coverage)
    args = p.parse_args()
    args.action(args)


if __name__ == "__main__":
    main()

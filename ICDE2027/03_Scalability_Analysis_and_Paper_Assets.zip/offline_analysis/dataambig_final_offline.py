#!/usr/bin/env python3
"""Read-only analysis of saved DataAmbigBench predictions. Never calls an API.

Usage: python dataambig_final_offline.py --base DRIVE_PROJECT --project PROJECT
Outputs are written only under BASE/analysis/final_offline_v1 (override with --out).
"""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import importlib.util
import json
import math
import statistics
import sys
from pathlib import Path

DATASETS = ("sec", "ambigdocs", "opinionqa", "retail", "usc", "sf311", "nyc311", "tatqa")
TASKS = ("detection", "condition_given", "e2e", "e2e_open")
METRICS = {
    "detection": ("dimension_f1", "condition_f1_norm"),
    "condition_given": ("answer_relaxed",),
    "e2e": ("answer_relaxed_norm",),
    "e2e_open": ("multi_answer_rate", "gold_answer_recall", "single_answer_correct"),
}


def write_csv(path, rows, columns):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")


def read_jsonl(path):
    with path.open(encoding="utf-8-sig") as source:
        for number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                yield number, json.loads(line)
            except json.JSONDecodeError:
                yield number, None


def load_lab(project):
    target = project / "lab.py"
    if not target.is_file():
        raise FileNotFoundError(f"Missing project lab.py: {target}")
    spec = importlib.util.spec_from_file_location("dataambig_original_lab", target)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def quality(row):
    return (
        row.get("status") == "ok" and isinstance(row.get("parsed"), dict)
        and not row.get("schema_error") and row.get("finish_reason") != "length",
        row.get("status") == "ok",
    )


def median_p95(values):
    if not values:
        return None, None
    ordered = sorted(values)
    return round(statistics.median(ordered), 2), round(ordered[math.ceil(.95 * len(ordered)) - 1], 2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True, help="DataAmbigBench_supplemental on Drive")
    parser.add_argument("--project", type=Path, required=True, help="unzipped DataAmbigBench_multimodel")
    parser.add_argument("--config", type=Path, help="models.json; defaults to PROJECT/models.json")
    parser.add_argument("--tatqa-data", type=Path, help="repaired v3 tatqa.jsonl")
    parser.add_argument("--tatqa-results", type=Path, help="merged v3 GPT-4.1-mini predictions")
    parser.add_argument("--out", type=Path, help="output directory")
    args = parser.parse_args()
    base, project = args.base.resolve(), args.project.resolve()
    out = args.out or base / "analysis" / "final_offline_v1"
    out.mkdir(parents=True, exist_ok=True)
    lab = load_lab(project)
    config_file = args.config or project / "models.json"
    cfg = json.loads(config_file.read_text(encoding="utf-8"))
    cfg = [m for m in cfg if m.get("enabled", True)]
    if len({m["id"] for m in cfg}) != len(cfg):
        raise ValueError("Duplicate model IDs")
    tatqa_data = args.tatqa_data or base / "analysis/tatqa_gold_repair_v3/data/tatqa.jsonl"
    tatqa_results = args.tatqa_results or base / "analysis/tatqa_gold_repair_v3/merged_gpt-4.1-mini_original_prompt/predictions_merged_v3.jsonl"

    expected = {}
    data_hashes = {}
    active_datasets = []
    data_issues = []
    query_duplicates = []
    for ds in DATASETS:
        data_path = tatqa_data if ds == "tatqa" else project / "data" / f"{ds}.jsonl"
        if not data_path.is_file():
            data_issues.append(f"{ds}: missing {data_path}")
            if ds != "tatqa":
                raise FileNotFoundError(data_path)
            continue
        samples = [r for _, r in read_jsonl(data_path)]
        if len(samples) != 200 or any(not isinstance(r, dict) for r in samples):
            raise ValueError(f"{ds} must contain exactly 200 JSON objects: {data_path}")
        if len({r["id"] for r in samples}) != 200:
            raise ValueError(f"{ds}: query IDs are duplicated")
        seen_queries = {}
        for sample in samples:
            normalized = lab.normalized(sample["query"])
            if normalized in seen_queries:
                query_duplicates.append({"dataset": ds, "first_id": seen_queries[normalized],
                                         "second_id": sample["id"], "normalized_query": normalized})
            else:
                seen_queries[normalized] = sample["id"]
        for sample in samples:
            lab.valid_sample(sample)
            table = lab.prompts.safe_get_table(sample)
            if lab.is_answer_table(table):
                raise ValueError(f"Answer lookup leaked in {ds}: {sample['id']}")
        data_hashes[ds] = lab.digest(samples)
        active_datasets.append(ds)
        for model_cfg in cfg:
            model = model_cfg["id"]
            if model_cfg.get("datasets") and ds not in model_cfg["datasets"]:
                continue
            for sample in samples:
                pairs = sample["gold"]["condition_answer_pairs"]
                for task in TASKS:
                    for pair_index in (range(len(pairs)) if task == "condition_given" else [None]):
                        system, prompt, max_tokens = lab.prompt_for(task, sample, pair_index)
                        gold = sample["gold"]["ambiguous_conditions"] if task == "detection" else (
                            pairs[pair_index] if task == "condition_given" else sample["gold"])
                        key = (model, ds, task, sample["id"], pair_index)
                        expected[key] = {
                            "query": sample["query"], "context_hash": lab.digest(sample["table"]),
                            "prompt_hash": lab.digest([system, prompt]), "max_tokens": max_tokens,
                            "gold": gold, "sample": sample,
                        }
    # Search the entire experiment Drive tree. In particular, full TAT-QA runs
    # may be saved under runs/, not under the three model-specific directories.
    # Exact query/context/prompt/gold checks below exclude old and pilot versions.
    source_roots = [base / name for name in ("multimodel_v1", "recovery_v2", "gemini_only", "runs")]
    paths = set(base.rglob("predictions.jsonl"))
    if tatqa_results.is_file():
        paths.add(tatqa_results)
    else:
        data_issues.append(f"tatqa: merged predictions absent: {tatqa_results}")
    if not paths:
        raise ValueError("No prediction files found; check Drive mount and BASE")

    best = {}
    copies = collections.Counter()
    conflicts = collections.Counter()
    rejection_counts = collections.Counter()
    rejected_examples = []
    corrupt = []
    for path in sorted(paths):
        for line_no, row in read_jsonl(path):
            if not isinstance(row, dict):
                corrupt.append({"file": str(path), "line": line_no})
                continue
            key = tuple(row.get(k) for k in ("model", "dataset", "task", "id", "pair_index"))
            want = expected.get(key)
            if want is None:
                rejection_counts["not_in_plan"] += 1
                continue
            mismatch = [field for field in ("query", "context_hash", "prompt_hash", "max_tokens", "gold")
                        if row.get(field) != want[field]]
            if mismatch:
                rejection_counts["input_or_prompt_mismatch"] += 1
                if len(rejected_examples) < 200:
                    rejected_examples.append({"model": key[0], "dataset": key[1], "task": key[2],
                                              "id": key[3], "pair_index": key[4],
                                              "fields": ";".join(mismatch), "file": str(path)})
                continue
            copies[key] += 1
            if key in best:
                old = best[key][0]
                if old.get("parsed") != row.get("parsed") and quality(old)[0] and quality(row)[0]:
                    conflicts[key] += 1
            if key not in best or quality(row) > quality(best[key][0]):
                best[key] = (row, path)

    coverage = collections.defaultdict(collections.Counter)
    metrics = collections.defaultdict(lambda: collections.defaultdict(list))
    times = collections.defaultdict(list)
    total_times = collections.defaultdict(list)
    tokens = collections.defaultdict(collections.Counter)
    flags = collections.Counter()
    pending = []
    failures = []
    rescoring_diffs = []
    selected = []
    open_scores = {}
    for key, want in expected.items():
        model, ds, task, sid, pi = key
        group = (model, ds)
        detail = (model, ds, task)
        c = coverage[detail]
        c["expected"] += 1
        if key not in best:
            reason = "missing_matching_version"
            c[reason] += 1
            pending.append({"model": model, "dataset": ds, "task": task, "id": sid,
                            "pair_index": pi, "reason": reason})
            continue
        row, path = best[key]
        c["recorded"] += 1
        reason = ""
        if row.get("status") != "ok":
            reason = "api_failed"
        elif not isinstance(row.get("parsed"), dict) or row.get("schema_error"):
            reason = "invalid_json_or_schema"
        elif row.get("finish_reason") == "length":
            reason = "truncated"
        try:
            scores = lab.score(task, want["sample"], row.get("parsed"), ds,
                               want["gold"] if task == "condition_given" else None)
        except (TypeError, AttributeError, KeyError, ValueError) as exc:
            reason = "invalid_json_or_schema" if not reason else reason
            scores = lab.score(task, want["sample"], None, ds,
                               want["gold"] if task == "condition_given" else None)
            flags["scoring_exception:" + type(exc).__name__] += 1
        if row.get("status") == "ok":
            c["api_ok"] += 1
        if not reason:
            c["usable"] += 1
        else:
            c[reason] += 1
            pending.append({"model": model, "dataset": ds, "task": task, "id": sid,
                            "pair_index": pi, "reason": reason})
        if isinstance(row.get("scores"), dict):
            for metric in METRICS[task]:
                old = row["scores"].get(metric)
                if isinstance(old, (int, float)) and not math.isclose(old, scores[metric], abs_tol=1e-8):
                    rescoring_diffs.append({"model": model, "dataset": ds, "task": task,
                                            "id": sid, "pair_index": pi, "metric": metric,
                                            "saved": old, "recomputed": scores[metric]})
        for metric in METRICS[task]:
            metrics[detail][metric].append(scores[metric])
        if isinstance(row.get("elapsed_ms"), (int, float)) and row.get("status") == "ok":
            times[detail].append(row["elapsed_ms"])
        if isinstance(row.get("total_elapsed_ms"), (int, float)):
            total_times[detail].append(row["total_elapsed_ms"])
        for field in ("prompt_tokens", "completion_tokens", "total_tokens"):
            if isinstance((row.get("usage") or {}).get(field), int):
                tokens[detail][field] += row["usage"][field]
                tokens[detail][field + "_n"] += 1
        for flag in lab.failure_flags(row, scores):
            flags[(model, ds, task, flag)] += 1
            failures.append({"model": model, "dataset": ds, "task": task,
                             "id": sid, "pair_index": pi, "flag": flag,
                             "query": want["query"], "gold": want["gold"],
                             "parsed": row.get("parsed"), "scores": scores,
                             "source": str(path)})
        if reason and not lab.failure_flags(row, scores):
            failures.append({"model": model, "dataset": ds, "task": task,
                             "id": sid, "pair_index": pi, "flag": reason,
                             "query": want["query"], "gold": want["gold"],
                             "parsed": row.get("parsed"), "scores": scores,
                             "source": str(path)})
        selected.append({"model": model, "dataset": ds, "task": task, "id": sid,
                         "pair_index": pi, "source": str(path), "reason": reason,
                         "duplicate_copies": copies[key], "conflicting_usable_copies": conflicts[key],
                         "scores": scores})
        if task in ("e2e", "e2e_open"):
            # Apply exactly the same open scorer to both settings for the ablation.
            open_scores[(model, ds, sid, task)] = lab.open_eval.score_open(
                want["sample"], row.get("parsed"), ds)

    coverage_rows = []
    grid = collections.defaultdict(collections.Counter)
    metric_rows = []
    for (model, ds, task), c in sorted(coverage.items()):
        d = (model, ds, task)
        g = grid[(model, ds)]
        for name in ("expected", "recorded", "api_ok", "usable", "api_failed",
                     "invalid_json_or_schema", "truncated", "missing_matching_version"):
            g[name] += c[name]
        state = "request_complete" if c["api_ok"] == c["expected"] else "missing_or_failed"
        coverage_rows.append({"model": model, "dataset": ds, "task": task, **{k: c[k] for k in (
            "expected", "recorded", "api_ok", "usable", "api_failed", "invalid_json_or_schema",
            "truncated", "missing_matching_version")}, "state": state})
        p50, p95 = median_p95(times[d])
        t50, t95 = median_p95(total_times[d])
        values = metrics[d]
        result = {m + "_pct": round(100 * statistics.mean(values[m]), 4)
                  for m in METRICS[task] if values[m]}
        metric_rows.append({"model": model, "dataset": ds, "task": task,
                            "expected": c["expected"], "scored": len(values[METRICS[task][0]]),
                            "paper_ready": c["api_ok"] == c["expected"] and
                                           c["recorded"] == c["expected"],
                            "valid_output": c["usable"], **result,
                            "latency_n": len(times[d]), "request_p50_ms": p50, "request_p95_ms": p95,
                            "job_p50_ms": t50, "job_p95_ms": t95,
                            **{k: tokens[d][k] for k in ("prompt_tokens", "completion_tokens", "total_tokens")},
                            "usage_complete": tokens[d]["prompt_tokens_n"] == c["expected"] and
                                              tokens[d]["completion_tokens_n"] == c["expected"]})
    grid_rows = []
    for (model, ds), c in sorted(grid.items()):
        grid_rows.append({"model": model, "dataset": ds, **{k: c[k] for k in (
            "expected", "recorded", "api_ok", "usable", "api_failed", "invalid_json_or_schema",
            "truncated", "missing_matching_version")},
                          "paper_ready": c["api_ok"] == c["expected"] and
                                         c["recorded"] == c["expected"],
                          "clean_json": c["usable"] == c["expected"]})
    ablation = []
    for (model, ds, sid, task), a in sorted(open_scores.items()):
        if task != "e2e":
            continue
        b = open_scores.get((model, ds, sid, "e2e_open"))
        if b is None:
            continue
        ablation.append({"model": model, "dataset": ds, "id": sid,
                         "hinted_recall": a["gold_answer_recall"],
                         "open_recall": b["gold_answer_recall"],
                         "open_minus_hinted_recall_pp": round(100 * (
                             b["gold_answer_recall"] - a["gold_answer_recall"]), 4),
                         "hinted_multi": a["multi_answer_rate"],
                         "open_multi": b["multi_answer_rate"]})
    ablation_summary = []
    by_ablation = collections.defaultdict(list)
    for row in ablation:
        by_ablation[(row["model"], row["dataset"])].append(row)
    for (model, ds), rows in sorted(by_ablation.items()):
        ablation_summary.append({"model": model, "dataset": ds, "matched_queries": len(rows),
                                 "open_minus_hinted_recall_pp": round(statistics.mean(
                                     x["open_minus_hinted_recall_pp"] for x in rows), 4),
                                 "hinted_multi_pct": round(100 * statistics.mean(
                                     x["hinted_multi"] for x in rows), 4),
                                 "open_multi_pct": round(100 * statistics.mean(
                                     x["open_multi"] for x in rows), 4),
                                 "full_200": len(rows) == 200})

    # Scalability: report observed table sizes only. No fabricated 1k/5k/20k values.
    scale_rows = []
    scale_files = set()
    for root in source_roots:
        if root.is_dir():
            scale_files.update(root.rglob("predictions.jsonl"))
    scale = collections.defaultdict(lambda: {"n": 0, "latency": []})
    for path in scale_files:
        for _, row in read_jsonl(path):
            if not isinstance(row, dict):
                continue
            size = row.get("table_rows")
            if isinstance(size, int) and size > 0 and row.get("task") in TASKS:
                k = (row.get("model"), row.get("dataset"), row["task"], size, str(path))
                scale[k]["n"] += 1
                if isinstance(row.get("elapsed_ms"), (int, float)):
                    scale[k]["latency"].append(row["elapsed_ms"])
    for (model, ds, task, size, path), x in sorted(scale.items(), key=lambda v: str(v[0])):
        p50, p95 = median_p95(x["latency"])
        scale_rows.append({"model": model, "dataset": ds, "task": task,
                           "table_rows": size, "records": x["n"], "latency_n": len(x["latency"]),
                           "p50_ms": p50, "p95_ms": p95, "source": path,
                           "note": "observed only; confirm workload and version before paper use"})

    # Throughput is a batch property; do not infer it by summing concurrent latencies.
    batch_rows = []
    for root in source_roots:
        if not root.is_dir():
            continue
        for path in root.rglob("batch_timing.jsonl"):
            for line_no, row in read_jsonl(path):
                if isinstance(row, dict):
                    batch_rows.append({"file": str(path), "line": line_no,
                                       "jobs": row.get("jobs"), "wall_seconds": row.get("wall_seconds"),
                                       "jobs_per_second": row.get("jobs_per_second"),
                                       "note": "observed batch; confirm model, query set, and concurrency"})

    write_csv(out / "model_dataset_grid.csv", grid_rows, list(grid_rows[0]))
    write_csv(out / "task_coverage.csv", coverage_rows, list(coverage_rows[0]))
    metric_cols = list(dict.fromkeys(k for row in metric_rows for k in row))
    write_csv(out / "paper_metrics.csv", metric_rows, metric_cols)
    write_csv(out / "pending_requests.csv", pending,
              ["model", "dataset", "task", "id", "pair_index", "reason"])
    write_csv(out / "version_mismatches.csv", rejected_examples,
              ["model", "dataset", "task", "id", "pair_index", "fields", "file"])
    write_csv(out / "rescoring_differences.csv", rescoring_diffs,
              ["model", "dataset", "task", "id", "pair_index", "metric", "saved", "recomputed"])
    write_csv(out / "ablation.csv", ablation_summary,
              ["model", "dataset", "matched_queries", "open_minus_hinted_recall_pp",
               "hinted_multi_pct", "open_multi_pct", "full_200"])
    write_csv(out / "scale_observed.csv", scale_rows,
              ["model", "dataset", "task", "table_rows", "records", "latency_n", "p50_ms",
               "p95_ms", "source", "note"])
    write_csv(out / "batch_timing_observed.csv", batch_rows,
              ["file", "line", "jobs", "wall_seconds", "jobs_per_second", "note"])
    write_csv(out / "duplicate_queries.csv", query_duplicates,
              ["dataset", "first_id", "second_id", "normalized_query"])
    write_csv(out / "selected_provenance.csv", selected,
              ["model", "dataset", "task", "id", "pair_index", "source", "reason",
               "duplicate_copies", "conflicting_usable_copies", "scores"])
    with (out / "failure_candidates.jsonl").open("w", encoding="utf-8") as fh:
        for row in failures:
            fh.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    summary = {
        "data_sha256": data_hashes, "planned_cells": len(grid_rows),
        "paper_ready_cells": sum(x["paper_ready"] for x in grid_rows),
        "clean_json_cells": sum(x["clean_json"] for x in grid_rows),
        "expected_requests": len(expected), "matched_requests": len(best),
        "status_ok_requests": sum(x["api_ok"] for x in grid_rows),
        "usable_requests": sum(x["usable"] for x in grid_rows),
        "pending_reasons": dict(collections.Counter(x["reason"] for x in pending)),
        "rejected": dict(rejection_counts), "corrupt_jsonl_lines": corrupt[:30],
        "conflicting_duplicate_keys": sum(bool(n) for n in conflicts.values()),
        "saved_score_differences": len(rescoring_diffs), "data_issues": data_issues,
        "normalized_query_duplicates": len(query_duplicates),
        "scalability": "observed_only" if scale_rows else "no_scale_run_found",
        "observed_batch_timing_rows": len(batch_rows),
        "source_files": len(paths), "output_dir": str(out),
        "caveat": "paper_ready means all API calls succeeded with matching input/prompt;"
                  " review invalid JSON, gold, and manual failure cases separately",
    }
    write_json(out / "summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("\nMAIN TABLE:", out / "paper_metrics.csv")
    print("COVERAGE:", out / "model_dataset_grid.csv")
    print("PENDING:", out / "pending_requests.csv")
    print("ABLATION:", out / "ablation.csv")
    print("SCALE:", out / "scale_observed.csv")
    print("FAILURES:", out / "failure_candidates.jsonl")


if __name__ == "__main__":
    main()
